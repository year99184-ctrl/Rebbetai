import { app } from "./firebase.js?v=1.10.0";
import {
  get,
  getDatabase,
  onValue,
  ref,
  remove,
  serverTimestamp,
  set
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-database.js";

const db = getDatabase(app);
const statusRef = ref(db, "appStatus");
const usersRef = ref(db, "users");
const bansRef = ref(db, "bans");
const APP_VERSION = document.querySelector('meta[name="app-version"]')?.content || "1.10.0";
const DEFAULT_UPDATE_MESSAGE = "A newer version of Rebbet AI is available.";
const DEFAULT_MAINTENANCE_MESSAGE = "Rebbet AI is under maintenance. Please check back shortly.";

const panelStatus = document.getElementById("panelStatus");
const liveStatus = document.getElementById("liveStatus");
const liveBadge = document.getElementById("liveBadge");
const liveMaintenance = document.getElementById("liveMaintenance");
const liveVersion = document.getElementById("liveVersion");
const liveUpdate = document.getElementById("liveUpdate");
const liveUpdated = document.getElementById("liveUpdated");
const statusForm = document.getElementById("statusForm");
const latestVersion = document.getElementById("latestVersion");
const publisher = document.getElementById("publisher");
const updateUrl = document.getElementById("updateUrl");
const updateMessage = document.getElementById("updateMessage");
const updateAvailable = document.getElementById("updateAvailable");
const forceUpdate = document.getElementById("forceUpdate");
const maintenance = document.getElementById("maintenance");
const maintenanceMessage = document.getElementById("maintenanceMessage");
const appVersion = document.getElementById("appVersion");
const userCount = document.getElementById("userCount");
const userSearch = document.getElementById("userSearch");
const banReason = document.getElementById("banReason");
const userList = document.getElementById("userList");
const userStatus = document.getElementById("userStatus");

let currentStatus = null;
let formDirty = false;
let users = {};
let bans = {};

appVersion.textContent = APP_VERSION;

function truthy(value) {
  return value === true || value === "true" || value === 1 || value === "1";
}

function versionParts(value) {
  return String(value || "")
    .trim()
    .replace(/^v/i, "")
    .split(/[.+-]/)
    .map(function(part) {
      const match = String(part).match(/\d+/);
      return match ? Number(match[0]) : 0;
    });
}

function compareVersions(left, right) {
  const a = versionParts(left);
  const b = versionParts(right);
  const length = Math.max(a.length, b.length);
  for (let index = 0; index < length; index++) {
    const av = a[index] || 0;
    const bv = b[index] || 0;
    if (av > bv) return 1;
    if (av < bv) return -1;
  }
  return 0;
}

function setMessage(node, message, isError) {
  node.textContent = message || "";
  node.classList.toggle("is-error", !!isError);
}

function formatTime(value) {
  const time = Number(value);
  if (!Number.isFinite(time) || time <= 0) return "—";
  try {
    return new Intl.DateTimeFormat(undefined, {
      dateStyle: "medium",
      timeStyle: "short"
    }).format(new Date(time));
  } catch (error) {
    return new Date(time).toLocaleString();
  }
}

function statusData() {
  return currentStatus && typeof currentStatus === "object" ? currentStatus : {};
}

function isValidUserId(value) {
  return /^[A-Za-z0-9_-]{6,80}$/.test(String(value || "").trim());
}

function isBanned(id) {
  const value = bans[id];
  if (value === true || value === 1 || value === "1" || value === "true") return true;
  if (value && typeof value === "object") return value.banned !== false;
  if (typeof value === "string" && value.length > 0 && value !== "false") return true;
  return false;
}

function buildUserRow(entry) {
  const row = document.createElement("article");
  row.className = "admin__user";

  const head = document.createElement("div");
  head.className = "admin__user-head";
  const idEl = document.createElement("code");
  idEl.className = "admin__user-id";
  idEl.textContent = entry.id;
  const state = document.createElement("span");
  state.className = "admin__user-state" + (entry.banned ? " is-banned" : "");
  state.textContent = entry.banned ? "Banned" : "Active";
  head.appendChild(idEl);
  head.appendChild(state);

  const meta = document.createElement("div");
  meta.className = "admin__user-meta";
  meta.textContent = [
    "Last seen: " + (entry.lastSeen ? formatTime(entry.lastSeen) : "—"),
    "App: v" + (entry.data.appVersion || "?"),
    entry.data.platform || "",
    entry.data.language || ""
  ].filter(Boolean).join(" · ");

  row.appendChild(head);
  row.appendChild(meta);

  const ban = bans[entry.id];
  if (entry.banned && ban && typeof ban === "object" && ban.reason) {
    const reason = document.createElement("div");
    reason.className = "admin__user-reason";
    reason.textContent = "Reason: " + ban.reason;
    row.appendChild(reason);
  }

  const actions = document.createElement("div");
  actions.className = "admin__user-actions";
  const button = document.createElement("button");
  button.type = "button";
  button.className = "admin__button " +
    (entry.banned ? "admin__button--ghost" : "admin__button--danger");
  button.dataset.action = entry.banned ? "unban" : "ban";
  button.dataset.id = entry.id;
  button.textContent = entry.banned ? "Unban" : "Ban";
  actions.appendChild(button);
  row.appendChild(actions);

  return row;
}

function renderUsers() {
  const filter = userSearch.value.trim().toLowerCase();
  const all = Object.keys(users);
  const bannedTotal = all.filter(isBanned).length;
  userCount.textContent = all.length + (all.length === 1 ? " user" : " users") +
    " · " + bannedTotal + " banned";

  const entries = all.map(function(id) {
    const data = users[id] && typeof users[id] === "object" ? users[id] : {};
    return {
      id: id,
      data: data,
      banned: isBanned(id),
      lastSeen: Number(data.lastSeen) || 0
    };
  }).filter(function(entry) {
    return !filter || entry.id.toLowerCase().indexOf(filter) !== -1;
  }).sort(function(a, b) {
    return b.lastSeen - a.lastSeen || a.id.localeCompare(b.id);
  });

  userList.textContent = "";
  if (!entries.length) {
    const empty = document.createElement("p");
    empty.className = "admin__empty";
    empty.textContent = filter
      ? "No user matches that search."
      : "No users have opened the app yet.";
    userList.appendChild(empty);
    return;
  }

  entries.slice(0, 200).forEach(function(entry) {
    userList.appendChild(buildUserRow(entry));
  });
  if (entries.length > 200) {
    const note = document.createElement("p");
    note.className = "admin__empty";
    note.textContent = "Showing the 200 most recent of " + entries.length + " users.";
    userList.appendChild(note);
  }
}

async function banUser(id, reasonOverride) {
  id = String(id || "").trim();
  if (!isValidUserId(id)) {
    setMessage(userStatus, "Enter a valid user ID (letters, numbers, _ or -).", true);
    return;
  }
  const reason = reasonOverride !== undefined ? reasonOverride : banReason.value.trim();
  setMessage(userStatus, "Banning " + id + "…");
  try {
    await set(ref(db, "bans/" + id), {
      banned: true,
      reason: reason || "",
      at: serverTimestamp(),
      by: publisher.value.trim() || "admin"
    });
    setMessage(userStatus, "Banned " + id + ". The app blocks them immediately.");
  } catch (error) {
    setMessage(
      userStatus,
      "Ban failed: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
}

async function unbanUser(id) {
  id = String(id || "").trim();
  if (!isValidUserId(id)) {
    setMessage(userStatus, "Enter a valid user ID (letters, numbers, _ or -).", true);
    return;
  }
  setMessage(userStatus, "Unbanning " + id + "…");
  try {
    await remove(ref(db, "bans/" + id));
    setMessage(userStatus, "Unbanned " + id + ".");
  } catch (error) {
    setMessage(
      userStatus,
      "Unban failed: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
}

function renderLive(status) {
  const data = status && typeof status === "object" ? status : {};
  const maintenanceOn = truthy(data.maintenance);
  const publishedVersion = String(data.latestVersion || "").trim();
  const hasUpdate = truthy(data.updateAvailable) ||
    (!!publishedVersion && compareVersions(publishedVersion, APP_VERSION) > 0);

  liveBadge.textContent = maintenanceOn ? "Maintenance ON" : "Live";
  liveBadge.classList.toggle("is-maintenance", maintenanceOn);
  liveMaintenance.textContent = maintenanceOn
    ? "On — the app is blocked for everyone"
    : "Off — the app is available";
  liveVersion.textContent = publishedVersion || "—";
  liveUpdate.textContent = hasUpdate
    ? "Shown — clients will see the update notice"
    : "Hidden — app is up to date (v" + APP_VERSION + ")";
  liveUpdate.classList.toggle("is-active", hasUpdate);
  liveUpdated.textContent = data.updatedAt ? formatTime(data.updatedAt) : "—";
}

function fillForm(status) {
  const data = status && typeof status === "object" ? status : {};
  latestVersion.value = data.latestVersion || APP_VERSION;
  publisher.value = data.updatedBy || "admin";
  updateUrl.value = data.updateUrl || "";
  updateMessage.value = data.updateMessage || DEFAULT_UPDATE_MESSAGE;
  updateAvailable.checked = truthy(data.updateAvailable);
  forceUpdate.checked = truthy(data.forceUpdate);
  maintenance.checked = truthy(data.maintenance);
  maintenanceMessage.value = data.maintenanceMessage || DEFAULT_MAINTENANCE_MESSAGE;
  formDirty = false;
}

function collectForm() {
  return {
    latestVersion: latestVersion.value.trim(),
    updateUrl: updateUrl.value.trim(),
    updateMessage: updateMessage.value.trim() || DEFAULT_UPDATE_MESSAGE,
    updateAvailable: updateAvailable.checked,
    forceUpdate: forceUpdate.checked,
    maintenance: maintenance.checked,
    maintenanceMessage: maintenanceMessage.value.trim() || DEFAULT_MAINTENANCE_MESSAGE,
    updatedBy: publisher.value.trim() || "admin"
  };
}

async function writeStatus(payload) {
  await set(statusRef, {
    latestVersion: payload.latestVersion,
    updateUrl: payload.updateUrl || "",
    updateMessage: payload.updateMessage || DEFAULT_UPDATE_MESSAGE,
    updateAvailable: !!payload.updateAvailable,
    forceUpdate: !!payload.forceUpdate,
    maintenance: !!payload.maintenance,
    maintenanceMessage: payload.maintenanceMessage || DEFAULT_MAINTENANCE_MESSAGE,
    updatedAt: serverTimestamp(),
    updatedBy: payload.updatedBy || "admin"
  });
}

async function publishStatus(event) {
  event.preventDefault();
  const payload = collectForm();
  if (!payload.latestVersion) {
    setMessage(panelStatus, "Latest version is required.", true);
    latestVersion.focus();
    return;
  }
  setMessage(panelStatus, "Publishing…");
  try {
    await writeStatus(payload);
    formDirty = false;
    setMessage(
      panelStatus,
      "Published. Rebbet AI clients will update live. " +
      (payload.maintenance ? "Maintenance mode is ON." : "Maintenance mode is OFF.")
    );
  } catch (error) {
    setMessage(
      panelStatus,
      "Publish failed: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
}

async function quickUpdate(changes, successMessage) {
  const payload = Object.assign({}, statusData(), changes);
  if (!payload.latestVersion) payload.latestVersion = APP_VERSION;
  if (!payload.updateMessage) payload.updateMessage = DEFAULT_UPDATE_MESSAGE;
  if (!payload.maintenanceMessage) payload.maintenanceMessage = DEFAULT_MAINTENANCE_MESSAGE;
  payload.updatedBy = publisher.value.trim() || "admin";
  setMessage(liveStatus, "Publishing…");
  try {
    await writeStatus(payload);
    setMessage(liveStatus, successMessage);
  } catch (error) {
    setMessage(
      liveStatus,
      "Update failed: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
}

async function loadStatus() {
  setMessage(panelStatus, "Loading current status…");
  try {
    const snapshot = await get(statusRef);
    const data = snapshot.val();
    currentStatus = data || {};
    renderLive(currentStatus);
    if (!formDirty) fillForm(currentStatus);
    setMessage(
      panelStatus,
      data && data.updatedBy
        ? "Loaded. Last published by " + data.updatedBy + "."
        : "Current status loaded."
    );
  } catch (error) {
    setMessage(
      panelStatus,
      "Could not read /appStatus: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
}

statusForm.addEventListener("input", function() {
  formDirty = true;
});
statusForm.addEventListener("change", function() {
  formDirty = true;
});
statusForm.addEventListener("submit", publishStatus);
document.getElementById("reloadStatus").addEventListener("click", loadStatus);

document.getElementById("quickMaintenanceOn").addEventListener("click", function() {
  quickUpdate(
    { maintenance: true },
    "Maintenance mode is ON. Clients are blocked immediately."
  );
});

document.getElementById("quickMaintenanceOff").addEventListener("click", function() {
  quickUpdate(
    { maintenance: false },
    "Maintenance mode is OFF. Clients can use the app again."
  );
});

document.getElementById("quickClearUpdate").addEventListener("click", function() {
  quickUpdate(
    { latestVersion: APP_VERSION, updateAvailable: false, forceUpdate: false },
    "Update notice cleared. Clients will not be asked to update."
  );
});

onValue(
  statusRef,
  function(snapshot) {
    currentStatus = snapshot.val() || {};
    renderLive(currentStatus);
    if (!formDirty) fillForm(currentStatus);
  },
  function(error) {
    liveBadge.textContent = "Offline";
    liveBadge.classList.add("is-maintenance");
    setMessage(
      liveStatus,
      "Live status unavailable: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
);

userSearch.addEventListener("input", renderUsers);

userList.addEventListener("click", function(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  if (button.dataset.action === "ban") {
    banUser(button.dataset.id);
  } else {
    unbanUser(button.dataset.id);
  }
});

document.getElementById("banById").addEventListener("click", function() {
  banUser(userSearch.value.trim());
});

document.getElementById("unbanById").addEventListener("click", function() {
  unbanUser(userSearch.value.trim());
});

onValue(
  usersRef,
  function(snapshot) {
    users = snapshot.val() || {};
    renderUsers();
  },
  function(error) {
    userCount.textContent = "Offline";
    setMessage(
      userStatus,
      "Users unavailable: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
);

onValue(
  bansRef,
  function(snapshot) {
    bans = snapshot.val() || {};
    renderUsers();
  },
  function(error) {
    setMessage(
      userStatus,
      "Ban list unavailable: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
);

renderUsers();


/* ---- Server, branding, releases and shared files ---- */

const SERVER_KEY = "rebbet.admin.server.v1";
const TOKEN_KEY = "rebbet.admin.token.v1";

const serverUrlInput = document.getElementById("serverUrl");
const adminTokenInput = document.getElementById("adminToken");
const serverBadge = document.getElementById("serverBadge");
const serverStatus = document.getElementById("serverStatus");
const serverVersion = document.getElementById("serverVersion");
const serverMaxUpload = document.getElementById("serverMaxUpload");
const serverUpdateUrl = document.getElementById("serverUpdateUrl");
const serverUpdateMessage = document.getElementById("serverUpdateMessage");
const serverUpdateAvailable = document.getElementById("serverUpdateAvailable");
const serverForceUpdate = document.getElementById("serverForceUpdate");
const serverIconPreview = document.getElementById("serverIconPreview");
const serverIconInput = document.getElementById("serverIconInput");
const serverApkInput = document.getElementById("serverApkInput");
const serverSettingsStatus = document.getElementById("serverSettingsStatus");
const sharedFilesList = document.getElementById("sharedFiles");
const filesStatus = document.getElementById("filesStatus");
const serverIconGallery = document.getElementById("serverIconGallery");
const configBadge = document.getElementById("configBadge");
const configStatus = document.getElementById("configStatus");
const editorCard = document.getElementById("editorCard");
const editorFileSelect = document.getElementById("editorFile");
const editorPathInput = document.getElementById("editorPath");
const editorContentInput = document.getElementById("editorContent");
const editorStatus = document.getElementById("editorStatus");

const configFields = {
  host: document.getElementById("cfgHost"),
  port: document.getElementById("cfgPort"),
  request_timeout: document.getElementById("cfgRequestTimeout"),
  provider: document.getElementById("cfgProvider"),
  default_model: document.getElementById("cfgDefaultModel"),
  api_key: document.getElementById("cfgApiKey"),
  base_url: document.getElementById("cfgBaseUrl"),
  system_prompt: document.getElementById("cfgSystemPrompt"),
  image_api_key: document.getElementById("cfgImageApiKey"),
  image_model: document.getElementById("cfgImageModel"),
  transcribe_model: document.getElementById("cfgTranscribeModel"),
  pollinations_model: document.getElementById("cfgPollinationsModel"),
  elevenlabs_api_key: document.getElementById("cfgElevenKey"),
  elevenlabs_voice_id: document.getElementById("cfgElevenVoice"),
  elevenlabs_model: document.getElementById("cfgElevenModel"),
  voice_speed: document.getElementById("cfgVoiceSpeed"),
  deepseek_api_key: document.getElementById("cfgDeepseekKey"),
  deepseek_model: document.getElementById("cfgDeepseekModel"),
  openrouter_api_key: document.getElementById("cfgOpenrouterKey"),
  openrouter_model: document.getElementById("cfgOpenrouterModel"),
  github_api_key: document.getElementById("cfgGithubKey"),
  github_model: document.getElementById("cfgGithubModel"),
  github_base_url: document.getElementById("cfgGithubBase"),
  cheatgpt_api_key: document.getElementById("cfgCheatgptKey"),
  cheatgpt_model: document.getElementById("cfgCheatgptModel"),
  cheatgpt_base_url: document.getElementById("cfgCheatgptBase"),
  admin_token: document.getElementById("cfgAdminToken"),
  public_base_url: document.getElementById("cfgPublicBaseUrl"),
  app_link_scheme: document.getElementById("cfgAppScheme"),
  app_package: document.getElementById("cfgAppPackage"),
  app_download_url: document.getElementById("cfgAppDownloadUrl")
};

const configBoolFields = {
  enable_web_search: document.getElementById("cfgWebSearch"),
  auto_switch_model: document.getElementById("cfgAutoSwitch"),
  enable_free_fallback: document.getElementById("cfgFreeFallback")
};

let serverSettings = null;
let sharedFiles = [];

function isAssetHost() {
  return location.hostname === "appassets.androidplatform.net";
}

function defaultServerUrl() {
  if (!isAssetHost() && /^https?:$/.test(location.protocol)) {
    return location.origin;
  }
  return "http://127.0.0.1:8917";
}

function normalizeServerUrl(value) {
  let url = String(value || "").trim();
  if (!url) return "";
  if (!/^https?:\/\//i.test(url)) url = "http://" + url;
  return url.replace(/\/+$/, "");
}

function serverBase() {
  return normalizeServerUrl(serverUrlInput ? serverUrlInput.value : "");
}

function serverToken() {
  return adminTokenInput ? adminTokenInput.value.trim() : "";
}

function setServerMessage(node, message, isError) {
  if (!node) return;
  node.textContent = message || "";
  node.classList.toggle("is-error", !!isError);
}

function setServerBadge(text, isConnected) {
  if (!serverBadge) return;
  serverBadge.textContent = text;
  serverBadge.classList.toggle("is-maintenance", !isConnected);
}

function absoluteServerUrl(path) {
  if (!path) return "";
  if (/^https?:\/\//i.test(path)) return path;
  return serverBase() + path;
}

async function serverRequest(path, options) {
  const base = serverBase();
  if (!base) throw new Error("Enter your server URL first.");
  const opts = Object.assign({}, options || {});
  const headers = new Headers(opts.headers || {});
  const token = serverToken();
  if (token) {
    headers.set("X-Admin-Token", token);
    headers.set("Authorization", "Bearer " + token);
  }
  if (opts.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  opts.headers = headers;
  opts.cache = "no-store";
  const response = await fetch(base + path, opts);
  let payload = null;
  try { payload = await response.json(); } catch (error) {}
  if (!response.ok) {
    const message = payload && payload.error && payload.error.message
      ? payload.error.message
      : "Server returned " + response.status;
    const failure = new Error(message);
    failure.status = response.status;
    failure.payload = payload;
    throw failure;
  }
  return payload || {};
}

function readFileAsDataUrl(file) {
  return new Promise(function(resolve, reject) {
    const reader = new FileReader();
    reader.onload = function() { resolve(String(reader.result || "")); };
    reader.onerror = function() { reject(reader.error || new Error("Could not read file")); };
    reader.readAsDataURL(file);
  });
}

function formatBytes(value) {
  const size = Number(value) || 0;
  if (size < 1024) return size + " B";
  if (size < 1024 * 1024) return (size / 1024).toFixed(1) + " KB";
  if (size < 1024 * 1024 * 1024) return (size / (1024 * 1024)).toFixed(1) + " MB";
  return (size / (1024 * 1024 * 1024)).toFixed(1) + " GB";
}

function fillConfigFields(settings) {
  const config = settings.config || {};
  Object.keys(configFields).forEach(function(key) {
    const field = configFields[key];
    if (!field) return;
    const value = config[key];
    field.value = value === undefined || value === null ? "" : String(value);
  });
  Object.keys(configBoolFields).forEach(function(key) {
    const field = configBoolFields[key];
    if (field) field.checked = !!config[key];
  });
  if (configBadge) {
    configBadge.textContent = "Connected · " + (config.provider || "gemini");
    configBadge.classList.remove("is-maintenance");
  }
}

function iconImageUrl(icon) {
  const path = icon.rawUrl || icon.url || "";
  const url = absoluteServerUrl(path);
  if (!url) return "";
  return url + (url.indexOf("?") === -1 ? "?v=" + (icon.created || Date.now()) : "");
}

function renderIconGallery(icons) {
  if (!serverIconGallery) return;
  serverIconGallery.textContent = "";
  const list = Array.isArray(icons) ? icons : [];
  if (!list.length) {
    const empty = document.createElement("p");
    empty.className = "admin__empty";
    empty.textContent = "No custom icons yet. Add one above.";
    serverIconGallery.appendChild(empty);
    return;
  }
  list.forEach(function(icon) {
    const tile = document.createElement("article");
    tile.className = "admin__icon-tile" + (icon.active ? " is-active" : "");

    const img = document.createElement("img");
    img.src = iconImageUrl(icon);
    img.alt = icon.name || "App icon";
    img.loading = "lazy";
    tile.appendChild(img);

    if (icon.active) {
      const badge = document.createElement("span");
      badge.className = "admin__icon-tile-badge";
      badge.textContent = "Active";
      tile.appendChild(badge);
    }

    const name = document.createElement("div");
    name.className = "admin__icon-tile-name";
    name.textContent = icon.name || "Icon";
    name.title = (icon.name || "Icon") + " · " + formatBytes(icon.size);
    tile.appendChild(name);

    const actions = document.createElement("div");
    actions.className = "admin__icon-tile-actions";

    if (!icon.active) {
      const use = document.createElement("button");
      use.type = "button";
      use.className = "is-primary";
      use.textContent = "Use";
      use.addEventListener("click", function() { activateServerIcon(icon.id); });
      actions.appendChild(use);
    }

    const del = document.createElement("button");
    del.type = "button";
    del.className = "is-danger";
    del.textContent = "Delete";
    del.addEventListener("click", function() { deleteServerIcon(icon); });
    actions.appendChild(del);

    tile.appendChild(actions);
    serverIconGallery.appendChild(tile);
  });
}

function fillServerSettings(settings) {
  serverSettings = settings || {};
  serverVersion.value = serverSettings.version || APP_VERSION;
  serverMaxUpload.value = serverSettings.max_upload_mb || 25;
  serverUpdateUrl.value = serverSettings.update_url ? absoluteServerUrl(serverSettings.update_url) : "";
  serverUpdateMessage.value = serverSettings.update_message || "";
  serverUpdateAvailable.checked = !!serverSettings.update_available;
  serverForceUpdate.checked = !!serverSettings.force_update;
  const icon = serverSettings.icon ? absoluteServerUrl(serverSettings.icon) : "static/icon-192.png";
  serverIconPreview.src = icon + (icon.indexOf("?") === -1 ? "?v=" + Date.now() : "");
  fillConfigFields(serverSettings);
  renderIconGallery(serverSettings.icons);
  setServerBadge("Connected · v" + (serverSettings.version || APP_VERSION), true);
}

async function loadServerSettings(showErrors) {
  if (!serverBase()) return;
  setServerMessage(serverStatus, "Connecting to " + serverBase() + "…");
  try {
    const payload = await serverRequest("/api/admin/settings");
    fillServerSettings(payload.settings || {});
    if (showErrors !== false) setServerMessage(serverStatus, "Connected. Settings loaded.");
    loadSharedFiles();
    if (editorCard) loadEditorFiles();
  } catch (error) {
    setServerBadge("Not connected", false);
    if (error.status === 401) {
      if (adminTokenInput) {
        adminTokenInput.focus();
        adminTokenInput.select();
        if (adminTokenInput.scrollIntoView) {
          adminTokenInput.scrollIntoView({ block: "center", behavior: "smooth" });
        }
      }
      const info = error.payload && error.payload.error ? error.payload.error : {};
      const detail = info.token_received
        ? "The token reached the server but does not match config.json. Restart the server if you changed config.json recently."
        : "No admin token reached the server. Check that the field above is filled in.";
      setServerMessage(
        serverStatus,
        "Admin token rejected by " + serverBase() + ". " + detail + " Paste the admin_token from config.json, then tap Connect.",
        true
      );
      return;
    }
    setServerMessage(serverStatus, "Could not connect: " + (error.message || "network error"), true);
  }
}

async function saveServerSettings() {
  if (!serverBase()) {
    setServerMessage(serverSettingsStatus, "Enter your server URL first.", true);
    return;
  }
  const payload = {
    app_version: serverVersion.value.trim(),
    max_upload_mb: Number(serverMaxUpload.value) || 25,
    update_url: serverUpdateUrl.value.trim(),
    update_message: serverUpdateMessage.value.trim(),
    update_available: serverUpdateAvailable.checked,
    force_update: serverForceUpdate.checked
  };
  Object.keys(configFields).forEach(function(key) {
    const field = configFields[key];
    if (!field) return;
    let value = field.value;
    if (field.type === "number") {
      value = Number(value);
      if (!Number.isFinite(value)) return;
    }
    payload[key] = typeof value === "string" ? value.trim() : value;
  });
  Object.keys(configBoolFields).forEach(function(key) {
    const field = configBoolFields[key];
    if (field) payload[key] = field.checked;
  });
  setServerMessage(serverSettingsStatus, "Saving…");
  setServerMessage(configStatus, "Saving configuration…");
  try {
    const result = await serverRequest("/api/admin/settings", {
      method: "POST",
      body: JSON.stringify(payload)
    });
    if (typeof payload.admin_token === "string" && payload.admin_token) {
      adminTokenInput.value = payload.admin_token;
    }
    persistServerFields();
    fillServerSettings(result.settings || {});
    const message = result.restart_required
      ? "Saved. Restart the server to apply the new host or port."
      : "Saved. The app picks up the new settings on next load.";
    setServerMessage(serverSettingsStatus, message);
    setServerMessage(configStatus, message);
  } catch (error) {
    const message = "Save failed: " + (error.message || "network error");
    setServerMessage(serverSettingsStatus, message, true);
    setServerMessage(configStatus, message, true);
  }
}

async function activateServerIcon(id) {
  if (!id) return;
  setServerMessage(serverSettingsStatus, "Applying icon…");
  try {
    const result = await serverRequest("/api/admin/set-icon", {
      method: "POST",
      body: JSON.stringify({ id: id })
    });
    fillServerSettings(result.settings || {});
    setServerMessage(serverSettingsStatus, "Icon applied. Reload the app to see it.");
  } catch (error) {
    setServerMessage(serverSettingsStatus, "Could not apply icon: " + (error.message || "network error"), true);
  }
}

async function deleteServerIcon(icon) {
  if (!icon || !icon.id) return;
  if (!confirm("Delete " + (icon.name || "this icon") + "?\n\nIf it is active, the default icon is restored.")) return;
  setServerMessage(serverSettingsStatus, "Deleting icon…");
  try {
    await serverRequest("/api/admin/delete-file", {
      method: "POST",
      body: JSON.stringify({ id: icon.id })
    });
    await loadServerSettings(false);
    setServerMessage(serverSettingsStatus, "Icon deleted.");
  } catch (error) {
    setServerMessage(serverSettingsStatus, "Could not delete icon: " + (error.message || "network error"), true);
  }
}

function persistServerFields() {
  try {
    localStorage.setItem(SERVER_KEY, serverBase());
    localStorage.setItem(TOKEN_KEY, serverToken());
  } catch (error) {}
}

async function uploadServerIcon() {
  const file = serverIconInput.files && serverIconInput.files[0];
  if (!file) return;
  if (file.size > 4 * 1024 * 1024) {
    setServerMessage(serverSettingsStatus, "Icon must be 4 MB or smaller.", true);
    serverIconInput.value = "";
    return;
  }
  setServerMessage(serverSettingsStatus, "Uploading icon…");
  try {
    const dataUrl = await readFileAsDataUrl(file);
    const result = await serverRequest("/api/admin/upload-icon", {
      method: "POST",
      body: JSON.stringify({ name: file.name, mimeType: file.type || "image/png", data: dataUrl })
    });
    fillServerSettings(result.settings || {});
    setServerMessage(serverSettingsStatus, "Icon added and applied. Reload the app to see it.");
  } catch (error) {
    setServerMessage(serverSettingsStatus, "Icon upload failed: " + (error.message || "network error"), true);
  } finally {
    serverIconInput.value = "";
  }
}

async function uploadServerApk() {
  const file = serverApkInput.files && serverApkInput.files[0];
  if (!file) return;
  if (file.size > 200 * 1024 * 1024) {
    setServerMessage(serverSettingsStatus, "APK must be 200 MB or smaller.", true);
    serverApkInput.value = "";
    return;
  }
  setServerMessage(serverSettingsStatus, "Uploading " + file.name + " (" + formatBytes(file.size) + ")…");
  try {
    const dataUrl = await readFileAsDataUrl(file);
    const result = await serverRequest("/api/admin/upload-update", {
      method: "POST",
      body: JSON.stringify({
        name: file.name,
        mimeType: file.type || "application/vnd.android.package-archive",
        data: dataUrl,
        version: serverVersion.value.trim(),
        update_message: serverUpdateMessage.value.trim()
      })
    });
    fillServerSettings(result.settings || {});
    setServerMessage(serverSettingsStatus, "Update published. Clients now see the update button.");
  } catch (error) {
    setServerMessage(serverSettingsStatus, "Update upload failed: " + (error.message || "network error"), true);
  } finally {
    serverApkInput.value = "";
  }
}

function copyServerLink(url) {
  const full = absoluteServerUrl(url);
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(full).then(function() {
      setServerMessage(filesStatus, "Link copied.");
    }).catch(function() {
      setServerMessage(filesStatus, "Could not copy link.", true);
    });
  } else {
    setServerMessage(filesStatus, "Clipboard is not available.", true);
  }
}

function renderSharedFiles() {
  if (!sharedFilesList) return;
  sharedFilesList.textContent = "";
  if (!sharedFiles.length) {
    const empty = document.createElement("p");
    empty.className = "admin__empty";
    empty.textContent = "No files uploaded yet.";
    sharedFilesList.appendChild(empty);
    return;
  }
  sharedFiles.forEach(function(file) {
    const row = document.createElement("article");
    row.className = "admin__file";

    const thumb = document.createElement("div");
    thumb.className = "admin__file-thumb";
    if (String(file.mimeType || "").indexOf("image/") === 0) {
      const img = document.createElement("img");
      img.src = absoluteServerUrl(file.rawUrl);
      img.alt = "";
      img.loading = "lazy";
      thumb.appendChild(img);
    } else {
      const ext = String(file.name || "FILE").split(".").pop().slice(0, 4).toUpperCase();
      thumb.textContent = ext || "FILE";
    }

    const body = document.createElement("div");
    body.className = "admin__file-body";
    const name = document.createElement("div");
    name.className = "admin__file-name";
    name.textContent = file.name || "Shared file";
    const meta = document.createElement("div");
    meta.className = "admin__file-meta";
    meta.textContent = [
      formatBytes(file.size),
      file.kind === "update" ? "APK update" : (file.kind === "icon" ? "App icon" : "Shared file"),
      file.created ? formatTime(Number(file.created) * 1000) : ""
    ].filter(Boolean).join(" · ");
    body.appendChild(name);
    body.appendChild(meta);

    const actions = document.createElement("div");
    actions.className = "admin__file-actions";

    const open = document.createElement("a");
    open.className = "admin__button admin__button--ghost";
    open.href = absoluteServerUrl(file.url);
    open.target = "_blank";
    open.rel = "noopener";
    open.textContent = "Open";
    actions.appendChild(open);

    const copy = document.createElement("button");
    copy.type = "button";
    copy.className = "admin__button admin__button--ghost";
    copy.textContent = "Copy link";
    copy.addEventListener("click", function() { copyServerLink(file.url); });
    actions.appendChild(copy);

    const del = document.createElement("button");
    del.type = "button";
    del.className = "admin__button admin__button--danger";
    del.textContent = "Delete";
    del.addEventListener("click", async function() {
      if (!confirm("Delete " + (file.name || "this file") + "?\n\nShare links will stop working.")) return;
      setServerMessage(filesStatus, "Deleting…");
      try {
        await serverRequest("/api/admin/delete-file", {
          method: "POST",
          body: JSON.stringify({ id: file.id })
        });
        setServerMessage(filesStatus, "Deleted.");
        loadSharedFiles();
        loadServerSettings(false);
      } catch (error) {
        setServerMessage(filesStatus, "Delete failed: " + (error.message || "network error"), true);
      }
    });
    actions.appendChild(del);

    row.appendChild(thumb);
    row.appendChild(body);
    row.appendChild(actions);
    sharedFilesList.appendChild(row);
  });
}

async function loadSharedFiles() {
  if (!serverBase() || !serverToken()) return;
  setServerMessage(filesStatus, "Loading shared files…");
  try {
    const payload = await serverRequest("/api/admin/files");
    sharedFiles = Array.isArray(payload.files) ? payload.files : [];
    renderSharedFiles();
    setServerMessage(filesStatus, sharedFiles.length + (sharedFiles.length === 1 ? " file" : " files") + " on the server.");
  } catch (error) {
    sharedFiles = [];
    renderSharedFiles();
    setServerMessage(filesStatus, "Could not load files: " + (error.message || "network error"), true);
  }
}

function setEditorStatus(message, isError) {
  setServerMessage(editorStatus, message, isError);
}

async function loadEditorFiles() {
  if (!serverBase()) {
    setEditorStatus("Enter your server URL first.", true);
    return;
  }
  setEditorStatus("Loading file list…");
  try {
    const payload = await serverRequest("/api/admin/editor");
    const files = Array.isArray(payload.files) ? payload.files : [];
    const current = editorPathInput.value.trim();
    editorFileSelect.innerHTML = "";
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = files.length ? "Select a file…" : "No editable files found";
    editorFileSelect.appendChild(placeholder);
    files.forEach(function(relative) {
      const option = document.createElement("option");
      option.value = relative;
      option.textContent = relative;
      editorFileSelect.appendChild(option);
    });
    if (current && files.indexOf(current) !== -1) editorFileSelect.value = current;
    setEditorStatus(files.length + (files.length === 1 ? " file" : " files") + " available.");
  } catch (error) {
    setEditorStatus("Could not load files: " + (error.message || "network error"), true);
  }
}

async function loadEditorFile() {
  const path = (editorFileSelect.value || editorPathInput.value || "").trim();
  if (!path) {
    setEditorStatus("Choose a file first.", true);
    return;
  }
  setEditorStatus("Loading " + path + "…");
  try {
    const payload = await serverRequest("/api/admin/editor?path=" + encodeURIComponent(path));
    const file = payload.file || {};
    editorPathInput.value = file.path || path;
    editorFileSelect.value = file.path || path;
    editorContentInput.value = file.content || "";
    setEditorStatus("Loaded " + (file.path || path) + " (" + formatBytes(file.size || 0) + ").");
  } catch (error) {
    setEditorStatus("Could not load file: " + (error.message || "network error"), true);
  }
}

async function saveEditorFile() {
  const path = (editorPathInput.value || editorFileSelect.value || "").trim();
  if (!path) {
    setEditorStatus("Enter a file path first.", true);
    return;
  }
  setEditorStatus("Saving " + path + "…");
  try {
    const payload = await serverRequest("/api/admin/editor", {
      method: "POST",
      body: JSON.stringify({ path: path, content: editorContentInput.value })
    });
    const file = payload.file || {};
    const suffix = payload.config_reloaded ? ". Config reloaded." : ".";
    setEditorStatus("Saved " + (file.path || path) + " (" + formatBytes(file.size || 0) + ")" + suffix);
    if (payload.config_reloaded) loadServerSettings(false);
  } catch (error) {
    setEditorStatus("Save failed: " + (error.message || "network error"), true);
  }
}

async function reloadServerConfig() {
  setEditorStatus("Reloading config.json…");
  try {
    await serverRequest("/api/admin/reload-config", { method: "POST", body: "{}" });
    setEditorStatus("Config reloaded from disk.");
    loadServerSettings(false);
  } catch (error) {
    setEditorStatus("Reload failed: " + (error.message || "network error"), true);
  }
}

async function restartServer() {
  if (!confirm("Restart the server now? The connection will drop for a few seconds.")) return;
  setEditorStatus("Restarting the server…");
  try {
    await serverRequest("/api/admin/restart", { method: "POST", body: "{}" });
    setEditorStatus("Restart requested. Reconnect in a few seconds.");
  } catch (error) {
    setEditorStatus("Restart failed: " + (error.message || "network error"), true);
  }
}

if (serverUrlInput) {
  serverUrlInput.value = localStorage.getItem(SERVER_KEY) || defaultServerUrl();
  adminTokenInput.value = localStorage.getItem(TOKEN_KEY) || "";

  document.getElementById("serverConnect").addEventListener("click", function() {
    serverUrlInput.value = normalizeServerUrl(serverUrlInput.value);
    persistServerFields();
    loadServerSettings(true);
  });
  document.getElementById("serverForget").addEventListener("click", function() {
    try {
      localStorage.removeItem(SERVER_KEY);
      localStorage.removeItem(TOKEN_KEY);
    } catch (error) {}
    serverUrlInput.value = defaultServerUrl();
    adminTokenInput.value = "";
    setServerBadge("Not connected", false);
    setServerMessage(serverStatus, "Saved server details cleared.");
    sharedFiles = [];
    renderSharedFiles();
  });
  document.getElementById("serverSave").addEventListener("click", saveServerSettings);
  const configSave = document.getElementById("configSave");
  const configReload = document.getElementById("configReload");
  if (configSave) configSave.addEventListener("click", saveServerSettings);
  if (configReload) configReload.addEventListener("click", function() { loadServerSettings(true); });
  document.getElementById("serverClearUpdate").addEventListener("click", async function() {
    setServerMessage(serverSettingsStatus, "Clearing update…");
    try {
      const result = await serverRequest("/api/admin/settings", {
        method: "POST",
        body: JSON.stringify({ update_available: false, force_update: false })
      });
      fillServerSettings(result.settings || {});
      setServerMessage(serverSettingsStatus, "Update notice cleared.");
    } catch (error) {
      setServerMessage(serverSettingsStatus, "Could not clear update: " + (error.message || "network error"), true);
    }
  });
  document.getElementById("serverIconClear").addEventListener("click", async function() {
    if (!confirm("Reset the app icon to the default?")) return;
    setServerMessage(serverSettingsStatus, "Resetting icon…");
    try {
      const result = await serverRequest("/api/admin/settings", {
        method: "POST",
        body: JSON.stringify({ clear_icon: true })
      });
      fillServerSettings(result.settings || {});
      setServerMessage(serverSettingsStatus, "Icon reset.");
    } catch (error) {
      setServerMessage(serverSettingsStatus, "Could not reset icon: " + (error.message || "network error"), true);
    }
  });
  serverIconInput.addEventListener("change", uploadServerIcon);
  serverApkInput.addEventListener("change", uploadServerApk);
  document.getElementById("serverReloadFiles").addEventListener("click", loadSharedFiles);
  if (editorCard) {
    document.getElementById("editorReloadList").addEventListener("click", loadEditorFiles);
    document.getElementById("editorLoad").addEventListener("click", loadEditorFile);
    document.getElementById("editorSave").addEventListener("click", saveEditorFile);
    document.getElementById("editorReloadConfig").addEventListener("click", reloadServerConfig);
    document.getElementById("editorRestart").addEventListener("click", restartServer);
    editorFileSelect.addEventListener("change", function() {
      if (!editorFileSelect.value) return;
      editorPathInput.value = editorFileSelect.value;
      loadEditorFile();
    });
  }
  adminTokenInput.addEventListener("change", function() {
    persistServerFields();
    if (serverBase() && serverToken()) loadServerSettings(true);
  });
  adminTokenInput.addEventListener("keydown", function(event) {
    if (event.key !== "Enter") return;
    event.preventDefault();
    persistServerFields();
    loadServerSettings(true);
  });

  if (serverToken()) {
    loadServerSettings(false);
  }
}
