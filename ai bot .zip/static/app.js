const DEFAULT_MODEL = 'gemini-3.6-flash';
const API_PORTS = [8765, 8766, 8767, 8768, 8769, 8770, 8771, 8772, 8773, 8774, 8775];
const FALLBACK_MODELS = [
  'gemini-3.8-flash',
  'gemini-3.7-flash',
  'gemini-3.6-flash',
  'gemini-3.5-flash',
  'gemini-3.5-flash-lite',
  'gemini-flash-latest',
  'gemini-flash-lite-latest',
  'gemini-3.1-flash-lite'
];

function fallbackModelLabel(id) {
  return String(id || '')
    .replace(/-/g, ' ')
    .replace(/\b\w/g, function(c) { return c.toUpperCase(); });
}

function fallbackModels() {
  return FALLBACK_MODELS.map(function(id) {
    return {
      id: id,
      label: fallbackModelLabel(id),
      family: 'google',
      free: true,
      recommended: true
    };
  });
}

function readCookie(name) {
  try {
    var prefix = name + '=';
    var parts = document.cookie ? document.cookie.split('; ') : [];
    for (var i = 0; i < parts.length; i++) {
      if (parts[i].indexOf(prefix) === 0) {
        return decodeURIComponent(parts[i].slice(prefix.length));
      }
    }
  } catch (e) {}
  return '';
}

function newClientId() {
  var raw = '';
  try {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      raw = window.crypto.randomUUID().replace(/-/g, '');
    }
  } catch (e) {}
  if (!raw) {
    raw = Math.random().toString(36).slice(2) + Date.now().toString(36) + Math.random().toString(36).slice(2);
  }
  raw = raw.replace(/[^A-Za-z0-9]/g, '').slice(0, 40);
  return 'u_' + raw;
}

function getClientId() {
  var id = '';
  try { id = localStorage.getItem('rebbet_client_id') || ''; } catch (e) {}
  if (!id) id = readCookie('rebbet_client_id');
  if (!/^[A-Za-z0-9_-]{6,80}$/.test(id)) id = newClientId();
  try { localStorage.setItem('rebbet_client_id', id); } catch (e) {}
  try {
    document.cookie = 'rebbet_client_id=' + encodeURIComponent(id) + '; Max-Age=31536000; Path=/; SameSite=Lax';
  } catch (e) {}
  return id;
}

window.rebbetUserId = getClientId();

let apiBase = null;
let apiBasePromise = null;

function candidateApiBases() {
  const bases = [];
  if (location.protocol === 'http:' || location.protocol === 'https:') {
    bases.push(location.origin);
  }
  API_PORTS.forEach(function(port) {
    bases.push('http://127.0.0.1:' + port);
    bases.push('http://localhost:' + port);
  });
  return bases.filter(function(base, index) {
    return bases.indexOf(base) === index;
  });
}

async function probeApiBase(base) {
  const controller = new AbortController();
  const timer = setTimeout(function() { controller.abort(); }, 1500);
  try {
    const res = await fetch(base + '/api/health', {
      cache: 'no-store',
      signal: controller.signal
    });
    if (!res.ok) return false;
    const data = await res.json();
    return !!(data && data.ok);
  } catch (e) {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

function resolveApiBase() {
  if (apiBase !== null) return Promise.resolve(apiBase);
  if (!apiBasePromise) {
    apiBasePromise = (async function() {
      const bases = candidateApiBases();
      for (let i = 0; i < bases.length; i++) {
        if (await probeApiBase(bases[i])) {
          apiBase = bases[i];
          return apiBase;
        }
      }
      apiBase = '';
      return apiBase;
    })();
  }
  return apiBasePromise;
}

function resetApiBase() {
  apiBase = null;
  apiBasePromise = null;
}

async function apiFetch(path, options) {
  const base = await resolveApiBase();
  const opts = Object.assign({}, options || {});
  const headers = new Headers(opts.headers || {});
  if (window.rebbetUserId && !headers.has('X-Rebbet-User')) {
    headers.set('X-Rebbet-User', window.rebbetUserId);
  }
  opts.headers = headers;
  return fetch(base + path, opts);
}

var voice = {
  enabled: false,
  recording: false,
  chunks: [],
  stream: null,
  audioContext: null,
  source: null,
  processor: null,
  recordTimer: null,
  audio: null,
  audioUrl: null,
  id: '',
  model: '',
  speed: 'fast',
  voices: [],
  models: [],
  loaded: false,
  loading: false,
  warning: '',
  previewAudio: null
};

function loadVoicePref() {
  try {
    voice.enabled = localStorage.getItem('rebbet_voice') === '1';
    voice.id = localStorage.getItem('rebbet_voice_id') || '';
    voice.model = localStorage.getItem('rebbet_voice_model') || '';
    voice.speed = localStorage.getItem('rebbet_voice_speed') || 'fast';
  } catch (e) {
    voice.enabled = false;
  }
  if (['fast', 'normal', 'slow'].indexOf(voice.speed) < 0) voice.speed = 'fast';
  updateVoiceToggle();
  updateVoiceControls();
}

function saveVoicePref(key, value) {
  try {
    if (value) localStorage.setItem(key, value);
    else localStorage.removeItem(key);
  } catch (e) {}
}

let webSearchEnabled = true;

function loadWebSearchPref() {
  try {
    webSearchEnabled = localStorage.getItem('rebbet_websearch') !== '0';
  } catch (e) {
    webSearchEnabled = true;
  }
  updateSearchToggle();
}

function updateSearchToggle() {
  if (!els.searchToggle) return;
  els.searchToggle.classList.toggle('is-on', webSearchEnabled);
  els.searchToggle.setAttribute('aria-pressed', webSearchEnabled ? 'true' : 'false');
  els.searchToggle.setAttribute('aria-label', webSearchEnabled ? 'Web search on' : 'Web search off');
}

function toggleWebSearch() {
  webSearchEnabled = !webSearchEnabled;
  try {
    localStorage.setItem('rebbet_websearch', webSearchEnabled ? '1' : '0');
  } catch (e) {}
  updateSearchToggle();
  showToast(webSearchEnabled ? 'Web search enabled' : 'Web search disabled');
}

function updateVoiceToggle() {
  if (!els.voiceToggle) return;
  els.voiceToggle.classList.toggle('is-on', voice.enabled);
  els.voiceToggle.setAttribute('aria-pressed', voice.enabled ? 'true' : 'false');
  els.voiceToggle.setAttribute('aria-label', voice.enabled ? 'Voice replies on' : 'Voice replies off');
  var row = document.getElementById('voiceEnableRow');
  if (row) {
    row.classList.toggle('is-on', voice.enabled);
    row.setAttribute('aria-pressed', voice.enabled ? 'true' : 'false');
  }
}

function updateVoiceControls() {
  var speeds = document.querySelectorAll('#voiceSpeedGroup button');
  for (var i = 0; i < speeds.length; i++) {
    speeds[i].classList.toggle('is-active', speeds[i].getAttribute('data-speed') === voice.speed);
  }
  if (els.voiceSelect && voice.id) els.voiceSelect.value = voice.id;
  if (els.voiceModelSelect && voice.model) els.voiceModelSelect.value = voice.model;
}

function toggleVoice() {
  voice.enabled = !voice.enabled;
  saveVoicePref('rebbet_voice', voice.enabled ? '1' : '0');
  updateVoiceToggle();
  showToast(voice.enabled ? 'Voice replies on' : 'Voice replies off');
  if (!voice.enabled) stopSpeaking();
}

function ttsPayload(clean) {
  var payload = { text: clean, speed: voice.speed || 'fast' };
  if (voice.id) payload.voice = voice.id;
  if (voice.model) payload.model = voice.model;
  return payload;
}

function speakableText(text) {
  var out = String(text || '');
  out = out.replace(/```[\s\S]*?```/g, ' ');
  out = out.replace(/`([^`]*)`/g, '$1');
  out = out.replace(/!\[[^\]]*\]\([^)]*\)/g, ' ');
  out = out.replace(/\[([^\]]+)\]\([^)]*\)/g, '$1');
  out = out.replace(/[*_#>|~]/g, ' ');
  out = out.replace(/\s+/g, ' ').trim();
  if (out.length > 3500) out = out.slice(0, 3500);
  return out;
}

function stopSpeaking() {
  if (voice.audio) {
    try { voice.audio.pause(); } catch (e) {}
    voice.audio = null;
  }
  if (voice.audioUrl) {
    URL.revokeObjectURL(voice.audioUrl);
    voice.audioUrl = null;
  }
  if (window.speechSynthesis) {
    try { window.speechSynthesis.cancel(); } catch (e) {}
  }
}

function browserSpeak(text) {
  if (!window.speechSynthesis || !window.SpeechSynthesisUtterance) return false;
  var clean = speakableText(text);
  if (!clean) return false;
  try {
    window.speechSynthesis.cancel();
    var utterance = new SpeechSynthesisUtterance(clean);
    utterance.rate = 1.12;
    utterance.pitch = 1;
    utterance.volume = 1;
    var voices = window.speechSynthesis.getVoices() || [];
    for (var i = 0; i < voices.length; i++) {
      if (/^en[-_]/i.test(voices[i].lang || '')) {
        utterance.voice = voices[i];
        break;
      }
    }
    window.speechSynthesis.speak(utterance);
    return true;
  } catch (e) {
    return false;
  }
}

async function speak(text) {
  var clean = speakableText(text);
  if (!clean) return;
  stopSpeaking();
  try {
    var res = await apiFetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(ttsPayload(clean))
    });
    if (!res.ok) {
      if (browserSpeak(clean)) {
        showToast('Using device voice');
        return;
      }
      var info = null;
      try { info = await res.json(); } catch (e) {}
      var message = info && info.error && info.error.message ? info.error.message : 'Voice failed';
      showToast('Voice: ' + message);
      return;
    }
    var blob = await res.blob();
    if (!blob || !blob.size) {
      if (!browserSpeak(clean)) showToast('Voice unavailable');
      return;
    }
    voice.audioUrl = URL.createObjectURL(blob);
    voice.audio = new Audio(voice.audioUrl);
    voice.audio.onended = function() { stopSpeaking(); };
    var played = voice.audio.play();
    if (played && played.catch) {
      played.catch(function() {
        if (!browserSpeak(clean)) showToast('Tap to enable audio playback');
      });
    }
  } catch (e) {
    if (!browserSpeak(clean)) showToast('Voice unavailable');
  }
}

function downsampleBuffer(buffer, inRate, outRate) {
  if (outRate >= inRate) return buffer;
  var ratio = inRate / outRate;
  var length = Math.round(buffer.length / ratio);
  var result = new Float32Array(length);
  var offsetResult = 0;
  var offsetBuffer = 0;
  while (offsetResult < length) {
    var nextOffsetBuffer = Math.round((offsetResult + 1) * ratio);
    var accum = 0;
    var count = 0;
    for (var i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i++) {
      accum += buffer[i];
      count++;
    }
    result[offsetResult] = count ? accum / count : 0;
    offsetResult++;
    offsetBuffer = nextOffsetBuffer;
  }
  return result;
}

function encodeWav(samples, sampleRate) {
  var buffer = new ArrayBuffer(44 + samples.length * 2);
  var view = new DataView(buffer);
  function writeString(offset, str) {
    for (var i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
  }
  writeString(0, 'RIFF');
  view.setUint32(4, 36 + samples.length * 2, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, samples.length * 2, true);
  var offset = 44;
  for (var i = 0; i < samples.length; i++, offset += 2) {
    var s = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return buffer;
}

function arrayBufferToBase64(buffer) {
  var bytes = new Uint8Array(buffer);
  var binary = '';
  var chunk = 0x8000;
  for (var i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

async function startRecording() {
  if (voice.recording) return;
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    showToast('Voice input is not supported here');
    return;
  }
  if (!window.isSecureContext) {
    showToast('Voice input needs HTTPS or localhost');
    return;
  }
  try {
    var stream = await navigator.mediaDevices.getUserMedia({
      audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true }
    });
    var Ctx = window.AudioContext || window.webkitAudioContext;
    var ctx = new Ctx();
    if (ctx.state === 'suspended') await ctx.resume();
    var source = ctx.createMediaStreamSource(stream);
    var processor = ctx.createScriptProcessor(4096, 1, 1);
    voice.chunks = [];
    processor.onaudioprocess = function(e) {
      voice.chunks.push(new Float32Array(e.inputBuffer.getChannelData(0)));
    };
    source.connect(processor);
    processor.connect(ctx.destination);
    voice.stream = stream;
    voice.audioContext = ctx;
    voice.source = source;
    voice.processor = processor;
    voice.recording = true;
    els.composerMic.classList.add('is-recording');
    els.composerMic.setAttribute('aria-label', 'Stop recording');
    showToast('Recording… tap mic to stop');
    voice.recordTimer = setTimeout(function() { stopRecording(); }, 45000);
  } catch (e) {
    showToast('Microphone permission denied');
  }
}

function stopRecording() {
  if (!voice.recording) return;
  voice.recording = false;
  clearTimeout(voice.recordTimer);
  els.composerMic.classList.remove('is-recording');
  els.composerMic.setAttribute('aria-label', 'Record voice message');
  try { voice.processor.disconnect(); } catch (e) {}
  try { voice.source.disconnect(); } catch (e) {}
  try { voice.stream.getTracks().forEach(function(track) { track.stop(); }); } catch (e) {}
  var ctx = voice.audioContext;
  var sampleRate = ctx ? ctx.sampleRate : 48000;
  try { if (ctx) ctx.close(); } catch (e) {}
  voice.processor = null;
  voice.source = null;
  voice.stream = null;
  voice.audioContext = null;

  var chunks = voice.chunks || [];
  voice.chunks = [];
  if (!chunks.length) {
    showToast('No audio recorded');
    return;
  }
  var total = 0;
  chunks.forEach(function(c) { total += c.length; });
  var merged = new Float32Array(total);
  var offset = 0;
  chunks.forEach(function(c) {
    merged.set(c, offset);
    offset += c.length;
  });
  var downsampled = downsampleBuffer(merged, sampleRate, 16000);
  var wav = encodeWav(downsampled, 16000);
  transcribeAudio(wav);
}

async function requestTranscription(wavBuffer) {
  var res = await apiFetch('/api/transcribe', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      audio: arrayBufferToBase64(wavBuffer),
      mimeType: 'audio/wav'
    })
  });
  var data = null;
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) {
    var message = data && data.error && data.error.message ? data.error.message : 'Transcription failed';
    throw new Error(message);
  }
  return {
    text: data && data.text ? String(data.text).trim() : '',
    model: data && data.model ? data.model : ''
  };
}

async function transcribeAudio(wavBuffer) {
  showToast('Transcribing…');
  try {
    var result = await requestTranscription(wavBuffer);
    if (!result.text) {
      showToast('No speech detected');
      return;
    }
    trackEvent('voice_transcribed', { model: result.model || '' });
    var current = els.composerInput.value.trim();
    els.composerInput.value = (current ? current + ' ' : '') + result.text;
    autoResize();
    els.composerSend.disabled = state.sending || !els.composerInput.value.trim();
    els.composerInput.focus();
  } catch (e) {
    showToast('Voice: ' + (e && e.message ? e.message : 'Transcription unavailable'));
  }
}

function toggleRecording() {
  if (voice.recording) {
    stopRecording();
  } else {
    startRecording();
  }
}

/* --------------------------------------------------------------------------
   Voice call
   -------------------------------------------------------------------------- */

var call = {
  active: false,
  muted: false,
  phase: 'idle',
  session: 0,
  stream: null,
  ctx: null,
  source: null,
  processor: null,
  sink: null,
  startedAt: 0,
  timer: null,
  captureFinish: null,
  audio: null,
  audioUrl: null,
  speakResolve: null
};

function delay(ms) {
  return new Promise(function(resolve) { setTimeout(resolve, ms); });
}

function setCallPhase(phase, label) {
  call.phase = phase;
  if (!els.voiceCall) return;
  els.voiceCall.classList.remove('is-listening', 'is-thinking', 'is-speaking', 'is-muted');
  if (phase === 'listening') els.voiceCall.classList.add('is-listening');
  else if (phase === 'thinking') els.voiceCall.classList.add('is-thinking');
  else if (phase === 'speaking') els.voiceCall.classList.add('is-speaking');
  if (call.muted) els.voiceCall.classList.add('is-muted');
  if (els.callStatus && label) els.callStatus.textContent = label;
}

function addCallLine(text, role) {
  if (!els.callTranscript || !text) return;
  var line = document.createElement('div');
  line.className = 'voice-call__line voice-call__line--' + (role === 'user' ? 'user' : 'assistant');
  line.textContent = text;
  els.callTranscript.appendChild(line);
  while (els.callTranscript.children.length > 24) {
    els.callTranscript.removeChild(els.callTranscript.firstChild);
  }
  els.callTranscript.scrollTop = els.callTranscript.scrollHeight;
}

function updateCallTimer() {
  if (!els.callTimer || !call.startedAt) return;
  var total = Math.max(0, Math.floor((Date.now() - call.startedAt) / 1000));
  var minutes = Math.floor(total / 60);
  var seconds = total % 60;
  els.callTimer.textContent =
    (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
}

function startCallTimer() {
  call.startedAt = Date.now();
  updateCallTimer();
  clearInterval(call.timer);
  call.timer = setInterval(updateCallTimer, 1000);
}

function stopCallTimer() {
  if (call.timer) clearInterval(call.timer);
  call.timer = null;
}

function stopCallStreams() {
  if (call.processor) {
    try { call.processor.onaudioprocess = null; } catch (e) {}
    try { call.processor.disconnect(); } catch (e) {}
  }
  if (call.source) {
    try { call.source.disconnect(); } catch (e) {}
  }
  if (call.sink) {
    try { call.sink.disconnect(); } catch (e) {}
  }
  if (call.stream) {
    try { call.stream.getTracks().forEach(function(track) { track.stop(); }); } catch (e) {}
  }
  if (call.ctx) {
    try { call.ctx.close(); } catch (e) {}
  }
  call.processor = null;
  call.source = null;
  call.sink = null;
  call.stream = null;
  call.ctx = null;
  call.captureFinish = null;
}

async function startVoiceCall() {
  if (call.active) return;
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    showToast('Voice calls are not supported here');
    return;
  }
  if (!window.isSecureContext) {
    showToast('Voice calls need HTTPS or localhost');
    return;
  }
  stopSpeaking();
  if (els.callTranscript) els.callTranscript.innerHTML = '';
  if (els.callTimer) els.callTimer.textContent = '00:00';
  if (els.voiceCall) els.voiceCall.hidden = false;
  document.body.classList.add('is-on-call');
  setCallPhase('thinking', 'Connecting…');
  var session = ++call.session;
  try {
    var stream = await navigator.mediaDevices.getUserMedia({
      audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true }
    });
    if (session !== call.session || !els.voiceCall || els.voiceCall.hidden) {
      try { stream.getTracks().forEach(function(track) { track.stop(); }); } catch (e) {}
      return;
    }
    var Ctx = window.AudioContext || window.webkitAudioContext;
    var ctx = new Ctx();
    if (ctx.state === 'suspended') await ctx.resume();
    if (session !== call.session) {
      try { ctx.close(); } catch (e) {}
      try { stream.getTracks().forEach(function(track) { track.stop(); }); } catch (e) {}
      return;
    }
    var source = ctx.createMediaStreamSource(stream);
    var processor = ctx.createScriptProcessor(4096, 1, 1);
    var sink = ctx.createGain();
    sink.gain.value = 0;
    source.connect(processor);
    processor.connect(sink);
    sink.connect(ctx.destination);
    call.stream = stream;
    call.ctx = ctx;
    call.source = source;
    call.processor = processor;
    call.sink = sink;
    call.active = true;
    call.muted = false;
    if (els.callMute) {
      els.callMute.classList.remove('is-on');
      els.callMute.setAttribute('aria-pressed', 'false');
    }
    startCallTimer();
    setCallPhase('listening', 'Listening…');
    trackEvent('voice_call_started', {});
    callLoop();
  } catch (e) {
    if (session !== call.session) return;
    if (els.voiceCall) els.voiceCall.hidden = true;
    document.body.classList.remove('is-on-call');
    setCallPhase('idle');
    showToast('Microphone permission denied');
  }
}

function endVoiceCall() {
  if (!call.active && els.voiceCall && els.voiceCall.hidden) return;
  call.session++;
  call.active = false;
  if (call.captureFinish) {
    var finish = call.captureFinish;
    call.captureFinish = null;
    try { finish(); } catch (e) {}
  }
  finishCallSpeech();
  stopCallTimer();
  stopCallStreams();
  if (els.voiceCall) els.voiceCall.hidden = true;
  document.body.classList.remove('is-on-call');
  setCallPhase('idle');
  showToast('Call ended');
  trackEvent('voice_call_ended', {});
}

function toggleCallMute() {
  if (!call.active) return;
  call.muted = !call.muted;
  if (els.callMute) {
    els.callMute.classList.toggle('is-on', call.muted);
    els.callMute.setAttribute('aria-pressed', call.muted ? 'true' : 'false');
  }
  if (call.muted) {
    setCallPhase('muted', 'Microphone muted');
  } else {
    setCallPhase('listening', 'Listening…');
  }
}

function handleCallOrb() {
  if (!call.active) return;
  if (call.phase === 'speaking') {
    finishCallSpeech();
    return;
  }
  if (call.phase === 'listening' && call.captureFinish) {
    call.captureFinish();
  }
}

function finishCallSpeech() {
  if (call.audio) {
    try { call.audio.pause(); } catch (e) {}
    call.audio = null;
  }
  if (call.audioUrl) {
    URL.revokeObjectURL(call.audioUrl);
    call.audioUrl = null;
  }
  if (window.speechSynthesis) {
    try { window.speechSynthesis.cancel(); } catch (e) {}
  }
  var resolve = call.speakResolve;
  call.speakResolve = null;
  if (resolve) resolve();
}

function browserSpeakCall(text) {
  if (!window.speechSynthesis || !window.SpeechSynthesisUtterance) return false;
  try {
    var utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = navigator.language || 'en-US';
    utterance.onend = finishCallSpeech;
    utterance.onerror = finishCallSpeech;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
    return true;
  } catch (e) {
    return false;
  }
}

function speakCall(text) {
  return new Promise(function(resolve) {
    var clean = speakableText(text);
    if (!clean || !call.active) {
      resolve();
      return;
    }
    call.speakResolve = resolve;
    apiFetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(ttsPayload(clean))
    }).then(function(res) {
      if (!res.ok) {
        if (!browserSpeakCall(clean)) finishCallSpeech();
        return;
      }
      return res.blob().then(function(blob) {
        if (!blob || !blob.size || !call.active) {
          finishCallSpeech();
          return;
        }
        call.audioUrl = URL.createObjectURL(blob);
        call.audio = new Audio(call.audioUrl);
        call.audio.onended = finishCallSpeech;
        call.audio.onerror = finishCallSpeech;
        var played = call.audio.play();
        if (played && played.catch) {
          played.catch(function() {
            if (!browserSpeakCall(clean)) finishCallSpeech();
          });
        }
      });
    }).catch(function() {
      if (!browserSpeakCall(clean)) finishCallSpeech();
    });
  });
}

function captureCallUtterance() {
  return new Promise(function(resolve) {
    if (!call.active || !call.processor || !call.ctx) {
      resolve(null);
      return;
    }
    var finished = false;
    var chunks = [];
    var speechStarted = false;
    var silenceMs = 0;
    var speechMs = 0;
    var elapsedMs = 0;

    function finish() {
      if (finished) return;
      finished = true;
      call.captureFinish = null;
      try { call.processor.onaudioprocess = null; } catch (e) {}
      var output = null;
      if (speechStarted && chunks.length) {
        var total = 0;
        chunks.forEach(function(chunk) { total += chunk.length; });
        var merged = new Float32Array(total);
        var offset = 0;
        chunks.forEach(function(chunk) {
          merged.set(chunk, offset);
          offset += chunk.length;
        });
        var rate = call.ctx ? call.ctx.sampleRate : 48000;
        var downsampled = downsampleBuffer(merged, rate, 16000);
        output = encodeWav(downsampled, 16000);
      }
      resolve(output);
    }

    call.captureFinish = finish;

    if (!call.processor.onaudioprocess) {
      call.processor.onaudioprocess = function(event) {
        if (finished) return;
        var data = event.inputBuffer.getChannelData(0);
        chunks.push(new Float32Array(data));
        var sum = 0;
        for (var i = 0; i < data.length; i++) sum += data[i] * data[i];
        var rms = Math.sqrt(sum / data.length);
        var bufferMs = (data.length / (call.ctx ? call.ctx.sampleRate : 48000)) * 1000;
        elapsedMs += bufferMs;
        if (rms > 0.016) {
          speechStarted = true;
          speechMs += bufferMs;
          silenceMs = 0;
        } else if (speechStarted) {
          silenceMs += bufferMs;
        }
        if (speechStarted && silenceMs >= 900) finish();
        else if (speechStarted && speechMs >= 20000) finish();
        else if (!speechStarted && elapsedMs >= 20000) finish();
        else if (elapsedMs >= 30000) finish();
      };
    }
  });
}

async function callSendTurn(userText) {
  var chat = getActiveChat();
  if (!chat) return '';
  var model = chat.model || state.selectedModel || DEFAULT_MODEL;
  chat.messages.push({ role: 'user', content: userText, time: nowTime() });
  updateChatTitle(chat);
  saveChats();
  renderThread();
  var history = chat.messages.slice(-20).map(function(message) {
    return apiMessage(message);
  });
  var res = await apiFetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: model, messages: history, web_search: webSearchEnabled })
  });
  if (!res.ok) {
    var info = null;
    try { info = await res.json(); } catch (e) {}
    throw new Error(info && info.error && info.error.message ? info.error.message : 'Voice request failed');
  }
  var reader = res.body.getReader();
  var decoder = new TextDecoder();
  var buffer = '';
  var fullText = '';
  var activeModel = model;
  var activeProvider = '';
  var streamError = '';
  while (true) {
    var result = await reader.read();
    if (result.done) break;
    buffer += decoder.decode(result.value, { stream: true });
    var parts = buffer.split('\n\n');
    buffer = parts.pop();
    for (var i = 0; i < parts.length; i++) {
      var chunk = parts[i];
      if (!chunk.startsWith('data:')) continue;
      var jsonStr = chunk.slice(5).trim();
      if (!jsonStr) continue;
      var event = null;
      try { event = JSON.parse(jsonStr); } catch (e) { continue; }
      if (event.type === 'meta') {
        activeModel = event.model || activeModel;
        activeProvider = event.provider || activeProvider;
      } else if (event.type === 'delta' && typeof event.text === 'string') {
        fullText += event.text;
      } else if (event.type === 'error') {
        streamError = event.message || 'Voice request failed';
      }
    }
  }
  if (streamError) throw new Error(streamError);
  if (!fullText) throw new Error('Empty response');
  var assistant = {
    role: 'assistant',
    content: fullText,
    raw: fullText,
    time: nowTime(),
    modelLabel: state.modelsById.get(activeModel)?.label || activeModel,
    provider: activeProvider
  };
  if (window.marked && window.DOMPurify) {
    assistant.html = DOMPurify.sanitize(marked.parse(fullText));
  }
  chat.messages.push(assistant);
  saveChats();
  renderThread();
  return fullText;
}

async function callLoop() {
  try {
    while (call.active) {
      if (call.muted) {
        setCallPhase('muted', 'Microphone muted');
        await delay(300);
        continue;
      }
      setCallPhase('listening', 'Listening…');
      var wav = await captureCallUtterance();
      if (!call.active) break;
      if (!wav) {
        await delay(200);
        continue;
      }
      setCallPhase('thinking', 'Thinking…');
      var text = '';
      try {
        var transcript = await requestTranscription(wav);
        text = transcript.text || '';
      } catch (e) {
        setCallPhase('thinking', 'Could not hear you');
        await delay(900);
        continue;
      }
      if (!call.active) break;
      if (!text) continue;
      addCallLine(text, 'user');
      var reply = '';
      try {
        reply = await callSendTurn(text);
      } catch (e) {
        if (!call.active) break;
        setCallPhase('thinking', e && e.message ? e.message : 'Connection issue');
        await delay(1200);
        continue;
      }
      if (!call.active) break;
      if (!reply) continue;
      addCallLine(reply, 'assistant');
      setCallPhase('speaking', 'Speaking…');
      await speakCall(reply);
      if (!call.active) break;
      await delay(350);
    }
  } catch (e) {
  } finally {
    if (call.active) endVoiceCall();
  }
}

const state = {
  models: [],
  modelsById: new Map(),
  selectedModel: null,
  chats: [],
  activeChatId: null,
  sending: false,
  appConfig: null
};

const els = {
  menuBtn: document.getElementById('menuBtn'),
  sidebar: document.getElementById('sidebar'),
  sidebarClose: document.getElementById('sidebarClose'),
  sidebarBackdrop: document.getElementById('sidebarBackdrop'),
  sidebarList: document.getElementById('sidebarList'),
  sidebarNew: document.getElementById('sidebarNew'),
  newChatBtn: document.getElementById('newChatBtn'),
  modelTrigger: document.getElementById('modelTrigger'),
  modelSheet: document.getElementById('modelSheet'),
  modelBackdrop: document.getElementById('modelBackdrop'),
  modelClose: document.getElementById('modelClose'),
  modelLabel: document.getElementById('modelLabel'),
  modelContent: document.getElementById('modelContent'),
  modelSearch: document.getElementById('modelSearch'),
  thread: document.getElementById('thread'),
  composerInput: document.getElementById('composerInput'),
  composerMic: document.getElementById('composerMic'),
  composerImage: document.getElementById('composerImage'),
  composerSend: document.getElementById('composerSend'),
  attachBtn: document.getElementById('attachBtn'),
  fileInput: document.getElementById('fileInput'),
  updateBtn: document.getElementById('updateBtn'),
  brandMark: document.getElementById('brandMark'),
  appFavicon: document.getElementById('appFavicon'),
  appTouchIcon: document.getElementById('appTouchIcon'),
  searchToggle: document.getElementById('searchToggle'),
  voiceToggle: document.getElementById('voiceToggle'),
  voiceSheet: document.getElementById('voiceSheet'),
  voiceBackdrop: document.getElementById('voiceBackdrop'),
  voiceClose: document.getElementById('voiceClose'),
  voiceSelect: document.getElementById('voiceSelect'),
  voiceModelSelect: document.getElementById('voiceModelSelect'),
  voicePreviewBtn: document.getElementById('voicePreviewBtn'),
  voiceWarning: document.getElementById('voiceWarning'),
  callBtn: document.getElementById('callBtn'),
  voiceCall: document.getElementById('voiceCall'),
  callOrb: document.getElementById('callOrb'),
  callStatus: document.getElementById('callStatus'),
  callTranscript: document.getElementById('callTranscript'),
  callMute: document.getElementById('callMute'),
  callEnd: document.getElementById('callEnd'),
  callTimer: document.getElementById('callTimer'),
  toast: document.getElementById('toast'),
  shareModal: document.getElementById('shareModal'),
  shareBackdrop: document.getElementById('shareBackdrop'),
  shareFileMeta: document.getElementById('shareFileMeta'),
  shareUrlInput: document.getElementById('shareUrlInput'),
  shareCopyBtn: document.getElementById('shareCopyBtn'),
  shareOpenLink: document.getElementById('shareOpenLink'),
  shareNativeBtn: document.getElementById('shareNativeBtn')
};

function uid() {
  return 'c_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function apiMessage(message) {
  var content = String((message && message.content) || '');
  if (message && message.file) {
    var link = message.file.url || message.file.shareUrl || message.file.rawUrl || '';
    if (link) {
      content += '\n[Shared file: ' + (message.file.name || 'file') + ' — ' + link + ']';
    }
  }
  return { role: message.role, content: content };
}

function nowTime() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function showToast(message) {
  els.toast.textContent = message;
  els.toast.classList.add('is-show');
  setTimeout(function() { els.toast.classList.remove('is-show'); }, 1800);
}

function trackEvent(name, params) {
  try {
    if (window.rebbetFirebase && typeof window.rebbetFirebase.trackEvent === 'function') {
      window.rebbetFirebase.trackEvent(name, params || {});
    }
  } catch (e) {}
}

function openSidebar() {
  els.sidebar.classList.add('is-open');
  els.sidebarBackdrop.classList.add('is-open');
}

function closeSidebar() {
  els.sidebar.classList.remove('is-open');
  els.sidebarBackdrop.classList.remove('is-open');
}

function openModelSheet() {
  els.modelSheet.classList.add('is-open');
  els.modelTrigger.setAttribute('aria-expanded', 'true');
  els.modelSearch.value = '';
  renderModels(els.modelSearch.value);
  if (window.matchMedia('(min-width: 900px)').matches) {
    setTimeout(function() { els.modelSearch.focus(); }, 180);
  }
}

function closeModelSheet() {
  els.modelSheet.classList.remove('is-open');
  els.modelTrigger.setAttribute('aria-expanded', 'false');
}

function showVoiceWarning(message) {
  if (!els.voiceWarning) return;
  if (message) {
    els.voiceWarning.textContent = message;
    els.voiceWarning.hidden = false;
  } else {
    els.voiceWarning.textContent = '';
    els.voiceWarning.hidden = true;
  }
}

function openVoiceSheet() {
  if (!els.voiceSheet) return;
  updateVoiceToggle();
  updateVoiceControls();
  els.voiceSheet.classList.add('is-open');
  if (!voice.loaded && !voice.loading) loadVoices();
  else renderVoiceOptions();
}

function closeVoiceSheet() {
  if (!els.voiceSheet) return;
  els.voiceSheet.classList.remove('is-open');
  stopVoicePreview();
}

function stopVoicePreview() {
  if (voice.previewAudio) {
    try { voice.previewAudio.pause(); } catch (e) {}
    voice.previewAudio = null;
  }
  if (els.voicePreviewBtn) {
    els.voicePreviewBtn.textContent = 'Preview voice';
    els.voicePreviewBtn.disabled = false;
  }
}

function renderVoiceOptions() {
  if (!els.voiceSelect || !els.voiceModelSelect) return;
  els.voiceSelect.innerHTML = '';
  voice.voices.forEach(function(item) {
    var option = document.createElement('option');
    option.value = item.id;
    option.textContent = item.name + (item.category && item.category !== 'premade' ? ' · ' + item.category : '');
    els.voiceSelect.appendChild(option);
  });
  if (!voice.voices.length) {
    var empty = document.createElement('option');
    empty.value = '';
    empty.textContent = 'No voices available';
    els.voiceSelect.appendChild(empty);
  }
  if (!voice.id && voice.voices.length) voice.id = voice.voices[0].id;
  els.voiceSelect.value = voice.id || '';

  els.voiceModelSelect.innerHTML = '';
  voice.models.forEach(function(model) {
    var option = document.createElement('option');
    option.value = model;
    option.textContent = model;
    els.voiceModelSelect.appendChild(option);
  });
  if (!voice.model && voice.models.length) voice.model = voice.models[0];
  els.voiceModelSelect.value = voice.model || '';
  updateVoiceControls();
  showVoiceWarning(voice.warning);
}

async function loadVoices() {
  if (!els.voiceSelect || voice.loading) return;
  voice.loading = true;
  els.voiceSelect.innerHTML = '<option value="">Loading voices…</option>';
  showVoiceWarning('');
  try {
    var res = await apiFetch('/api/voices');
    var data = null;
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) {
      var info = data && data.error ? data.error.message : 'Could not load voices';
      throw new Error(info);
    }
    voice.voices = (data.voices || []).filter(function(item) {
      return item && item.id;
    });
    voice.models = data.models || [];
    if (!voice.id) voice.id = data.default_voice || '';
    if (!voice.model) voice.model = data.default_model || '';
    if (!voice.speed) voice.speed = data.speed || 'fast';
    voice.warning = data.warning || '';
    voice.loaded = true;
    saveVoicePref('rebbet_voice_id', voice.id);
    saveVoicePref('rebbet_voice_model', voice.model);
    renderVoiceOptions();
  } catch (e) {
    els.voiceSelect.innerHTML = '<option value="">Voices unavailable</option>';
    showVoiceWarning(e && e.message ? e.message : 'Could not load voices');
  } finally {
    voice.loading = false;
  }
}

function selectedVoice() {
  for (var i = 0; i < voice.voices.length; i++) {
    if (voice.voices[i].id === voice.id) return voice.voices[i];
  }
  return null;
}

function previewVoice() {
  if (!els.voicePreviewBtn) return;
  stopVoicePreview();
  var item = selectedVoice();
  var name = item ? item.name : 'your Rebbet AI';
  if (item && item.preview_url) {
    voice.previewAudio = new Audio(item.preview_url);
    voice.previewAudio.onended = stopVoicePreview;
    voice.previewAudio.onerror = stopVoicePreview;
    voice.previewAudio.play().catch(stopVoicePreview);
    els.voicePreviewBtn.textContent = 'Stop preview';
    return;
  }
  els.voicePreviewBtn.disabled = true;
  els.voicePreviewBtn.textContent = 'Loading…';
  apiFetch('/api/tts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(ttsPayload('Hi, I am ' + name + ', your Rebbet AI voice.'))
  }).then(function(res) {
    if (!res.ok) throw new Error('Preview failed');
    return res.blob();
  }).then(function(blob) {
    if (!blob || !blob.size) throw new Error('Preview failed');
    var url = URL.createObjectURL(blob);
    voice.previewAudio = new Audio(url);
    voice.previewAudio.onended = function() {
      URL.revokeObjectURL(url);
      stopVoicePreview();
    };
    voice.previewAudio.onerror = function() {
      URL.revokeObjectURL(url);
      stopVoicePreview();
    };
    voice.previewAudio.play().catch(function() {
      URL.revokeObjectURL(url);
      stopVoicePreview();
    });
    els.voicePreviewBtn.disabled = false;
    els.voicePreviewBtn.textContent = 'Stop preview';
  }).catch(function(e) {
    showVoiceWarning(e && e.message ? e.message : 'Preview unavailable');
    els.voicePreviewBtn.disabled = false;
    els.voicePreviewBtn.textContent = 'Preview voice';
  });
}

function loadChats() {
  try {
    var raw = localStorage.getItem('rebbet_chats');
    if (raw) state.chats = JSON.parse(raw);
  } catch (e) {
    state.chats = [];
  }
  if (!state.chats.length) {
    createChat(true);
  } else if (!state.activeChatId || !state.chats.find(function(c){ return c.id === state.activeChatId; })) {
    state.activeChatId = state.chats[0].id;
  }
  renderSidebar();
  renderThread();
}

function saveChats() {
  try {
    localStorage.setItem('rebbet_chats', JSON.stringify(state.chats));
  } catch (e) {}
}

function createChat(silent) {
  var chat = {
    id: uid(),
    title: 'New chat',
    model: state.selectedModel || DEFAULT_MODEL,
    messages: [],
    createdAt: Date.now()
  };
  state.chats.unshift(chat);
  state.activeChatId = chat.id;
  saveChats();
  renderSidebar();
  renderThread();
  if (!silent) showToast('New chat created');
  closeSidebar();
}

function getActiveChat() {
  return state.chats.find(function(c){ return c.id === state.activeChatId; }) || null;
}

function deleteChat(chatId) {
  var idx = state.chats.findIndex(function(c){ return c.id === chatId; });
  if (idx === -1) return;
  state.chats.splice(idx, 1);
  if (state.activeChatId === chatId) {
    if (state.chats.length) {
      state.activeChatId = state.chats[0].id;
    } else {
      state.activeChatId = null;
      createChat(true);
      return;
    }
  }
  saveChats();
  renderSidebar();
  renderThread();
  closeSidebar();
  showToast('Chat deleted');
}

function renameChat(chatId) {
  var chat = state.chats.find(function(c){ return c.id === chatId; });
  if (!chat) return;
  var current = chat.title || 'New chat';
  var name = prompt('Rename chat', current);
  if (name === null) return;
  name = name.trim();
  if (!name) name = current;
  if (name.length > 60) name = name.slice(0, 60);
  chat.title = name;
  saveChats();
  renderSidebar();
  showToast('Renamed');
}

function editUserMessage(idx) {
  var chat = getActiveChat();
  if (!chat) return;
  var msg = chat.messages[idx];
  if (!msg || msg.role !== 'user') return;
  var newText = prompt('Edit message', msg.content);
  if (newText === null) return;
  newText = newText.replace(/\r\n/g, '\n').trim();
  if (!newText) return;
  msg.content = newText;
  if (chat.title === 'New chat') {
    updateChatTitle(chat);
  }
  chat.messages = chat.messages.slice(0, idx + 1);
  saveChats();
  renderThread();
  showToast('Message edited');
}

function updateChatTitle(chat) {
  if (!chat || chat.title !== 'New chat') return;
  var firstUser = chat.messages.find(function(m){ return m.role === 'user'; });
  if (!firstUser) return;
  var text = firstUser.content.replace(/\n+/g, ' ').trim();
  if (!text) return;
  chat.title = text.length > 32 ? text.slice(0, 32) + '…' : text;
  saveChats();
  renderSidebar();
}

function renderSidebar() {
  els.sidebarList.innerHTML = '';
  state.chats.forEach(function(chat) {
    var wrap = document.createElement('div');
    wrap.className = 'sidebar__row' + (chat.id === state.activeChatId ? ' is-active' : '');

    var btn = document.createElement('button');
    btn.className = 'sidebar__item-main';
    btn.type = 'button';
    var text = document.createElement('span');
    text.className = 'sidebar__item-text';
    text.textContent = chat.title || 'New chat';
    btn.appendChild(text);
    btn.addEventListener('click', function(e) {
      if (e.target.closest('.sidebar__menu')) return;
      state.activeChatId = chat.id;
      renderSidebar();
      renderThread();
      closeSidebar();
      setModel(chat.model || state.selectedModel);
    });

    var menuBtn = document.createElement('button');
    menuBtn.className = 'sidebar__menu';
    menuBtn.type = 'button';
    menuBtn.setAttribute('aria-label', 'Chat options');
    menuBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.6"></circle><circle cx="12" cy="12" r="1.6"></circle><circle cx="12" cy="19" r="1.6"></circle></svg>';
    menuBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      var existing = document.querySelector('.sidebar__dropdown');
      if (existing) existing.remove();
      var menu = document.createElement('div');
      menu.className = 'sidebar__dropdown';
      var rename = document.createElement('button');
      rename.className = 'sidebar__dropdown-item';
      rename.textContent = 'Rename';
      rename.addEventListener('click', function(ev) {
        ev.stopPropagation();
        menu.remove();
        renameChat(chat.id);
      });
      var del = document.createElement('button');
      del.className = 'sidebar__dropdown-item sidebar__dropdown-item--danger';
      del.textContent = 'Delete';
      del.addEventListener('click', function(ev) {
        ev.stopPropagation();
        menu.remove();
        if (confirm('Delete this chat?')) {
          deleteChat(chat.id);
        }
      });
      menu.appendChild(rename);
      menu.appendChild(del);
      document.body.appendChild(menu);
      var rect = menuBtn.getBoundingClientRect();
      menu.style.left = Math.min(rect.right - 140, window.innerWidth - 150) + 'px';
      menu.style.top = rect.bottom + 6 + 'px';
      setTimeout(function() {
        document.addEventListener('click', function closeMenu(ev) {
          if (!menu.contains(ev.target) && ev.target !== menuBtn) {
            menu.remove();
            document.removeEventListener('click', closeMenu);
          }
        });
      }, 0);
    });

    wrap.appendChild(btn);
    wrap.appendChild(menuBtn);
    els.sidebarList.appendChild(wrap);
  });
}

function setModel(modelId) {
  if (!modelId) return;
  if (state.modelsById.has(modelId)) {
    state.selectedModel = modelId;
  } else if (!state.selectedModel) {
    state.selectedModel = modelId;
  }
  var chat = getActiveChat();
  if (chat) chat.model = state.selectedModel;
  saveChats();
  var model = state.modelsById.get(state.selectedModel);
  els.modelLabel.textContent = model ? model.label : state.selectedModel;
  closeModelSheet();
}

function renderModels(filter) {
  var f = (filter || '').toLowerCase().trim();
  var list = state.models.filter(function(m) {
    if (!f) return true;
    return m.id.toLowerCase().indexOf(f) !== -1 || m.label.toLowerCase().indexOf(f) !== -1;
  });
  els.modelContent.innerHTML = '';
  if (!list.length) {
    var empty = document.createElement('div');
    empty.style.padding = '18px 12px';
    empty.style.color = 'var(--text-dim)';
    empty.textContent = 'No models match';
    els.modelContent.appendChild(empty);
    return;
  }
  var groups = {};
  list.forEach(function(m) {
    var key;
    if (m.family === 'google' || /^gemini-/i.test(m.id)) {
      key = 'Gemini';
    } else if (m.recommended) {
      key = 'Recommended';
    } else if (m.free) {
      key = 'Free';
    } else {
      key = 'Other models';
    }
    if (!groups[key]) groups[key] = [];
    groups[key].push(m);
  });
  var order = ['Gemini', 'Recommended', 'Free', 'Other models'];
  order.forEach(function(key) {
    if (!groups[key] || !groups[key].length) return;
    var label = document.createElement('div');
    label.className = 'model-group__label';
    label.textContent = key;
    els.modelContent.appendChild(label);
    groups[key].forEach(function(m) {
      var btn = document.createElement('button');
      btn.className = 'model-item' + (m.id === state.selectedModel ? ' is-active' : '');
      var main = document.createElement('div');
      main.className = 'model-item__main';
      var name = document.createElement('div');
      name.className = 'model-item__name';
      name.textContent = m.label;
      var meta = document.createElement('div');
      meta.className = 'model-item__meta';
      meta.textContent = m.id;
      main.appendChild(name);
      main.appendChild(meta);
      var badges = document.createElement('div');
      badges.className = 'model-item__badges';
      if (m.recommended) {
        var rec = document.createElement('span');
        rec.className = 'badge badge--rec';
        rec.textContent = 'Rec';
        badges.appendChild(rec);
      }
      if (m.free) {
        var fr = document.createElement('span');
        fr.className = 'badge badge--free';
        fr.textContent = 'Free';
        badges.appendChild(fr);
      }
      btn.appendChild(main);
      btn.appendChild(badges);
      btn.addEventListener('click', function() {
        setModel(m.id);
        var chat = getActiveChat();
        if (chat) {
          chat.model = m.id;
          saveChats();
        }
      });
      els.modelContent.appendChild(btn);
    });
  });
}

function applyModels(models, defaultId) {
  state.models = models && models.length ? models : fallbackModels();
  state.modelsById.clear();
  state.models.forEach(function(m) { state.modelsById.set(m.id, m); });
  if (!state.selectedModel && defaultId) {
    state.selectedModel = defaultId;
  }
  if (!state.modelsById.has(state.selectedModel) && state.models.length) {
    state.selectedModel = state.models[0].id;
  }
  var chat = getActiveChat();
  if (chat && chat.model && state.modelsById.has(chat.model)) {
    state.selectedModel = chat.model;
  }
  setModel(state.selectedModel);
  renderModels(els.modelSearch.value);
}

async function loadModels() {
  try {
    var res = await apiFetch('/api/models');
    if (!res.ok) throw new Error('Failed');
    var data = await res.json();
    applyModels(data.models || [], data.default);
  } catch (e) {
    applyModels(fallbackModels(), DEFAULT_MODEL);
  }
}

function scrollThread() {
  requestAnimationFrame(function() {
    els.thread.scrollTop = els.thread.scrollHeight;
  });
}

function renderEmptyState() {
  var empty = document.createElement('div');
  empty.className = 'thread-empty';

  var mark = document.createElement('img');
  mark.className = 'thread-empty__mark';
  mark.src = 'static/logo.png?v=1.6.0';
  mark.alt = '';

  var title = document.createElement('div');
  title.className = 'thread-empty__title';
  title.textContent = 'How can I help?';

  var sub = document.createElement('div');
  sub.className = 'thread-empty__subtitle';
  sub.textContent = 'Ask a question, write code, or explore a new idea.';

  var chips = document.createElement('div');
  chips.className = 'thread-empty__chips';
  [
    'Explain something simply',
    'Write code',
    'Generate an image of a neon city',
    'Fix my writing'
  ].forEach(function(text) {
    var chip = document.createElement('button');
    chip.className = 'suggestion';
    chip.type = 'button';
    chip.textContent = text;
    chip.addEventListener('click', function() {
      els.composerInput.value = text + ' ';
      els.composerInput.focus();
      autoResize();
      els.composerSend.disabled = false;
    });
    chips.appendChild(chip);
  });

  empty.appendChild(mark);
  empty.appendChild(title);
  empty.appendChild(sub);
  empty.appendChild(chips);
  els.thread.appendChild(empty);
}

function renderThread() {
  var chat = getActiveChat();
  els.thread.innerHTML = '';
  if (!chat || chat.messages.length === 0) {
    renderEmptyState();
    return;
  }
  chat.messages.forEach(function(msg, index) {
    if (msg.role === 'user') {
      renderUserMessage(msg);
    } else {
      renderAssistantMessage(msg);
    }
    if (index === chat.messages.length - 1) {
      var last = els.thread.lastElementChild;
      if (last) last.classList.add('message--enter');
    }
  });
  scrollThread();
}

function formatFileSize(bytes) {
  var size = Number(bytes) || 0;
  if (size < 1024) return size + ' B';
  if (size < 1024 * 1024) return (size / 1024).toFixed(1) + ' KB';
  if (size < 1024 * 1024 * 1024) return (size / (1024 * 1024)).toFixed(1) + ' MB';
  return (size / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
}

function resolveAssetUrl(path) {
  if (!path) return '';
  if (/^(https?:|data:|blob:)/i.test(path)) return path;
  return (apiBase || '') + path;
}

function attachmentIcon(mime) {
  if (!mime) {
    return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>';
  }
  if (mime.indexOf('image/') === 0) {
    return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><path d="M21 15l-5-5L5 21"></path></svg>';
  }
  if (mime.indexOf('video/') === 0) {
    return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="14" height="14" rx="2"></rect><polygon points="22 7 16 11 16 13 22 17 22 7"></polygon></svg>';
  }
  if (mime.indexOf('audio/') === 0) {
    return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg>';
  }
  return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="9" y1="15" x2="15" y2="15"></line></svg>';
}

function renderFileAttachment(container, file) {
  if (!file || !file.rawUrl) return;
  var raw = resolveAssetUrl(file.rawUrl);
  var share = resolveAssetUrl(file.url || file.rawUrl);
  var mime = String(file.mimeType || '');
  var wrap = document.createElement('div');
  wrap.className = 'message__attachment';
  if (mime.indexOf('image/') === 0) {
    var link = document.createElement('a');
    link.href = share;
    link.target = '_blank';
    link.rel = 'noopener';
    var img = document.createElement('img');
    img.src = raw;
    img.alt = file.name || 'Shared image';
    img.loading = 'lazy';
    link.appendChild(img);
    wrap.appendChild(link);
  } else if (mime.indexOf('video/') === 0) {
    var video = document.createElement('video');
    video.src = raw;
    video.controls = true;
    video.playsInline = true;
    video.preload = 'metadata';
    wrap.appendChild(video);
  } else if (mime.indexOf('audio/') === 0) {
    var audio = document.createElement('audio');
    audio.src = raw;
    audio.controls = true;
    audio.preload = 'metadata';
    wrap.appendChild(audio);
  }
  var card = document.createElement('a');
  card.className = 'attachment-card';
  card.href = share;
  card.target = '_blank';
  card.rel = 'noopener';
  var icon = document.createElement('span');
  icon.className = 'attachment-card__icon';
  icon.innerHTML = attachmentIcon(mime);
  var body = document.createElement('span');
  body.className = 'attachment-card__body';
  var name = document.createElement('span');
  name.className = 'attachment-card__name';
  name.textContent = file.name || 'Shared file';
  var meta = document.createElement('span');
  meta.className = 'attachment-card__meta';
  meta.textContent = formatFileSize(file.size) + ' · tap to share';
  body.appendChild(name);
  body.appendChild(meta);
  card.appendChild(icon);
  card.appendChild(body);
  wrap.appendChild(card);
  container.appendChild(wrap);
}

function openShareModal(file) {
  if (!file || !els.shareModal) return;
  var link = file.url || file.shareUrl || file.rawUrl || '';
  if (link) link = resolveAssetUrl(link);
  if (els.shareUrlInput) els.shareUrlInput.value = link;
  if (els.shareFileMeta) {
    els.shareFileMeta.textContent = '';
    var icon = document.createElement('span');
    icon.innerHTML = attachmentIcon(file.mimeType);
    if (icon.firstChild) els.shareFileMeta.appendChild(icon.firstChild);
    var info = document.createElement('span');
    info.textContent = (file.name || 'Shared file') + ' · ' + formatFileSize(file.size);
    els.shareFileMeta.appendChild(info);
  }
  if (els.shareOpenLink) els.shareOpenLink.href = link;
  if (els.shareNativeBtn) els.shareNativeBtn.hidden = !(navigator.share);
  els.shareModal.hidden = false;
  if (els.shareCopyBtn) els.shareCopyBtn.textContent = 'Copy link';
}

function closeShareModal() {
  if (els.shareModal) els.shareModal.hidden = true;
}

function shareLinkToOthers() {
  var link = els.shareUrlInput ? els.shareUrlInput.value : '';
  if (!link || !navigator.share) return;
  navigator.share({
    title: 'Rebbet AI',
    text: 'Shared with Rebbet AI',
    url: link
  }).catch(function() {});
}

function readFileAsDataURL(file) {
  return new Promise(function(resolve, reject) {
    var reader = new FileReader();
    reader.onload = function() { resolve(String(reader.result || '')); };
    reader.onerror = function() { reject(reader.error || new Error('Could not read file')); };
    reader.readAsDataURL(file);
  });
}

async function uploadFile(file) {
  if (!file) return;
  var limit = (state.appConfig && state.appConfig.max_upload_mb) || 25;
  if (file.size > limit * 1024 * 1024) {
    showToast('File is larger than ' + limit + ' MB');
    return;
  }
  if (els.attachBtn) els.attachBtn.classList.add('is-uploading');
  showToast('Uploading ' + file.name + '…');
  try {
    var dataUrl = await readFileAsDataURL(file);
    var response = await apiFetch('/api/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: file.name, mimeType: file.type || '', data: dataUrl })
    });
    var payload = {};
    try { payload = await response.json(); } catch (e) {}
    if (!response.ok) {
      throw new Error((payload.error && payload.error.message) || 'Upload failed');
    }
    var shared = payload.file;
    var chat = getActiveChat();
    if (!chat) {
      createChat(false);
      chat = getActiveChat();
    }
    if (!chat) throw new Error('Could not open a chat');
    var msg = {
      id: uid(),
      role: 'user',
      content: 'Shared ' + (shared.name || 'file'),
      file: shared,
      time: nowTime()
    };
    chat.messages.push(msg);
    if (chat.title === 'New chat') updateChatTitle(chat);
    saveChats();
    renderThread();
    openShareModal(shared);
    showToast('Link ready — copy or share it');
  } catch (error) {
    showToast(error && error.message ? error.message : 'Upload failed');
  } finally {
    if (els.attachBtn) els.attachBtn.classList.remove('is-uploading');
    if (els.fileInput) els.fileInput.value = '';
  }
}

async function loadAppConfig() {
  try {
    var response = await apiFetch('/api/app-config', { cache: 'no-store' });
    if (!response.ok) return;
    var config = await response.json();
    state.appConfig = config;
    applyAppConfig(config);
  } catch (e) {}
}

function applyAppConfig(config) {
  if (!config) return;
  if (config.icon) {
    var iconUrl = resolveAssetUrl(config.icon);
    if (els.appFavicon) els.appFavicon.href = iconUrl;
    if (els.appTouchIcon) els.appTouchIcon.href = iconUrl;
  }
  if (els.updateBtn && config.update_available && config.update_url) {
    els.updateBtn.hidden = false;
    els.updateBtn.title = config.update_message || ('Update to v' + (config.version || ''));
    els.updateBtn.addEventListener('click', function() {
      window.open(resolveAssetUrl(config.update_url), '_blank', 'noopener');
    });
  }
}

function renderUserMessage(msg) {
  var chat = getActiveChat();
  var idx = chat ? chat.messages.indexOf(msg) : -1;
  var wrap = document.createElement('div');
  wrap.className = 'message';
  var meta = document.createElement('div');
  meta.className = 'message__meta';
  meta.style.justifyContent = 'flex-end';
  var name = document.createElement('div');
  name.className = 'message__name';
  name.textContent = 'You';
  var time = document.createElement('div');
  time.className = 'message__time';
  time.textContent = msg.time || nowTime();
  meta.appendChild(time);
  meta.appendChild(name);
  var avatar = document.createElement('div');
  avatar.className = 'message__avatar message__avatar--user';
  avatar.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="8" r="4"></circle><path d="M12 14c-6 0-8 3-8 4v2h16v-2c0-1-2-4-8-4z"></path></svg>';
  meta.appendChild(avatar);
  var bubble = document.createElement('div');
  bubble.className = 'message__bubble message__bubble--user';
  var content = document.createElement('div');
  content.className = 'message__content';
  var p = document.createElement('p');
  p.textContent = msg.content;
  content.appendChild(p);
  if (msg.file) renderFileAttachment(content, msg.file);
  bubble.appendChild(content);
  var actions = document.createElement('div');
  actions.className = 'message__actions';
  actions.style.justifyContent = 'flex-end';
  var editBtn = document.createElement('button');
  editBtn.className = 'chip';
  editBtn.textContent = 'Edit';
  editBtn.addEventListener('click', function() {
    if (idx >= 0) editUserMessage(idx);
  });
  actions.appendChild(editBtn);
  if (msg.file && (msg.file.url || msg.file.rawUrl)) {
    var copyBtn = document.createElement('button');
    copyBtn.className = 'chip';
    copyBtn.textContent = 'Copy link';
    copyBtn.addEventListener('click', function() { copyText(msg.file.url || msg.file.rawUrl); showToast('Copied'); });
    actions.appendChild(copyBtn);
    var shareBtn = document.createElement('button');
    shareBtn.className = 'chip';
    shareBtn.textContent = 'Share';
    shareBtn.addEventListener('click', function() { openShareModal(msg.file); });
    actions.appendChild(shareBtn);
    var openLink = document.createElement('a');
    openLink.className = 'chip';
    openLink.href = msg.file.url || msg.file.rawUrl;
    openLink.target = '_blank';
    openLink.rel = 'noopener';
    openLink.textContent = 'Open';
    actions.appendChild(openLink);
  }
  wrap.appendChild(meta);
  wrap.appendChild(bubble);
  wrap.appendChild(actions);
  els.thread.appendChild(wrap);
}

function copyText(text) {
  if (!text) return;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(function() {
      showToast('Copied');
    }).catch(function() {
      fallbackCopy(text);
    });
    return;
  }
  fallbackCopy(text);
}

function fallbackCopy(text) {
  var area = document.createElement('textarea');
  area.value = text;
  area.setAttribute('readonly', '');
  area.style.position = 'fixed';
  area.style.opacity = '0';
  document.body.appendChild(area);
  area.select();
  try {
    document.execCommand('copy');
    showToast('Copied');
  } catch (e) {
    showToast('Could not copy');
  }
  area.remove();
}

function renderAssistantMessage(msg) {
  var wrap = document.createElement('div');
  wrap.className = 'message';
  var meta = document.createElement('div');
  meta.className = 'message__meta';
  var avatar = document.createElement('div');
  avatar.className = 'message__avatar message__avatar--assistant';
  avatar.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"></circle><path d="M12 1v6m0 6v6M4.22 4.22l4.24 4.24m5.08 5.08l4.24 4.24M1 12h6m6 0h6M4.22 19.78l4.24-4.24m5.08-5.08l4.24-4.24"></path></svg>';
  var name = document.createElement('div');
  name.className = 'message__name';
  name.textContent = msg.modelLabel || 'Rebbet AI';
  var time = document.createElement('div');
  time.className = 'message__time';
  time.textContent = msg.time || nowTime();
  meta.appendChild(avatar);
  meta.appendChild(name);
  meta.appendChild(time);
  var bubble = document.createElement('div');
  bubble.className = 'message__bubble message__bubble--assistant';
  var content = document.createElement('div');
  content.className = 'message__content';
  if (msg.html) {
    content.innerHTML = msg.html;
  } else {
    var p = document.createElement('p');
    p.textContent = msg.content;
    content.appendChild(p);
  }
  if (msg.image) {
    var image = document.createElement('img');
    image.src = msg.image;
    image.alt = msg.imageAlt || msg.content || 'Generated image';
    image.loading = 'lazy';
    image.className = 'message__image';
    content.appendChild(image);
  }
  bubble.appendChild(content);
  var actions = document.createElement('div');
  actions.className = 'message__actions';
  var copyBtn = document.createElement('button');
  copyBtn.className = 'chip';
  copyBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg> Copy';
  copyBtn.addEventListener('click', function() {
    copyText(msg.raw || msg.content || '');
  });
  actions.appendChild(copyBtn);
  var speakBtn = document.createElement('button');
  speakBtn.className = 'chip';
  speakBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path><path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path></svg> Speak';
  speakBtn.addEventListener('click', function() {
    speak(msg.content || msg.raw || '');
  });
  actions.appendChild(speakBtn);
  if (msg.image) {
    var downloadBtn = document.createElement('button');
    downloadBtn.className = 'chip';
    downloadBtn.textContent = 'Download';
    downloadBtn.addEventListener('click', function() {
      var link = document.createElement('a');
      link.href = msg.image;
      link.download = msg.image.indexOf('image/png') === 5 ? 'rebbet-ai-image.png' : 'rebbet-ai-image.jpg';
      document.body.appendChild(link);
      link.click();
      link.remove();
    });
    actions.appendChild(downloadBtn);
  }
  if (!msg.image) {
    var regenBtn = document.createElement('button');
    regenBtn.className = 'chip';
    regenBtn.textContent = 'Regenerate';
    regenBtn.addEventListener('click', function() {
      var chat = getActiveChat();
      if (!chat) return;
      chat.messages = chat.messages.slice(0, -1);
      saveChats();
      renderThread();
      sendMessage();
    });
    actions.appendChild(regenBtn);
  }
  wrap.appendChild(meta);
  wrap.appendChild(bubble);
  wrap.appendChild(actions);
  els.thread.appendChild(wrap);
}

function renderStreamingPlaceholder(chat, options) {
  options = options || {};
  var kind = options.kind || 'text';
  var label = options.label || (kind === 'image' ? 'Creating your image' : 'Thinking');
  var wrap = document.createElement('div');
  wrap.className = 'message message--streaming';
  wrap.id = 'streamingWrap';
  var meta = document.createElement('div');
  meta.className = 'message__meta';
  var avatar = document.createElement('div');
  avatar.className = 'message__avatar message__avatar--assistant message__avatar--busy';
  avatar.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"></circle><path d="M12 1v6m0 6v6M4.22 4.22l4.24 4.24m5.08 5.08l4.24 4.24M1 12h6m6 0h6M4.22 19.78l4.24-4.24m5.08-5.08l4.24-4.24"></path></svg>';
  var name = document.createElement('div');
  name.className = 'message__name';
  name.textContent = state.modelsById.get(state.selectedModel)?.label || state.selectedModel || 'Rebbet AI';
  var time = document.createElement('div');
  time.className = 'message__time';
  time.textContent = nowTime();
  meta.appendChild(avatar);
  meta.appendChild(name);
  meta.appendChild(time);

  var typing = document.createElement('div');
  typing.className = 'typing';
  var dots = document.createElement('div');
  dots.className = 'typing__dots';
  var d1 = document.createElement('div');
  d1.className = 'typing__dot';
  var d2 = document.createElement('div');
  d2.className = 'typing__dot';
  var d3 = document.createElement('div');
  d3.className = 'typing__dot';
  dots.appendChild(d1);
  dots.appendChild(d2);
  dots.appendChild(d3);
  var head = document.createElement('div');
  head.className = 'typing__head';
  head.appendChild(dots);
  var labelEl = document.createElement('span');
  labelEl.className = 'typing__label';
  labelEl.textContent = label;
  head.appendChild(labelEl);
  var wave = document.createElement('span');
  wave.className = 'typing__wave';
  wave.setAttribute('aria-hidden', 'true');
  wave.innerHTML = '<i></i><i></i><i></i><i></i>';
  head.appendChild(wave);
  typing.appendChild(head);

  if (kind === 'image') {
    typing.className += ' typing--image';
    var skeleton = document.createElement('div');
    skeleton.className = 'image-skeleton';
    skeleton.innerHTML =
      '<div class="image-skeleton__grid"></div>' +
      '<div class="image-skeleton__glow"></div>' +
      '<div class="image-skeleton__sweep"></div>' +
      '<div class="image-skeleton__scan"></div>' +
      '<div class="image-skeleton__icon">' +
      '<svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
      '<rect x="3" y="3" width="18" height="18" rx="3"></rect>' +
      '<circle cx="8.5" cy="8.5" r="1.5"></circle>' +
      '<path d="m21 15-4.35-4.35a2 2 0 0 0-2.83 0L4 21"></path>' +
      '</svg></div>' +
      '<div class="image-skeleton__phases" aria-hidden="true">' +
      '<span>Composing the scene</span>' +
      '<span>Rendering details</span>' +
      '<span>Adding final polish</span>' +
      '</div>' +
      '<div class="image-skeleton__progress" aria-hidden="true"><i></i></div>';
    typing.appendChild(skeleton);
  }

  wrap.appendChild(meta);
  wrap.appendChild(typing);
  els.thread.appendChild(wrap);
  scrollThread();
}

function updateStreamingBubble(text, thinking) {
  var existing = document.getElementById('streamingWrap');
  if (!existing) return;
  var typing = existing.querySelector('.typing');
  if (typing) typing.remove();
  existing.classList.remove('message--streaming');
  existing.classList.add('message--live');
  var bubble = existing.querySelector('.message__bubble');
  if (!bubble) {
    bubble = document.createElement('div');
    bubble.className = 'message__bubble message__bubble--assistant';
    existing.appendChild(bubble);
  }
  var content = bubble.querySelector('.message__content');
  if (!content) {
    content = document.createElement('div');
    content.className = 'message__content';
    bubble.appendChild(content);
  }
  if (text && text.length) {
    if (window.marked && window.DOMPurify) {
      var html = DOMPurify.sanitize(marked.parse(text));
      content.innerHTML = html;
    } else {
      content.textContent = text;
    }
  }
  var caret = document.createElement('span');
  caret.className = 'stream-caret';
  caret.setAttribute('aria-hidden', 'true');
  content.appendChild(caret);
  scrollThread();
}

function removeStreamingPlaceholder() {
  var existing = document.getElementById('streamingWrap');
  if (existing) existing.remove();
}

function extractImagePrompt(text) {
  var value = String(text || '').trim();
  var slash = value.match(/^\/(?:image|imagine)\b\s*([\s\S]*)$/i);
  if (slash) return slash[1].trim();
  var intent = value.match(/^(?:generate|create|draw|make|render)\s+(?:me\s+)?(?:an?\s+)?(?:image|picture|photo|art|drawing|illustration)\s*(?:of|showing|with|depicting|:)\s*([\s\S]+)$/i);
  if (intent) return intent[1].trim();
  return null;
}

function blobToDataUrl(blob) {
  return new Promise(function(resolve, reject) {
    var reader = new FileReader();
    reader.onload = function() { resolve(reader.result); };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

function shrinkImage(blob) {
  return new Promise(function(resolve) {
    var url = URL.createObjectURL(blob);
    var image = new Image();
    image.onload = function() {
      try {
        var max = 768;
        var width = image.naturalWidth;
        var height = image.naturalHeight;
        var scale = Math.min(1, max / Math.max(width, height));
        width = Math.max(1, Math.round(width * scale));
        height = Math.max(1, Math.round(height * scale));
        var canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(image, 0, 0, width, height);
        var data = canvas.toDataURL('image/jpeg', 0.87);
        URL.revokeObjectURL(url);
        resolve(data);
      } catch (e) {
        URL.revokeObjectURL(url);
        blobToDataUrl(blob).then(resolve).catch(function() { resolve(''); });
      }
    };
    image.onerror = function() {
      URL.revokeObjectURL(url);
      blobToDataUrl(blob).then(resolve).catch(function() { resolve(''); });
    };
    image.src = url;
  });
}

async function generateImage(promptText) {
  var chat = getActiveChat();
  if (!chat) return;
  var prompt = String(promptText || '').trim();
  if (!prompt) {
    showToast('Describe the image you want');
    return;
  }
  if (state.sending) return;
  chat.messages.push({ role: 'user', content: prompt, time: nowTime() });
  updateChatTitle(chat);
  saveChats();
  renderThread();
  els.composerInput.value = '';
  autoResize();
  state.sending = true;
  els.composerSend.disabled = true;
  els.composerSend.classList.add('is-busy');
  renderStreamingPlaceholder(chat, { label: 'Creating your image', kind: 'image' });
  try {
    var res = await apiFetch('/api/image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: prompt, width: 768, height: 768 })
    });
    if (!res.ok) {
      var info = null;
      try { info = await res.json(); } catch (e) {}
      var message = info && info.error && info.error.message ? info.error.message : 'Image generation failed';
      var hint = info && info.error && info.error.hint ? info.error.hint : '';
      throw new Error(message + (hint ? ' ' + hint : ''));
    }
    var blob = await res.blob();
    if (!blob || !blob.size) throw new Error('The image service returned an empty image.');
    var imageData = await shrinkImage(blob);
    if (!imageData) throw new Error('Could not read the generated image.');
    var source = res.headers.get('X-Image-Source') || '';
    removeStreamingPlaceholder();
    chat.messages.push({
      role: 'assistant',
      content: 'Generated image: ' + prompt,
      raw: prompt,
      image: imageData,
      imageAlt: prompt,
      time: nowTime(),
      modelLabel: source === 'gemini' ? 'Rebbet Image' : 'Rebbet Image (free)'
    });
    saveChats();
    renderThread();
    scrollThread();
    trackEvent('image_generated', { source: source || 'unknown' });
    showToast('Image ready');
  } catch (e) {
    removeStreamingPlaceholder();
    chat.messages.push({
      role: 'assistant',
      content: 'Image generation failed. ' + (e && e.message ? e.message : ''),
      raw: 'Image generation failed',
      time: nowTime(),
      modelLabel: 'Rebbet Image'
    });
    saveChats();
    renderThread();
    showToast('Image failed');
  } finally {
    state.sending = false;
    els.composerSend.disabled = false;
    els.composerSend.classList.remove('is-busy');
  }
}

async function sendMessage() {
  var chat = getActiveChat();
  if (!chat) return;
  var text = els.composerInput.value.replace(/\r\n/g, '\n').trim();
  if (!text || state.sending) return;
  var imagePrompt = extractImagePrompt(text);
  if (imagePrompt !== null) {
    if (!imagePrompt) {
      showToast('Add a description after /image');
      return;
    }
    await generateImage(imagePrompt);
    return;
  }
  var model = chat.model || state.selectedModel || DEFAULT_MODEL;
  trackEvent('chat_request', { model: model, web_search: !!webSearchEnabled });
  var userMsg = {
    role: 'user',
    content: text,
    time: nowTime()
  };
  chat.messages.push(userMsg);
  updateChatTitle(chat);
  saveChats();
  renderThread();
  els.composerInput.value = '';
  autoResize();
  state.sending = true;
  els.composerSend.disabled = true;
  els.composerSend.classList.add('is-busy');
  renderStreamingPlaceholder(chat, { label: webSearchEnabled ? 'Searching the web' : 'Thinking' });

  try {
    var history = chat.messages.slice(-20).map(function(m) {
      return apiMessage(m);
    });
    var res;
    try {
      res = await apiFetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: model,
          messages: history,
          web_search: webSearchEnabled
        })
      });
    } catch (e) {
      resetApiBase();
      removeStreamingPlaceholder();
      var assistantMsgNet2 = {
        role: 'assistant',
        content: 'Network error. Check that the server is running at http://127.0.0.1:8765 and reachable. (' + e + ')',
        raw: String(e),
        time: nowTime(),
        modelLabel: state.modelsById.get(model)?.label || model
      };
      if (window.marked && window.DOMPurify) {
        assistantMsgNet2.html = DOMPurify.sanitize(marked.parse(assistantMsgNet2.content));
      }
      chat.messages.push(assistantMsgNet2);
      saveChats();
      renderThread();
      showToast('Connection failed');
      state.sending = false;
      els.composerSend.disabled = false;
      return;
    }

    if (!res.ok) {
      var errJson = null;
      try { errJson = await res.json(); } catch(e) {}
      var errMsg = errJson && errJson.error && errJson.error.message ? errJson.error.message : ('Error: ' + res.status);
      var hint = errJson && errJson.error && errJson.error.hint ? errJson.error.hint : '';
      removeStreamingPlaceholder();
      var assistantMsg = {
        role: 'assistant',
        content: errMsg + (hint ? '\n\n' + hint : ''),
        raw: errMsg,
        time: nowTime(),
        modelLabel: state.modelsById.get(model)?.label || model
      };
      if (window.marked && window.DOMPurify) {
        assistantMsg.html = DOMPurify.sanitize(marked.parse(assistantMsg.content));
      }
      chat.messages.push(assistantMsg);
      saveChats();
      renderThread();
      showToast('Request failed');
      return;
    }

    var reader = res.body.getReader();
    var decoder = new TextDecoder();
    var buffer = '';
    var fullText = '';
    var usage = null;
    var activeModel = model;
    var activeProvider = '';

    while (true) {
      var result = await reader.read();
      if (result.done) break;
      buffer += decoder.decode(result.value, { stream: true });
      var parts = buffer.split('\n\n');
      buffer = parts.pop();
      for (var i = 0; i < parts.length; i++) {
        var chunk = parts[i];
        if (!chunk.startsWith('data:')) continue;
        var jsonStr = chunk.slice(5).trim();
        if (!jsonStr) continue;
        try {
          var ev = JSON.parse(jsonStr);
        } catch(e) {
          continue;
        }
        if (ev.type === 'meta') {
          activeModel = ev.model || model;
          activeProvider = ev.provider || '';
          var streamWrap = document.getElementById('streamingWrap');
          if (streamWrap) {
            var streamName = streamWrap.querySelector('.message__name');
            if (streamName) {
              streamName.textContent = state.modelsById.get(activeModel)?.label || activeModel;
            }
          }
          if (ev.switched) {
            var switchedLabel = state.modelsById.get(activeModel)?.label || activeModel;
            showToast('Switched to ' + switchedLabel);
            trackEvent('model_switched', {
              requested_model: model,
              model: activeModel,
              provider: activeProvider
            });
          }
        } else if (ev.type === 'delta' && typeof ev.text === 'string') {
          fullText += ev.text;
          updateStreamingBubble(fullText);
        } else if (ev.type === 'thinking') {
          // show subtle indicator is handled by placeholder
        } else if (ev.type === 'error') {
          removeStreamingPlaceholder();
          var errContent = ev.message || 'Unknown error';
          if (ev.hint) errContent += '\n\n' + ev.hint;
          var assistantMsgErr = {
            role: 'assistant',
            content: errContent,
            raw: ev.message || errContent,
            time: nowTime(),
            modelLabel: state.modelsById.get(activeModel)?.label || activeModel
          };
          if (window.marked && window.DOMPurify) {
            assistantMsgErr.html = DOMPurify.sanitize(marked.parse(assistantMsgErr.content));
          }
          chat.messages.push(assistantMsgErr);
          saveChats();
          renderThread();
          showToast('Error');
          state.sending = false;
          els.composerSend.disabled = false;
          return;
        } else if (ev.type === 'done') {
          usage = ev.usage || null;
        }
      }
    }

    removeStreamingPlaceholder();
    if (fullText.length) {
      var assistantMsg = {
        role: 'assistant',
        content: fullText,
        raw: fullText,
        time: nowTime(),
        modelLabel: state.modelsById.get(activeModel)?.label || activeModel,
        provider: activeProvider
      };
      if (window.marked && window.DOMPurify) {
        assistantMsg.html = DOMPurify.sanitize(marked.parse(fullText));
      }
      chat.messages.push(assistantMsg);
      saveChats();
      renderThread();
      trackEvent('chat_response', {
        model: activeModel,
        provider: activeProvider,
        web_search: !!webSearchEnabled
      });
      if (voice.enabled) speak(fullText);
    } else {
      showToast('Empty response');
    }
  } catch (e) {
    resetApiBase();
    removeStreamingPlaceholder();
    var assistantMsgNet = {
      role: 'assistant',
      content: 'Network error. Check that the server is running and reachable.',
      raw: 'Network error',
      time: nowTime(),
      modelLabel: state.modelsById.get(model)?.label || model
    };
    if (window.marked && window.DOMPurify) {
      assistantMsgNet.html = DOMPurify.sanitize(marked.parse(assistantMsgNet.content));
    }
    chat.messages.push(assistantMsgNet);
    saveChats();
    renderThread();
    showToast('Connection failed');
  } finally {
    state.sending = false;
    els.composerSend.disabled = false;
    els.composerSend.classList.remove('is-busy');
  }
}

function autoResize() {
  var ta = els.composerInput;
  ta.style.height = 'auto';
  ta.style.height = Math.min(140, ta.scrollHeight) + 'px';
}

els.menuBtn.addEventListener('click', openSidebar);
els.sidebarClose.addEventListener('click', closeSidebar);
els.sidebarBackdrop.addEventListener('click', closeSidebar);
els.sidebarNew.addEventListener('click', function() { createChat(false); });
els.newChatBtn.addEventListener('click', function() { createChat(false); });

els.modelTrigger.addEventListener('click', openModelSheet);
els.modelBackdrop.addEventListener('click', closeModelSheet);
els.modelClose.addEventListener('click', closeModelSheet);
els.modelSearch.addEventListener('input', function() {
  renderModels(els.modelSearch.value);
});

els.composerInput.addEventListener('input', function() {
  autoResize();
  els.composerSend.disabled = state.sending || !els.composerInput.value.trim();
});

els.composerInput.addEventListener('keydown', function(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

els.composerSend.addEventListener('click', sendMessage);
els.composerSend.disabled = true;
if (els.callBtn) els.callBtn.addEventListener('click', startVoiceCall);
if (els.callEnd) els.callEnd.addEventListener('click', endVoiceCall);
if (els.callMute) els.callMute.addEventListener('click', toggleCallMute);
if (els.callOrb) els.callOrb.addEventListener('click', handleCallOrb);
els.composerMic.addEventListener('click', toggleRecording);
if (els.attachBtn) {
  els.attachBtn.addEventListener('click', function() {
    if (els.fileInput) els.fileInput.click();
  });
}
if (els.fileInput) {
  els.fileInput.addEventListener('change', function() {
    var file = els.fileInput.files && els.fileInput.files[0];
    if (file) uploadFile(file);
  });
}
if (els.shareBackdrop) els.shareBackdrop.addEventListener('click', closeShareModal);
if (els.shareCopyBtn) {
  els.shareCopyBtn.addEventListener('click', function() {
    copyText(els.shareUrlInput ? els.shareUrlInput.value : '');
    els.shareCopyBtn.textContent = 'Copied';
  });
}
if (els.shareNativeBtn) els.shareNativeBtn.addEventListener('click', shareLinkToOthers);
if (els.thread) {
  ['dragenter', 'dragover'].forEach(function(name) {
    els.thread.addEventListener(name, function(e) {
      e.preventDefault();
      els.thread.classList.add('is-dragging');
    });
  });
  ['dragleave', 'drop'].forEach(function(name) {
    els.thread.addEventListener(name, function(e) {
      e.preventDefault();
      els.thread.classList.remove('is-dragging');
    });
  });
  els.thread.addEventListener('drop', function(e) {
    var file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (file) uploadFile(file);
  });
}
els.composerInput.addEventListener('paste', function(e) {
  var file = e.clipboardData && e.clipboardData.files && e.clipboardData.files[0];
  if (file) {
    e.preventDefault();
    uploadFile(file);
  }
});
if (els.composerImage) {
  els.composerImage.addEventListener('click', function() {
    var text = els.composerInput.value.trim();
    var imagePrompt = extractImagePrompt(text);
    if (imagePrompt === null || !imagePrompt) {
      imagePrompt = window.prompt('Describe the image you want', text || '');
    }
    if (imagePrompt && imagePrompt.trim()) {
      generateImage(imagePrompt.trim());
    }
  });
}
els.voiceToggle.addEventListener('click', openVoiceSheet);
if (els.voiceBackdrop) els.voiceBackdrop.addEventListener('click', closeVoiceSheet);
if (els.voiceClose) els.voiceClose.addEventListener('click', closeVoiceSheet);
var voiceEnableRow = document.getElementById('voiceEnableRow');
if (voiceEnableRow) voiceEnableRow.addEventListener('click', toggleVoice);
var voiceSpeedGroup = document.getElementById('voiceSpeedGroup');
if (voiceSpeedGroup) {
  voiceSpeedGroup.addEventListener('click', function(e) {
    var btn = e.target && e.target.closest ? e.target.closest('button[data-speed]') : null;
    if (!btn) return;
    voice.speed = btn.getAttribute('data-speed') || 'fast';
    saveVoicePref('rebbet_voice_speed', voice.speed);
    updateVoiceControls();
  });
}
if (els.voiceSelect) {
  els.voiceSelect.addEventListener('change', function() {
    voice.id = els.voiceSelect.value;
    saveVoicePref('rebbet_voice_id', voice.id);
    stopVoicePreview();
  });
}
if (els.voiceModelSelect) {
  els.voiceModelSelect.addEventListener('change', function() {
    voice.model = els.voiceModelSelect.value;
    saveVoicePref('rebbet_voice_model', voice.model);
  });
}
if (els.voicePreviewBtn) els.voicePreviewBtn.addEventListener('click', previewVoice);
if (els.searchToggle) {
  els.searchToggle.addEventListener('click', toggleWebSearch);
}

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    closeModelSheet();
    closeVoiceSheet();
    closeSidebar();
    closeShareModal();
  }
});

loadChats();
loadModels();
loadAppConfig();
loadVoicePref();
loadWebSearchPref();
autoResize();
