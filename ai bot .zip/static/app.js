const DEFAULT_MODEL = 'gemini-3.6-flash';
const API_PORTS = [8917, 8765, 8766, 8767, 8768, 8769, 8770, 8771, 8772, 8773, 8774, 8775];
const FALLBACK_MODELS = [
  'gemini-3.8-flash',
  'gemini-3.7-flash',
  'gemini-3.6-flash',
  'gemini-3.5-flash',
  'gemini-3.5-flash-lite',
  'gemini-flash-latest',
  'gemini-flash-lite-latest',
  'gemini-3.1-flash-lite',
  'gpt-5-nano',
  'gpt-5.4-nano'
];

function fallbackModelLabel(id) {
  return String(id || '')
    .replace(/-/g, ' ')
    .replace(/\b\w/g, function(c) { return c.toUpperCase(); });
}

function fallbackModelFamily(id) {
  if (/^gemini-/i.test(id)) return 'google';
  if (/^(gpt|o[134])/i.test(id)) return 'openai';
  return 'other';
}

function fallbackModels() {
  return FALLBACK_MODELS.map(function(id) {
    return {
      id: id,
      label: fallbackModelLabel(id),
      family: fallbackModelFamily(id),
      free: /nano|mini|flash|lite/i.test(id),
      recommended: /^(gemini-3\.8-flash|gpt-5-nano)$/i.test(id)
    };
  });
}

function readCookie(name) {
  try {
    var prefix = name + '=';
    var parts = document.cookie ? document.cookie.split('; ') : [];
    for (var i = 0; i < parts.length; i++) {
      if (parts[i].indexOf(prefix) === 0) {
        return decodeURIComponent(parts[i].slice(prefix.length));
      }
    }
  } catch (e) {}
  return '';
}

function newClientId() {
  var raw = '';
  try {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      raw = window.crypto.randomUUID().replace(/-/g, '');
    }
  } catch (e) {}
  if (!raw) {
    raw = Math.random().toString(36).slice(2) + Date.now().toString(36) + Math.random().toString(36).slice(2);
  }
  raw = raw.replace(/[^A-Za-z0-9]/g, '').slice(0, 40);
  return 'u_' + raw;
}

function getClientId() {
  var id = '';
  try { id = localStorage.getItem('rebbet_client_id') || ''; } catch (e) {}
  if (!id) id = readCookie('rebbet_client_id');
  if (!/^[A-Za-z0-9_-]{6,80}$/.test(id)) id = newClientId();
  try { localStorage.setItem('rebbet_client_id', id); } catch (e) {}
  try {
    document.cookie = 'rebbet_client_id=' + encodeURIComponent(id) + '; Max-Age=31536000; Path=/; SameSite=Lax';
  } catch (e) {}
  return id;
}

window.rebbetUserId = getClientId();

let apiBase = null;
let apiBasePromise = null;

function candidateApiBases() {
  const bases = [];
  if (location.protocol === 'http:' || location.protocol === 'https:') {
    bases.push(location.origin);
  }
  API_PORTS.forEach(function(port) {
    bases.push('http://127.0.0.1:' + port);
    bases.push('http://localhost:' + port);
  });
  return bases.filter(function(base, index) {
    return bases.indexOf(base) === index;
  });
}

async function probeApiBase(base) {
  const controller = new AbortController();
  const timer = setTimeout(function() { controller.abort(); }, 1500);
  try {
    const res = await fetch(base + '/api/health', {
      cache: 'no-store',
      signal: controller.signal
    });
    if (!res.ok) return false;
    const data = await res.json();
    return !!(data && data.ok);
  } catch (e) {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

function resolveApiBase() {
  if (apiBase !== null) return Promise.resolve(apiBase);
  if (!apiBasePromise) {
    apiBasePromise = (async function() {
      const bases = candidateApiBases();
      for (let i = 0; i < bases.length; i++) {
        if (await probeApiBase(bases[i])) {
          apiBase = bases[i];
          return apiBase;
        }
      }
      apiBase = '';
      return apiBase;
    })();
  }
  return apiBasePromise;
}

function resetApiBase() {
  apiBase = null;
  apiBasePromise = null;
}

async function apiFetch(path, options) {
  const base = await resolveApiBase();
  const opts = Object.assign({}, options || {});
  const headers = new Headers(opts.headers || {});
  if (window.rebbetUserId && !headers.has('X-Rebbet-User')) {
    headers.set('X-Rebbet-User', window.rebbetUserId);
  }
  opts.headers = headers;
  return fetch(base + path, opts);
}

var voice = {
  enabled: false,
  recording: false,
  chunks: [],
  stream: null,
  audioContext: null,
  source: null,
  processor: null,
  recordTimer: null,
  audio: null,
  audioUrl: null,
  id: '',
  model: '',
  speed: 'fast',
  voices: [],
  models: [],
  loaded: false,
  loading: false,
  warning: '',
  previewAudio: null
};

function loadVoicePref() {
  try {
    voice.enabled = localStorage.getItem('rebbet_voice') === '1';
    voice.id = localStorage.getItem('rebbet_voice_id') || '';
    voice.model = localStorage.getItem('rebbet_voice_model') || '';
    voice.speed = localStorage.getItem('rebbet_voice_speed') || 'fast';
  } catch (e) {
    voice.enabled = false;
  }
  if (['fast', 'normal', 'slow'].indexOf(voice.speed) < 0) voice.speed = 'fast';
  updateVoiceToggle();
  updateVoiceControls();
}

function saveVoicePref(key, value) {
  try {
    if (value) localStorage.setItem(key, value);
    else localStorage.removeItem(key);
  } catch (e) {}
}

let webSearchEnabled = true;

function loadWebSearchPref() {
  try {
    webSearchEnabled = localStorage.getItem('rebbet_websearch') !== '0';
  } catch (e) {
    webSearchEnabled = true;
  }
  updateSearchToggle();
}

function updateSearchToggle() {
  if (els.menuSearchState) els.menuSearchState.textContent = webSearchEnabled ? 'On' : 'Off';
  if (!els.searchToggle) return;
  els.searchToggle.classList.toggle('is-on', webSearchEnabled);
  els.searchToggle.setAttribute('aria-pressed', webSearchEnabled ? 'true' : 'false');
  els.searchToggle.setAttribute('aria-label', webSearchEnabled ? 'Web search on' : 'Web search off');
}

function toggleWebSearch() {
  webSearchEnabled = !webSearchEnabled;
  try {
    localStorage.setItem('rebbet_websearch', webSearchEnabled ? '1' : '0');
  } catch (e) {}
  updateSearchToggle();
  showToast(webSearchEnabled ? 'Web search enabled' : 'Web search disabled');
}

function updateVoiceToggle() {
  if (!els.voiceToggle) return;
  els.voiceToggle.classList.toggle('is-on', voice.enabled);
  els.voiceToggle.setAttribute('aria-pressed', voice.enabled ? 'true' : 'false');
  els.voiceToggle.setAttribute('aria-label', voice.enabled ? 'Voice replies on' : 'Voice replies off');
  var row = document.getElementById('voiceEnableRow');
  if (row) {
    row.classList.toggle('is-on', voice.enabled);
    row.setAttribute('aria-pressed', voice.enabled ? 'true' : 'false');
  }
}

function updateVoiceControls() {
  var speeds = document.querySelectorAll('#voiceSpeedGroup button');
  for (var i = 0; i < speeds.length; i++) {
    speeds[i].classList.toggle('is-active', speeds[i].getAttribute('data-speed') === voice.speed);
  }
  if (els.voiceSelect && voice.id) els.voiceSelect.value = voice.id;
  if (els.voiceModelSelect && voice.model) els.voiceModelSelect.value = voice.model;
}

function toggleVoice() {
  voice.enabled = !voice.enabled;
  saveVoicePref('rebbet_voice', voice.enabled ? '1' : '0');
  updateVoiceToggle();
  showToast(voice.enabled ? 'Voice replies on' : 'Voice replies off');
  if (!voice.enabled) stopSpeaking();
}

function ttsPayload(clean) {
  var payload = { text: clean, speed: voice.speed || 'fast' };
  if (voice.id) payload.voice = voice.id;
  if (voice.model) payload.model = voice.model;
  return payload;
}

function speakableText(text) {
  var out = String(text || '');
  out = out.replace(/```[\s\S]*?```/g, ' ');
  out = out.replace(/`([^`]*)`/g, '$1');
  out = out.replace(/!\[[^\]]*\]\([^)]*\)/g, ' ');
  out = out.replace(/\[([^\]]+)\]\([^)]*\)/g, '$1');
  out = out.replace(/[*_#>|~]/g, ' ');
  out = out.replace(/\s+/g, ' ').trim();
  if (out.length > 3500) out = out.slice(0, 3500);
  return out;
}

function stopSpeaking() {
  if (voice.audio) {
    try { voice.audio.pause(); } catch (e) {}
    voice.audio = null;
  }
  if (voice.audioUrl) {
    URL.revokeObjectURL(voice.audioUrl);
    voice.audioUrl = null;
  }
  if (window.speechSynthesis) {
    try { window.speechSynthesis.cancel(); } catch (e) {}
  }
}

function browserSpeak(text) {
  if (!window.speechSynthesis || !window.SpeechSynthesisUtterance) return false;
  var clean = speakableText(text);
  if (!clean) return false;
  try {
    window.speechSynthesis.cancel();
    var utterance = new SpeechSynthesisUtterance(clean);
    utterance.rate = 1.12;
    utterance.pitch = 1;
    utterance.volume = 1;
    var voices = window.speechSynthesis.getVoices() || [];
    for (var i = 0; i < voices.length; i++) {
      if (/^en[-_]/i.test(voices[i].lang || '')) {
        utterance.voice = voices[i];
        break;
      }
    }
    window.speechSynthesis.speak(utterance);
    return true;
  } catch (e) {
    return false;
  }
}

async function speak(text) {
  var clean = speakableText(text);
  if (!clean) return;
  stopSpeaking();
  try {
    var res = await apiFetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(ttsPayload(clean))
    });
    if (!res.ok) {
      if (browserSpeak(clean)) {
        showToast('Using device voice');
        return;
      }
      var info = null;
      try { info = await res.json(); } catch (e) {}
      var message = info && info.error && info.error.message ? info.error.message : 'Voice failed';
      showToast('Voice: ' + message);
      return;
    }
    var blob = await res.blob();
    if (!blob || !blob.size) {
      if (!browserSpeak(clean)) showToast('Voice unavailable');
      return;
    }
    voice.audioUrl = URL.createObjectURL(blob);
    voice.audio = new Audio(voice.audioUrl);
    voice.audio.onended = function() { stopSpeaking(); };
    var played = voice.audio.play();
    if (played && played.catch) {
      played.catch(function() {
        if (!browserSpeak(clean)) showToast('Tap to enable audio playback');
      });
    }
  } catch (e) {
    if (!browserSpeak(clean)) showToast('Voice unavailable');
  }
}

function downsampleBuffer(buffer, inRate, outRate) {
  if (outRate >= inRate) return buffer;
  var ratio = inRate / outRate;
  var length = Math.round(buffer.length / ratio);
  var result = new Float32Array(length);
  var offsetResult = 0;
  var offsetBuffer = 0;
  while (offsetResult < length) {
    var nextOffsetBuffer = Math.round((offsetResult + 1) * ratio);
    var accum = 0;
    var count = 0;
    for (var i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i++) {
      accum += buffer[i];
      count++;
    }
    result[offsetResult] = count ? accum / count : 0;
    offsetResult++;
    offsetBuffer = nextOffsetBuffer;
  }
  return result;
}

function encodeWav(samples, sampleRate) {
  var buffer = new ArrayBuffer(44 + samples.length * 2);
  var view = new DataView(buffer);
  function writeString(offset, str) {
    for (var i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
  }
  writeString(0, 'RIFF');
  view.setUint32(4, 36 + samples.length * 2, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, samples.length * 2, true);
  var offset = 44;
  for (var i = 0; i < samples.length; i++, offset += 2) {
    var s = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return buffer;
}

function arrayBufferToBase64(buffer) {
  var bytes = new Uint8Array(buffer);
  var binary = '';
  var chunk = 0x8000;
  for (var i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

async function startRecording() {
  if (voice.recording) return;
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    showToast('Voice input is not supported here');
    return;
  }
  if (!window.isSecureContext) {
    showToast('Voice input needs HTTPS or localhost');
    return;
  }
  try {
    var stream = await navigator.mediaDevices.getUserMedia({
      audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true }
    });
    var Ctx = window.AudioContext || window.webkitAudioContext;
    var ctx = new Ctx();
    if (ctx.state === 'suspended') await ctx.resume();
    var source = ctx.createMediaStreamSource(stream);
    var processor = ctx.createScriptProcessor(4096, 1, 1);
    voice.chunks = [];
    processor.onaudioprocess = function(e) {
      voice.chunks.push(new Float32Array(e.inputBuffer.getChannelData(0)));
    };
    source.connect(processor);
    processor.connect(ctx.destination);
    voice.stream = stream;
    voice.audioContext = ctx;
    voice.source = source;
    voice.processor = processor;
    voice.recording = true;
    els.composerMic.classList.add('is-recording');
    els.composerMic.setAttribute('aria-label', 'Stop recording');
    showToast('Recording… tap mic to stop');
    voice.recordTimer = setTimeout(function() { stopRecording(); }, 45000);
  } catch (e) {
    showToast('Microphone permission denied');
  }
}

function stopRecording() {
  if (!voice.recording) return;
  voice.recording = false;
  clearTimeout(voice.recordTimer);
  els.composerMic.classList.remove('is-recording');
  els.composerMic.setAttribute('aria-label', 'Record voice message');
  try { voice.processor.disconnect(); } catch (e) {}
  try { voice.source.disconnect(); } catch (e) {}
  try { voice.stream.getTracks().forEach(function(track) { track.stop(); }); } catch (e) {}
  var ctx = voice.audioContext;
  var sampleRate = ctx ? ctx.sampleRate : 48000;
  try { if (ctx) ctx.close(); } catch (e) {}
  voice.processor = null;
  voice.source = null;
  voice.stream = null;
  voice.audioContext = null;

  var chunks = voice.chunks || [];
  voice.chunks = [];
  if (!chunks.length) {
    showToast('No audio recorded');
    return;
  }
  var total = 0;
  chunks.forEach(function(c) { total += c.length; });
  var merged = new Float32Array(total);
  var offset = 0;
  chunks.forEach(function(c) {
    merged.set(c, offset);
    offset += c.length;
  });
  var downsampled = downsampleBuffer(merged, sampleRate, 16000);
  var wav = encodeWav(downsampled, 16000);
  transcribeAudio(wav);
}

async function requestTranscription(wavBuffer) {
  var res = await apiFetch('/api/transcribe', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      audio: arrayBufferToBase64(wavBuffer),
      mimeType: 'audio/wav'
    })
  });
  var data = null;
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) {
    var message = data && data.error && data.error.message ? data.error.message : 'Transcription failed';
    throw new Error(message);
  }
  return {
    text: data && data.text ? String(data.text).trim() : '',
    model: data && data.model ? data.model : ''
  };
}

async function transcribeAudio(wavBuffer) {
  showToast('Transcribing…');
  try {
    var result = await requestTranscription(wavBuffer);
    if (!result.text) {
      showToast('No speech detected');
      return;
    }
    trackEvent('voice_transcribed', { model: result.model || '' });
    var current = els.composerInput.value.trim();
    els.composerInput.value = (current ? current + ' ' : '') + result.text;
    autoResize();
    els.composerSend.disabled = state.sending || !els.composerInput.value.trim();
    els.composerInput.focus();
  } catch (e) {
    showToast('Voice: ' + (e && e.message ? e.message : 'Transcription unavailable'));
  }
}

function toggleRecording() {
  if (voice.recording) {
    stopRecording();
  } else {
    startRecording();
  }
}

/* --------------------------------------------------------------------------
   Voice call
   -------------------------------------------------------------------------- */

var call = {
  active: false,
  muted: false,
  phase: 'idle',
  session: 0,
  stream: null,
  ctx: null,
  source: null,
  processor: null,
  sink: null,
  startedAt: 0,
  timer: null,
  captureFinish: null,
  audio: null,
  audioUrl: null,
  speakResolve: null
};

function delay(ms) {
  return new Promise(function(resolve) { setTimeout(resolve, ms); });
}

function setCallPhase(phase, label) {
  call.phase = phase;
  if (!els.voiceCall) return;
  els.voiceCall.classList.remove('is-listening', 'is-thinking', 'is-speaking', 'is-muted');
  if (phase === 'listening') els.voiceCall.classList.add('is-listening');
  else if (phase === 'thinking') els.voiceCall.classList.add('is-thinking');
  else if (phase === 'speaking') els.voiceCall.classList.add('is-speaking');
  if (call.muted) els.voiceCall.classList.add('is-muted');
  if (els.callStatus && label) els.callStatus.textContent = label;
}

function addCallLine(text, role) {
  if (!els.callTranscript || !text) return;
  var line = document.createElement('div');
  line.className = 'voice-call__line voice-call__line--' + (role === 'user' ? 'user' : 'assistant');
  line.textContent = text;
  els.callTranscript.appendChild(line);
  while (els.callTranscript.children.length > 24) {
    els.callTranscript.removeChild(els.callTranscript.firstChild);
  }
  els.callTranscript.scrollTop = els.callTranscript.scrollHeight;
}

function updateCallTimer() {
  if (!els.callTimer || !call.startedAt) return;
  var total = Math.max(0, Math.floor((Date.now() - call.startedAt) / 1000));
  var minutes = Math.floor(total / 60);
  var seconds = total % 60;
  els.callTimer.textContent =
    (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
}

function startCallTimer() {
  call.startedAt = Date.now();
  updateCallTimer();
  clearInterval(call.timer);
  call.timer = setInterval(updateCallTimer, 1000);
}

function stopCallTimer() {
  if (call.timer) clearInterval(call.timer);
  call.timer = null;
}

function stopCallStreams() {
  if (call.processor) {
    try { call.processor.onaudioprocess = null; } catch (e) {}
    try { call.processor.disconnect(); } catch (e) {}
  }
  if (call.source) {
    try { call.source.disconnect(); } catch (e) {}
  }
  if (call.sink) {
    try { call.sink.disconnect(); } catch (e) {}
  }
  if (call.stream) {
    try { call.stream.getTracks().forEach(function(track) { track.stop(); }); } catch (e) {}
  }
  if (call.ctx) {
    try { call.ctx.close(); } catch (e) {}
  }
  call.processor = null;
  call.source = null;
  call.sink = null;
  call.stream = null;
  call.ctx = null;
  call.captureFinish = null;
}

async function startVoiceCall() {
  if (call.active) return;
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    showToast('Voice calls are not supported here');
    return;
  }
  if (!window.isSecureContext) {
    showToast('Voice calls need HTTPS or localhost');
    return;
  }
  stopSpeaking();
  if (els.callTranscript) els.callTranscript.innerHTML = '';
  if (els.callTimer) els.callTimer.textContent = '00:00';
  if (els.voiceCall) els.voiceCall.hidden = false;
  document.body.classList.add('is-on-call');
  setCallPhase('thinking', 'Connecting…');
  var session = ++call.session;
  try {
    var stream = await navigator.mediaDevices.getUserMedia({
      audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true }
    });
    if (session !== call.session || !els.voiceCall || els.voiceCall.hidden) {
      try { stream.getTracks().forEach(function(track) { track.stop(); }); } catch (e) {}
      return;
    }
    var Ctx = window.AudioContext || window.webkitAudioContext;
    var ctx = new Ctx();
    if (ctx.state === 'suspended') await ctx.resume();
    if (session !== call.session) {
      try { ctx.close(); } catch (e) {}
      try { stream.getTracks().forEach(function(track) { track.stop(); }); } catch (e) {}
      return;
    }
    var source = ctx.createMediaStreamSource(stream);
    var processor = ctx.createScriptProcessor(4096, 1, 1);
    var sink = ctx.createGain();
    sink.gain.value = 0;
    source.connect(processor);
    processor.connect(sink);
    sink.connect(ctx.destination);
    call.stream = stream;
    call.ctx = ctx;
    call.source = source;
    call.processor = processor;
    call.sink = sink;
    call.active = true;
    call.muted = false;
    if (els.callMute) {
      els.callMute.classList.remove('is-on');
      els.callMute.setAttribute('aria-pressed', 'false');
    }
    startCallTimer();
    setCallPhase('listening', 'Listening…');
    trackEvent('voice_call_started', {});
    callLoop();
  } catch (e) {
    if (session !== call.session) return;
    if (els.voiceCall) els.voiceCall.hidden = true;
    document.body.classList.remove('is-on-call');
    setCallPhase('idle');
    showToast('Microphone permission denied');
  }
}

function endVoiceCall() {
  if (!call.active && els.voiceCall && els.voiceCall.hidden) return;
  call.session++;
  call.active = false;
  if (call.captureFinish) {
    var finish = call.captureFinish;
    call.captureFinish = null;
    try { finish(); } catch (e) {}
  }
  finishCallSpeech();
  stopCallTimer();
  stopCallStreams();
  if (els.voiceCall) els.voiceCall.hidden = true;
  document.body.classList.remove('is-on-call');
  setCallPhase('idle');
  showToast('Call ended');
  trackEvent('voice_call_ended', {});
}

function toggleCallMute() {
  if (!call.active) return;
  call.muted = !call.muted;
  if (els.callMute) {
    els.callMute.classList.toggle('is-on', call.muted);
    els.callMute.setAttribute('aria-pressed', call.muted ? 'true' : 'false');
  }
  if (call.muted) {
    setCallPhase('muted', 'Microphone muted');
  } else {
    setCallPhase('listening', 'Listening…');
  }
}

function handleCallOrb() {
  if (!call.active) return;
  if (call.phase === 'speaking') {
    finishCallSpeech();
    return;
  }
  if (call.phase === 'listening' && call.captureFinish) {
    call.captureFinish();
  }
}

function finishCallSpeech() {
  if (call.audio) {
    try { call.audio.pause(); } catch (e) {}
    call.audio = null;
  }
  if (call.audioUrl) {
    URL.revokeObjectURL(call.audioUrl);
    call.audioUrl = null;
  }
  if (window.speechSynthesis) {
    try { window.speechSynthesis.cancel(); } catch (e) {}
  }
  var resolve = call.speakResolve;
  call.speakResolve = null;
  if (resolve) resolve();
}

function browserSpeakCall(text) {
  if (!window.speechSynthesis || !window.SpeechSynthesisUtterance) return false;
  try {
    var utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = navigator.language || 'en-US';
    utterance.onend = finishCallSpeech;
    utterance.onerror = finishCallSpeech;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
    return true;
  } catch (e) {
    return false;
  }
}

function speakCall(text) {
  return new Promise(function(resolve) {
    var clean = speakableText(text);
    if (!clean || !call.active) {
      resolve();
      return;
    }
    call.speakResolve = resolve;
    apiFetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(ttsPayload(clean))
    }).then(function(res) {
      if (!res.ok) {
        if (!browserSpeakCall(clean)) finishCallSpeech();
        return;
      }
      return res.blob().then(function(blob) {
        if (!blob || !blob.size || !call.active) {
          finishCallSpeech();
          return;
        }
        call.audioUrl = URL.createObjectURL(blob);
        call.audio = new Audio(call.audioUrl);
        call.audio.onended = finishCallSpeech;
        call.audio.onerror = finishCallSpeech;
        var played = call.audio.play();
        if (played && played.catch) {
          played.catch(function() {
            if (!browserSpeakCall(clean)) finishCallSpeech();
          });
        }
      });
    }).catch(function() {
      if (!browserSpeakCall(clean)) finishCallSpeech();
    });
  });
}

function captureCallUtterance() {
  return new Promise(function(resolve) {
    if (!call.active || !call.processor || !call.ctx) {
      resolve(null);
      return;
    }
    var finished = false;
    var chunks = [];
    var speechStarted = false;
    var silenceMs = 0;
    var speechMs = 0;
    var elapsedMs = 0;

    function finish() {
      if (finished) return;
      finished = true;
      call.captureFinish = null;
      try { call.processor.onaudioprocess = null; } catch (e) {}
      var output = null;
      if (speechStarted && chunks.length) {
        var total = 0;
        chunks.forEach(function(chunk) { total += chunk.length; });
        var merged = new Float32Array(total);
        var offset = 0;
        chunks.forEach(function(chunk) {
          merged.set(chunk, offset);
          offset += chunk.length;
        });
        var rate = call.ctx ? call.ctx.sampleRate : 48000;
        var downsampled = downsampleBuffer(merged, rate, 16000);
        output = encodeWav(downsampled, 16000);
      }
      resolve(output);
    }

    call.captureFinish = finish;

    if (!call.processor.onaudioprocess) {
      call.processor.onaudioprocess = function(event) {
        if (finished) return;
        var data = event.inputBuffer.getChannelData(0);
        chunks.push(new Float32Array(data));
        var sum = 0;
        for (var i = 0; i < data.length; i++) sum += data[i] * data[i];
        var rms = Math.sqrt(sum / data.length);
        var bufferMs = (data.length / (call.ctx ? call.ctx.sampleRate : 48000)) * 1000;
        elapsedMs += bufferMs;
        if (rms > 0.016) {
          speechStarted = true;
          speechMs += bufferMs;
          silenceMs = 0;
        } else if (speechStarted) {
          silenceMs += bufferMs;
        }
        if (speechStarted && silenceMs >= 900) finish();
        else if (speechStarted && speechMs >= 20000) finish();
        else if (!speechStarted && elapsedMs >= 20000) finish();
        else if (elapsedMs >= 30000) finish();
      };
    }
  });
}

async function callSendTurn(userText) {
  var chat = getActiveChat();
  if (!chat) return '';
  var model = chat.model || state.selectedModel || DEFAULT_MODEL;
  chat.messages.push({ role: 'user', content: userText, time: nowTime() });
  updateChatTitle(chat);
  saveChats();
  renderThread();
  var history = chat.messages.slice(-20).map(function(message) {
    return apiMessage(message);
  });
  var res = await apiFetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: model,
      messages: history,
      web_search: webSearchEnabled,
      memory: memoryPayload(),
      personality: currentPersonalityPayload()
    })
  });
  if (!res.ok) {
    var info = null;
    try { info = await res.json(); } catch (e) {}
    throw new Error(info && info.error && info.error.message ? info.error.message : 'Voice request failed');
  }
  var reader = res.body.getReader();
  var decoder = new TextDecoder();
  var buffer = '';
  var fullText = '';
  var activeModel = model;
  var activeProvider = '';
  var streamError = '';
  while (true) {
    var result = await reader.read();
    if (result.done) break;
    buffer += decoder.decode(result.value, { stream: true });
    var parts = buffer.split('\n\n');
    buffer = parts.pop();
    for (var i = 0; i < parts.length; i++) {
      var chunk = parts[i];
      if (!chunk.startsWith('data:')) continue;
      var jsonStr = chunk.slice(5).trim();
      if (!jsonStr) continue;
      var event = null;
      try { event = JSON.parse(jsonStr); } catch (e) { continue; }
      if (event.type === 'meta') {
        activeModel = event.model || activeModel;
        activeProvider = event.provider || activeProvider;
      } else if (event.type === 'delta' && typeof event.text === 'string') {
        fullText += event.text;
      } else if (event.type === 'error') {
        streamError = event.message || 'Voice request failed';
      }
    }
  }
  if (streamError) throw new Error(streamError);
  if (!fullText) throw new Error('Empty response');
  var assistant = {
    role: 'assistant',
    content: fullText,
    raw: fullText,
    time: nowTime(),
    modelLabel: state.modelsById.get(activeModel)?.label || activeModel,
    provider: activeProvider
  };
  if (window.marked && window.DOMPurify) {
    assistant.html = DOMPurify.sanitize(marked.parse(fullText));
  }
  chat.messages.push(assistant);
  saveChats();
  renderThread();
  return fullText;
}

async function callLoop() {
  try {
    while (call.active) {
      if (call.muted) {
        setCallPhase('muted', 'Microphone muted');
        await delay(300);
        continue;
      }
      setCallPhase('listening', 'Listening…');
      var wav = await captureCallUtterance();
      if (!call.active) break;
      if (!wav) {
        await delay(200);
        continue;
      }
      setCallPhase('thinking', 'Thinking…');
      var text = '';
      try {
        var transcript = await requestTranscription(wav);
        text = transcript.text || '';
      } catch (e) {
        setCallPhase('thinking', 'Could not hear you');
        await delay(900);
        continue;
      }
      if (!call.active) break;
      if (!text) continue;
      addCallLine(text, 'user');
      var reply = '';
      try {
        reply = await callSendTurn(text);
      } catch (e) {
        if (!call.active) break;
        setCallPhase('thinking', e && e.message ? e.message : 'Connection issue');
        await delay(1200);
        continue;
      }
      if (!call.active) break;
      if (!reply) continue;
      addCallLine(reply, 'assistant');
      setCallPhase('speaking', 'Speaking…');
      await speakCall(reply);
      if (!call.active) break;
      await delay(350);
    }
  } catch (e) {
  } finally {
    if (call.active) endVoiceCall();
  }
}

const state = {
  models: [],
  modelsById: new Map(),
  selectedModel: null,
  chats: [],
  activeChatId: null,
  sending: false,
  appConfig: null,
  abortController: null,
  stopRequested: false,
  memory: [],
  folders: [],
  folderFilter: 'all',
  chatSearch: '',
  theme: 'dark'
};

const PERSONALITIES = [
  { id: 'default', name: 'Default', emoji: '✧', desc: 'Balanced and friendly', system: '' },
  { id: 'concise', name: 'Concise', emoji: '⚡', desc: 'Short, direct answers', system: 'Be extremely concise. Prefer short sentences and bullet points. Skip filler, restatements and unnecessary caveats. Still answer completely and accurately.' },
  { id: 'creative', name: 'Creative', emoji: '✦', desc: 'Vivid and imaginative', system: 'Be imaginative, expressive and vivid. Use strong imagery, playful language and fresh ideas while staying accurate and useful.' },
  { id: 'teacher', name: 'Teacher', emoji: '◈', desc: 'Step-by-step clarity', system: 'Act as a patient expert tutor. Explain step by step, define jargon, use simple analogies and check understanding. Keep structure clear.' },
  { id: 'coder', name: 'Coder', emoji: '⌘', desc: 'Practical engineering', system: 'Act as a senior software engineer. Prefer working code, exact file references and practical trade-offs. Use clear code blocks and concise explanations. Ask only essential clarifying questions.' },
  { id: 'analyst', name: 'Analyst', emoji: '▤', desc: 'Structured and precise', system: 'Act as a rigorous analyst. Structure answers with clear headings, evidence, assumptions and trade-offs. Separate facts from opinions and call out uncertainty.' },
  { id: 'coach', name: 'Coach', emoji: '◉', desc: 'Encouraging action plan', system: 'Act as a supportive coach. Be encouraging but honest. Turn advice into small concrete next steps and ask useful follow-up questions.' },
  { id: 'translator', name: 'Translator', emoji: '文', desc: 'Natural translations', system: 'Act as a professional translator. Preserve meaning, tone and nuance. Provide the translation first, then brief notes only when a phrase is ambiguous.' }
];

const els = {
  menuBtn: document.getElementById('menuBtn'),
  sidebar: document.getElementById('sidebar'),
  sidebarClose: document.getElementById('sidebarClose'),
  sidebarBackdrop: document.getElementById('sidebarBackdrop'),
  sidebarList: document.getElementById('sidebarList'),
  sidebarNew: document.getElementById('sidebarNew'),
  newChatBtn: document.getElementById('newChatBtn'),
  modelTrigger: document.getElementById('modelTrigger'),
  modelSheet: document.getElementById('modelSheet'),
  modelBackdrop: document.getElementById('modelBackdrop'),
  modelClose: document.getElementById('modelClose'),
  modelLabel: document.getElementById('modelLabel'),
  modelContent: document.getElementById('modelContent'),
  modelSearch: document.getElementById('modelSearch'),
  thread: document.getElementById('thread'),
  composerInput: document.getElementById('composerInput'),
  composerMic: document.getElementById('composerMic'),
  composerImage: document.getElementById('composerImage'),
  composerSend: document.getElementById('composerSend'),
  attachBtn: document.getElementById('attachBtn'),
  fileInput: document.getElementById('fileInput'),
  updateBtn: document.getElementById('updateBtn'),
  brandMark: document.getElementById('brandMark'),
  appFavicon: document.getElementById('appFavicon'),
  appTouchIcon: document.getElementById('appTouchIcon'),
  searchToggle: document.getElementById('searchToggle'),
  themeToggle: document.getElementById('themeToggle'),
  moreBtn: document.getElementById('moreBtn'),
  appMenu: document.getElementById('appMenu'),
  menuPersonality: document.getElementById('menuPersonality'),
  menuMemoryCount: document.getElementById('menuMemoryCount'),
  menuSearchState: document.getElementById('menuSearchState'),
  menuThemeIcon: document.getElementById('menuThemeIcon'),
  menuThemeLabel: document.getElementById('menuThemeLabel'),
  chatSearch: document.getElementById('chatSearch'),
  folderFilters: document.getElementById('folderFilters'),
  sidebarMemory: document.getElementById('sidebarMemory'),
  sidebarPersonality: document.getElementById('sidebarPersonality'),
  sidebarTemp: document.getElementById('sidebarTemp'),
  attachmentStrip: document.getElementById('attachmentStrip'),
  composerStop: document.getElementById('composerStop'),
  composerStatus: document.getElementById('composerStatus'),
  composerPersona: document.getElementById('composerPersona'),
  scrollBottom: document.getElementById('scrollBottom'),
  personalitySheet: document.getElementById('personalitySheet'),
  personalityBackdrop: document.getElementById('personalityBackdrop'),
  personalityClose: document.getElementById('personalityClose'),
  personalityGrid: document.getElementById('personalityGrid'),
  customPersonality: document.getElementById('customPersonality'),
  savePersonality: document.getElementById('savePersonality'),
  memorySheet: document.getElementById('memorySheet'),
  memoryBackdrop: document.getElementById('memoryBackdrop'),
  memoryClose: document.getElementById('memoryClose'),
  memoryInput: document.getElementById('memoryInput'),
  memoryAddBtn: document.getElementById('memoryAddBtn'),
  memoryList: document.getElementById('memoryList'),
  memoryClearBtn: document.getElementById('memoryClearBtn'),
  folderSheet: document.getElementById('folderSheet'),
  folderBackdrop: document.getElementById('folderBackdrop'),
  folderClose: document.getElementById('folderClose'),
  folderInput: document.getElementById('folderInput'),
  folderAddBtn: document.getElementById('folderAddBtn'),
  folderList: document.getElementById('folderList'),
  voiceToggle: document.getElementById('voiceToggle'),
  voiceSheet: document.getElementById('voiceSheet'),
  voiceBackdrop: document.getElementById('voiceBackdrop'),
  voiceClose: document.getElementById('voiceClose'),
  voiceSelect: document.getElementById('voiceSelect'),
  voiceModelSelect: document.getElementById('voiceModelSelect'),
  voicePreviewBtn: document.getElementById('voicePreviewBtn'),
  voiceWarning: document.getElementById('voiceWarning'),
  callBtn: document.getElementById('callBtn'),
  voiceCall: document.getElementById('voiceCall'),
  callOrb: document.getElementById('callOrb'),
  callStatus: document.getElementById('callStatus'),
  callTranscript: document.getElementById('callTranscript'),
  callMute: document.getElementById('callMute'),
  callEnd: document.getElementById('callEnd'),
  callTimer: document.getElementById('callTimer'),
  toast: document.getElementById('toast'),
  shareModal: document.getElementById('shareModal'),
  shareBackdrop: document.getElementById('shareBackdrop'),
  shareFileMeta: document.getElementById('shareFileMeta'),
  shareUrlInput: document.getElementById('shareUrlInput'),
  shareCopyBtn: document.getElementById('shareCopyBtn'),
  shareOpenLink: document.getElementById('shareOpenLink'),
  shareNativeBtn: document.getElementById('shareNativeBtn')
};

function uid() {
  return 'c_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function apiMessage(message) {
  var content = String((message && message.content) || '');
  if (message && message.file) {
    var link = message.file.url || message.file.shareUrl || message.file.rawUrl || '';
    if (link) {
      content += '\n[Shared file: ' + (message.file.name || 'file') + ' — ' + link + ']';
    }
    if (message.file.text) {
      var excerpt = String(message.file.text).slice(0, 14000);
      content += '\n\n[Attached document: ' + (message.file.name || 'document') +
        (message.file.pages ? ' · ' + message.file.pages + ' page(s)' : '') +
        ']\n' + excerpt + (message.file.text.length > excerpt.length ? '\n[Document truncated]' : '');
    }
  }
  return { role: message.role, content: content };
}

function currentPersonalityPayload() {
  var chat = getActiveChat();
  var persona = getPersonalityById(chat && chat.personality);
  if (!persona || persona.id === 'default') return null;
  return { id: persona.id, name: persona.name, system: persona.system };
}

function memoryPayload() {
  return state.memory.map(function(text) { return { text: text }; });
}

function nowTime() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function showToast(message) {
  els.toast.textContent = message;
  els.toast.classList.add('is-show');
  setTimeout(function() { els.toast.classList.remove('is-show'); }, 1800);
}

function trackEvent(name, params) {
  try {
    if (window.rebbetFirebase && typeof window.rebbetFirebase.trackEvent === 'function') {
      window.rebbetFirebase.trackEvent(name, params || {});
    }
  } catch (e) {}
}

function openSidebar() {
  els.sidebar.classList.add('is-open');
  els.sidebarBackdrop.classList.add('is-open');
}

function closeSidebar() {
  els.sidebar.classList.remove('is-open');
  els.sidebarBackdrop.classList.remove('is-open');
}

function openModelSheet() {
  els.modelSheet.classList.add('is-open');
  els.modelTrigger.setAttribute('aria-expanded', 'true');
  els.modelSearch.value = '';
  renderModels(els.modelSearch.value);
  if (window.matchMedia('(min-width: 900px)').matches) {
    setTimeout(function() { els.modelSearch.focus(); }, 180);
  }
}

function closeModelSheet() {
  els.modelSheet.classList.remove('is-open');
  els.modelTrigger.setAttribute('aria-expanded', 'false');
}

function showVoiceWarning(message) {
  if (!els.voiceWarning) return;
  if (message) {
    els.voiceWarning.textContent = message;
    els.voiceWarning.hidden = false;
  } else {
    els.voiceWarning.textContent = '';
    els.voiceWarning.hidden = true;
  }
}

function openVoiceSheet() {
  if (!els.voiceSheet) return;
  updateVoiceToggle();
  updateVoiceControls();
  els.voiceSheet.classList.add('is-open');
  if (!voice.loaded && !voice.loading) loadVoices();
  else renderVoiceOptions();
}

function closeVoiceSheet() {
  if (!els.voiceSheet) return;
  els.voiceSheet.classList.remove('is-open');
  stopVoicePreview();
}

function stopVoicePreview() {
  if (voice.previewAudio) {
    try { voice.previewAudio.pause(); } catch (e) {}
    voice.previewAudio = null;
  }
  if (els.voicePreviewBtn) {
    els.voicePreviewBtn.textContent = 'Preview voice';
    els.voicePreviewBtn.disabled = false;
  }
}

function renderVoiceOptions() {
  if (!els.voiceSelect || !els.voiceModelSelect) return;
  els.voiceSelect.innerHTML = '';
  voice.voices.forEach(function(item) {
    var option = document.createElement('option');
    option.value = item.id;
    option.textContent = item.name + (item.category && item.category !== 'premade' ? ' · ' + item.category : '');
    els.voiceSelect.appendChild(option);
  });
  if (!voice.voices.length) {
    var empty = document.createElement('option');
    empty.value = '';
    empty.textContent = 'No voices available';
    els.voiceSelect.appendChild(empty);
  }
  if (!voice.id && voice.voices.length) voice.id = voice.voices[0].id;
  els.voiceSelect.value = voice.id || '';

  els.voiceModelSelect.innerHTML = '';
  voice.models.forEach(function(model) {
    var option = document.createElement('option');
    option.value = model;
    option.textContent = model;
    els.voiceModelSelect.appendChild(option);
  });
  if (!voice.model && voice.models.length) voice.model = voice.models[0];
  els.voiceModelSelect.value = voice.model || '';
  updateVoiceControls();
  showVoiceWarning(voice.warning);
}

async function loadVoices() {
  if (!els.voiceSelect || voice.loading) return;
  voice.loading = true;
  els.voiceSelect.innerHTML = '<option value="">Loading voices…</option>';
  showVoiceWarning('');
  try {
    var res = await apiFetch('/api/voices');
    var data = null;
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) {
      var info = data && data.error ? data.error.message : 'Could not load voices';
      throw new Error(info);
    }
    voice.voices = (data.voices || []).filter(function(item) {
      return item && item.id;
    });
    voice.models = data.models || [];
    if (!voice.id) voice.id = data.default_voice || '';
    if (!voice.model) voice.model = data.default_model || '';
    if (!voice.speed) voice.speed = data.speed || 'fast';
    voice.warning = data.warning || '';
    voice.loaded = true;
    saveVoicePref('rebbet_voice_id', voice.id);
    saveVoicePref('rebbet_voice_model', voice.model);
    renderVoiceOptions();
  } catch (e) {
    els.voiceSelect.innerHTML = '<option value="">Voices unavailable</option>';
    showVoiceWarning(e && e.message ? e.message : 'Could not load voices');
  } finally {
    voice.loading = false;
  }
}

function selectedVoice() {
  for (var i = 0; i < voice.voices.length; i++) {
    if (voice.voices[i].id === voice.id) return voice.voices[i];
  }
  return null;
}

function previewVoice() {
  if (!els.voicePreviewBtn) return;
  stopVoicePreview();
  var item = selectedVoice();
  var name = item ? item.name : 'your Rebbet AI';
  if (item && item.preview_url) {
    voice.previewAudio = new Audio(item.preview_url);
    voice.previewAudio.onended = stopVoicePreview;
    voice.previewAudio.onerror = stopVoicePreview;
    voice.previewAudio.play().catch(stopVoicePreview);
    els.voicePreviewBtn.textContent = 'Stop preview';
    return;
  }
  els.voicePreviewBtn.disabled = true;
  els.voicePreviewBtn.textContent = 'Loading…';
  apiFetch('/api/tts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(ttsPayload('Hi, I am ' + name + ', your Rebbet AI voice.'))
  }).then(function(res) {
    if (!res.ok) throw new Error('Preview failed');
    return res.blob();
  }).then(function(blob) {
    if (!blob || !blob.size) throw new Error('Preview failed');
    var url = URL.createObjectURL(blob);
    voice.previewAudio = new Audio(url);
    voice.previewAudio.onended = function() {
      URL.revokeObjectURL(url);
      stopVoicePreview();
    };
    voice.previewAudio.onerror = function() {
      URL.revokeObjectURL(url);
      stopVoicePreview();
    };
    voice.previewAudio.play().catch(function() {
      URL.revokeObjectURL(url);
      stopVoicePreview();
    });
    els.voicePreviewBtn.disabled = false;
    els.voicePreviewBtn.textContent = 'Stop preview';
  }).catch(function(e) {
    showVoiceWarning(e && e.message ? e.message : 'Preview unavailable');
    els.voicePreviewBtn.disabled = false;
    els.voicePreviewBtn.textContent = 'Preview voice';
  });
}

function loadChats() {
  try {
    var raw = localStorage.getItem('rebbet_chats');
    if (raw) state.chats = JSON.parse(raw);
    if (!Array.isArray(state.chats)) state.chats = [];
  } catch (e) {
    state.chats = [];
  }
  state.chats.forEach(function(chat) {
    if (!chat.personality) chat.personality = 'default';
    if (typeof chat.title !== 'string' || !chat.title) chat.title = chat.temp ? 'Temporary chat' : 'New chat';
    if (!Array.isArray(chat.messages)) chat.messages = [];
  });
  if (!state.chats.length) {
    createChat(true);
  } else if (!state.activeChatId || !state.chats.find(function(c){ return c.id === state.activeChatId; })) {
    state.activeChatId = state.chats[0].id;
  }
  renderSidebar();
  renderThread();
  updatePersonaBadge();
}

function saveChats() {
  try {
    var persisted = state.chats.filter(function(chat) { return !chat.temp; });
    localStorage.setItem('rebbet_chats', JSON.stringify(persisted));
    if (state.selectedModel) localStorage.setItem('rebbet_model', state.selectedModel);
  } catch (e) {
    if (e && e.name === 'QuotaExceededError') showToast('Storage full — remove an old chat or large file');
  }
}

function createChat(silent, options) {
  options = options || {};
  var chat = {
    id: uid(),
    title: options.temp ? 'Temporary chat' : 'New chat',
    model: state.selectedModel || DEFAULT_MODEL,
    messages: [],
    createdAt: Date.now(),
    folder: options.folder || (state.folderFilter !== 'all' ? state.folderFilter : ''),
    temp: !!options.temp,
    personality: options.personality || 'default'
  };
  state.chats.unshift(chat);
  state.activeChatId = chat.id;
  saveChats();
  renderSidebar();
  renderThread();
  updatePersonaBadge();
  if (!silent) showToast(options.temp ? 'Temporary chat — not saved' : 'New chat created');
  closeSidebar();
}

function getActiveChat() {
  return state.chats.find(function(c){ return c.id === state.activeChatId; }) || null;
}

function deleteChat(chatId) {
  var idx = state.chats.findIndex(function(c){ return c.id === chatId; });
  if (idx === -1) return;
  state.chats.splice(idx, 1);
  if (state.activeChatId === chatId) {
    if (state.chats.length) {
      state.activeChatId = state.chats[0].id;
    } else {
      state.activeChatId = null;
      createChat(true);
      return;
    }
  }
  saveChats();
  renderSidebar();
  renderThread();
  updatePersonaBadge();
  closeSidebar();
  showToast('Chat deleted');
}

function renameChat(chatId) {
  var chat = state.chats.find(function(c){ return c.id === chatId; });
  if (!chat) return;
  var current = chat.title || 'New chat';
  var name = prompt('Rename chat', current);
  if (name === null) return;
  name = name.trim();
  if (!name) name = current;
  if (name.length > 60) name = name.slice(0, 60);
  chat.title = name;
  saveChats();
  renderSidebar();
  showToast('Renamed');
}

function editUserMessage(idx) {
  var chat = getActiveChat();
  if (!chat) return;
  var msg = chat.messages[idx];
  if (!msg || msg.role !== 'user') return;
  var newText = prompt('Edit message', msg.content);
  if (newText === null) return;
  newText = newText.replace(/\r\n/g, '\n').trim();
  if (!newText) return;
  msg.content = newText;
  if (chat.title === 'New chat') {
    updateChatTitle(chat);
  }
  chat.messages = chat.messages.slice(0, idx + 1);
  saveChats();
  renderThread();
  showToast('Message edited');
}

function updateChatTitle(chat) {
  if (!chat || chat.title !== 'New chat') return;
  var firstUser = chat.messages.find(function(m){ return m.role === 'user'; });
  if (!firstUser) return;
  var text = firstUser.content.replace(/\n+/g, ' ').trim();
  if (!text) return;
  chat.title = text.length > 32 ? text.slice(0, 32) + '…' : text;
  saveChats();
  renderSidebar();
}

function chatFolderName(chat) {
  return (chat && chat.folder) ? chat.folder : 'General';
}

function visibleChats() {
  var query = (state.chatSearch || '').toLowerCase().trim();
  return state.chats.filter(function(chat) {
    if (state.folderFilter !== 'all' && chatFolderName(chat) !== state.folderFilter) return false;
    if (!query) return true;
    if ((chat.title || '').toLowerCase().indexOf(query) !== -1) return true;
    return (chat.messages || []).some(function(message) {
      return String(message.content || '').toLowerCase().indexOf(query) !== -1;
    });
  }).sort(function(a, b) {
    if (!!b.pinned !== !!a.pinned) return b.pinned ? 1 : -1;
    return (b.createdAt || 0) - (a.createdAt || 0);
  });
}

function renderFolderFilters() {
  if (!els.folderFilters) return;
  els.folderFilters.innerHTML = '';
  var folders = ['all'].concat(allFolders());
  folders.forEach(function(folder) {
    var chip = document.createElement('button');
    chip.type = 'button';
    chip.className = 'folder-chip' + (state.folderFilter === folder ? ' is-active' : '');
    var label = folder === 'all' ? 'All chats' : folder;
    var count = state.chats.filter(function(chat) {
      return folder === 'all' || chatFolderName(chat) === folder;
    }).length;
    chip.textContent = label + (folder === 'all' ? '' : ' ' + count);
    chip.addEventListener('click', function() {
      state.folderFilter = folder;
      renderFolderFilters();
      renderSidebar();
    });
    els.folderFilters.appendChild(chip);
  });
  var manage = document.createElement('button');
  manage.type = 'button';
  manage.className = 'folder-chip folder-chip--add';
  manage.textContent = '+ Folder';
  manage.addEventListener('click', openFolderSheet);
  els.folderFilters.appendChild(manage);
}

function renderSidebar() {
  if (!els.sidebarList) return;
  els.sidebarList.innerHTML = '';
  renderFolderFilters();
  var list = visibleChats();
  if (!list.length) {
    var empty = document.createElement('div');
    empty.className = 'sidebar__empty';
    empty.textContent = state.chatSearch ? 'No chats match your search' : 'No chats in this folder yet';
    els.sidebarList.appendChild(empty);
    return;
  }
  if (state.folderFilter === 'all') {
    var folders = allFolders();
    if (folders.length) {
      var general = list.filter(function(chat) { return chatFolderName(chat) === 'General'; });
      if (general.length) {
        var generalHeading = document.createElement('div');
        generalHeading.className = 'sidebar__group';
        generalHeading.textContent = 'General';
        els.sidebarList.appendChild(generalHeading);
        general.forEach(function(chat) { els.sidebarList.appendChild(renderSidebarRow(chat)); });
      }
      folders.forEach(function(name) {
        var matches = list.filter(function(chat) { return chatFolderName(chat) === name; });
        if (!matches.length) return;
        var heading = document.createElement('div');
        heading.className = 'sidebar__group';
        heading.textContent = name;
        els.sidebarList.appendChild(heading);
        matches.forEach(function(chat) { els.sidebarList.appendChild(renderSidebarRow(chat)); });
      });
      return;
    }
  }
  list.forEach(function(chat) { els.sidebarList.appendChild(renderSidebarRow(chat)); });
}

function renderSidebarRow(chat) {
  var wrap = document.createElement('div');
  wrap.className = 'sidebar__row' + (chat.id === state.activeChatId ? ' is-active' : '') + (chat.temp ? ' is-temp' : '');

  var btn = document.createElement('button');
  btn.className = 'sidebar__item-main';
  btn.type = 'button';
  var icon = document.createElement('span');
  icon.className = 'sidebar__item-icon';
  var persona = getPersonalityById(chat.personality);
  icon.textContent = persona && persona.id !== 'default' ? persona.emoji : '';
  var textWrap = document.createElement('span');
  textWrap.className = 'sidebar__item-body';
  var text = document.createElement('span');
  text.className = 'sidebar__item-text';
  text.textContent = chat.title || 'New chat';
  textWrap.appendChild(text);
  var meta = document.createElement('span');
  meta.className = 'sidebar__item-meta';
  var parts = [];
  if (chat.pinned) parts.push('Pinned');
  if (chat.temp) parts.push('Temporary');
  if (chat.folder) parts.push(chat.folder);
  if (chat.messages && chat.messages.length) parts.push(chat.messages.length + ' msgs');
  meta.textContent = parts.join(' · ') || 'Ready';
  textWrap.appendChild(meta);
  if (icon.textContent) btn.appendChild(icon);
  btn.appendChild(textWrap);
  btn.addEventListener('click', function(e) {
    if (e.target.closest('.sidebar__menu')) return;
    state.activeChatId = chat.id;
    state.folderFilter = 'all';
    renderSidebar();
    renderThread();
    closeSidebar();
    setModel(chat.model || state.selectedModel);
    updatePersonaBadge();
  });

  var menuBtn = document.createElement('button');
  menuBtn.className = 'sidebar__menu';
  menuBtn.type = 'button';
  menuBtn.setAttribute('aria-label', 'Chat options');
  menuBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.6"></circle><circle cx="12" cy="12" r="1.6"></circle><circle cx="12" cy="19" r="1.6"></circle></svg>';
  menuBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    var existing = document.querySelector('.sidebar__dropdown');
    if (existing) existing.remove();
    var menu = document.createElement('div');
    menu.className = 'sidebar__dropdown';
    function addItem(label, handler, danger) {
      var item = document.createElement('button');
      item.className = 'sidebar__dropdown-item' + (danger ? ' sidebar__dropdown-item--danger' : '');
      item.textContent = label;
      item.addEventListener('click', function(ev) {
        ev.stopPropagation();
        menu.remove();
        handler();
      });
      menu.appendChild(item);
    }
    addItem(chat.pinned ? 'Unpin' : 'Pin', function() {
      chat.pinned = !chat.pinned;
      saveChats();
      renderSidebar();
      showToast(chat.pinned ? 'Chat pinned' : 'Chat unpinned');
    });
    addItem('Rename', function() { renameChat(chat.id); });
    addItem('Move to folder', function() { moveChatToFolder(chat); });
    addItem('Export Markdown', function() { exportChat(chat, 'md'); });
    addItem(chat.temp ? 'Save chat' : 'Make temporary', function() {
      chat.temp = !chat.temp;
      if (!chat.temp) chat.title = chat.title === 'Temporary chat' ? 'New chat' : chat.title;
      saveChats();
      renderSidebar();
      showToast(chat.temp ? 'This chat will not be saved' : 'Chat saved');
    });
    if (chat.id === state.activeChatId) {
      addItem('Clear messages', function() {
        if (!chat.messages.length) return;
        if (!confirm('Clear all messages in this chat?')) return;
        chat.messages = [];
        chat.title = chat.temp ? 'Temporary chat' : 'New chat';
        saveChats();
        renderSidebar();
        renderThread();
      });
    }
    addItem('Delete', function() {
      if (confirm('Delete this chat?')) deleteChat(chat.id);
    }, true);
    document.body.appendChild(menu);
    var rect = menuBtn.getBoundingClientRect();
    menu.style.left = Math.min(rect.right - 170, window.innerWidth - 180) + 'px';
    menu.style.top = Math.min(rect.bottom + 6, window.innerHeight - 260) + 'px';
    setTimeout(function() {
      document.addEventListener('click', function closeMenu(ev) {
        if (!menu.contains(ev.target) && ev.target !== menuBtn) {
          menu.remove();
          document.removeEventListener('click', closeMenu);
        }
      });
    }, 0);
  });

  wrap.appendChild(btn);
  wrap.appendChild(menuBtn);
  return wrap;
}

function setModel(modelId) {
  if (!modelId) return;
  if (state.modelsById.has(modelId)) {
    state.selectedModel = modelId;
  } else if (!state.selectedModel) {
    state.selectedModel = modelId;
  }
  var chat = getActiveChat();
  if (chat) chat.model = state.selectedModel;
  try {
    if (state.selectedModel) localStorage.setItem('rebbet_model', state.selectedModel);
  } catch (e) {}
  saveChats();
  var model = state.modelsById.get(state.selectedModel);
  if (els.modelLabel) els.modelLabel.textContent = model ? model.label : state.selectedModel;
  closeModelSheet();
}

function renderModels(filter) {
  var f = (filter || '').toLowerCase().trim();
  var list = state.models.filter(function(m) {
    if (!f) return true;
    return m.id.toLowerCase().indexOf(f) !== -1 || m.label.toLowerCase().indexOf(f) !== -1;
  });
  els.modelContent.innerHTML = '';
  if (!list.length) {
    var empty = document.createElement('div');
    empty.style.padding = '18px 12px';
    empty.style.color = 'var(--text-dim)';
    empty.textContent = 'No models match';
    els.modelContent.appendChild(empty);
    return;
  }
  var groups = {};
  list.forEach(function(m) {
    var key;
    if (m.family === 'google' || /^gemini-/i.test(m.id)) {
      key = 'Gemini';
    } else if (/^(gpt|o[134])/i.test(m.id)) {
      key = 'GPT';
    } else if (m.recommended) {
      key = 'Recommended';
    } else if (m.free) {
      key = 'Free';
    } else {
      key = 'Other models';
    }
    if (!groups[key]) groups[key] = [];
    groups[key].push(m);
  });
  var order = ['Gemini', 'GPT', 'Recommended', 'Free', 'Other models'];
  order.forEach(function(key) {
    if (!groups[key] || !groups[key].length) return;
    var label = document.createElement('div');
    label.className = 'model-group__label';
    label.textContent = key;
    els.modelContent.appendChild(label);
    groups[key].forEach(function(m) {
      var btn = document.createElement('button');
      btn.className = 'model-item' + (m.id === state.selectedModel ? ' is-active' : '');
      var main = document.createElement('div');
      main.className = 'model-item__main';
      var name = document.createElement('div');
      name.className = 'model-item__name';
      name.textContent = m.label;
      var meta = document.createElement('div');
      meta.className = 'model-item__meta';
      meta.textContent = m.id;
      main.appendChild(name);
      main.appendChild(meta);
      var badges = document.createElement('div');
      badges.className = 'model-item__badges';
      if (m.recommended) {
        var rec = document.createElement('span');
        rec.className = 'badge badge--rec';
        rec.textContent = 'Rec';
        badges.appendChild(rec);
      }
      if (m.free) {
        var fr = document.createElement('span');
        fr.className = 'badge badge--free';
        fr.textContent = 'Free';
        badges.appendChild(fr);
      }
      btn.appendChild(main);
      btn.appendChild(badges);
      btn.addEventListener('click', function() {
        setModel(m.id);
        var chat = getActiveChat();
        if (chat) {
          chat.model = m.id;
          saveChats();
        }
      });
      els.modelContent.appendChild(btn);
    });
  });
}

function applyModels(models, defaultId) {
  state.models = models && models.length ? models : fallbackModels();
  state.modelsById.clear();
  state.models.forEach(function(m) { state.modelsById.set(m.id, m); });
  if (!state.selectedModel) {
    try { state.selectedModel = localStorage.getItem('rebbet_model') || ''; } catch (e) {}
  }
  if (!state.selectedModel && defaultId) {
    state.selectedModel = defaultId;
  }
  if (!state.modelsById.has(state.selectedModel) && state.models.length) {
    state.selectedModel = state.models[0].id;
  }
  var chat = getActiveChat();
  if (chat && chat.model && state.modelsById.has(chat.model)) {
    state.selectedModel = chat.model;
  }
  setModel(state.selectedModel);
  renderModels(els.modelSearch.value);
}

async function loadModels() {
  try {
    var res = await apiFetch('/api/models');
    if (!res.ok) throw new Error('Failed');
    var data = await res.json();
    applyModels(data.models || [], data.default);
  } catch (e) {
    applyModels(fallbackModels(), DEFAULT_MODEL);
  }
}

function scrollThread() {
  requestAnimationFrame(function() {
    els.thread.scrollTop = els.thread.scrollHeight;
  });
}

function renderEmptyState() {
  var empty = document.createElement('div');
  empty.className = 'thread-empty';

  var mark = document.createElement('img');
  mark.className = 'thread-empty__mark';
  mark.src = 'static/logo.png?v=1.11.0';
  mark.alt = '';

  var title = document.createElement('div');
  title.className = 'thread-empty__title';
  title.textContent = 'How can I help?';

  var sub = document.createElement('div');
  sub.className = 'thread-empty__subtitle';
  sub.textContent = 'Ask anything, attach a PDF, generate images, or start a voice call.';

  var chips = document.createElement('div');
  chips.className = 'thread-empty__chips';
  [
    'Explain something simply',
    'Write code',
    'Analyze the PDF I attach',
    'Generate an image of a neon city'
  ].forEach(function(text) {
    var chip = document.createElement('button');
    chip.className = 'suggestion';
    chip.type = 'button';
    chip.textContent = text;
    chip.addEventListener('click', function() {
      els.composerInput.value = text + ' ';
      els.composerInput.focus();
      autoResize();
      els.composerSend.disabled = false;
    });
    chips.appendChild(chip);
  });

  empty.appendChild(mark);
  empty.appendChild(title);
  empty.appendChild(sub);
  empty.appendChild(chips);
  els.thread.appendChild(empty);
}

function renderThread() {
  var chat = getActiveChat();
  els.thread.innerHTML = '';
  updatePersonaBadge();
  if (!chat || chat.messages.length === 0) {
    renderEmptyState();
    updateScrollButton();
    return;
  }
  chat.messages.forEach(function(msg, index) {
    if (msg.role === 'user') {
      renderUserMessage(msg);
    } else {
      renderAssistantMessage(msg);
    }
    if (index === chat.messages.length - 1) {
      var last = els.thread.lastElementChild;
      if (last) last.classList.add('message--enter');
    }
  });
  scrollThread();
}

function formatFileSize(bytes) {
  var size = Number(bytes) || 0;
  if (size < 1024) return size + ' B';
  if (size < 1024 * 1024) return (size / 1024).toFixed(1) + ' KB';
  if (size < 1024 * 1024 * 1024) return (size / (1024 * 1024)).toFixed(1) + ' MB';
  return (size / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
}

function resolveAssetUrl(path) {
  if (!path) return '';
  if (/^(https?:|data:|blob:)/i.test(path)) return path;
  return (apiBase || '') + path;
}

function attachmentIcon(mime) {
  if (!mime) {
    return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>';
  }
  if (mime.indexOf('image/') === 0) {
    return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><path d="M21 15l-5-5L5 21"></path></svg>';
  }
  if (mime.indexOf('video/') === 0) {
    return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="14" height="14" rx="2"></rect><polygon points="22 7 16 11 16 13 22 17 22 7"></polygon></svg>';
  }
  if (mime.indexOf('audio/') === 0) {
    return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg>';
  }
  return '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="9" y1="15" x2="15" y2="15"></line></svg>';
}

function renderFileAttachment(container, file) {
  if (!file || !file.rawUrl) return;
  var raw = resolveAssetUrl(file.rawUrl);
  var share = resolveAssetUrl(file.url || file.rawUrl);
  var mime = String(file.mimeType || '');
  var wrap = document.createElement('div');
  wrap.className = 'message__attachment';
  if (mime.indexOf('image/') === 0) {
    var link = document.createElement('a');
    link.href = share;
    link.target = '_blank';
    link.rel = 'noopener';
    var img = document.createElement('img');
    img.src = raw;
    img.alt = file.name || 'Shared image';
    img.loading = 'lazy';
    link.appendChild(img);
    wrap.appendChild(link);
  } else if (mime.indexOf('video/') === 0) {
    var video = document.createElement('video');
    video.src = raw;
    video.controls = true;
    video.playsInline = true;
    video.preload = 'metadata';
    wrap.appendChild(video);
  } else if (mime.indexOf('audio/') === 0) {
    var audio = document.createElement('audio');
    audio.src = raw;
    audio.controls = true;
    audio.preload = 'metadata';
    wrap.appendChild(audio);
  }
  var card = document.createElement('a');
  card.className = 'attachment-card';
  card.href = share;
  card.target = '_blank';
  card.rel = 'noopener';
  var icon = document.createElement('span');
  icon.className = 'attachment-card__icon';
  icon.innerHTML = attachmentIcon(mime);
  var body = document.createElement('span');
  body.className = 'attachment-card__body';
  var name = document.createElement('span');
  name.className = 'attachment-card__name';
  name.textContent = file.name || 'Shared file';
  var meta = document.createElement('span');
  meta.className = 'attachment-card__meta';
  meta.textContent = formatFileSize(file.size) +
    (file.text ? ' · ' + (file.pages || 1) + ' page(s) analyzed' : ' · tap to share');
  body.appendChild(name);
  body.appendChild(meta);
  if (file.text) {
    var badge = document.createElement('span');
    badge.className = 'attachment-card__badge';
    badge.textContent = 'READY';
    card.appendChild(badge);
  }
  card.appendChild(icon);
  card.appendChild(body);
  wrap.appendChild(card);
  container.appendChild(wrap);
}

function openShareModal(file) {
  if (!file || !els.shareModal) return;
  var link = file.url || file.shareUrl || file.rawUrl || '';
  if (link) link = resolveAssetUrl(link);
  if (els.shareUrlInput) els.shareUrlInput.value = link;
  if (els.shareFileMeta) {
    els.shareFileMeta.textContent = '';
    var icon = document.createElement('span');
    icon.innerHTML = attachmentIcon(file.mimeType);
    if (icon.firstChild) els.shareFileMeta.appendChild(icon.firstChild);
    var info = document.createElement('span');
    info.textContent = (file.name || 'Shared file') + ' · ' + formatFileSize(file.size);
    els.shareFileMeta.appendChild(info);
  }
  if (els.shareOpenLink) els.shareOpenLink.href = link;
  if (els.shareNativeBtn) els.shareNativeBtn.hidden = !(navigator.share);
  els.shareModal.hidden = false;
  if (els.shareCopyBtn) els.shareCopyBtn.textContent = 'Copy link';
}

function closeShareModal() {
  if (els.shareModal) els.shareModal.hidden = true;
}

function shareLinkToOthers() {
  var link = els.shareUrlInput ? els.shareUrlInput.value : '';
  if (!link || !navigator.share) return;
  navigator.share({
    title: 'Rebbet AI',
    text: 'Shared with Rebbet AI',
    url: link
  }).catch(function() {});
}

function readFileAsDataURL(file) {
  return new Promise(function(resolve, reject) {
    var reader = new FileReader();
    reader.onload = function() { resolve(String(reader.result || '')); };
    reader.onerror = function() { reject(reader.error || new Error('Could not read file')); };
    reader.readAsDataURL(file);
  });
}

function isAnalyzableFile(file) {
  if (!file) return false;
  var mime = String(file.mimeType || '').toLowerCase();
  var name = String(file.name || '').toLowerCase();
  if (mime === 'application/pdf' || name.endsWith('.pdf')) return true;
  if (mime.indexOf('text/') === 0 || mime === 'application/json') return true;
  return /\.(txt|md|csv|json|xml|yaml|yml|html?|log|py|js|mjs|rst)$/.test(name);
}

async function analyzeDocument(fileId) {
  var response = await apiFetch('/api/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ fileId: fileId })
  });
  var payload = {};
  try { payload = await response.json(); } catch (e) {}
  if (!response.ok) {
    throw new Error((payload.error && payload.error.message) || 'Could not read that document');
  }
  return payload;
}

async function uploadFile(file) {
  if (!file) return;
  var limit = (state.appConfig && state.app_config_max) || (state.appConfig && state.appConfig.max_upload_mb) || 25;
  if (file.size > limit * 1024 * 1024) {
    showToast('File is larger than ' + limit + ' MB');
    return;
  }
  if (els.attachBtn) els.attachBtn.classList.add('is-uploading');
  showToast('Uploading ' + file.name + '…');
  try {
    var dataUrl = await readFileAsDataURL(file);
    var response = await apiFetch('/api/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: file.name, mimeType: file.type || '', data: dataUrl })
    });
    var payload = {};
    try { payload = await response.json(); } catch (e) {}
    if (!response.ok) {
      throw new Error((payload.error && payload.error.message) || 'Upload failed');
    }
    var shared = payload.file;
    if (!shared) throw new Error('Upload did not return a file');
    var analyzed = false;
    if (isAnalyzableFile(shared)) {
      showToast('Reading ' + shared.name + '…');
      try {
        var analysis = await analyzeDocument(shared.id);
        shared.text = String(analysis.text || '').slice(0, 50000);
        shared.pages = analysis.pages || 1;
        shared.charCount = analysis.chars || shared.text.length;
        shared.truncated = !!analysis.truncated;
        analyzed = !!shared.text;
      } catch (docError) {
        showToast(docError && docError.message ? docError.message : 'Document analysis failed');
      }
    }
    var chat = getActiveChat();
    if (!chat) {
      createChat(false);
      chat = getActiveChat();
    }
    if (!chat) throw new Error('Could not open a chat');
    var msg = {
      id: uid(),
      role: 'user',
      content: analyzed
        ? 'Attached ' + (shared.name || 'document') + ' (' + (shared.pages || 1) + ' page' + ((shared.pages || 1) === 1 ? '' : 's') + '). Ask me about it.'
        : 'Shared ' + (shared.name || 'file'),
      file: shared,
      time: nowTime()
    };
    chat.messages.push(msg);
    if (chat.title === 'New chat') updateChatTitle(chat);
    saveChats();
    renderThread();
    if (analyzed) {
      showToast('Document ready — ask a question about it');
      els.composerInput.focus();
    } else {
      openShareModal(shared);
      showToast('Link ready — copy or share it');
    }
  } catch (error) {
    showToast(error && error.message ? error.message : 'Upload failed');
  } finally {
    if (els.attachBtn) els.attachBtn.classList.remove('is-uploading');
    if (els.fileInput) els.fileInput.value = '';
  }
}

async function loadAppConfig() {
  try {
    var response = await apiFetch('/api/app-config', { cache: 'no-store' });
    if (!response.ok) return;
    var config = await response.json();
    state.appConfig = config;
    applyAppConfig(config);
  } catch (e) {}
}

function applyAppConfig(config) {
  if (!config) return;
  if (config.icon) {
    var iconUrl = resolveAssetUrl(config.icon);
    if (els.appFavicon) els.appFavicon.href = iconUrl;
    if (els.appTouchIcon) els.appTouchIcon.href = iconUrl;
  }
  if (els.updateBtn && config.update_available && config.update_url) {
    els.updateBtn.hidden = false;
    els.updateBtn.title = config.update_message || ('Update to v' + (config.version || ''));
    els.updateBtn.addEventListener('click', function() {
      window.open(resolveAssetUrl(config.update_url), '_blank', 'noopener');
    });
  }
}

function renderUserMessage(msg) {
  var chat = getActiveChat();
  var idx = chat ? chat.messages.indexOf(msg) : -1;
  var wrap = document.createElement('div');
  wrap.className = 'message';
  var meta = document.createElement('div');
  meta.className = 'message__meta';
  meta.style.justifyContent = 'flex-end';
  var name = document.createElement('div');
  name.className = 'message__name';
  name.textContent = 'You';
  var time = document.createElement('div');
  time.className = 'message__time';
  time.textContent = msg.time || nowTime();
  meta.appendChild(time);
  meta.appendChild(name);
  var avatar = document.createElement('div');
  avatar.className = 'message__avatar message__avatar--user';
  avatar.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="8" r="4"></circle><path d="M12 14c-6 0-8 3-8 4v2h16v-2c0-1-2-4-8-4z"></path></svg>';
  meta.appendChild(avatar);
  var bubble = document.createElement('div');
  bubble.className = 'message__bubble message__bubble--user';
  var content = document.createElement('div');
  content.className = 'message__content';
  var p = document.createElement('p');
  p.textContent = msg.content;
  content.appendChild(p);
  if (msg.file) renderFileAttachment(content, msg.file);
  bubble.appendChild(content);
  var actions = document.createElement('div');
  actions.className = 'message__actions';
  actions.style.justifyContent = 'flex-end';
  var editBtn = document.createElement('button');
  editBtn.className = 'chip';
  editBtn.textContent = 'Edit';
  editBtn.addEventListener('click', function() {
    if (idx >= 0) editUserMessage(idx);
  });
  actions.appendChild(editBtn);
  if (msg.file && (msg.file.url || msg.file.rawUrl)) {
    var copyBtn = document.createElement('button');
    copyBtn.className = 'chip';
    copyBtn.textContent = 'Copy link';
    copyBtn.addEventListener('click', function() { copyText(msg.file.url || msg.file.rawUrl); showToast('Copied'); });
    actions.appendChild(copyBtn);
    var shareBtn = document.createElement('button');
    shareBtn.className = 'chip';
    shareBtn.textContent = 'Share';
    shareBtn.addEventListener('click', function() { openShareModal(msg.file); });
    actions.appendChild(shareBtn);
    var openLink = document.createElement('a');
    openLink.className = 'chip';
    openLink.href = msg.file.url || msg.file.rawUrl;
    openLink.target = '_blank';
    openLink.rel = 'noopener';
    openLink.textContent = 'Open';
    actions.appendChild(openLink);
  }
  wrap.appendChild(meta);
  wrap.appendChild(bubble);
  wrap.appendChild(actions);
  els.thread.appendChild(wrap);
}

function copyText(text) {
  if (!text) return;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(function() {
      showToast('Copied');
    }).catch(function() {
      fallbackCopy(text);
    });
    return;
  }
  fallbackCopy(text);
}

function fallbackCopy(text) {
  var area = document.createElement('textarea');
  area.value = text;
  area.setAttribute('readonly', '');
  area.style.position = 'fixed';
  area.style.opacity = '0';
  document.body.appendChild(area);
  area.select();
  try {
    document.execCommand('copy');
    showToast('Copied');
  } catch (e) {
    showToast('Could not copy');
  }
  area.remove();
}

function renderAssistantMessage(msg) {
  var wrap = document.createElement('div');
  wrap.className = 'message';
  var meta = document.createElement('div');
  meta.className = 'message__meta';
  var avatar = document.createElement('div');
  avatar.className = 'message__avatar message__avatar--assistant';
  avatar.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"></circle><path d="M12 1v6m0 6v6M4.22 4.22l4.24 4.24m5.08 5.08l4.24 4.24M1 12h6m6 0h6M4.22 19.78l4.24-4.24m5.08-5.08l4.24-4.24"></path></svg>';
  var name = document.createElement('div');
  name.className = 'message__name';
  name.textContent = msg.modelLabel || 'Rebbet AI';
  var time = document.createElement('div');
  time.className = 'message__time';
  time.textContent = msg.time || nowTime();
  meta.appendChild(avatar);
  meta.appendChild(name);
  meta.appendChild(time);
  var bubble = document.createElement('div');
  bubble.className = 'message__bubble message__bubble--assistant';
  var content = document.createElement('div');
  content.className = 'message__content';
  if (msg.html) {
    content.innerHTML = msg.html;
  } else {
    var p = document.createElement('p');
    p.textContent = msg.content;
    content.appendChild(p);
  }
  if (msg.image) {
    var image = document.createElement('img');
    image.src = msg.image;
    image.alt = msg.imageAlt || msg.content || 'Generated image';
    image.loading = 'lazy';
    image.className = 'message__image';
    content.appendChild(image);
  }
  enhanceRenderedContent(content);
  bubble.appendChild(content);
  var actions = document.createElement('div');
  actions.className = 'message__actions';
  var copyBtn = document.createElement('button');
  copyBtn.className = 'chip';
  copyBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg> Copy';
  copyBtn.addEventListener('click', function() {
    copyText(msg.raw || msg.content || '');
  });
  actions.appendChild(copyBtn);
  var speakBtn = document.createElement('button');
  speakBtn.className = 'chip';
  speakBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path><path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path></svg> Speak';
  speakBtn.addEventListener('click', function() {
    speak(msg.content || msg.raw || '');
  });
  actions.appendChild(speakBtn);
  if (msg.image) {
    var downloadBtn = document.createElement('button');
    downloadBtn.className = 'chip';
    downloadBtn.textContent = 'Download';
    downloadBtn.addEventListener('click', function() {
      var link = document.createElement('a');
      link.href = msg.image;
      link.download = msg.image.indexOf('image/png') === 5 ? 'rebbet-ai-image.png' : 'rebbet-ai-image.jpg';
      document.body.appendChild(link);
      link.click();
      link.remove();
    });
    actions.appendChild(downloadBtn);
  }
  if (!msg.image) {
    var regenBtn = document.createElement('button');
    regenBtn.className = 'chip';
    regenBtn.textContent = 'Regenerate';
    regenBtn.addEventListener('click', function() {
      var chat = getActiveChat();
      if (!chat) return;
      chat.messages = chat.messages.slice(0, -1);
      saveChats();
      renderThread();
      sendMessage();
    });
    actions.appendChild(regenBtn);
  }
  wrap.appendChild(meta);
  wrap.appendChild(bubble);
  wrap.appendChild(actions);
  els.thread.appendChild(wrap);
}

function renderStreamingPlaceholder(chat, options) {
  options = options || {};
  var kind = options.kind || 'text';
  var label = options.label || (kind === 'image' ? 'Creating your image' : 'Thinking');
  var wrap = document.createElement('div');
  wrap.className = 'message message--streaming';
  wrap.id = 'streamingWrap';
  var meta = document.createElement('div');
  meta.className = 'message__meta';
  var avatar = document.createElement('div');
  avatar.className = 'message__avatar message__avatar--assistant message__avatar--busy';
  avatar.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"></circle><path d="M12 1v6m0 6v6M4.22 4.22l4.24 4.24m5.08 5.08l4.24 4.24M1 12h6m6 0h6M4.22 19.78l4.24-4.24m5.08-5.08l4.24-4.24"></path></svg>';
  var name = document.createElement('div');
  name.className = 'message__name';
  name.textContent = state.modelsById.get(state.selectedModel)?.label || state.selectedModel || 'Rebbet AI';
  var time = document.createElement('div');
  time.className = 'message__time';
  time.textContent = nowTime();
  meta.appendChild(avatar);
  meta.appendChild(name);
  meta.appendChild(time);

  var typing = document.createElement('div');
  typing.className = 'typing';
  var dots = document.createElement('div');
  dots.className = 'typing__dots';
  var d1 = document.createElement('div');
  d1.className = 'typing__dot';
  var d2 = document.createElement('div');
  d2.className = 'typing__dot';
  var d3 = document.createElement('div');
  d3.className = 'typing__dot';
  dots.appendChild(d1);
  dots.appendChild(d2);
  dots.appendChild(d3);
  var head = document.createElement('div');
  head.className = 'typing__head';
  head.appendChild(dots);
  var labelEl = document.createElement('span');
  labelEl.className = 'typing__label';
  labelEl.textContent = label;
  head.appendChild(labelEl);
  var wave = document.createElement('span');
  wave.className = 'typing__wave';
  wave.setAttribute('aria-hidden', 'true');
  wave.innerHTML = '<i></i><i></i><i></i><i></i>';
  head.appendChild(wave);
  typing.appendChild(head);

  if (kind === 'image') {
    typing.className += ' typing--image';
    var skeleton = document.createElement('div');
    skeleton.className = 'image-skeleton';
    skeleton.innerHTML =
      '<div class="image-skeleton__grid"></div>' +
      '<div class="image-skeleton__glow"></div>' +
      '<div class="image-skeleton__sweep"></div>' +
      '<div class="image-skeleton__scan"></div>' +
      '<div class="image-skeleton__icon">' +
      '<svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
      '<rect x="3" y="3" width="18" height="18" rx="3"></rect>' +
      '<circle cx="8.5" cy="8.5" r="1.5"></circle>' +
      '<path d="m21 15-4.35-4.35a2 2 0 0 0-2.83 0L4 21"></path>' +
      '</svg></div>' +
      '<div class="image-skeleton__phases" aria-hidden="true">' +
      '<span>Composing the scene</span>' +
      '<span>Rendering details</span>' +
      '<span>Adding final polish</span>' +
      '</div>' +
      '<div class="image-skeleton__progress" aria-hidden="true"><i></i></div>';
    typing.appendChild(skeleton);
  }

  wrap.appendChild(meta);
  wrap.appendChild(typing);
  els.thread.appendChild(wrap);
  scrollThread();
}

function updateStreamingBubble(text, thinking) {
  var existing = document.getElementById('streamingWrap');
  if (!existing) return;
  var typing = existing.querySelector('.typing');
  if (typing) typing.remove();
  existing.classList.remove('message--streaming');
  existing.classList.add('message--live');
  var bubble = existing.querySelector('.message__bubble');
  if (!bubble) {
    bubble = document.createElement('div');
    bubble.className = 'message__bubble message__bubble--assistant';
    existing.appendChild(bubble);
  }
  var content = bubble.querySelector('.message__content');
  if (!content) {
    content = document.createElement('div');
    content.className = 'message__content';
    bubble.appendChild(content);
  }
  if (text && text.length) {
    if (window.marked && window.DOMPurify) {
      var html = DOMPurify.sanitize(marked.parse(text));
      content.innerHTML = html;
    } else {
      content.textContent = text;
    }
  }
  var caret = document.createElement('span');
  caret.className = 'stream-caret';
  caret.setAttribute('aria-hidden', 'true');
  content.appendChild(caret);
  scrollThread();
}

function removeStreamingPlaceholder() {
  var existing = document.getElementById('streamingWrap');
  if (existing) existing.remove();
}

function extractImagePrompt(text) {
  var value = String(text || '').trim();
  var slash = value.match(/^\/(?:image|imagine)\b\s*([\s\S]*)$/i);
  if (slash) return slash[1].trim();
  var intent = value.match(/^(?:generate|create|draw|make|render)\s+(?:me\s+)?(?:an?\s+)?(?:image|picture|photo|art|drawing|illustration)\s*(?:of|showing|with|depicting|:)\s*([\s\S]+)$/i);
  if (intent) return intent[1].trim();
  return null;
}

function blobToDataUrl(blob) {
  return new Promise(function(resolve, reject) {
    var reader = new FileReader();
    reader.onload = function() { resolve(reader.result); };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

function shrinkImage(blob) {
  return new Promise(function(resolve) {
    var url = URL.createObjectURL(blob);
    var image = new Image();
    image.onload = function() {
      try {
        var max = 768;
        var width = image.naturalWidth;
        var height = image.naturalHeight;
        var scale = Math.min(1, max / Math.max(width, height));
        width = Math.max(1, Math.round(width * scale));
        height = Math.max(1, Math.round(height * scale));
        var canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(image, 0, 0, width, height);
        var data = canvas.toDataURL('image/jpeg', 0.87);
        URL.revokeObjectURL(url);
        resolve(data);
      } catch (e) {
        URL.revokeObjectURL(url);
        blobToDataUrl(blob).then(resolve).catch(function() { resolve(''); });
      }
    };
    image.onerror = function() {
      URL.revokeObjectURL(url);
      blobToDataUrl(blob).then(resolve).catch(function() { resolve(''); });
    };
    image.src = url;
  });
}

async function generateImage(promptText) {
  var chat = getActiveChat();
  if (!chat) return;
  var prompt = String(promptText || '').trim();
  if (!prompt) {
    showToast('Describe the image you want');
    return;
  }
  if (state.sending) return;
  chat.messages.push({ role: 'user', content: prompt, time: nowTime() });
  updateChatTitle(chat);
  saveChats();
  renderThread();
  els.composerInput.value = '';
  autoResize();
  state.sending = true;
  state.stopRequested = false;
  state.abortController = new AbortController();
  els.composerSend.disabled = true;
  els.composerSend.classList.add('is-busy');
  if (els.composerStop) els.composerStop.hidden = false;
  setComposerStatus('Painting your image…');
  renderStreamingPlaceholder(chat, { label: 'Creating your image', kind: 'image' });
  try {
    var res = await apiFetch('/api/image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: prompt, width: 768, height: 768 }),
      signal: state.abortController.signal
    });
    if (!res.ok) {
      var info = null;
      try { info = await res.json(); } catch (e) {}
      var message = info && info.error && info.error.message ? info.error.message : 'Image generation failed';
      var hint = info && info.error && info.error.hint ? info.error.hint : '';
      throw new Error(message + (hint ? ' ' + hint : ''));
    }
    var blob = await res.blob();
    if (!blob || !blob.size) throw new Error('The image service returned an empty image.');
    var imageData = await shrinkImage(blob);
    if (!imageData) throw new Error('Could not read the generated image.');
    var source = res.headers.get('X-Image-Source') || '';
    removeStreamingPlaceholder();
    chat.messages.push({
      role: 'assistant',
      content: 'Generated image: ' + prompt,
      raw: prompt,
      image: imageData,
      imageAlt: prompt,
      time: nowTime(),
      modelLabel: source === 'gemini' ? 'Rebbet Image' : 'Rebbet Image (free)'
    });
    saveChats();
    renderThread();
    scrollThread();
    trackEvent('image_generated', { source: source || 'unknown' });
    showToast('Image ready');
  } catch (e) {
    removeStreamingPlaceholder();
    if ((e && e.name === 'AbortError') || state.stopRequested) {
      showToast('Stopped');
      return;
    }
    chat.messages.push({
      role: 'assistant',
      content: 'Image generation failed. ' + (e && e.message ? e.message : ''),
      raw: 'Image generation failed',
      time: nowTime(),
      modelLabel: 'Rebbet Image'
    });
    saveChats();
    renderThread();
    showToast('Image failed');
  } finally {
    state.sending = false;
    state.abortController = null;
    state.stopRequested = false;
    els.composerSend.disabled = !els.composerInput.value.trim();
    els.composerSend.classList.remove('is-busy');
    if (els.composerStop) els.composerStop.hidden = true;
    setComposerStatus('Rebbet AI can make mistakes. Check important information.');
  }
}

async function sendMessage() {
  var chat = getActiveChat();
  if (!chat) return;
  var text = els.composerInput.value.replace(/\r\n/g, '\n').trim();
  if (!text || state.sending) return;
  var imagePrompt = extractImagePrompt(text);
  if (imagePrompt !== null) {
    if (!imagePrompt) {
      showToast('Add a description after /image');
      return;
    }
    await generateImage(imagePrompt);
    return;
  }
  var model = chat.model || state.selectedModel || DEFAULT_MODEL;
  trackEvent('chat_request', { model: model, web_search: !!webSearchEnabled });
  var userMsg = {
    role: 'user',
    content: text,
    time: nowTime()
  };
  chat.messages.push(userMsg);
  updateChatTitle(chat);
  saveChats();
  renderThread();
  els.composerInput.value = '';
  autoResize();
  state.sending = true;
  state.stopRequested = false;
  state.abortController = new AbortController();
  els.composerSend.disabled = true;
  els.composerSend.classList.add('is-busy');
  if (els.composerStop) els.composerStop.hidden = false;
  setComposerStatus(webSearchEnabled ? 'Searching the web…' : 'Thinking…');
  renderStreamingPlaceholder(chat, { label: webSearchEnabled ? 'Searching the web' : 'Thinking' });

  try {
    var history = chat.messages.slice(-20).map(function(m) {
      return apiMessage(m);
    });
    var res;
    try {
      res = await apiFetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: model,
          messages: history,
          web_search: webSearchEnabled,
          memory: memoryPayload(),
          personality: currentPersonalityPayload()
        }),
        signal: state.abortController.signal
      });
    } catch (e) {
      removeStreamingPlaceholder();
      if ((e && e.name === 'AbortError') || state.stopRequested) {
        showToast('Stopped');
        return;
      }
      resetApiBase();
      var assistantMsgNet2 = {
        role: 'assistant',
        content: 'Network error. I could not reach the Rebbet AI server. Check your connection and try again.',
        raw: String(e),
        time: nowTime(),
        modelLabel: state.modelsById.get(model)?.label || model
      };
      if (window.marked && window.DOMPurify) {
        assistantMsgNet2.html = DOMPurify.sanitize(marked.parse(assistantMsgNet2.content));
      }
      chat.messages.push(assistantMsgNet2);
      saveChats();
      renderThread();
      showToast('Connection failed');
      return;
    }

    if (!res.ok) {
      var errJson = null;
      try { errJson = await res.json(); } catch(e) {}
      var errMsg = errJson && errJson.error && errJson.error.message ? errJson.error.message : ('Error: ' + res.status);
      var hint = errJson && errJson.error && errJson.error.hint ? errJson.error.hint : '';
      removeStreamingPlaceholder();
      var assistantMsg = {
        role: 'assistant',
        content: errMsg + (hint ? '\n\n' + hint : ''),
        raw: errMsg,
        time: nowTime(),
        modelLabel: state.modelsById.get(model)?.label || model
      };
      if (window.marked && window.DOMPurify) {
        assistantMsg.html = DOMPurify.sanitize(marked.parse(assistantMsg.content));
      }
      chat.messages.push(assistantMsg);
      saveChats();
      renderThread();
      showToast('Request failed');
      return;
    }

    if (!res.body) throw new Error('The server returned an empty stream.');
    var reader = res.body.getReader();
    var decoder = new TextDecoder();
    var buffer = '';
    var fullText = '';
    var usage = null;
    var activeModel = model;
    var activeProvider = '';
    var streamError = '';

    while (true) {
      if (state.stopRequested) {
        try { await reader.cancel(); } catch (cancelError) {}
        break;
      }
      var result = await reader.read();
      if (result.done) break;
      buffer += decoder.decode(result.value, { stream: true });
      var parts = buffer.split('\n\n');
      buffer = parts.pop();
      for (var i = 0; i < parts.length; i++) {
        var chunk = parts[i];
        if (!chunk.startsWith('data:')) continue;
        var jsonStr = chunk.slice(5).trim();
        if (!jsonStr) continue;
        try {
          var ev = JSON.parse(jsonStr);
        } catch(e) {
          continue;
        }
        if (ev.type === 'meta') {
          activeModel = ev.model || model;
          activeProvider = ev.provider || '';
          var streamWrap = document.getElementById('streamingWrap');
          if (streamWrap) {
            var streamName = streamWrap.querySelector('.message__name');
            if (streamName) {
              streamName.textContent = state.modelsById.get(activeModel)?.label || activeModel;
            }
          }
          if (ev.switched) {
            var switchedLabel = state.modelsById.get(activeModel)?.label || activeModel;
            showToast('Switched to ' + switchedLabel);
            trackEvent('model_switched', {
              requested_model: model,
              model: activeModel,
              provider: activeProvider
            });
          }
        } else if (ev.type === 'delta' && typeof ev.text === 'string') {
          fullText += ev.text;
          updateStreamingBubble(fullText);
        } else if (ev.type === 'thinking') {
          // show subtle indicator is handled by placeholder
        } else if (ev.type === 'error') {
          streamError = ev.message || 'Unknown error';
          if (ev.hint) streamError += '\n\n' + ev.hint;
          try { await reader.cancel(); } catch (cancelError) {}
          break;
        } else if (ev.type === 'done') {
          usage = ev.usage || null;
        }
      }
      if (streamError) break;
    }

    removeStreamingPlaceholder();
    if (streamError && !fullText.trim()) {
      var assistantMsgErr = {
        role: 'assistant',
        content: streamError,
        raw: streamError,
        time: nowTime(),
        modelLabel: state.modelsById.get(activeModel)?.label || activeModel
      };
      if (window.marked && window.DOMPurify) {
        assistantMsgErr.html = DOMPurify.sanitize(marked.parse(assistantMsgErr.content));
      }
      chat.messages.push(assistantMsgErr);
      saveChats();
      renderThread();
      showToast('Error');
    } else if (fullText.length) {
      var stopped = state.stopRequested;
      var finalText = fullText;
      if (streamError) finalText += '\n\n> Response interrupted: ' + streamError;
      if (stopped) finalText += '\n\n*Stopped by you.*';
      var assistantMsg = {
        role: 'assistant',
        content: finalText,
        raw: fullText,
        stopped: stopped,
        time: nowTime(),
        modelLabel: state.modelsById.get(activeModel)?.label || activeModel,
        provider: activeProvider
      };
      if (window.marked && window.DOMPurify) {
        assistantMsg.html = DOMPurify.sanitize(marked.parse(finalText));
      }
      chat.messages.push(assistantMsg);
      saveChats();
      renderThread();
      trackEvent('chat_response', {
        model: activeModel,
        provider: activeProvider,
        web_search: !!webSearchEnabled,
        stopped: !!stopped
      });
      if (voice.enabled && !stopped) speak(fullText);
      if (stopped) showToast('Stopped');
    } else {
      showToast('Empty response');
    }
  } catch (e) {
    removeStreamingPlaceholder();
    if ((e && e.name === 'AbortError') || state.stopRequested) {
      if (typeof fullText === 'string' && fullText.trim()) {
        var stoppedMsg = {
          role: 'assistant',
          content: fullText + '\n\n*Stopped by you.*',
          raw: fullText,
          stopped: true,
          time: nowTime(),
          modelLabel: state.modelsById.get(activeModel)?.label || model
        };
        if (window.marked && window.DOMPurify) {
          stoppedMsg.html = DOMPurify.sanitize(marked.parse(stoppedMsg.content));
        }
        chat.messages.push(stoppedMsg);
        saveChats();
        renderThread();
      }
      showToast('Stopped');
    } else {
      resetApiBase();
      var assistantMsgNet = {
        role: 'assistant',
        content: 'Network error. Check that the server is running and reachable.',
        raw: 'Network error',
        time: nowTime(),
        modelLabel: state.modelsById.get(model)?.label || model
      };
      if (window.marked && window.DOMPurify) {
        assistantMsgNet.html = DOMPurify.sanitize(marked.parse(assistantMsgNet.content));
      }
      chat.messages.push(assistantMsgNet);
      saveChats();
      renderThread();
      showToast('Connection failed');
    }
  } finally {
    state.sending = false;
    state.abortController = null;
    state.stopRequested = false;
    els.composerSend.disabled = !els.composerInput.value.trim();
    els.composerSend.classList.remove('is-busy');
    if (els.composerStop) els.composerStop.hidden = true;
    setComposerStatus('Rebbet AI can make mistakes. Check important information.');
  }
}

function autoResize() {
  var ta = els.composerInput;
  ta.style.height = 'auto';
  ta.style.height = Math.min(140, ta.scrollHeight) + 'px';
}

els.menuBtn.addEventListener('click', openSidebar);
els.sidebarClose.addEventListener('click', closeSidebar);
els.sidebarBackdrop.addEventListener('click', closeSidebar);
els.sidebarNew.addEventListener('click', function() { createChat(false); });
els.newChatBtn.addEventListener('click', function() { createChat(false); });

els.modelTrigger.addEventListener('click', openModelSheet);
els.modelBackdrop.addEventListener('click', closeModelSheet);
els.modelClose.addEventListener('click', closeModelSheet);
els.modelSearch.addEventListener('input', function() {
  renderModels(els.modelSearch.value);
});

els.composerInput.addEventListener('input', function() {
  autoResize();
  els.composerSend.disabled = state.sending || !els.composerInput.value.trim();
});

els.composerInput.addEventListener('keydown', function(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

els.composerSend.addEventListener('click', sendMessage);
els.composerSend.disabled = true;
if (els.callBtn) els.callBtn.addEventListener('click', startVoiceCall);
if (els.callEnd) els.callEnd.addEventListener('click', endVoiceCall);
if (els.callMute) els.callMute.addEventListener('click', toggleCallMute);
if (els.callOrb) els.callOrb.addEventListener('click', handleCallOrb);
els.composerMic.addEventListener('click', toggleRecording);
if (els.attachBtn) {
  els.attachBtn.addEventListener('click', function() {
    if (els.fileInput) els.fileInput.click();
  });
}
if (els.fileInput) {
  els.fileInput.addEventListener('change', function() {
    var file = els.fileInput.files && els.fileInput.files[0];
    if (file) uploadFile(file);
  });
}
if (els.shareBackdrop) els.shareBackdrop.addEventListener('click', closeShareModal);
if (els.shareCopyBtn) {
  els.shareCopyBtn.addEventListener('click', function() {
    copyText(els.shareUrlInput ? els.shareUrlInput.value : '');
    els.shareCopyBtn.textContent = 'Copied';
  });
}
if (els.shareNativeBtn) els.shareNativeBtn.addEventListener('click', shareLinkToOthers);
if (els.thread) {
  ['dragenter', 'dragover'].forEach(function(name) {
    els.thread.addEventListener(name, function(e) {
      e.preventDefault();
      els.thread.classList.add('is-dragging');
    });
  });
  ['dragleave', 'drop'].forEach(function(name) {
    els.thread.addEventListener(name, function(e) {
      e.preventDefault();
      els.thread.classList.remove('is-dragging');
    });
  });
  els.thread.addEventListener('drop', function(e) {
    var file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (file) uploadFile(file);
  });
}
els.composerInput.addEventListener('paste', function(e) {
  var file = e.clipboardData && e.clipboardData.files && e.clipboardData.files[0];
  if (file) {
    e.preventDefault();
    uploadFile(file);
  }
});
if (els.composerImage) {
  els.composerImage.addEventListener('click', function() {
    var text = els.composerInput.value.trim();
    var imagePrompt = extractImagePrompt(text);
    if (imagePrompt === null || !imagePrompt) {
      imagePrompt = window.prompt('Describe the image you want', text || '');
    }
    if (imagePrompt && imagePrompt.trim()) {
      generateImage(imagePrompt.trim());
    }
  });
}
els.voiceToggle.addEventListener('click', openVoiceSheet);
if (els.voiceBackdrop) els.voiceBackdrop.addEventListener('click', closeVoiceSheet);
if (els.voiceClose) els.voiceClose.addEventListener('click', closeVoiceSheet);
var voiceEnableRow = document.getElementById('voiceEnableRow');
if (voiceEnableRow) voiceEnableRow.addEventListener('click', toggleVoice);
var voiceSpeedGroup = document.getElementById('voiceSpeedGroup');
if (voiceSpeedGroup) {
  voiceSpeedGroup.addEventListener('click', function(e) {
    var btn = e.target && e.target.closest ? e.target.closest('button[data-speed]') : null;
    if (!btn) return;
    voice.speed = btn.getAttribute('data-speed') || 'fast';
    saveVoicePref('rebbet_voice_speed', voice.speed);
    updateVoiceControls();
  });
}
if (els.voiceSelect) {
  els.voiceSelect.addEventListener('change', function() {
    voice.id = els.voiceSelect.value;
    saveVoicePref('rebbet_voice_id', voice.id);
    stopVoicePreview();
  });
}
if (els.voiceModelSelect) {
  els.voiceModelSelect.addEventListener('change', function() {
    voice.model = els.voiceModelSelect.value;
    saveVoicePref('rebbet_voice_model', voice.model);
  });
}
if (els.voicePreviewBtn) els.voicePreviewBtn.addEventListener('click', previewVoice);
if (els.searchToggle) {
  els.searchToggle.addEventListener('click', toggleWebSearch);
}

/* --------------------------------------------------------------------------
   Themes, memory, personalities, folders, export, stop and polish
   -------------------------------------------------------------------------- */

function loadTheme() {
  var theme = 'dark';
  try {
    var saved = localStorage.getItem('rebbet_theme');
    if (saved === 'light' || saved === 'dark') theme = saved;
    else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) theme = 'light';
  } catch (e) {}
  applyTheme(theme, false);
}

function applyTheme(theme, persist) {
  state.theme = theme === 'light' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', state.theme);
  var meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', state.theme === 'light' ? '#f4f5fb' : '#080a13');
  if (els.menuThemeLabel) els.menuThemeLabel.textContent = state.theme === 'light' ? 'Dark mode' : 'Light mode';
  if (els.menuThemeIcon) els.menuThemeIcon.textContent = state.theme === 'light' ? '☀' : '☾';
  if (persist) {
    try { localStorage.setItem('rebbet_theme', state.theme); } catch (e) {}
  }
}

function toggleTheme() {
  applyTheme(state.theme === 'light' ? 'dark' : 'light', true);
  showToast(state.theme === 'light' ? 'Light mode' : 'Dark mode');
}

function loadWorkspacePrefs() {
  try {
    var memory = JSON.parse(localStorage.getItem('rebbet_memory') || '[]');
    state.memory = Array.isArray(memory) ? memory.filter(function(item) { return typeof item === 'string' && item.trim(); }).slice(0, 80) : [];
  } catch (e) { state.memory = []; }
  try {
    var folders = JSON.parse(localStorage.getItem('rebbet_folders') || '[]');
    state.folders = Array.isArray(folders) ? folders.filter(function(item) { return typeof item === 'string' && item.trim(); }) : [];
  } catch (e) { state.folders = []; }
}

function saveMemory() {
  try { localStorage.setItem('rebbet_memory', JSON.stringify(state.memory)); } catch (e) {}
  updateMenuMeta();
}

function saveFolders() {
  try { localStorage.setItem('rebbet_folders', JSON.stringify(state.folders)); } catch (e) {}
}

function updateMenuMeta() {
  if (els.menuMemoryCount) els.menuMemoryCount.textContent = state.memory.length ? String(state.memory.length) : '0';
  if (els.menuPersonality) {
    var chat = getActiveChat();
    var persona = getPersonalityById(chat && chat.personality);
    els.menuPersonality.textContent = persona ? persona.name : 'Default';
  }
}

function renderMemory() {
  if (!els.memoryList) return;
  els.memoryList.innerHTML = '';
  if (!state.memory.length) {
    var empty = document.createElement('div');
    empty.className = 'sheet-empty';
    empty.textContent = 'No memories yet. Add preferences, names, or facts you want Rebbet to remember.';
    els.memoryList.appendChild(empty);
  }
  state.memory.forEach(function(text, index) {
    var row = document.createElement('div');
    row.className = 'memory-item';
    var body = document.createElement('span');
    body.className = 'memory-item__text';
    body.textContent = text;
    var remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'memory-item__remove';
    remove.setAttribute('aria-label', 'Remove memory');
    remove.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';
    remove.addEventListener('click', function() {
      state.memory.splice(index, 1);
      saveMemory();
      renderMemory();
      showToast('Memory removed');
    });
    row.appendChild(body);
    row.appendChild(remove);
    els.memoryList.appendChild(row);
  });
}

function addMemory(text) {
  var clean = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 500);
  if (!clean) return;
  if (state.memory.some(function(item) { return item.toLowerCase() === clean.toLowerCase(); })) {
    showToast('Already remembered');
    return;
  }
  state.memory.unshift(clean);
  if (state.memory.length > 80) state.memory = state.memory.slice(0, 80);
  saveMemory();
  renderMemory();
  if (els.memoryInput) els.memoryInput.value = '';
  showToast('Added to memory');
}

function clearMemory() {
  if (!state.memory.length) return;
  if (!confirm('Clear all saved memories?')) return;
  state.memory = [];
  saveMemory();
  renderMemory();
  showToast('Memory cleared');
}

function openMemorySheet() {
  closeAppMenu();
  renderMemory();
  if (els.memorySheet) els.memorySheet.classList.add('is-open');
  setTimeout(function() { if (els.memoryInput) els.memoryInput.focus(); }, 160);
}

function closeMemorySheet() {
  if (els.memorySheet) els.memorySheet.classList.remove('is-open');
}

function getPersonalityById(id) {
  var key = String(id || 'default');
  if (key === 'custom') {
    try {
      var custom = JSON.parse(localStorage.getItem('rebbet_custom_persona') || 'null');
      if (custom && custom.system) {
        return { id: 'custom', name: custom.name || 'Custom', emoji: '✎', desc: 'Your instructions', system: custom.system };
      }
    } catch (e) {}
    return PERSONALITIES[0];
  }
  for (var i = 0; i < PERSONALITIES.length; i++) {
    if (PERSONALITIES[i].id === key) return PERSONALITIES[i];
  }
  return PERSONALITIES[0];
}

function activeChatPersonality() {
  var chat = getActiveChat();
  return chat ? chat.personality || 'default' : 'default';
}

function setChatPersonality(id, customSystem) {
  var chat = getActiveChat();
  if (!chat) {
    createChat(true);
    chat = getActiveChat();
  }
  if (!chat) return;
  if (id === 'custom') {
    var system = String(customSystem || '').trim();
    if (!system) {
      showToast('Write custom instructions first');
      return;
    }
    var custom = { name: 'Custom', system: system.slice(0, 4000) };
    try { localStorage.setItem('rebbet_custom_persona', JSON.stringify(custom)); } catch (e) {}
    chat.personality = 'custom';
  } else {
    chat.personality = id;
  }
  saveChats();
  renderPersonalityGrid();
  updatePersonaBadge();
  updateMenuMeta();
  renderSidebar();
  closePersonalitySheet();
  var persona = getPersonalityById(chat.personality);
  showToast('Personality: ' + persona.name);
}

function renderPersonalityGrid() {
  if (!els.personalityGrid) return;
  els.personalityGrid.innerHTML = '';
  var active = activeChatPersonality();
  var list = PERSONALITIES.slice();
  var custom = null;
  try { custom = JSON.parse(localStorage.getItem('rebbet_custom_persona') || 'null'); } catch (e) {}
  if (custom && custom.system) {
    list.push({ id: 'custom', name: custom.name || 'Custom', emoji: '✎', desc: 'Your instructions', system: custom.system });
  }
  if (els.customPersonality && custom && custom.system) els.customPersonality.value = custom.system;
  list.forEach(function(persona) {
    var card = document.createElement('button');
    card.type = 'button';
    card.className = 'personality-card' + (persona.id === active ? ' is-active' : '');
    var emoji = document.createElement('span');
    emoji.className = 'personality-card__emoji';
    emoji.textContent = persona.emoji || '✧';
    var name = document.createElement('span');
    name.className = 'personality-card__name';
    name.textContent = persona.name;
    var desc = document.createElement('span');
    desc.className = 'personality-card__desc';
    desc.textContent = persona.desc || '';
    card.appendChild(emoji);
    card.appendChild(name);
    card.appendChild(desc);
    card.addEventListener('click', function() { setChatPersonality(persona.id); });
    els.personalityGrid.appendChild(card);
  });
}

function openPersonalitySheet() {
  closeAppMenu();
  renderPersonalityGrid();
  if (els.personalitySheet) els.personalitySheet.classList.add('is-open');
}

function closePersonalitySheet() {
  if (els.personalitySheet) els.personalitySheet.classList.remove('is-open');
}

function updatePersonaBadge() {
  var persona = getPersonalityById(activeChatPersonality());
  if (els.composerPersona) {
    if (persona && persona.id !== 'default') {
      els.composerPersona.hidden = false;
      els.composerPersona.textContent = persona.emoji + ' ' + persona.name;
    } else {
      els.composerPersona.hidden = true;
      els.composerPersona.textContent = '';
    }
  }
  updateMenuMeta();
}

function allFolders() {
  var seen = {};
  var list = [];
  (state.folders || []).concat(state.chats.map(function(chat) { return chat.folder; })).forEach(function(name) {
    name = String(name || '').trim();
    if (!name || name === 'General') return;
    var key = name.toLowerCase();
    if (seen[key]) return;
    seen[key] = true;
    list.push(name);
  });
  return list.sort(function(a, b) { return a.localeCompare(b); });
}

function createFolder(name) {
  var clean = String(name || '').replace(/\s+/g, ' ').trim().slice(0, 40);
  if (!clean) return;
  var exists = allFolders().some(function(folder) { return folder.toLowerCase() === clean.toLowerCase(); });
  if (!exists) {
    state.folders.push(clean);
    saveFolders();
  }
  if (els.folderInput) els.folderInput.value = '';
  renderFolderList();
  renderFolderFilters();
  renderSidebar();
  showToast('Folder ready: ' + clean);
}

function moveChatToFolder(chat) {
  if (!chat) return;
  state.folderTargetId = chat.id;
  openFolderSheet();
}

function openFolderSheet() {
  closeAppMenu();
  renderFolderList();
  if (els.folderSheet) els.folderSheet.classList.add('is-open');
}

function closeFolderSheet() {
  if (els.folderSheet) els.folderSheet.classList.remove('is-open');
  state.folderTargetId = null;
}

function renderFolderList() {
  if (!els.folderList) return;
  els.folderList.innerHTML = '';
  var target = state.folderTargetId ? state.chats.find(function(chat) { return chat.id === state.folderTargetId; }) : null;
  var folders = ['General'].concat(allFolders());
  folders.forEach(function(name) {
    var row = document.createElement('div');
    row.className = 'folder-item' + (target && chatFolderName(target) === name ? ' is-active' : '');
    var open = document.createElement('button');
    open.type = 'button';
    open.className = 'folder-item__name';
    var count = state.chats.filter(function(chat) { return chatFolderName(chat) === name; }).length;
    open.textContent = name + ' · ' + count;
    open.addEventListener('click', function() {
      if (target) {
        target.folder = name === 'General' ? '' : name;
        saveChats();
        renderSidebar();
        renderFolderFilters();
        closeFolderSheet();
        showToast('Moved to ' + name);
      } else {
        state.folderFilter = name === 'General' ? 'all' : name;
        renderFolderFilters();
        renderSidebar();
        closeFolderSheet();
      }
    });
    row.appendChild(open);
    if (name !== 'General' && !target) {
      var del = document.createElement('button');
      del.type = 'button';
      del.className = 'folder-item__remove';
      del.setAttribute('aria-label', 'Delete folder');
      del.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';
      del.addEventListener('click', function() {
        state.chats.forEach(function(chat) {
          if (chatFolderName(chat) === name) chat.folder = '';
        });
        state.folders = state.folders.filter(function(folder) { return folder !== name; });
        if (state.folderFilter === name) state.folderFilter = 'all';
        saveFolders();
        saveChats();
        renderFolderList();
        renderFolderFilters();
        renderSidebar();
        showToast('Folder removed');
      });
      row.appendChild(del);
    }
    els.folderList.appendChild(row);
  });
}

function exportChat(chat, format) {
  chat = chat || getActiveChat();
  if (!chat || !chat.messages.length) {
    showToast('Nothing to export yet');
    return;
  }
  var safeTitle = (chat.title || 'rebbet-chat').replace(/[^A-Za-z0-9 _-]+/g, '').trim().replace(/\s+/g, '-').slice(0, 60) || 'rebbet-chat';
  if (format === 'json') {
    var payload = {
      app: 'Rebbet AI',
      exportedAt: new Date().toISOString(),
      title: chat.title,
      model: chat.model,
      personality: chat.personality || 'default',
      folder: chat.folder || '',
      messages: chat.messages.map(function(message) {
        var clone = {};
        Object.keys(message).forEach(function(key) {
          if (key === 'image') return;
          clone[key] = message[key];
        });
        return clone;
      })
    };
    downloadText(safeTitle + '.json', JSON.stringify(payload, null, 2), 'application/json');
  } else {
    var lines = [];
    lines.push('# ' + (chat.title || 'Rebbet AI chat'));
    lines.push('');
    lines.push('- Exported: ' + new Date().toLocaleString());
    lines.push('- Model: ' + (chat.model || state.selectedModel || DEFAULT_MODEL));
    var persona = getPersonalityById(chat.personality);
    if (persona && persona.id !== 'default') lines.push('- Personality: ' + persona.name);
    if (chat.folder) lines.push('- Folder: ' + chat.folder);
    lines.push('');
    chat.messages.forEach(function(message) {
      lines.push(message.role === 'user' ? '## You' : '## Rebbet AI');
      lines.push('');
      lines.push(String(message.content || '').trim());
      if (message.file) {
        lines.push('');
        lines.push('_Attachment: [' + (message.file.name || 'file') + '](' + resolveAssetUrl(message.file.url || message.file.rawUrl) + ')_');
        if (message.file.text) lines.push('', '_Document text was included as context._');
      }
      if (message.image) lines.push('', '_Generated image omitted from Markdown export._');
      lines.push('');
    });
    downloadText(safeTitle + '.md', lines.join('\n'), 'text/markdown');
  }
  closeAppMenu();
  showToast('Chat exported');
}

function downloadText(filename, text, mime) {
  var blob = new Blob([text], { type: (mime || 'text/plain') + ';charset=utf-8' });
  var url = URL.createObjectURL(blob);
  var link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(function() { URL.revokeObjectURL(url); }, 1000);
}

function setComposerStatus(text) {
  if (els.composerStatus) els.composerStatus.textContent = text;
}

function stopGeneration() {
  if (!state.sending) return;
  state.stopRequested = true;
  if (state.abortController) {
    try { state.abortController.abort(); } catch (e) {}
  }
  showToast('Stopping…');
}

function enhanceRenderedContent(root) {
  if (!root) return;
  root.querySelectorAll('a[href]').forEach(function(link) {
    if (!link.getAttribute('target')) {
      link.setAttribute('target', '_blank');
      link.setAttribute('rel', 'noopener noreferrer');
    }
  });
  root.querySelectorAll('table').forEach(function(table) {
    if (table.parentElement && table.parentElement.classList.contains('table-wrap')) return;
    var wrap = document.createElement('div');
    wrap.className = 'table-wrap';
    table.parentNode.insertBefore(wrap, table);
    wrap.appendChild(table);
  });
  if (window.hljs) {
    root.querySelectorAll('pre code').forEach(function(code) {
      if (code.dataset.highlighted === 'yes') return;
      try { window.hljs.highlightElement(code); } catch (e) {}
    });
  }
  root.querySelectorAll('pre').forEach(function(pre) {
    if (pre.parentElement && pre.parentElement.classList.contains('code-block')) return;
    var code = pre.querySelector('code');
    var className = code ? String(code.className || '') : '';
    var match = className.match(/language-([A-Za-z0-9_+#-]+)/);
    var block = document.createElement('div');
    block.className = 'code-block';
    var head = document.createElement('div');
    head.className = 'code-block__head';
    var label = document.createElement('span');
    label.className = 'code-block__label';
    label.textContent = match ? match[1] : 'code';
    var copy = document.createElement('button');
    copy.type = 'button';
    copy.className = 'code-block__copy';
    copy.textContent = 'Copy';
    copy.addEventListener('click', function() {
      copyText(code ? code.textContent : pre.textContent);
      copy.textContent = 'Copied';
      setTimeout(function() { copy.textContent = 'Copy'; }, 1400);
    });
    head.appendChild(label);
    head.appendChild(copy);
    pre.parentNode.insertBefore(block, pre);
    block.appendChild(head);
    block.appendChild(pre);
  });
}

function toggleAppMenu(force) {
  if (!els.appMenu || !els.moreBtn) return;
  var show = typeof force === 'boolean' ? force : els.appMenu.hidden;
  els.appMenu.hidden = !show;
  els.moreBtn.setAttribute('aria-expanded', show ? 'true' : 'false');
  if (show) updateMenuMeta();
}

function closeAppMenu() {
  if (els.appMenu) els.appMenu.hidden = true;
  if (els.moreBtn) els.moreBtn.setAttribute('aria-expanded', 'false');
}

function handleAppMenuAction(action) {
  closeAppMenu();
  var chat = getActiveChat();
  if (action === 'new') createChat(false);
  else if (action === 'temp') createChat(false, { temp: true });
  else if (action === 'personality') openPersonalitySheet();
  else if (action === 'memory') openMemorySheet();
  else if (action === 'folder') { if (chat) moveChatToFolder(chat); else openFolderSheet(); }
  else if (action === 'export-md') exportChat(chat, 'md');
  else if (action === 'export-json') exportChat(chat, 'json');
  else if (action === 'theme') toggleTheme();
  else if (action === 'voice') openVoiceSheet();
  else if (action === 'search') toggleWebSearch();
  else if (action === 'call') startVoiceCall();
  else if (action === 'clear') {
    if (!chat || !chat.messages.length) return;
    if (!confirm('Clear all messages in this chat?')) return;
    chat.messages = [];
    chat.title = chat.temp ? 'Temporary chat' : 'New chat';
    saveChats();
    renderSidebar();
    renderThread();
    showToast('Chat cleared');
  }
}

function updateScrollButton() {
  if (!els.scrollBottom || !els.thread) return;
  var distance = els.thread.scrollHeight - els.thread.scrollTop - els.thread.clientHeight;
  els.scrollBottom.hidden = distance < 160;
}

/* Bindings for the new workspace controls */
if (els.themeToggle) els.themeToggle.addEventListener('click', toggleTheme);
if (els.moreBtn) els.moreBtn.addEventListener('click', function(e) {
  e.stopPropagation();
  toggleAppMenu();
});
if (els.appMenu) {
  els.appMenu.addEventListener('click', function(e) {
    var item = e.target.closest('[data-action]');
    if (!item) return;
    handleAppMenuAction(item.getAttribute('data-action'));
  });
}
document.addEventListener('click', function(e) {
  if (!els.appMenu || els.appMenu.hidden) return;
  if (els.appMenu.contains(e.target) || (els.moreBtn && els.moreBtn.contains(e.target))) return;
  closeAppMenu();
});
if (els.chatSearch) {
  els.chatSearch.addEventListener('input', function() {
    state.chatSearch = els.chatSearch.value;
    renderSidebar();
  });
}
if (els.sidebarMemory) els.sidebarMemory.addEventListener('click', openMemorySheet);
if (els.sidebarPersonality) els.sidebarPersonality.addEventListener('click', openPersonalitySheet);
if (els.sidebarTemp) els.sidebarTemp.addEventListener('click', function() { createChat(false, { temp: true }); });
if (els.memoryBackdrop) els.memoryBackdrop.addEventListener('click', closeMemorySheet);
if (els.memoryClose) els.memoryClose.addEventListener('click', closeMemorySheet);
if (els.memoryAddBtn) els.memoryAddBtn.addEventListener('click', function() { addMemory(els.memoryInput ? els.memoryInput.value : ''); });
if (els.memoryInput) {
  els.memoryInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      addMemory(els.memoryInput.value);
    }
  });
}
if (els.memoryClearBtn) els.memoryClearBtn.addEventListener('click', clearMemory);
if (els.personalityBackdrop) els.personalityBackdrop.addEventListener('click', closePersonalitySheet);
if (els.personalityClose) els.personalityClose.addEventListener('click', closePersonalitySheet);
if (els.savePersonality) els.savePersonality.addEventListener('click', function() {
  setChatPersonality('custom', els.customPersonality ? els.customPersonality.value : '');
});
if (els.folderBackdrop) els.folderBackdrop.addEventListener('click', closeFolderSheet);
if (els.folderClose) els.folderClose.addEventListener('click', closeFolderSheet);
if (els.folderAddBtn) els.folderAddBtn.addEventListener('click', function() { createFolder(els.folderInput ? els.folderInput.value : ''); });
if (els.folderInput) {
  els.folderInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      createFolder(els.folderInput.value);
    }
  });
}
if (els.composerStop) els.composerStop.addEventListener('click', stopGeneration);
if (els.scrollBottom) els.scrollBottom.addEventListener('click', scrollThread);
if (els.thread) els.thread.addEventListener('scroll', updateScrollButton, { passive: true });
if (els.composerInput) {
  els.composerInput.addEventListener('input', function() {
    if (els.composerInput.value.length > 8000) {
      setComposerStatus(els.composerInput.value.length + ' characters — long messages may be trimmed');
    } else if (!state.sending) {
      setComposerStatus('Rebbet AI can make mistakes. Check important information.');
    }
  });
}

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    closeModelSheet();
    closeVoiceSheet();
    closeSidebar();
    closeShareModal();
    closeMemorySheet();
    closePersonalitySheet();
    closeFolderSheet();
    closeAppMenu();
  }
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    openModelSheet();
  }
});

loadTheme();
loadWorkspacePrefs();
loadChats();
loadModels();
loadAppConfig();
loadVoicePref();
loadWebSearchPref();
renderMemory();
renderPersonalityGrid();
updatePersonaBadge();
updateMenuMeta();
autoResize();
updateScrollButton();
