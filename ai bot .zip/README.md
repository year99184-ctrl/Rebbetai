# Rebbet AI

A clean, mobile-first chat app with Gemini-native chat, web search, voice input/output, image generation, and automatic free-model fallback. It also supports OpenCode and other OpenAI-compatible endpoints.

## Features
- Direct Gemini chat with speed-first fallback across Gemini models
- Optional DeepSeek, GitHub Models legacy, OpenRouter, and keyless Pollinations fallback
- Web search with DuckDuckGo results and source citations
- Voice input via Gemini transcription and browser fallback
- Voice output via ElevenLabs and browser speech synthesis fallback
- In-app voice picker for ElevenLabs voice, model, and speed
- Hands-free voice call mode with automatic listening, replies, and interruption
- Image generation with Gemini and Pollinations fallback
- Upload any file and generate a share link that opens in the app when installed
- Model picker with search, recommendations, and free badges
- Multi-chat history saved locally
- PWA support (installable, offline shell)
- Firebase Analytics for the web app
- Clean dark UI optimized for phones

## Quick start
1. Put your API key in `config.json` (or set `GEMINI_API_KEY`).
2. Run the server:
   ```bash
   python3 app.py
   ```
   Or:
   ```bash
   ./run.sh
   ```
3. Open `http://127.0.0.1:8765` in your browser.

## Config
Edit `config.json`:
- `api_key` - Gemini API key (also supports OpenCode keys)
- `default_model` - Model id to use by default
- `host` / `port` - Bind address/port
- `base_url` - Gemini native base URL
- `enable_web_search` - Enable web search globally
- `auto_switch_model` / `enable_free_fallback` - Automatic model fallback
- `voice_speed` - Voice speed (`fast`, `normal`, or `slow`)
- `elevenlabs_api_key` / `elevenlabs_voice_id` / `elevenlabs_model` - ElevenLabs voice output (required for server-side voice replies)
- `transcribe_model` - Gemini speech-to-text model
- `image_model` - Preferred Gemini image model
- `pollinations_model` - Keyless free text fallback model
- `deepseek_api_key` / `deepseek_model` - Optional DeepSeek fallback
- `openrouter_api_key` / `openrouter_model` - Optional OpenRouter fallback
- `github_api_key` / `github_model` - Optional GitHub Models legacy fallback
- `github_base_url` - GitHub Models endpoint, default `https://models.github.ai/inference`

Environment overrides include `GEMINI_API_KEY`, `REBBET_DEFAULT_MODEL`, `REBBET_VOICE_MODEL`, `REBBET_TRANSCRIBE_MODEL`, `REBBET_IMAGE_MODEL`, `DEEPSEEK_API_KEY`, `OPENROUTER_API_KEY`, `GITHUB_MODELS_TOKEN`, `GITHUB_MODELS_MODEL`, and `GITHUB_MODELS_BASE_URL`. `GITHUB_TOKEN` is also accepted. `ELEVENLABS_API_KEY`, `ELEVENLABS_VOICE_ID`, and `ELEVENLABS_MODEL` are also accepted.

## Image generation
- Type `/image a neon city at night` or use the image button in the composer.
- The `/api/image` endpoint tries Gemini image models, then falls back to Pollinations.

## Share links
Upload any file, photo, video, audio, PDF or document from the composer (paperclip, drag-and-drop, or paste). Rebbet AI stores it and creates a share link:

- `GET /s/<id>` opens a share page with a preview and download button.
- `GET /f/<id>` serves the raw file (supports range requests and downloads).
- On Android, the share page tries the Rebbet AI app first with an `intent://` deep link. If the app is not installed, the browser shows the same file page. Add `?web=1` to skip the app attempt.
- The app must declare the `rebbetai` scheme. The Android WebView app in `../rabbet ai app` already handles it and loads the shared URL.
- Configure `public_base_url` when the server runs behind a proxy so generated links use your public domain.
- Optional settings: `app_link_scheme` (default `rebbetai`), `app_package` (default `com.rabbet.ai`), and `app_download_url` (shown as a “Get Rebbet AI app” button). Set `app_package` to an empty string to always open links in the browser.

## Firebase
Firebase is initialized in `static/firebase.js` with the Rebbet AI web config and Firebase Analytics enabled when supported. Anonymous events cover chat requests, model switches, image generation, and voice transcription; message content is not sent.

### Remote status and admin panel
Open `/admin.html` (or `/admin`) to publish app-wide notices. The main app listens to Firebase Realtime Database at `/appStatus` and shows:

- An update popup when `latestVersion` is newer than the running app, or when `updateAvailable` is `true`.
- A forced update popup that hides the "Later" button.
- A full maintenance screen that blocks the app while `maintenance` is `true`.

Published schema:

```json
{
  "latestVersion": "1.11.0",
  "updateUrl": "https://example.com/update",
  "updateMessage": "A newer version of Rebbet AI is available.",
  "updateAvailable": false,
  "forceUpdate": false,
  "maintenance": false,
  "maintenanceMessage": "Rebbet AI is under maintenance. Please check back shortly.",
  "updatedAt": 0,
  "updatedBy": "admin@example.com"
}
```

Admin panel:

1. Open `/admin.html` (or `/admin`).
2. Check the **Live status** card: it shows the current maintenance state, published version, whether clients will see an update popup, and when the status was last published.
3. Set the latest version, optional update URL, messages, force-update, and maintenance mode, then press **Publish status**. Changes appear live in open app tabs.
4. Use the quick actions to turn maintenance on/off or clear the update notice without touching the rest of the form.
5. Connect to the Python server in **Server & releases** with its URL and `admin_token` to edit every `config.json` value (host, port, provider, models, API keys, ElevenLabs voice, fallback providers, limits) from the browser.
6. In the same card, upload an APK to publish an in-app update, and add app icons to a library. Choose **Use** to make an icon active for the favicon and launcher icon. The Rebbet AI logo is fixed and is never replaced by icon uploads.

### Users and bans
Every app load registers a stable browser ID under `/users/<userId>` with last seen, app version, platform, and language. The admin panel lists users live and can ban or unban them.

- **Ban** writes `/bans/<userId>` with `banned`, an optional `reason`, `at`, and `by`.
- **Unban** deletes `/bans/<userId>`.
- The app listens to its ban node and shows a blocking screen immediately.
- The Python server also checks `/bans/<userId>` (15-second cache) and returns `403 banned` for API calls, so a banned client cannot keep using chat, search, voice, or image endpoints.
- Set `REBBET_FIREBASE_DB_URL` to override the default Realtime Database URL used by the server check.

The browser ID is stored in localStorage plus a cookie. Clearing both creates a new ID. For stronger identity, enable Firebase Anonymous Auth and use the Firebase UID instead.

The basic panel writes directly to `/appStatus`, `/users`, and `/bans` and works while your Realtime Database rules allow writes. This project’s database currently has open writes, so anyone with the admin URL can publish or ban. Before sharing the app publicly, tighten the rules and add authenticated admin writes.

To protect only the status node while keeping public reads:

```json
{
  "rules": {
    "appStatus": {
      ".read": true,
      ".write": "auth != null"
    },
    "users": {
      ".read": true,
      "$userId": {
        ".write": true
      }
    },
    "bans": {
      ".read": true,
      ".write": "auth != null"
    }
  }
}
```

If your existing database uses open root rules such as `".read": true, ".write": true`, child rules cannot revoke that access; scope the existing rules first. After locking writes to authenticated users, add Firebase Authentication to the admin panel before using it again. The Realtime Database URL is present in the config, but chat history is still stored locally in the browser.

## Android admin app
The project also contains a small Android WebView app that opens the same admin panel without needing the Python server.

- Installable debug APK: `app/build/outputs/apk/debug/app-debug.apk` (rebuild after admin changes).
- Package: `com.rebbet.ai.admin` · min Android 7.0 (API 24) · target API 33.
- The Gradle `copyAdminAssets` task bundles `admin.html`, `static/admin.css`, `static/admin.js`, `static/firebase.js`, and the icon into the APK at build time.
- The app needs internet access for Firebase; it loads the panel from bundled assets, not from the Python server.
- Rebuild after changing the admin panel:
  ```bash
  sh ./gradlew assembleDebug
  ```
  The APK is written to `app/build/outputs/apk/debug/app-debug.apk`.
- You can also open the project root in AndroidIDE and run the `app` module.

## Notes
- On Render, set `REBBET_ADMIN_TOKEN` in the service environment to the same value as `admin_token`; this overrides `config.json` without committing the token.
- Gemini image generation may return `429 FREE_LIMIT` on the free tier; Pollinations is used automatically.
- Keyless Pollinations text is limited to 1 reply every 30 seconds per IP. Add a DeepSeek, GitHub Models, or OpenRouter key for a stronger fallback.
- GitHub Models was retired on July 30, 2026. Its legacy endpoint is supported only for compatibility or custom GitHub-compatible proxies; set `github_base_url` to your proxy if needed.
- Some models use different API families; this app handles OpenAI Chat Completions, Responses, Anthropic Messages, and Gemini.
- Free model availability and quotas change frequently.
- Firebase web config is public by design. Keep Realtime Database/Firestore rules locked down and restrict authorized domains in Firebase Console.
