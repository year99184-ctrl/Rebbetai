# Rebbet AI

A clean, mobile-first chat app with a PHP backend, multi-provider chat, web search, voice input/output, image generation, and automatic provider fallback. It supports OpenAI-compatible endpoints.

## Features
- Chat with CheatGPT/OpenAI, OpenCode, DeepSeek, GitHub Models legacy, OpenRouter, Hugging Face Inference Providers, and keyless Pollinations
- Automatic fallback across configured providers
- Web search with DuckDuckGo results and source citations
- Voice input via the browser speech recognition fallback
- Voice output via ElevenLabs and browser speech synthesis fallback
- In-app voice picker for ElevenLabs voice, model, and speed
- Hands-free voice call mode with automatic listening, replies, and interruption
- Image generation with Pollinations
- Upload any file and generate a share link that opens in the app when installed
- Model picker with search, recommendations, and free badges
- Multi-chat history saved locally
- PWA support (installable, offline shell)
- Firebase Analytics for the web app
- Clean dark UI optimized for phones

## Quick start
Build and run the PHP site with Docker (PHP, cURL, and mbstring are installed by the image):

```bash
docker build -t rebbet-ai .
docker run --rm -p 10000:10000 -e PORT=10000 -e CHEATGPT_API_KEY="$CHEATGPT_API_KEY" rebbet-ai
```

Open `http://127.0.0.1:10000`. Set provider keys as environment variables; the Docker image intentionally does not include `config.json`.

## Config
Edit `config.json`:
- `api_key` - OpenCode-compatible API key
- `default_model` - Model id to use by default
- `host` / `port` - Bind address/port
- `base_url` - OpenAI-compatible base URL
- `enable_web_search` - Enable web search globally
- `auto_switch_model` / `enable_free_fallback` - Automatic model fallback
- `voice_speed` - Voice speed (`fast`, `normal`, or `slow`)
- `elevenlabs_api_key` / `elevenlabs_voice_id` / `elevenlabs_model` - ElevenLabs voice output (required for server-side voice replies)
- `pollinations_model` - Pollinations text model (default `openai-fast`)
- `pollinations_api_key` - Optional Pollinations secret key; adds a Pollinations choice to the model picker
- `deepseek_api_key` / `deepseek_model` - Optional DeepSeek fallback
- `openrouter_api_key` / `openrouter_model` - Optional OpenRouter fallback
- `github_api_key` / `github_model` - Optional GitHub Models legacy fallback
- `github_base_url` - GitHub Models endpoint, default `https://models.github.ai/inference`
- `huggingface_api_key` - Hugging Face token; adds Hugging Face models to the picker and enables the provider
- `huggingface_model` - Default Hugging Face model (default `deepseek-ai/DeepSeek-V4.1-Flash:fastest`)
- `huggingface_base_url` - Hugging Face OpenAI-compatible router, default `https://router.huggingface.co/v1`
- `upload_encryption_key` - Base64 32-byte key used to encrypt uploaded files at rest; generated automatically and kept in `config.json`
- `force_https` - Redirect all HTTP requests to HTTPS (useful behind a TLS-terminating proxy)
- `firebase_database_url` - Realtime Database URL used by the server proxy
- `firebase_database_secret` - Realtime Database secret used only by the server proxy; never expose it in the browser

Environment overrides include `OPENCODE_API_KEY`, `REBBET_DEFAULT_MODEL`, `POLLINATIONS_API_KEY`, `REBBET_POLLINATIONS_MODEL`, `DEEPSEEK_API_KEY`, `OPENROUTER_API_KEY`, `GITHUB_MODELS_TOKEN`, `GITHUB_MODELS_MODEL`, `GITHUB_MODELS_BASE_URL`, `HUGGINGFACE_API_KEY`, `HUGGINGFACE_MODEL`, and `HUGGINGFACE_BASE_URL`. `GITHUB_TOKEN`, `HF_TOKEN`, and `HF_API_KEY` are also accepted. `ELEVENLABS_API_KEY`, `ELEVENLABS_VOICE_ID`, and `ELEVENLABS_MODEL` are also accepted. Security overrides are `REBBET_UPLOAD_ENCRYPTION_KEY`, `REBBET_FORCE_HTTPS`, `REBBET_FIREBASE_DATABASE_URL`, and `REBBET_FIREBASE_DB_SECRET`.

## Image generation
- Type `/image a neon city at night` or use the image button in the composer.
- The `/api/image` endpoint uses Pollinations.

## Share links
Upload any file, photo, video, audio, PDF or document from the composer (paperclip, drag-and-drop, or paste). Rebbet AI stores it and creates a share link:

- `GET /s/<id>` opens a share page with a preview and download button.
- `GET /f/<id>` serves the decrypted file inline; add `?download=1` to force a download.
- On Android, the share page tries the Rebbet AI app first with an `intent://` deep link. If the app is not installed, the browser shows the same file page. Add `?web=1` to skip the app attempt.
- The app must declare the `rebbetai` scheme. The Android WebView app in `../rabbet ai app` already handles it and loads the shared URL.
- Configure `public_base_url` when the server runs behind a proxy so generated links use your public domain. Set it to an `https://` URL (or enable `force_https`) for secure share links.
- Uploaded files are encrypted at rest with AES-256-GCM using `upload_encryption_key`. Existing plaintext files are migrated automatically when downloaded or via `POST /api/admin/encrypt-uploads`.
- Optional settings: `app_link_scheme` (default `rebbetai`), `app_package` (default `com.rabbet.ai`), and `app_download_url` (shown as a “Get Rebbet AI app” button). Set `app_package` to an empty string to always open links in the browser.

## Firebase
Firebase is initialized in `static/firebase.js` with the Rebbet AI web config and Firebase Analytics enabled when supported. Anonymous events cover chat requests, model switches, image generation, and voice transcription; message content is not sent.

### Remote status and admin panel
Open `/admin.html` (or `/admin`) to publish app-wide notices. The app and admin panel now read and write through the PHP server proxy (`/api/firebase/*` and `/api/admin/firebase/*`), so the browser never needs database write access. The main app polls the proxy and shows:

- An update popup when `latestVersion` is newer than the running app, or when `updateAvailable` is `true`.
- A forced update popup that hides the "Later" button.
- A full maintenance screen that blocks the app while `maintenance` is `true`.

Published schema:

```json
{
  "latestVersion": "1.12.4",
  "updateUrl": "https://example.com/update",
  "updateMessage": "A newer version of Rebbet AI is available.",
  "updateAvailable": false,
  "forceUpdate": false,
  "maintenance": false,
  "maintenanceMessage": "Rebbet AI is under maintenance. Please check back shortly.",
  "updatedAt": 0,
  "updatedBy": "admin@example.com"
}
```

Admin panel:

1. Open `/admin.html` (or `/admin`).
2. Check the **Live status** card: it shows the current maintenance state, published version, whether clients will see an update popup, and when the status was last published.
3. Set the latest version, optional update URL, messages, force-update, and maintenance mode, then press **Publish status**. Changes appear live in open app tabs.
4. Use the quick actions to turn maintenance on/off or clear the update notice without touching the rest of the form.
5. Connect to the PHP server in **Server & releases** with its URL and `admin_token` to edit every `config.json` value (host, port, provider, models, API keys, ElevenLabs voice, fallback providers, limits) from the browser.
6. In the same card, upload an APK to publish an in-app update, and add app icons to a library. Choose **Use** to make an icon active for the favicon and launcher icon. The Rebbet AI logo is fixed and is never replaced by icon uploads.

### Users and bans
Every app load registers a stable browser ID under `/users/<userId>` with last seen, app version, platform, and language. The admin panel lists users live and can ban or unban them.

- **Ban** posts to `/api/admin/firebase/ban`, which writes `/bans/<userId>` with `banned`, an optional `reason`, `at`, and `by`.
- **Unban** posts to `/api/admin/firebase/unban`, which deletes `/bans/<userId>`.
- The app polls `/api/firebase/status` and shows a blocking screen immediately when banned.
- The server also checks `/bans/<userId>` and returns `403 banned` for API calls, so a banned client cannot keep using chat, search, voice, or image endpoints.
- Set `firebase_database_secret` (or `REBBET_FIREBASE_DB_SECRET`) so the PHP proxy can access the database. The browser never receives this secret.

The browser ID is stored in localStorage plus a cookie. Clearing both creates a new ID.

The checked-in `database.rules.json` denies all public reads and writes except public read access to `/appStatus`. All writes, user registration, ban checks, and admin reads go through the authenticated PHP proxy. To apply, open Firebase Console → Realtime Database → Rules, replace the entire ruleset with `database.rules.json`, and publish. A permissive root `.read` or `.write` rule would override these child restrictions. Chat history remains local in the browser.

## Android admin app
The project also contains a small Android WebView app that opens the same admin panel without needing the PHP server.

- Installable debug APK: `app/build/outputs/apk/debug/app-debug.apk` (rebuild after admin changes).
- Package: `com.rebbet.ai.admin` · min Android 7.0 (API 24) · target API 33.
- The Gradle `copyAdminAssets` task bundles `admin.html`, `static/admin.css`, `static/admin.js`, `static/firebase.js`, and the icon into the APK at build time.
- The app loads the panel from bundled assets, but status/ban actions require connecting to the PHP server URL with `admin_token` in **Server & releases**.
- Rebuild after changing the admin panel:
  ```bash
  sh ./gradlew assembleDebug
  ```
  The APK is written to `app/build/outputs/apk/debug/app-debug.apk`.
- You can also open the project root in AndroidIDE and run the `app` module.

## Notes
- On Render, set `REBBET_ADMIN_TOKEN` in the service environment to the same value as `admin_token`; this overrides `config.json` without committing the token.
- For encrypted uploads, set `REBBET_UPLOAD_ENCRYPTION_KEY` to the same base64 32-byte value as `upload_encryption_key`. Back up this key; losing it makes existing uploads unreadable.
- For secure database proxying, set `REBBET_FIREBASE_DB_SECRET`. For HTTPS, set `force_https: true` or `REBBET_FORCE_HTTPS=true` behind a TLS-terminating proxy, and configure `public_base_url` with your HTTPS domain.
- Keyless Pollinations text is limited to 1 reply every 30 seconds per IP. Add a DeepSeek, GitHub Models, or OpenRouter key for a stronger fallback.
- GitHub Models was retired on July 30, 2026. Its legacy endpoint is supported only for compatibility or custom GitHub-compatible proxies; set `github_base_url` to your proxy if needed.
- The PHP backend runs under Apache in the project Dockerfile. Render uses this Docker image and checks `/api/health`.
- Free model availability and quotas change frequently.
- Firebase web config is public by design. Keep Realtime Database/Firestore rules locked down and restrict authorized domains in Firebase Console.
