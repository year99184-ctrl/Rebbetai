<?php
declare(strict_types=1);

/*
 * PHP replacement for app.py. Kept as a side-by-side router while feature
 * parity is built; Render remains on Python until migration is complete.
 */
const APP_VERSION = '1.12.4';
const APP_NAME = 'Rebbet AI';
const ROOT_DIR = __DIR__;
const UPLOAD_DIR = ROOT_DIR . '/uploads';
const CONFIG_FILE = ROOT_DIR . '/config.json';
const INDEX_FILE = UPLOAD_DIR . '/index.json';
const POLLINATIONS_CHAT = 'https://gen.pollinations.ai/v1/chat/completions';
const POLLINATIONS_IMAGE = 'https://image.pollinations.ai/prompt';
const HUGGINGFACE_BASE_URL = 'https://router.huggingface.co/v1';
const HUGGINGFACE_MODEL_IDS = ['deepseek-ai/DeepSeek-V4.1-Flash:fastest','zai-org/GLM-5.3:fastest','Qwen/Qwen3.8-27B:fastest','openai/gpt-oss-120b:fastest','moonshotai/Kimi-K3.1-Pro:fastest','MiniMaxAI/MiniMax-M3.1-Flash:fastest'];

function default_config(): array {
    return [
        'host'=>'0.0.0.0','port'=>8765,'provider'=>'cheatgpt','api_key'=>'',
        'base_url'=>'https://api.openai.com/v1','default_model'=>'gpt-5-nano',
        'system_prompt'=>'You are Rebbet AI, a helpful, friendly assistant. Be accurate and clear. Use Markdown when it improves readability, and keep answers focused on what the user asked.',
        'request_timeout'=>300,'enable_web_search'=>true,'auto_switch_model'=>true,'enable_free_fallback'=>true,'force_https'=>false,
        'voice_speed'=>'fast','elevenlabs_api_key'=>'','elevenlabs_voice_id'=>'21m00Tcm4TlvDq8ikWAM',
        'elevenlabs_model'=>'eleven_multilingual_v2',
        'pollinations_model'=>'openai-fast','pollinations_api_key'=>'',
        'pollinations_image_model'=>'black-forest-labs/flux.1-schnell','pollinations_image_aspect'=>'1:1',
        'pollinations_tts_model'=>'openai/tts-1','pollinations_tts_voice'=>'alloy',
        'pollinations_transcribe_model'=>'openai/whisper-large-v3','deepseek_api_key'=>'',
        'deepseek_model'=>'deepseek-chat','openrouter_api_key'=>'',
        'openrouter_model'=>'deepseek/deepseek-chat-v3-0324:free','github_api_key'=>'',
        'github_model'=>'openai/gpt-4.1','github_base_url'=>'https://models.github.ai/inference',
        'cheatgpt_api_key'=>'','cheatgpt_model'=>'gpt-5-nano','cheatgpt_base_url'=>'https://api.openai.com/v1',
        'huggingface_api_key'=>'','huggingface_model'=>'deepseek-ai/DeepSeek-V4.1-Flash:fastest','huggingface_base_url'=>HUGGINGFACE_BASE_URL,
        'firebase_database_url'=>'https://drip-wire-36ff0-default-rtdb.firebaseio.com','firebase_database_secret'=>'',
        'admin_token'=>'','upload_encryption_key'=>'','app_version'=>APP_VERSION,'app_icon'=>'','update_url'=>'','update_message'=>'',
        'update_available'=>false,'force_update'=>false,'max_upload_mb'=>25,'public_base_url'=>'',
        'app_link_scheme'=>'rebbetai','app_package'=>'com.rabbet.ai','app_download_url'=>'',
    ];
}

function read_config(): array {
    $cfg = default_config();
    if (is_file(CONFIG_FILE)) {
        $saved = json_decode((string)file_get_contents(CONFIG_FILE), true);
        if (is_array($saved)) $cfg = array_replace($cfg, $saved);
    }
    $env = [
        'OPENCODE_API_KEY'=>'api_key',
        'POLLINATIONS_API_KEY'=>'pollinations_api_key','REBBET_POLLINATIONS_API_KEY'=>'pollinations_api_key',
        'DEEPSEEK_API_KEY'=>'deepseek_api_key','OPENROUTER_API_KEY'=>'openrouter_api_key',
        'GITHUB_MODELS_TOKEN'=>'github_api_key','GITHUB_TOKEN'=>'github_api_key',
        'CHEATGPT_API_KEY'=>'cheatgpt_api_key','OPENAI_API_KEY'=>'cheatgpt_api_key',
        'HUGGINGFACE_API_KEY'=>'huggingface_api_key','HF_TOKEN'=>'huggingface_api_key','HF_API_KEY'=>'huggingface_api_key',
        'HUGGINGFACE_MODEL'=>'huggingface_model','HUGGINGFACE_BASE_URL'=>'huggingface_base_url',
        'REBBET_FIREBASE_DATABASE_URL'=>'firebase_database_url','FIREBASE_DATABASE_URL'=>'firebase_database_url','REBBET_FIREBASE_DB_URL'=>'firebase_database_url',
        'REBBET_FIREBASE_DB_SECRET'=>'firebase_database_secret','FIREBASE_DATABASE_SECRET'=>'firebase_database_secret',
        'REBBET_UPLOAD_ENCRYPTION_KEY'=>'upload_encryption_key','UPLOAD_ENCRYPTION_KEY'=>'upload_encryption_key',
        'ELEVENLABS_API_KEY'=>'elevenlabs_api_key','REBBET_ADMIN_TOKEN'=>'admin_token',
        'REBBET_DEFAULT_MODEL'=>'default_model','REBBET_HOST'=>'host',
        'REBBET_PORT'=>'port','PORT'=>'port','REBBET_FORCE_HTTPS'=>'force_https','FORCE_HTTPS'=>'force_https',
        'REBBET_PUBLIC_BASE_URL'=>'public_base_url','PUBLIC_BASE_URL'=>'public_base_url',
    ];
    foreach ($env as $name=>$key) {
        $value = getenv($name);
        if ($value !== false && $value !== '') $cfg[$key] = $value;
    }
    if (getenv('PORT') && !getenv('REBBET_HOST')) $cfg['host']='0.0.0.0';
    $cfg['port'] = max(1, min(65535, (int)$cfg['port']));
    $cfg['force_https'] = filter_var($cfg['force_https'],FILTER_VALIDATE_BOOLEAN);
    $cfg['provider'] = strtolower(trim((string)$cfg['provider']));
    $cfg['base_url'] = rtrim((string)$cfg['base_url'], '/');
    $cfg['huggingface_base_url'] = rtrim((string)$cfg['huggingface_base_url'], '/');
    $cfg['default_model'] = trim((string)$cfg['default_model']);
    foreach ($cfg as $k=>$v) if (str_ends_with($k, '_api_key') || in_array($k,['api_key','admin_token','upload_encryption_key','firebase_database_secret'],true)) $cfg[$k]=trim((string)$v);
    return $cfg;
}

function json_response(int $status, array $data, array $headers=[]): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    foreach ($headers as $name=>$value) header($name . ': ' . $value);
    echo json_encode($data, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    exit;
}
function api_error(int $status, string $code, string $message, array $more=[]): never {
    json_response($status, ['error'=>array_merge(['code'=>$code,'message'=>$message],$more)]);
}
function body_json(int $limit=4194304): array {
    $raw = file_get_contents('php://input', false, null, 0, $limit+1);
    if ($raw === false || strlen($raw)>$limit) throw new RuntimeException('Request body is too large');
    $data=json_decode($raw,true);
    if (!is_array($data)) throw new InvalidArgumentException('Request body must be a JSON object');
    return $data;
}
function send_cors(): void {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, HEAD, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Authorization, Content-Type, X-Rebbet-User, X-Admin-Token');
    header('Access-Control-Expose-Headers: X-Voice-Model, X-Image-Source, X-Image-Model, X-Image-Prompt');
}
function admin_ok(array $cfg): bool {
    $want=(string)($cfg['admin_token']??'');
    $got=(string)($_SERVER['HTTP_X_ADMIN_TOKEN']??'');
    if ($got==='' && preg_match('/^Bearer\s+(.+)$/i',(string)($_SERVER['HTTP_AUTHORIZATION']??''),$m)) $got=trim($m[1]);
    return $want!=='' && hash_equals($want,$got);
}
function http_call(string $url, string $method='GET', ?array $payload=null, array $headers=[], int $timeout=45): array {
    if (!function_exists('curl_init')) throw new RuntimeException('PHP cURL extension is required');
    $ch=curl_init($url);
    $outHeaders=[];
    $h=['Accept: application/json','User-Agent: RebbetAI/'.APP_VERSION,...$headers];
    if ($payload!==null) $h[]='Content-Type: application/json';
    curl_setopt_array($ch,[
        CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$h,
        CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>12,CURLOPT_TIMEOUT=>$timeout,
        CURLOPT_FOLLOWLOCATION=>false,
        CURLOPT_HEADERFUNCTION=>static function($ch,$line) use (&$outHeaders) {
            $len=strlen($line); $p=strpos($line,':');
            if($p!==false) $outHeaders[strtolower(trim(substr($line,0,$p)))]=trim(substr($line,$p+1));
            return $len;
        },
    ]);
    if ($payload!==null) curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
    $raw=curl_exec($ch); $err=curl_error($ch); $status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); curl_close($ch);
    if ($raw===false) throw new RuntimeException($err?:'Upstream request failed');
    return ['status'=>$status,'body'=>(string)$raw,'headers'=>$outHeaders];
}
function config_save(array $cfg): void {
    $tmp=CONFIG_FILE.'.tmp';
    if (file_put_contents($tmp,json_encode($cfg,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n")===false) throw new RuntimeException('Could not save config');
    if(!rename($tmp,CONFIG_FILE)) { @unlink($tmp); throw new RuntimeException('Could not replace config'); }
}
function app_config(array $c): array {
    return ['app'=>APP_NAME,'version'=>$c['app_version']?:APP_VERSION,'built_version'=>APP_VERSION,
        'icon'=>$c['app_icon'],'update_url'=>$c['update_url'],'update_message'=>$c['update_message'],
        'update_available'=>(bool)$c['update_available'],'force_update'=>(bool)$c['force_update'],
        'max_upload_mb'=>(int)$c['max_upload_mb'],'app_link_scheme'=>$c['app_link_scheme'],
        'app_package'=>$c['app_package'],'app_download_url'=>$c['app_download_url'],
        'public_base_url'=>$c['public_base_url']];
}
function request_scheme(): string {
    $proto=strtolower(trim((string)($_SERVER['HTTP_X_FORWARDED_PROTO']??'')));
    if($proto!=='') return explode(',',$proto)[0];
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off')?'https':'http';
}
function request_host(): string {
    return trim(explode(',',(string)($_SERVER['HTTP_X_FORWARDED_HOST']??$_SERVER['HTTP_HOST']??'localhost'))[0]);
}
function request_origin(): string {
    return request_scheme().'://'.request_host();
}
function firebase_db_request(string $node, string $method='GET', ?array $payload=null, array $cfg=[]) {
    $cfg=$cfg?:read_config();
    $secret=trim((string)$cfg['firebase_database_secret']);
    if($secret==='') throw new RuntimeException('Firebase database secret is not configured.');
    $base=rtrim((string)$cfg['firebase_database_url'],'/');
    $url=$base.'/'.trim($node,'/').'.json?auth='.rawurlencode($secret);
    $body=$payload===null?null:json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    $r=http_call($url,$method,$body,['Content-Type: application/json'],25);
    if($r['status']<200||$r['status']>=300) throw new RuntimeException('Firebase database request failed ('.$r['status'].').');
    $decoded=json_decode($r['body'],true);
    return is_array($decoded)?$decoded:[];
}
function serve_path(string $path): bool {
    $path=rawurldecode($path);
    $rel=ltrim($path,'/');
    if($rel==='' ) $rel='index.html';
    if($rel==='admin' || $rel==='admin/') $rel='admin.html';
    if(str_contains($rel,"..") || str_contains($rel,"\0")) return false;
    $root=realpath(ROOT_DIR); $file=realpath(ROOT_DIR.'/'.$rel);
    if($file===false || !str_starts_with($file,$root.DIRECTORY_SEPARATOR) || !is_file($file)) return false;
    $ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));
    $types=['html'=>'text/html; charset=utf-8','htm'=>'text/html; charset=utf-8','css'=>'text/css; charset=utf-8','js'=>'text/javascript; charset=utf-8','json'=>'application/json; charset=utf-8','webmanifest'=>'application/manifest+json','svg'=>'image/svg+xml','png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','ico'=>'image/x-icon','webp'=>'image/webp','txt'=>'text/plain; charset=utf-8'];
    header('Content-Type: '.($types[$ext]??'application/octet-stream'));
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: '.(str_starts_with($path,'/static/')?'public, max-age=3600':'no-cache'));
    readfile($file); return true;
}
function provider_for_model(array $cfg,string $model): string {
    $m=strtolower($model);
    if($m==='pollinations'||str_starts_with($m,'pollinations/')) return 'pollinations';
    if(str_starts_with($m,'deepseek/')) return 'deepseek';
    if(str_starts_with($m,'openrouter/')) return 'openrouter';
    if(str_starts_with($m,'github/')) return 'github';
    if($m==='huggingface'||str_starts_with($m,'hf/')||str_starts_with($m,'huggingface/')) return 'huggingface';
    if(in_array(strtolower($cfg['provider']),['openai','chatgpt','cheatgpt'],true)) return 'cheatgpt';
    if(strtolower($cfg['provider'])==='pollinations') return 'pollinations';
    if(strtolower($cfg['provider'])==='deepseek') return 'deepseek';
    if(strtolower($cfg['provider'])==='openrouter') return 'openrouter';
    if(strtolower($cfg['provider'])==='github') return 'github';
    if(strtolower($cfg['provider'])==='huggingface') return 'huggingface';
    return 'opencode';
}
function provider_spec(array $cfg,string $provider,string $model): array {
    return match($provider) {
        'pollinations'=>[POLLINATIONS_CHAT,$cfg['pollinations_api_key'],[]],
        'deepseek'=>['https://api.deepseek.com/chat/completions',$cfg['deepseek_api_key'],[]],
        'openrouter'=>['https://openrouter.ai/api/v1/chat/completions',$cfg['openrouter_api_key'],['HTTP-Referer: '.request_origin(),'X-Title: Rebbet AI']],
        'github'=>[rtrim($cfg['github_base_url'],'/').'/chat/completions',$cfg['github_api_key'],[]],
        'huggingface'=>[rtrim($cfg['huggingface_base_url'],'/').'/chat/completions',$cfg['huggingface_api_key'],[]],
        'cheatgpt'=>[rtrim($cfg['cheatgpt_base_url'],'/').'/chat/completions',$cfg['cheatgpt_api_key'],[]],
        default=>[rtrim($cfg['base_url'],'/').'/chat/completions',$cfg['api_key'],[]],
    };
}
function chat_reply(array $cfg,array $payload): never {
    $messages=$payload['messages']??null;
    if(!is_array($messages)||count($messages)<1||count($messages)>200) api_error(400,'bad_request','messages must be a non-empty array of at most 200 entries');
    $clean=[];
    foreach($messages as $m) {
        if(!is_array($m)||!in_array($m['role']??'', ['user','assistant'],true)||!is_string($m['content']??null)) api_error(400,'bad_request','Messages need a user/assistant role and text content');
        $content=mb_substr($m['content'],0,120000);
        if(($m['role']==='user')&&trim($content)==='') api_error(400,'bad_request','User messages cannot be empty');
        $clean[]=['role'=>$m['role'],'content'=>$content];
    }
    if(end($clean)['role']!=='user') api_error(400,'bad_request','The last message must be from the user');
    $model=trim((string)($payload['model']??$cfg['default_model']));
    if($model===''||strlen($model)>160) api_error(400,'bad_request','Invalid model id');
    $provider=provider_for_model($cfg,$model);
    $upstreamModel=$model;
    if($model==='pollinations'||$model==='pollinations/default') $upstreamModel=$cfg['pollinations_model']?:'openai-fast';
    elseif(str_starts_with(strtolower($model),'pollinations/')) $upstreamModel=substr($model,13);
    elseif(str_starts_with(strtolower($model),'deepseek/')) $upstreamModel=substr($model,9);
    elseif(str_starts_with(strtolower($model),'openrouter/')) $upstreamModel=substr($model,11);
    elseif(str_starts_with(strtolower($model),'github/')) $upstreamModel=substr($model,7);
    elseif(strtolower($model)==='huggingface') $upstreamModel=$cfg['huggingface_model'];
    elseif(str_starts_with(strtolower($model),'hf/')) $upstreamModel=substr($model,3);
    elseif(str_starts_with(strtolower($model),'huggingface/')) $upstreamModel=substr($model,12);
    elseif($provider==='cheatgpt' && ($model===''||$model==='default')) $upstreamModel=$cfg['cheatgpt_model'];
    $apiKey=(string)(provider_spec($cfg,$provider,$upstreamModel)[1]??'');
    $fallbackAvailable=(bool)$cfg['enable_free_fallback'] && (bool)($cfg['deepseek_api_key']||$cfg['github_api_key']||$cfg['openrouter_api_key']||$cfg['cheatgpt_api_key']||$cfg['huggingface_api_key']);
    if($apiKey==='' && !($provider==='pollinations' && (bool)$cfg['enable_free_fallback']) && !$fallbackAvailable) api_error(503,'no_key','No API key is configured for the selected provider.');
    $system=$payload['system']??$cfg['system_prompt'];
    if(!is_string($system)) api_error(400,'bad_request','system must be text');
    if(is_array($payload['personality']??null) && !empty($payload['personality']['system'])) $system="You are speaking in the '".substr((string)($payload['personality']['name']??'custom'),0,80)."' personality. Stay in character while remaining helpful and truthful.\n".substr((string)$payload['personality']['system'],0,4000)."\n\n".$system;
    if(is_array($payload['memory']??null)) { $mem=[]; foreach(array_slice($payload['memory'],0,40) as $item) if(is_array($item)&&isset($item['text'])) $mem[]=mb_substr((string)$item['text'],0,500); if($mem)$system.="\n\nRelevant saved context (treat as user-provided facts):\n- ".implode("\n- ",$mem); }
    $last=strtolower((string)end($clean)['content']);
    if(($payload['web_search']??$cfg['enable_web_search']) && preg_match('/\b(news|current|today|latest|weather|price|stock|score|update|now|202[5-9])\b/i',$last)) { $results=web_search_results((string)end($clean)['content'],5); if($results) { $system.="\n\nCurrent web search results (cite these links when relevant):\n"; foreach($results as $result)$system.='- '.$result['title'].' — '.$result['url']."\n"; } }
    $all=[['role'=>'system','content'=>mb_substr($system,0,24000)],...$clean];
    $body=['model'=>$upstreamModel,'messages'=>$all,'stream'=>false];
    if(isset($payload['temperature'])&&is_numeric($payload['temperature'])) $body['temperature']=max(0,min(2,(float)$payload['temperature']));
    if(isset($payload['max_tokens'])&&is_numeric($payload['max_tokens'])) $body['max_tokens']=max(1,min(65536,(int)$payload['max_tokens']));
    $plans=[$provider];
    if($cfg['enable_free_fallback']) foreach(['deepseek','github','openrouter','cheatgpt','huggingface','pollinations'] as $candidate) if($candidate!==$provider && ($candidate==='pollinations'||provider_spec($cfg,$candidate,$upstreamModel)[1]!=='')) $plans[]=$candidate;
    $lastStatus=0; $lastBody=''; $data=null; $usedProvider=$provider; $usedModel=$upstreamModel; $networkError='';
    foreach($plans as $tryProvider) {
        $tryModel=match($tryProvider) {'deepseek'=>$cfg['deepseek_model'],'openrouter'=>$cfg['openrouter_model'],'github'=>$cfg['github_model'],'cheatgpt'=>$cfg['cheatgpt_model'],'huggingface'=>$cfg['huggingface_model'],'pollinations'=>$cfg['pollinations_model'],default=>$upstreamModel};
        $spec=provider_spec($cfg,$tryProvider,$tryModel); $requestBody=$body; $requestBody['model']=$tryModel;
        $headers=$spec[2]; if($spec[1]!=='') $headers[]='Authorization: Bearer '.$spec[1];
        try {
            $res=http_call($spec[0],'POST',$requestBody,$headers,(int)$cfg['request_timeout']);
            if(in_array($res['status'],[401,403],true)&&$tryProvider==='pollinations'&&$spec[1]!=='') $res=http_call($spec[0],'POST',$requestBody,$spec[2],(int)$cfg['request_timeout']);
        } catch(Throwable $e) { $networkError=substr($e->getMessage(),0,240); continue; }
        $lastStatus=$res['status']; $lastBody=$res['body']; $data=json_decode($res['body'],true);
        if($lastStatus>=200&&$lastStatus<300&&is_array($data)) { $usedProvider=$tryProvider; $usedModel=$tryModel; break; }
        if(!$cfg['enable_free_fallback'] || !in_array($lastStatus,[401,402,403,404,408,429,500,502,503,504],true)) break;
    }
    if(!is_array($data)||$lastStatus<200||$lastStatus>=300) {
        $detail=is_array($data)?(string)($data['error']['message']??$data['message']??'The AI provider rejected the request.'):'The AI provider returned an invalid response.';
        $status=$lastStatus>=400&&$lastStatus<500?$lastStatus:502;
        api_error($status,$lastStatus===0?'network_error':'upstream_error',substr($detail?:$networkError,0,500),['provider'=>$usedProvider]);
    }
    $text=$data['choices'][0]['message']['content']??'';
    if(is_array($text)) $text=implode("\n",array_map(static fn($x)=>(string)($x['text']??''),$text));
    if(!is_string($text)||trim($text)==='') api_error(502,'empty_response','The AI provider returned an empty response.');
    header('Content-Type: text/event-stream; charset=utf-8'); header('Cache-Control: no-cache, no-transform'); header('X-Accel-Buffering: no');
    echo 'data: '.json_encode(['type'=>'meta','model'=>$usedModel,'provider'=>$usedProvider,'family'=>$usedProvider],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n\n";
    echo 'data: '.json_encode(['type'=>'delta','text'=>$text],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n\n";
    echo 'data: '.json_encode(['type'=>'done','usage'=>$data['usage']??new stdClass()],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n\n";
    exit;
}
function model_family(string $id): string {
    $s=strtolower($id);
    if($s==='pollinations'||str_starts_with($s,'pollinations/'))return 'pollinations';
    if($s==='huggingface'||str_starts_with($s,'hf/')||str_starts_with($s,'huggingface/'))return 'huggingface';
    if(str_starts_with($s,'claude')||str_starts_with($s,'qwen'))return 'anthropic';
    if(preg_match('/^(gpt|grok|muse|o1|o3|o4)/',$s))return 'responses';
    return 'openai';
}
function model_free(string $id): bool {
    $s=strtolower($id); return str_ends_with($s,'-free')||$s==='big-pickle'||(str_starts_with($s,'gpt')&&str_contains($s,'-nano'));
}
function model_label(string $id): string {
    if(strtolower($id)==='pollinations')return 'Pollinations';
    if(strtolower($id)==='huggingface')return 'Hugging Face';
    if(str_starts_with(strtolower($id),'hf/')) return 'HF '.model_label(substr($id,3));
    if(str_starts_with(strtolower($id),'huggingface/')) return 'HF '.model_label(substr($id,12));
    $s=preg_replace('/([A-Za-z])(\\d)/','$1 $2',$id)??$id;
    $s=str_replace(['gpt','glm','qwen','deepseek','minimax','kimi','claude','grok'],['GPT','GLM','Qwen','DeepSeek','MiniMax','Kimi','Claude','Grok'],$s);
    return trim(ucwords(str_replace(['-','_'], ' ', $s)));
}
function model_list(array $cfg): array {
    $provider=strtolower((string)$cfg['provider']);
    if(in_array($provider,['cheatgpt','openai','chatgpt'],true)) $ids=array_values(array_unique([$cfg['cheatgpt_model']?:'gpt-5-nano','gpt-5-nano','gpt-5.4-nano']));
    elseif($provider==='pollinations')$ids=[$cfg['pollinations_model']?:'openai-fast','pollinations'];
    else $ids=['glm-5.3-flash','deepseek-v4.1-flash','minimax-m3','qwen3.8-flash','big-pickle','glm-5.3-flash-free','deepseek-v4.1-flash-free'];
    if($cfg['enable_free_fallback'] && $provider!=='pollinations') $ids[]='pollinations';
    if($cfg['huggingface_api_key']!=='') {
        $hfModel=trim((string)$cfg['huggingface_model']);
        if($hfModel!=='') {
            if(str_starts_with(strtolower($hfModel),'hf/')) $hfModel=substr($hfModel,3);
            elseif(str_starts_with(strtolower($hfModel),'huggingface/')) $hfModel=substr($hfModel,12);
            $ids[]='hf/'.$hfModel;
        }
        foreach(HUGGINGFACE_MODEL_IDS as $hfId) $ids[]='hf/'.$hfId;
    }
    $models=[]; foreach(array_unique($ids) as $id) $models[]=['id'=>$id,'label'=>model_label($id),'family'=>model_family($id),'free'=>model_free($id),'recommended'=>in_array($id,['gpt-5-nano','big-pickle'],true)];
    return $models;
}
function web_search_results(string $q,int $max=5): array {
    $url='https://html.duckduckgo.com/html/?'.http_build_query(['q'=>$q]);
    try {$r=http_call($url,'GET',null,['Accept: text/html'],15);} catch(Throwable $e) {return [];}
    if($r['status']!==200) return [];
    preg_match_all('~<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>~is',$r['body'],$ms,PREG_SET_ORDER);
    $out=[];
    foreach($ms as $m) {
        $href=html_entity_decode(strip_tags($m[1]),ENT_QUOTES|ENT_HTML5,'UTF-8');
        if(str_starts_with($href,'//')) $href='https:'.$href;
        $title=trim(html_entity_decode(strip_tags($m[2]),ENT_QUOTES|ENT_HTML5,'UTF-8'));
        if(!filter_var($href,FILTER_VALIDATE_URL)||$title==='') continue;
        $out[]=['title'=>$title,'url'=>$href,'snippet'=>'']; if(count($out)>=$max) break;
    }
    return $out;
}

function is_banned(string $userId, array $cfg=[]): bool {
    if(!preg_match('/^[A-Za-z0-9_-]{6,80}$/',$userId)) return false;
    try {$v=firebase_db_request('bans/'.$userId,'GET',null,$cfg);} catch(Throwable $e) {return false;}
    if(is_array($v)) return ($v['banned']??true)!==false;
    return $v===true || $v===1 || $v==='true';
}
function rate_limited(string $bucket): int {
    $limits=['chat'=>[80,60],'search'=>[40,60],'tts'=>[60,60],'image'=>[30,60],'transcribe'=>[60,60],'upload'=>[40,60],'analyze'=>[40,60]];
    if(!isset($limits[$bucket])) return 0;
    $user=(string)($_SERVER['HTTP_X_REBBET_USER']??''); $key=$bucket.':'.(preg_match('/^[A-Za-z0-9_-]{6,80}$/',$user)?$user:($_SERVER['REMOTE_ADDR']??'unknown')); $file=sys_get_temp_dir().'/rebbet-rate-'.hash('sha256',$key); $fh=@fopen($file,'c+');
    if(!$fh) return 0;
    flock($fh,LOCK_EX); $raw=stream_get_contents($fh); $events=json_decode($raw?:'[]',true); if(!is_array($events))$events=[];
    $now=time(); [$max,$window]=$limits[$bucket]; $events=array_values(array_filter($events,static fn($t)=>is_numeric($t)&&(int)$t>$now-$window));
    if(count($events)>=$max) $wait=max(1,(int)$events[0]+$window-$now); else {$events[]=$now;$wait=0;}
    rewind($fh);ftruncate($fh,0);fwrite($fh,json_encode($events));fflush($fh);flock($fh,LOCK_UN);fclose($fh);return $wait;
}
function rate_guard(string $path): void {
    if(!str_starts_with($path,'/api/')) return;
    $bucket=substr($path,5); $wait=rate_limited($bucket);
    if($wait>0) api_error(429,'rate_limited','Too many requests. Please slow down.',['retry_after'=>$wait,'hint'=>'Try again in about '.$wait.' seconds.']);
}
const UPLOAD_CIPHER_PREFIX = 'RBENC1';
function upload_key(array $cfg): string {
    $encoded=(string)($cfg['upload_encryption_key']??'');
    if($encoded==='') throw new RuntimeException('Upload encryption key is not configured.');
    $key=base64_decode($encoded,true);
    if($key===false||strlen($key)!==32) throw new RuntimeException('Upload encryption key must be a base64-encoded 32-byte key.');
    return $key;
}
function upload_encrypt(string $bytes,string $key): string {
    $iv=random_bytes(12); $tag='';
    $cipher=openssl_encrypt($bytes,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);
    if($cipher===false) throw new RuntimeException('Could not encrypt upload.');
    return UPLOAD_CIPHER_PREFIX.$iv.$tag.$cipher;
}
function upload_decrypt(string $stored,string $key): string {
    if(!str_starts_with($stored,UPLOAD_CIPHER_PREFIX)) return $stored;
    $body=substr($stored,strlen(UPLOAD_CIPHER_PREFIX));
    if(strlen($body)<28) throw new RuntimeException('Encrypted upload is damaged.');
    $iv=substr($body,0,12); $tag=substr($body,12,16); $cipher=substr($body,28);
    $plain=openssl_decrypt($cipher,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);
    if($plain===false) throw new RuntimeException('Could not decrypt upload.');
    return $plain;
}
function upload_bytes(array $meta,array $cfg): string {
    $stored=(string)file_get_contents((string)$meta['path']);
    return upload_decrypt($stored,upload_key($cfg));
}
function migrate_upload(array $meta,array $cfg,array &$idx): bool {
    if(!empty($meta['encrypted'])) return false;
    $path=(string)$meta['path'];
    $plain=upload_decrypt((string)file_get_contents($path),upload_key($cfg));
    $tmp=$path.'.enc';
    if(file_put_contents($tmp,upload_encrypt($plain,upload_key($cfg)))===false) throw new RuntimeException('Could not encrypt upload.');
    rename($tmp,$path);
    $idx[$meta['id']]['encrypted']=true;
    return true;
}
function store_json_upload(array $payload,string $kind='shared'): array {
    $raw=$payload['data']??'';
    if(!is_string($raw)||trim($raw)==='') throw new InvalidArgumentException('Upload data is required');
    if(str_starts_with($raw,'data:')) {[$head,$raw]=array_pad(explode(',',$raw,2),2,''); if(!str_contains(strtolower($head),'base64')) throw new InvalidArgumentException('Upload must be base64 encoded');}
    $raw=preg_replace('/\s+/','',$raw)??''; $bytes=base64_decode($raw,true);
    if($bytes===false) throw new InvalidArgumentException('Upload data is not valid base64');
    $limit=match($kind) {'update'=>200*1024*1024,'icon'=>4*1024*1024,default=>(int)(read_config()['max_upload_mb']??25)*1024*1024};
    if(strlen($bytes)>$limit) throw new LengthException($kind==='update'?'Update file must be 200 MB or smaller':($kind==='icon'?'Icon must be 4 MB or smaller':'File is larger than the upload limit'));
    return store_upload((string)($payload['name']??'file'),(string)($payload['mimeType']??$payload['mime']??''),$bytes,$kind);
}
function serve_uploaded(array $meta,bool $download=false,array $cfg=[]): never {
    $path=(string)$meta['path']; $mime=(string)($meta['mimeType']??'application/octet-stream');
    if(in_array(strtolower($mime),['text/html','application/xhtml+xml','image/svg+xml','application/xml','text/xml'],true)) $mime='text/plain; charset=utf-8';
    $name=trim(preg_replace('/[^A-Za-z0-9._-]+/','_',basename((string)($meta['name']??'file'))),'._'); if($name==='') $name='file';
    try {
        $bytes=upload_bytes($meta,$cfg ?: read_config());
        if(!empty($meta['encrypted'])===false) {
            $idx=load_upload_index(); if(migrate_upload($meta,$cfg ?: read_config(),$idx)) save_upload_index($idx);
        }
    } catch(Throwable $e) { api_error(500,'upload_unavailable','This file cannot be decrypted on the server.'); }
    header('Content-Type: '.$mime); header('Content-Length: '.strlen($bytes)); header('Accept-Ranges: bytes');
    header('Content-Disposition: '.($download?'attachment':'inline').'; filename="'.$name.'"'); header('Cache-Control: private, no-store'); echo $bytes; exit;
}
function admin_payload(array $cfg): array {
    $keys=['host','port','provider','api_key','base_url','default_model','system_prompt','request_timeout','enable_web_search','auto_switch_model','enable_free_fallback','force_https','voice_speed','elevenlabs_api_key','elevenlabs_voice_id','elevenlabs_model','pollinations_model','pollinations_api_key','pollinations_image_model','pollinations_image_aspect','pollinations_tts_model','pollinations_tts_voice','pollinations_transcribe_model','deepseek_api_key','deepseek_model','openrouter_api_key','openrouter_model','github_api_key','github_model','github_base_url','cheatgpt_api_key','cheatgpt_model','cheatgpt_base_url','huggingface_api_key','huggingface_model','huggingface_base_url','firebase_database_url','firebase_database_secret','admin_token','upload_encryption_key','app_version','app_icon','update_url','update_message','update_available','force_update','max_upload_mb','public_base_url','app_link_scheme','app_package','app_download_url'];
    $out=[]; foreach($keys as $k) $out[$k]=$cfg[$k]??''; return $out;
}
function admin_settings(array $cfg): array {
    $active=(string)($cfg['app_icon']??'');$icons=[];
    foreach(load_upload_index() as $m) if(is_array($m)&&($m['kind']??'')==='icon'&&str_starts_with((string)($m['mimeType']??''),'image/')) {$item=public_meta($m);$item['active']=('/f/'.($m['id']??''))===$active;$icons[]=$item;}
    usort($icons,static fn($a,$b)=>(($b['active']??false)<=>($a['active']??false))?:((int)($b['created']??0)<=>(int)($a['created']??0)));
    return array_merge(app_config($cfg),admin_payload($cfg),['icons'=>$icons,'logo'=>'static/logo.png']);
}
function safe_editor_path(string $path): string {
    $relative=ltrim(str_replace('\\','/',$path),'/'); if($relative===''||str_contains('/'.$relative,'/../')||str_starts_with($relative,'../')) throw new InvalidArgumentException('Invalid file path');
    $skip=['.git','.gradle','.androidide','__pycache__','build','uploads','node_modules'];
    foreach(explode('/',$relative) as $part) if(in_array($part,$skip,true)) throw new InvalidArgumentException('That folder cannot be edited');
    $full=realpath(ROOT_DIR.'/'.$relative); $root=realpath(ROOT_DIR);
    if($full===false||!str_starts_with($full,$root.DIRECTORY_SEPARATOR)||!is_file($full)) throw new InvalidArgumentException('File not found');
    if(filesize($full)>2*1024*1024) throw new InvalidArgumentException('File is too large to edit');
    $ext=strtolower(pathinfo($full,PATHINFO_EXTENSION)); $allowed=['bat','cfg','css','gradle','htm','html','ini','java','js','json','md','mjs','properties','py','sh','svg','toml','txt','xml','yaml','yml'];
    if(!in_array($ext,$allowed,true) && !in_array(basename($full),['.gitignore','Dockerfile','LICENSE','Procfile','gradlew','render.yaml'],true)) throw new InvalidArgumentException('This file type cannot be edited');
    return $full;
}

function send_binary(string $bytes,string $mime,array $headers=[]): never {
    header('Content-Type: '.$mime); header('Content-Length: '.strlen($bytes)); header('Cache-Control: no-store');
    foreach($headers as $k=>$v) header($k.': '.$v); echo $bytes; exit;
}
function tts_audio(array $cfg,array $p): never {
    $text=trim((string)($p['text']??'')); if($text==='') api_error(400,'bad_request','text is required'); $text=mb_substr($text,0,4000);
    $voice=substr(preg_replace('/[^A-Za-z0-9_-]/','',(string)($p['voice']??$cfg['elevenlabs_voice_id']))??'',0,64);
    $speed=strtolower((string)($p['speed']??$cfg['voice_speed'])); $model=(string)($p['model']??'');
    if($cfg['elevenlabs_api_key']!=='') {
        $id=$voice?:$cfg['elevenlabs_voice_id']; $m=$model?:$cfg['elevenlabs_model'];
        $b=['text'=>$text,'model_id'=>$m,'voice_settings'=>['stability'=>0.5,'similarity_boost'=>0.75,'speed'=>$speed==='fast'?1.15:($speed==='slow'?0.85:1.0)]];
        $r=http_call('https://api.elevenlabs.io/v1/text-to-speech/'.rawurlencode($id).'?output_format=mp3_44100_128','POST',$b,['xi-api-key: '.$cfg['elevenlabs_api_key'],'Accept: audio/mpeg'],60);
        if($r['status']>=200&&$r['status']<300) send_binary($r['body'],'audio/mpeg',['X-Voice-Model'=>$m,'X-Voice-Provider'=>'elevenlabs']);
    }
    api_error(503,'no_voice_provider','Configure an ElevenLabs API key for server voice.');
}
function image_bytes(array $cfg,string $prompt,int $w=768,int $h=768): array {
    $w=max(256,min(1024,$w));$h=max(256,min(1024,$h));
    if(!$cfg['enable_free_fallback']) throw new RuntimeException('Image generation is not configured.');
    $lockFile=fopen(sys_get_temp_dir().'/rebbet-pollinations-image.lock','c+');$wait=0;
    if($lockFile){flock($lockFile,LOCK_EX);rewind($lockFile);$last=(int)stream_get_contents($lockFile);$wait=45-(time()-$last);if($wait>0)sleep($wait);}
    $url=POLLINATIONS_IMAGE.'/'.rawurlencode($prompt).'?'.http_build_query(['width'=>$w,'height'=>$h,'seed'=>hexdec(substr(hash('sha256',$prompt),0,8)),'nologo'=>'true']);
    try {$r=http_call($url,'GET',null,['Accept: image/*'],90);} finally {if($lockFile){rewind($lockFile);ftruncate($lockFile,0);fwrite($lockFile,(string)time());fflush($lockFile);flock($lockFile,LOCK_UN);fclose($lockFile);}}
    if($r['status']<200||$r['status']>=300) throw new RuntimeException('Pollinations image request failed (HTTP '.$r['status'].')');
    $mime=$r['headers']['content-type']??'image/jpeg';if(!str_starts_with(strtolower($mime),'image/'))throw new RuntimeException('Image provider returned non-image data.');return [$r['body'],$mime,'pollinations','sana'];
}
function transcribe_audio(array $cfg,array $p): never {
    api_error(503,'no_transcribe_provider','Server transcription is not configured.');
}
function pdf_text(string $data): array {
    $pages=preg_match_all('~/Type\\s*/Page(?![sA-Za-z])~',$data,$unused); $chunks=[];
    if(preg_match_all('~stream\\s*\\r?\\n(.*?)\\r?\\n?endstream~s',$data,$streams)) foreach($streams[1] as $raw) {
        $decoded=@gzuncompress($raw); if($decoded===false)$decoded=@gzinflate($raw);if($decoded===false)$decoded=$raw;
        if(preg_match_all('~\\((?:\\\\.|[^\\\\()])*\\)|<[0-9A-Fa-f\\s]+>~s',$decoded,$tokens)) foreach($tokens[0] as $tok) {
            if($tok[0]==='(') {$v=substr($tok,1,-1);$v=preg_replace_callback('/\\\\([nrtbf()\\\\]|[0-7]{1,3}|\\r?\\n)/',static function($m){$x=$m[1];$map=['n'=>"\n",'r'=>"\r",'t'=>"\t",'b'=>"\x08",'f'=>"\x0c",'('=>'(',')'=>')','\\'=>'\\'];if(isset($map[$x]))return $map[$x];if(preg_match('/^[0-7]{1,3}$/',$x))return chr(octdec($x)&255);return '';},$v)??$v;}
            else {$hex=preg_replace('/[^0-9A-Fa-f]/','',substr($tok,1,-1))??'';if(strlen($hex)%2)$hex.='0';$v=hex2bin($hex)?:'';}
            if(str_starts_with($v,"\xfe\xff"))$v=@iconv('UTF-16BE','UTF-8//IGNORE',substr($v,2))?:'';elseif(!mb_check_encoding($v,'UTF-8'))$v=mb_convert_encoding($v,'UTF-8','ISO-8859-1');
            $clean=preg_replace('/[^\p{L}\p{N}\p{P}\p{S}\s]/u',' ',$v)??'';$print=mb_strlen(trim($clean));if($print>=2&&$print/max(1,mb_strlen($v))>=0.55)$chunks[]=$clean;
        }
    }
    $text=trim(preg_replace('/[ \t]+/u',' ',preg_replace('/\n{3,}/','\n\n',implode(' ',$chunks))??'')??'');
    if(mb_strlen($text)<20&&preg_match_all('~\\((?:\\\\.|[^\\\\()])*\\)~s',$data,$tokens)) {$fallback=[];foreach($tokens[0]as$t){$v=stripcslashes(substr($t,1,-1));if(mb_strlen(trim($v))>1)$fallback[]=$v;}$candidate=trim(preg_replace('/\s+/u',' ',implode(' ',$fallback))??'');if(mb_strlen($candidate)>mb_strlen($text))$text=$candidate;}
    return [$text,max(1,(int)$pages)];
}
function analyze_document(array $cfg,array $p): never {
    $name=(string)($p['name']??'document');$mime=strtolower((string)($p['mimeType']??$p['mime']??''));$bytes='';
    if(!empty($p['fileId'])) {$m=upload_meta((string)$p['fileId']);if(!$m)api_error(404,'not_found','Uploaded file not found.');try{$bytes=upload_bytes($m,$cfg);}catch(Throwable $e){api_error(500,'upload_unavailable','This file cannot be decrypted on the server.');}$name=(string)$m['name'];$mime=(string)$m['mimeType'];}
    else {$raw=(string)($p['data']??'');if(str_starts_with($raw,'data:')){$parts=explode(',',$raw,2);if(count($parts)!==2||!str_contains(strtolower($parts[0]),'base64'))api_error(400,'bad_request','Document data must be base64 encoded');$raw=$parts[1];}$bytes=base64_decode(preg_replace('/\s+/','',$raw)??'',true)?:'';}
    if($bytes==='')api_error(400,'empty_file','Document is empty.'); if(strlen($bytes)>40*1024*1024)api_error(413,'too_large','Document is too large to analyze.');
    $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));$text='';$kind='text';$pages=1;
    if($ext==='pdf'||$mime==='application/pdf') { $kind='pdf'; [$text,$pages]=pdf_text($bytes); }
    elseif(preg_match('/\.(csv|htm|html|ini|log|md|py|js|mjs|json|rst|text|txt|xml|yaml|yml)$/',$name)||str_starts_with($mime,'text/')||in_array($mime,['application/json','application/xml'],true)) { $text=mb_convert_encoding($bytes,'UTF-8','UTF-8'); }
    else api_error(415,'unsupported_document','Only PDF and text documents can be analyzed.');
    $text=trim($text); if($text==='') api_error(422,'no_text','No readable text was found in that document.');$truncated=mb_strlen($text)>180000;$text=mb_substr($text,0,180000);
    json_response(200,['ok'=>true,'name'=>$name,'kind'=>$kind,'pages'=>$pages,'chars'=>mb_strlen($text),'truncated'=>$truncated,'text'=>$text]);
}

function load_upload_index(): array {
    if(!is_file(INDEX_FILE)) return [];
    $data=json_decode((string)file_get_contents(INDEX_FILE),true);
    return is_array($data)?$data:[];
}
function save_upload_index(array $idx): void {
    if(!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR,0770,true);
    $tmp=INDEX_FILE.'.tmp';
    file_put_contents($tmp,json_encode($idx,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n");
    rename($tmp,INDEX_FILE);
}
function upload_meta(string $id): ?array {
    if(!preg_match('/^[A-Za-z0-9_-]{4,40}$/',$id)) return null;
    $meta=load_upload_index()[$id]??null;
    if(!is_array($meta)) return null;
    $stored=basename((string)($meta['stored']??''));
    if($stored==='' || !is_file(UPLOAD_DIR.'/'.$stored)) return null;
    $meta['path']=UPLOAD_DIR.'/'.$stored; return $meta;
}
function public_meta(array $m): array {
    return ['id'=>$m['id']??'','name'=>$m['name']??'file','size'=>$m['size']??0,'mimeType'=>$m['mimeType']??'application/octet-stream','kind'=>$m['kind']??'file','created'=>$m['created']??0,'url'=>'/s/'.($m['id']??''),'rawUrl'=>'/f/'.($m['id']??'')];
}
function store_upload(string $name,string $mime,string $bytes,string $kind='shared'): array {
    if(strlen($bytes)>200*1024*1024) throw new LengthException('Upload is too large');
    if(!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR,0770,true);
    $name=basename(str_replace('\\','/',$name)); $name=trim(preg_replace('/[\x00-\x1f\x7f]/u','',$name)??'file'," .\t\n\r\0\x0B");
    if($name==='') $name='file';
    $mime=preg_match('~^[a-z0-9!#$&^_.+-]+/[a-z0-9!#$&^_.+-]+$~i',$mime)?strtolower($mime):'application/octet-stream';
    $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION)); $ext=preg_match('/^[a-z0-9]{1,10}$/',$ext)?'.'.$ext:'';
    $id=rtrim(strtr(base64_encode(random_bytes(9)),'+/','-_'),'=');
    $stored=$id.$ext;
    if(file_put_contents(UPLOAD_DIR.'/'.$stored,upload_encrypt($bytes,upload_key(read_config())))===false) throw new RuntimeException('Could not store upload');
    $m=['id'=>$id,'name'=>substr($name,0,120),'size'=>strlen($bytes),'storedSize'=>filesize(UPLOAD_DIR.'/'.$stored),'mimeType'=>$mime,'kind'=>$kind,'stored'=>$stored,'encrypted'=>true,'created'=>time()];
    $idx=load_upload_index(); $idx[$id]=$m; save_upload_index($idx); return $m;
}

$cfg=read_config();
send_cors();
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://www.gstatic.com; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob: https:; media-src 'self' data: blob:; connect-src 'self' https: wss:; frame-src 'self' blob: https:; object-src 'none'; base-uri 'self'");
$method=strtoupper((string)($_SERVER['REQUEST_METHOD']??'GET'));
$uri=(string)($_SERVER['REQUEST_URI']??'/');
$path=parse_url($uri,PHP_URL_PATH)?:'/';
$query=[]; parse_str((string)(parse_url($uri,PHP_URL_QUERY)??''),$query);
if(request_scheme()==='https') header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
if($cfg['force_https'] && request_scheme()!=='https') { http_response_code(301); header('Location: https://'.request_host().$uri); exit; }
if($method==='OPTIONS') { http_response_code(204); exit; }

if($method==='POST' && str_starts_with($path,'/api/')) {
    rate_guard($path);
    if(in_array($path,['/api/chat','/api/search','/api/tts','/api/image','/api/transcribe','/api/analyze','/api/upload'],true) && is_banned((string)($_SERVER['HTTP_X_REBBET_USER']??''),$cfg)) api_error(403,'banned','Your access has been blocked by an administrator.');
}
if(($path==='/health'||$path==='/api/health') && $method==='GET') {
    json_response(200,['ok'=>true,'app'=>APP_NAME,'version'=>APP_VERSION,'module'=>'rebbet-ai','module_id'=>'rebbet_ai',
        'key_configured'=>(bool)($cfg['api_key']||$cfg['cheatgpt_api_key']||$cfg['huggingface_api_key']),'default_model'=>$cfg['default_model'],
        'bind'=>$cfg['host'].':'.$cfg['port'],'provider'=>$cfg['provider'],'web_search'=>(bool)$cfg['enable_web_search'],
        'auto_switch'=>(bool)$cfg['auto_switch_model'],'free_fallback'=>(bool)$cfg['enable_free_fallback'],
        'elevenlabs_voice'=>(bool)$cfg['elevenlabs_api_key'],'github_models'=>(bool)$cfg['github_api_key'],
        'pollinations'=>(bool)$cfg['pollinations_api_key'],'cheatgpt'=>(bool)$cfg['cheatgpt_api_key'],
        'huggingface'=>(bool)$cfg['huggingface_api_key']]);
}
if($method==='GET' && $path==='/api/models') {
    $models=model_list($cfg); $source='fallback'; $provider=strtolower((string)$cfg['provider']);
    if($provider==='huggingface' && $cfg['huggingface_api_key']!=='') {
        try {
            $r=http_call(rtrim((string)$cfg['huggingface_base_url'],'/').'/models','GET',null,['Authorization: Bearer '.$cfg['huggingface_api_key']],30);
            $d=json_decode($r['body'],true); $ids=[];
            if($r['status']>=200&&$r['status']<300&&is_array($d)) foreach(($d['data']??$d['models']??[]) as $item) {
                if(!is_array($item)) continue; $id=(string)($item['id']??$item['name']??''); if(str_starts_with($id,'models/'))$id=substr($id,7);
                if($id===''||preg_match('/embedding|tts|transcri|image|audio|video|robotics|whisper/i',$id))continue;
                $ids[]='hf/'.$id;
            }
            if($ids) { $models=[]; foreach(array_unique($ids) as $id)$models[]=['id'=>$id,'label'=>model_label($id),'family'=>model_family($id),'free'=>model_free($id),'recommended'=>false]; $source='live'; }
        } catch(Throwable $e) { /* Keep the configured fallback list when model discovery is unavailable. */ }
    }
    elseif(in_array($provider,['pollinations','openai','chatgpt','cheatgpt'],true)) $source='config';
    elseif($cfg['api_key']!=='') {
        try {
            $url=rtrim((string)$cfg['base_url'],'/').'/v1/models';
            $headers=['Authorization: Bearer '.$cfg['api_key']];
            $r=http_call($url,'GET',null,$headers,30); $d=json_decode($r['body'],true); $ids=[];
            if($r['status']>=200&&$r['status']<300&&is_array($d)) foreach(($d['data']??$d['models']??[]) as $item) {
                if(!is_array($item)) continue; $id=(string)($item['id']??$item['name']??''); if(str_starts_with($id,'models/'))$id=substr($id,7);
                if($id==='')continue;
                if(preg_match('/embedding|tts|transcri|image|audio|video|robotics/i',$id))continue;
                $ids[]=$id;
            }
            if($ids) { $models=[]; foreach(array_unique($ids) as $id)$models[]=['id'=>$id,'label'=>model_label($id),'family'=>model_family($id),'free'=>model_free($id),'recommended'=>in_array($id,['gpt-5-nano','big-pickle'],true)]; $source='live'; }
        } catch(Throwable $e) { /* Keep the configured fallback list when model discovery is unavailable. */ }
    }
    json_response(200,['models'=>$models,'source'=>$source,'default'=>$cfg['default_model']]);
}
if($method==='POST' && $path==='/api/chat') {
    try { $payload=body_json(); } catch(Throwable $e) { api_error(400,'bad_request',$e->getMessage()); }
    chat_reply($cfg,$payload);
}
if($method==='POST' && $path==='/api/search') {
    try {$payload=body_json(65536);} catch(Throwable $e) {api_error(400,'bad_request',$e->getMessage());}
    $q=trim((string)($payload['query']??'')); if($q==='') api_error(400,'bad_request','query is required');
    json_response(200,['results'=>web_search_results($q),'query'=>$q]);
}
if($method==='GET' && $path==='/api/app-config') json_response(200,app_config($cfg));
if($method==='GET' && $path==='/api/firebase/status') {
    $uid=(string)($query['user']??'');
    if(!preg_match('/^[A-Za-z0-9_-]{6,80}$/',$uid)) api_error(400,'invalid_user','Valid user ID required.');
    if(trim((string)$cfg['firebase_database_secret'])==='') json_response(200,['ok'=>true,'configured'=>false,'status'=>[],'ban'=>null]);
    try {
        $status=firebase_db_request('appStatus','GET',null,$cfg);
        $ban=firebase_db_request('bans/'.$uid,'GET',null,$cfg);
    } catch(Throwable $e) { api_error(503,'status_unavailable','Live status is temporarily unavailable.'); }
    json_response(200,['ok'=>true,'status'=>$status,'ban'=>$ban]);
}
if($method==='POST' && $path==='/api/firebase/register') {
    try {$p=body_json(16384);} catch(Throwable $e) {api_error(400,'bad_request',$e->getMessage());}
    $uid=(string)($p['userId']??'');
    if(!preg_match('/^[A-Za-z0-9_-]{6,80}$/',$uid)) api_error(400,'invalid_user','Valid user ID required.');
    if(trim((string)$cfg['firebase_database_secret'])==='') json_response(200,['ok'=>true,'configured'=>false]);
    try {
        firebase_db_request('users/'.$uid,'PATCH',[
            'lastSeen'=>['.sv'=>'timestamp'],
            'appVersion'=>substr((string)($p['appVersion']??''),0,40),
            'platform'=>substr((string)($p['platform']??''),0,80),
            'language'=>substr((string)($p['language']??''),0,40),
            'userAgent'=>substr((string)($p['userAgent']??''),0,220)
        ],$cfg);
    } catch(Throwable $e) { api_error(503,'register_unavailable','Could not register this device.'); }
    json_response(200,['ok'=>true]);
}
if($method==='GET' && $path==='/api/voices') {
    $voices=[]; if($cfg['elevenlabs_api_key']!=='') {try {$r=http_call('https://api.elevenlabs.io/v1/voices','GET',null,['xi-api-key: '.$cfg['elevenlabs_api_key']],25);$d=json_decode($r['body'],true);foreach(($d['voices']??[])as$v)if(is_array($v)&&!empty($v['voice_id']))$voices[]=['id'=>$v['voice_id'],'name'=>$v['name']??$v['voice_id'],'category'=>$v['category']??'','labels'=>$v['labels']??[],'preview_url'=>$v['preview_url']??''];}catch(Throwable $e){}}
    if(!$voices)$voices=[['id'=>'21m00Tcm4TlvDq8ikWAM','name'=>'Rachel','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'AZnzlk1XvdvUeBnXmlld','name'=>'Domi','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'EXAVITQu4vr4xnSDxMaL','name'=>'Bella','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'MF3mGyEYCl7XYWbV9V6O','name'=>'Elli','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'ErXwobaYiN019PkySvjV','name'=>'Antoni','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'TxGEqnHWrfWFTfGW9XjX','name'=>'Josh','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'VR6AewLTigWG4xSOukaG','name'=>'Arnold','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'pNInz6obpgDQGcFmaJgB','name'=>'Adam','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'yoZ06aMxZJJ28mfd3POQ','name'=>'Sam','category'=>'premade','labels'=>[],'preview_url'=>'']];
    json_response(200,['voices'=>$voices,'models'=>['eleven_multilingual_v2','eleven_turbo_v2_5','eleven_flash_v2_5','eleven_multilingual_v1','eleven_monolingual_v1'],'default_voice'=>$cfg['elevenlabs_voice_id'],'default_model'=>$cfg['elevenlabs_model'],'speed'=>$cfg['voice_speed'],'warning'=>'']);
}
if($method==='POST'&&in_array($path,['/api/tts','/api/image','/api/transcribe','/api/analyze'],true)) {
    try {$payload=body_json($path==='/api/transcribe'?18*1024*1024:($path==='/api/analyze'?42*1024*1024:262144));} catch(Throwable $e) {api_error(400,'bad_request',$e->getMessage());}
    if($path==='/api/tts') tts_audio($cfg,$payload);
    if($path==='/api/transcribe') transcribe_audio($cfg,$payload);
    if($path==='/api/analyze') analyze_document($cfg,$payload);
    $prompt=trim((string)($payload['prompt']??'')); if($prompt==='') api_error(400,'bad_request','prompt is required');
    try {[$bytes,$mime,$provider,$model]=image_bytes($cfg,mb_substr($prompt,0,2000),(int)($payload['width']??768),(int)($payload['height']??768));} catch(Throwable $e) {api_error(502,'image_error','Image generation failed.',['detail'=>substr($e->getMessage(),0,250)]);}
    if(!is_string($bytes)||$bytes==='')api_error(502,'image_error','Image provider returned no picture.');
    send_binary($bytes,$mime,['X-Image-Source'=>$provider,'X-Image-Model'=>$model,'X-Image-Prompt'=>rawurlencode(mb_substr($prompt,0,180))]);
}

if($method==='GET' && str_starts_with($path,'/api/file/')) {
    $m=upload_meta(substr($path,10)); if(!$m) api_error(404,'not_found','File not found'); json_response(200,public_meta($m));
}
if($method==='GET' && str_starts_with($path,'/f/')) {
    $m=upload_meta(substr($path,3)); if(!$m) api_error(404,'not_found','File not found'); serve_uploaded($m,in_array((string)($query['download']??''),['1','true'],true),$cfg);
}
if($method==='GET' && str_starts_with($path,'/s/')) {
    $m=upload_meta(substr($path,3));
    if(!$m) {http_response_code(404); echo '<h1>File not found</h1>'; exit;}
    $name=htmlspecialchars((string)$m['name'],ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); $url='/f/'.rawurlencode((string)$m['id']);
    header('Content-Type: text/html; charset=utf-8'); echo '<!doctype html><meta name="viewport" content="width=device-width"><title>'.$name.' · Rebbet AI</title><main style="font:16px system-ui;max-width:700px;margin:10vh auto;padding:24px"><h1>'.$name.'</h1><p>'.number_format((int)$m['size']).' bytes</p><a href="'.$url.'?download=1">Download file</a></main>'; exit;
}
if($method==='POST' && $path==='/api/upload') {
    try {$p=body_json(40*1024*1024); $m=store_json_upload($p);} catch(Throwable $e) {api_error(400,'invalid_upload',$e->getMessage());}
    $out=public_meta($m); $origin=(string)($cfg['public_base_url']?:request_origin()); $out['url']=$origin.$out['url']; $out['rawUrl']=$origin.$out['rawUrl']; $out['shareUrl']=$out['url']; $out['downloadUrl']=$out['rawUrl']; $out['deepLink']=''; json_response(201,['ok'=>true,'file'=>$out]);
}
if($method==='GET' && $path==='/api/admin/settings') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token'); json_response(200,admin_settings($cfg));
}
if($method==='POST' && $path==='/api/admin/settings') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token');
    try {$payload=body_json(131072);} catch(Throwable $e) {api_error(400,'invalid_body',$e->getMessage());}
    $restartRequired=false;
    foreach(admin_payload($cfg) as $k=>$old) if(array_key_exists($k,$payload)) {
        $v=$payload[$k];
        if(in_array($k,['enable_web_search','auto_switch_model','enable_free_fallback','force_https','update_available','force_update']
,true)) $cfg[$k]=filter_var($v,FILTER_VALIDATE_BOOLEAN);
        elseif(in_array($k,['port','request_timeout','max_upload_mb'],true)) {
            $next=max(1,min($k==='port'?65535:($k==='request_timeout'?900:200),(int)$v));
            if($k==='port' && $next!==(int)$cfg[$k]) $restartRequired=true;
            $cfg[$k]=$next;
        } elseif(is_scalar($v)) {
            $next=substr(trim((string)$v),0,20000);
            if($k==='host' && $next!==$cfg[$k]) $restartRequired=true;
            if($k==='provider' && !in_array(strtolower($next),['opencode','pollinations','github','deepseek','openrouter','cheatgpt','openai','chatgpt','huggingface'],true)) api_error(400,'invalid_setting','Unsupported provider.');
            if($k==='voice_speed' && !in_array(strtolower($next),['fast','normal','slow'],true)) $next='fast';
            $cfg[$k]=$next;
        }
    }
    try {config_save($cfg);} catch(Throwable $e) {api_error(500,'save_failed',$e->getMessage());}
    json_response(200,['ok'=>true,'settings'=>admin_settings($cfg),'restart_required'=>$restartRequired]);
}
if($method==='GET' && $path==='/api/admin/firebase/state') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token');
    if(trim((string)$cfg['firebase_database_secret'])==='') json_response(200,['ok'=>true,'configured'=>false,'state'=>['appStatus'=>[],'users'=>[],'bans'=>[]]]);
    try {
        $state=[
            'appStatus'=>firebase_db_request('appStatus','GET',null,$cfg),
            'users'=>firebase_db_request('users','GET',null,$cfg),
            'bans'=>firebase_db_request('bans','GET',null,$cfg)
        ];
    } catch(Throwable $e) { api_error(503,'firebase_unavailable',$e->getMessage()); }
    json_response(200,['ok'=>true,'state'=>$state]);
}
if($method==='POST' && $path==='/api/admin/firebase/status') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token');
    try {$p=body_json(65536);} catch(Throwable $e) {api_error(400,'invalid_body',$e->getMessage());}
    $status=is_array($p['status']??null)?$p['status']:$p;
    $status['updatedAt']=['.sv'=>'timestamp'];
    try {firebase_db_request('appStatus','PUT',$status,$cfg);} catch(Throwable $e) {api_error(503,'firebase_unavailable',$e->getMessage());}
    json_response(200,['ok'=>true]);
}
if($method==='POST' && $path==='/api/admin/firebase/ban') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token');
    try {$p=body_json(16384);} catch(Throwable $e) {api_error(400,'invalid_body',$e->getMessage());}
    $uid=(string)($p['userId']??'');
    if(!preg_match('/^[A-Za-z0-9_-]{6,80}$/',$uid)) api_error(400,'invalid_user','Valid user ID required.');
    try {
        firebase_db_request('bans/'.$uid,'PUT',[
            'banned'=>true,
            'reason'=>substr((string)($p['reason']??''),0,400),
            'at'=>['.sv'=>'timestamp'],
            'by'=>substr((string)($p['by']??'admin'),0,80)
        ],$cfg);
    } catch(Throwable $e) {api_error(503,'firebase_unavailable',$e->getMessage());}
    json_response(200,['ok'=>true]);
}
if($method==='POST' && $path==='/api/admin/firebase/unban') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token');
    try {$p=body_json(16384);} catch(Throwable $e) {api_error(400,'invalid_body',$e->getMessage());}
    $uid=(string)($p['userId']??'');
    if(!preg_match('/^[A-Za-z0-9_-]{6,80}$/',$uid)) api_error(400,'invalid_user','Valid user ID required.');
    try {firebase_db_request('bans/'.$uid,'DELETE',null,$cfg);} catch(Throwable $e) {api_error(503,'firebase_unavailable',$e->getMessage());}
    json_response(200,['ok'=>true]);
}
if($method==='POST' && in_array($path,['/api/admin/upload-icon','/api/admin/upload-update','/api/admin/set-icon','/api/admin/delete-file','/api/admin/reload-config','/api/admin/restart','/api/admin/encrypt-uploads'],true)
) {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token');
    try {$payload=body_json($path==='/api/admin/upload-update'?285*1024*1024:6*1024*1024);} catch(Throwable $e) {api_error(400,'invalid_body',$e->getMessage());}
    if($path==='/api/admin/set-icon') {
        $id=(string)($payload['id']??''); $m=upload_meta($id); if(!$m||($m['kind']??'')!=='icon')api_error(404,'not_found','Icon not found');
        $cfg['app_icon']='/f/'.$id; config_save($cfg); json_response(200,['ok'=>true,'settings'=>admin_settings($cfg)]);
    }
    if($path==='/api/admin/delete-file') {
        $id=(string)($payload['id']??''); $m=upload_meta($id); if(!$m)api_error(404,'not_found','File not found'); @unlink($m['path']);$idx=load_upload_index();unset($idx[$id]);save_upload_index($idx);$changed=false;if(($cfg['app_icon']??'')==='/f/'.$id){$cfg['app_icon']='';$changed=true;}if(($cfg['update_url']??'')==='/f/'.$id){$cfg['update_url']='';$cfg['update_available']=false;$changed=true;}if($changed)config_save($cfg);json_response(200,['ok'=>true]);
    }
    if($path==='/api/admin/reload-config') { $cfg=read_config(); json_response(200,['ok'=>true,'settings'=>admin_settings($cfg)]); }
    if($path==='/api/admin/encrypt-uploads') {
        $idx=load_upload_index(); $changed=0; $failed=0;
        foreach(array_keys($idx) as $id) {
            $meta=upload_meta((string)$id); if(!$meta) continue;
            try { if(migrate_upload($meta,$cfg,$idx)) $changed++; } catch(Throwable $e) { $failed++; }
        }
        if($changed>0) save_upload_index($idx);
        json_response(200,['ok'=>true,'encrypted'=>$changed,'failed'=>$failed,'total'=>count($idx)]);
    }
    if($path==='/api/admin/restart') json_response(200,['ok'=>true,'message'=>'Restart the Render service to apply runtime changes.']);
    if($path==='/api/admin/upload-icon') {
        try {$m=store_json_upload($payload,'icon');}catch(Throwable $e){api_error(400,'invalid_upload',$e->getMessage());}
        try{$bytes=upload_bytes($m,$cfg);}catch(Throwable $e){api_error(500,'upload_unavailable','This file cannot be decrypted on the server.');}$mime=(string)$m['mimeType'];
        $valid=($mime==='image/png'&&str_starts_with($bytes,"\x89PNG\r\n\x1a\n"))||($mime==='image/jpeg'&&str_starts_with($bytes,"\xff\xd8\xff"))||($mime==='image/webp'&&substr($bytes,0,4)==='RIFF'&&substr($bytes,8,4)==='WEBP')||($mime==='image/gif'&&in_array(substr($bytes,0,6),['GIF87a','GIF89a'],true));
        if(!$valid){@unlink($m['path']);$idx=load_upload_index();unset($idx[$m['id']]);save_upload_index($idx);api_error(400,'invalid_image','Use a valid PNG, JPEG, WEBP or GIF image.');}
        if(($payload['activate']??true)!==false) {$cfg['app_icon']='/f/'.$m['id'];config_save($cfg);}
        $out=public_meta($m);$out['url']=request_origin().$out['url'];$out['rawUrl']=request_origin().$out['rawUrl'];json_response(200,['ok'=>true,'settings'=>admin_settings($cfg),'file'=>$out]);
    }
    if($path==='/api/admin/upload-update') {
        try {$m=store_json_upload($payload,'update');}catch(Throwable $e){api_error(400,'invalid_upload',$e->getMessage());}
        if(!str_ends_with(strtolower((string)$m['name']),'.apk')) api_error(400,'invalid_file','Update upload must be an APK.');
        $cfg['update_url']='/f/'.$m['id'];$cfg['update_available']=true;
        if(!empty($payload['version']))$cfg['app_version']=substr((string)$payload['version'],0,40);
        if(!empty($payload['update_message']))$cfg['update_message']=substr((string)$payload['update_message'],0,600);
        config_save($cfg);$out=public_meta($m);$out['url']=request_origin().$out['url'];$out['rawUrl']=request_origin().$out['rawUrl'];json_response(200,['ok'=>true,'settings'=>admin_settings($cfg),'file'=>$out]);
    }
}

if($method==='GET' && $path==='/api/admin/files') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token'); $list=[]; foreach(load_upload_index() as $m) if(is_array($m)) $list[]=public_meta($m); usort($list,static fn($a,$b)=>($b['created']??0)<=>($a['created']??0)); json_response(200,['files'=>$list]);
}
if($method==='GET' && $path==='/api/admin/editor') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token');
    $file=(string)($query['path']??'');
    if($file==='') { $files=[]; $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator(ROOT_DIR,FilesystemIterator::SKIP_DOTS)); foreach($it as $f) if($f->isFile()&&$f->getSize()<2*1024*1024&&!str_contains($f->getPathname(),'/uploads/')) $files[]=str_replace(ROOT_DIR.'/','',$f->getPathname()); json_response(200,['files'=>$files]); }
    try {$full=safe_editor_path($file);} catch(Throwable $e) {api_error(400,'invalid_path',$e->getMessage());} json_response(200,['file'=>['path'=>$file,'content'=>(string)file_get_contents($full),'size'=>filesize($full)] ]);
}
if($method==='POST' && $path==='/api/admin/editor') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token'); try {$p=body_json(2*1024*1024+8192);$full=safe_editor_path((string)($p['path']??''));} catch(Throwable $e){api_error(400,'invalid_path',$e->getMessage());}
    if(!is_string($p['content']??null)||strlen($p['content'])>2*1024*1024) api_error(400,'invalid_body','File content is invalid or too large.');
    if(file_put_contents($full,$p['content'])===false) api_error(500,'write_failed','Could not write file.');$reload=false;if(($p['path']??'')==='config.json'){$cfg=read_config();$reload=true;}json_response(200,['ok'=>true,'file'=>['path'=>$p['path'],'size'=>strlen($p['content'])],'config_reloaded'=>$reload]);
}

if($method==='GET' && ($path==='/api/module'||$path==='/api/rebbet')) {
    json_response(200,['name'=>'rebbet-ai','id'=>'rebbet_ai','display_name'=>APP_NAME,'version'=>APP_VERSION,
        'features'=>['web_search'=>true,'internet_search'=>true,'free_ai_models'=>true,'auto_switch_on_limit'=>true,'better_voice'=>true,'fast_voice'=>true,'image_generation'=>true,'free_fallback'=>(bool)$cfg['enable_free_fallback']],
        'free_models'=>[$cfg['default_model']],'auto_switch_order'=>[$cfg['default_model']],
        'free_fallback_providers'=>array_keys(array_filter(['deepseek'=>$cfg['deepseek_api_key'],'openrouter'=>$cfg['openrouter_api_key'],'github'=>$cfg['github_api_key'],'cheatgpt'=>$cfg['cheatgpt_api_key'],'huggingface'=>$cfg['huggingface_api_key'],'pollinations'=>$cfg['enable_free_fallback']])),
        'voice_models'=>['eleven_multilingual_v2'],'image_models'=>['pollinations']]);
}
if($method==='GET' && ($path==='/'||$path==='/index.html'||$path==='/admin'||$path==='/admin/'||$path==='/admin.html'||str_starts_with($path,'/static/')||$path==='/manifest.json'||$path==='/service-worker.js'||$path==='/favicon.ico')) {
    $p=$path==='/favicon.ico'?'/static/icon-192.png':$path;
    if(serve_path($p)) exit;
}
if($method==='GET' && in_array($path,['/api/chat','/api/search','/api/tts','/api/image','/api/transcribe','/api/analyze'],true)) api_error(405,'method_not_allowed','Use POST for '.$path);
if(str_starts_with($path,'/api/')) api_error(404,'not_found','Not found',['path'=>$path]);
http_response_code(404);
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['error'=>['message'=>'Not found','path'=>$path,'hint'=>'Open / for the app or /admin.html for the admin panel.']]);
