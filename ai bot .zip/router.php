<?php
declare(strict_types=1);

/*
 * PHP replacement for app.py. Kept as a side-by-side router while feature
 * parity is built; Render remains on Python until migration is complete.
 */
const APP_VERSION = '1.12.4';
const APP_NAME = 'Rebbet AI';
const ROOT_DIR = __DIR__;
const UPLOAD_DIR = ROOT_DIR . '/uploads';
const CONFIG_FILE = ROOT_DIR . '/config.json';
const INDEX_FILE = UPLOAD_DIR . '/index.json';
const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/openai';
const POLLINATIONS_CHAT = 'https://gen.pollinations.ai/v1/chat/completions';
const POLLINATIONS_IMAGE = 'https://image.pollinations.ai/prompt';

function default_config(): array {
    return [
        'host'=>'0.0.0.0','port'=>8765,'provider'=>'gemini','api_key'=>'','image_api_key'=>'',
        'base_url'=>GEMINI_BASE,'default_model'=>'gemini-3.6-flash',
        'system_prompt'=>'You are Rebbet AI, a helpful, friendly assistant. Be accurate and clear. Use Markdown when it improves readability, and keep answers focused on what the user asked.',
        'request_timeout'=>300,'enable_web_search'=>true,'auto_switch_model'=>true,'enable_free_fallback'=>true,
        'voice_speed'=>'fast','elevenlabs_api_key'=>'','elevenlabs_voice_id'=>'21m00Tcm4TlvDq8ikWAM',
        'elevenlabs_model'=>'eleven_multilingual_v2','image_model'=>'gemini-3.1-flash-image',
        'transcribe_model'=>'gemini-3.5-transcribe','pollinations_model'=>'openai-fast','pollinations_api_key'=>'',
        'pollinations_image_model'=>'black-forest-labs/flux.1-schnell','pollinations_image_aspect'=>'1:1',
        'pollinations_tts_model'=>'openai/tts-1','pollinations_tts_voice'=>'alloy',
        'pollinations_transcribe_model'=>'openai/whisper-large-v3','deepseek_api_key'=>'',
        'deepseek_model'=>'deepseek-chat','openrouter_api_key'=>'',
        'openrouter_model'=>'deepseek/deepseek-chat-v3-0324:free','github_api_key'=>'',
        'github_model'=>'openai/gpt-4.1','github_base_url'=>'https://models.github.ai/inference',
        'cheatgpt_api_key'=>'','cheatgpt_model'=>'gpt-5-nano','cheatgpt_base_url'=>'https://api.openai.com/v1',
        'admin_token'=>'','app_version'=>APP_VERSION,'app_icon'=>'','update_url'=>'','update_message'=>'',
        'update_available'=>false,'force_update'=>false,'max_upload_mb'=>25,'public_base_url'=>'',
        'app_link_scheme'=>'rebbetai','app_package'=>'com.rabbet.ai','app_download_url'=>'',
        'google_client_id'=>'','google_client_secret'=>'','google_redirect_uri'=>'','auth_session_secret'=>'',
        'auth_session_name'=>'rik_member','auth_access_code'=>'',
    ];
}

function read_config(): array {
    $cfg = default_config();
    if (is_file(CONFIG_FILE)) {
        $saved = json_decode((string)file_get_contents(CONFIG_FILE), true);
        if (is_array($saved)) $cfg = array_replace($cfg, $saved);
    }
    $env = [
        'GEMINI_API_KEY'=>'api_key','OPENCODE_API_KEY'=>'api_key',
        'REBBET_IMAGE_API_KEY'=>'image_api_key','GEMINI_IMAGE_API_KEY'=>'image_api_key',
        'POLLINATIONS_API_KEY'=>'pollinations_api_key','REBBET_POLLINATIONS_API_KEY'=>'pollinations_api_key',
        'DEEPSEEK_API_KEY'=>'deepseek_api_key','OPENROUTER_API_KEY'=>'openrouter_api_key',
        'GITHUB_MODELS_TOKEN'=>'github_api_key','GITHUB_TOKEN'=>'github_api_key',
        'CHEATGPT_API_KEY'=>'cheatgpt_api_key','OPENAI_API_KEY'=>'cheatgpt_api_key',
        'ELEVENLABS_API_KEY'=>'elevenlabs_api_key','REBBET_ADMIN_TOKEN'=>'admin_token',
        'GOOGLE_CLIENT_ID'=>'google_client_id','GOOGLE_CLIENT_SECRET'=>'google_client_secret',
        'GOOGLE_REDIRECT_URI'=>'google_redirect_uri','AUTH_SESSION_SECRET'=>'auth_session_secret',
        'AUTH_SESSION_NAME'=>'auth_session_name','AUTH_ACCESS_CODE'=>'auth_access_code',
        'REBBET_DEFAULT_MODEL'=>'default_model','REBBET_HOST'=>'host',
        'REBBET_PORT'=>'port','PORT'=>'port',
    ];
    foreach ($env as $name=>$key) {
        $value = getenv($name);
        if ($value !== false && $value !== '') $cfg[$key] = $value;
    }
    if (getenv('GEMINI_API_KEY')) { $cfg['provider']='gemini'; $cfg['base_url']=GEMINI_BASE; }
    if (getenv('PORT') && !getenv('REBBET_HOST')) $cfg['host']='0.0.0.0';
    $cfg['port'] = max(1, min(65535, (int)$cfg['port']));
    $cfg['provider'] = strtolower(trim((string)$cfg['provider']));
    $cfg['base_url'] = rtrim((string)$cfg['base_url'], '/');
    $cfg['default_model'] = trim((string)$cfg['default_model']);
    foreach ($cfg as $k=>$v) if (str_ends_with($k, '_api_key') || in_array($k,['api_key','admin_token','google_client_secret','auth_session_secret'],true)) $cfg[$k]=trim((string)$v);
    return $cfg;
}

function json_response(int $status, array $data, array $headers=[]): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    foreach ($headers as $name=>$value) header($name . ': ' . $value);
    echo json_encode($data, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    exit;
}
function api_error(int $status, string $code, string $message, array $more=[]): never {
    json_response($status, ['error'=>array_merge(['code'=>$code,'message'=>$message],$more)]);
}
function body_json(int $limit=4194304): array {
    $raw = file_get_contents('php://input', false, null, 0, $limit+1);
    if ($raw === false || strlen($raw)>$limit) throw new RuntimeException('Request body is too large');
    $data=json_decode($raw,true);
    if (!is_array($data)) throw new InvalidArgumentException('Request body must be a JSON object');
    return $data;
}
function send_cors(): void {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, HEAD, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Authorization, Content-Type, X-Rebbet-User, X-Admin-Token');
    header('Access-Control-Expose-Headers: X-Voice-Model, X-Image-Source, X-Image-Model, X-Image-Prompt');
}
function admin_ok(array $cfg): bool {
    $want=(string)($cfg['admin_token']??'');
    $got=(string)($_SERVER['HTTP_X_ADMIN_TOKEN']??'');
    if ($got==='' && preg_match('/^Bearer\s+(.+)$/i',(string)($_SERVER['HTTP_AUTHORIZATION']??''),$m)) $got=trim($m[1]);
    return $want!=='' && hash_equals($want,$got);
}
function http_call(string $url, string $method='GET', ?array $payload=null, array $headers=[], int $timeout=45): array {
    if (!function_exists('curl_init')) throw new RuntimeException('PHP cURL extension is required');
    $ch=curl_init($url);
    $outHeaders=[];
    $h=['Accept: application/json','User-Agent: RebbetAI/'.APP_VERSION,...$headers];
    if ($payload!==null) $h[]='Content-Type: application/json';
    curl_setopt_array($ch,[
        CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$h,
        CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>12,CURLOPT_TIMEOUT=>$timeout,
        CURLOPT_FOLLOWLOCATION=>false,
        CURLOPT_HEADERFUNCTION=>static function($ch,$line) use (&$outHeaders) {
            $len=strlen($line); $p=strpos($line,':');
            if($p!==false) $outHeaders[strtolower(trim(substr($line,0,$p)))]=trim(substr($line,$p+1));
            return $len;
        },
    ]);
    if ($payload!==null) curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
    $raw=curl_exec($ch); $err=curl_error($ch); $status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); curl_close($ch);
    if ($raw===false) throw new RuntimeException($err?:'Upstream request failed');
    return ['status'=>$status,'body'=>(string)$raw,'headers'=>$outHeaders];
}
function config_save(array $cfg): void {
    $tmp=CONFIG_FILE.'.tmp';
    if (file_put_contents($tmp,json_encode($cfg,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n",LOCK_EX)===false) throw new RuntimeException('Could not save config');
    if(!rename($tmp,CONFIG_FILE)) { @unlink($tmp); throw new RuntimeException('Could not replace config'); }
}
function app_config(array $c): array {
    return ['app'=>APP_NAME,'version'=>$c['app_version']?:APP_VERSION,'built_version'=>APP_VERSION,
        'icon'=>$c['app_icon'],'update_url'=>$c['update_url'],'update_message'=>$c['update_message'],
        'update_available'=>(bool)$c['update_available'],'force_update'=>(bool)$c['force_update'],
        'max_upload_mb'=>(int)$c['max_upload_mb'],'app_link_scheme'=>$c['app_link_scheme'],
        'app_package'=>$c['app_package'],'app_download_url'=>$c['app_download_url'],
        'public_base_url'=>$c['public_base_url'],'google_login'=>google_configured($c)];
}
function google_configured(array $c): bool { return trim((string)$c['google_client_id'])!=='' && trim((string)$c['google_client_secret'])!==''; }
function request_origin(): string {
    $proto=(string)($_SERVER['HTTP_X_FORWARDED_PROTO']??'');
    if ($proto==='') $proto=(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off')?'https':'http';
    $host=(string)($_SERVER['HTTP_X_FORWARDED_HOST']??$_SERVER['HTTP_HOST']??'localhost');
    return $proto.'://'.$host;
}
function serve_path(string $path): bool {
    $path=rawurldecode($path);
    $rel=ltrim($path,'/');
    if($rel==='' ) $rel='index.html';
    if($rel==='admin' || $rel==='admin/') $rel='admin.html';
    if(str_contains($rel,"..") || str_contains($rel,"\0")) return false;
    $root=realpath(ROOT_DIR); $file=realpath(ROOT_DIR.'/'.$rel);
    if($file===false || !str_starts_with($file,$root.DIRECTORY_SEPARATOR) || !is_file($file)) return false;
    $ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));
    $types=['html'=>'text/html; charset=utf-8','htm'=>'text/html; charset=utf-8','css'=>'text/css; charset=utf-8','js'=>'text/javascript; charset=utf-8','json'=>'application/json; charset=utf-8','webmanifest'=>'application/manifest+json','svg'=>'image/svg+xml','png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','ico'=>'image/x-icon','webp'=>'image/webp','txt'=>'text/plain; charset=utf-8'];
    header('Content-Type: '.($types[$ext]??'application/octet-stream'));
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: '.(str_starts_with($path,'/static/')?'public, max-age=3600':'no-cache'));
    readfile($file); return true;
}
function safe_next(string $next): string {
    $next=trim($next);
    if($next==='' || $next[0]!=='/' || str_starts_with($next,'//') || str_contains($next,"\\")) return '/';
    return $next;
}
function redirect_to(string $url, array $cookies=[]): never {
    foreach($cookies as $name=>$spec) setcookie($name,$spec['value'],['expires'=>$spec['expires']??0,'path'=>'/','secure'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')||str_starts_with(request_origin(),'https://'),'httponly'=>$spec['httponly']??true,'samesite'=>$spec['samesite']??'Lax']);
    header('Location: '.$url,true,302); exit;
}
function auth_secret(array $cfg): string {
    return $cfg['auth_session_secret']?:hash('sha256','rebbet-google-auth:'.$cfg['google_client_secret']);
}
function signed_cookie(array $data,array $cfg): string {
    $payload=rtrim(strtr(base64_encode(json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)),'+/','-_'),'=');
    return $payload.'.'.hash_hmac('sha256',$payload,auth_secret($cfg));
}
function verified_cookie(array $cfg,string $name): ?array {
    $token=(string)($_COOKIE[$name]??''); $p=strrpos($token,'.'); if($p===false) return null;
    $payload=substr($token,0,$p); $sig=substr($token,$p+1);
    if(!hash_equals(hash_hmac('sha256',$payload,auth_secret($cfg)),$sig)) return null;
    $raw=base64_decode(strtr($payload,'-_','+/')); $data=json_decode($raw?:'',true);
    return is_array($data)&&($data['exp']??0)>time()?$data:null;
}
function auth_redirect_uri(array $cfg): string {
    return $cfg['google_redirect_uri']?:request_origin().'/auth-callback.php';
}
function post_form(string $url,array $fields,int $timeout=25): array {
    $ch=curl_init($url); curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query($fields),CURLOPT_HTTPHEADER=>['Accept: application/json','Content-Type: application/x-www-form-urlencoded'],CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>$timeout]);
    $body=curl_exec($ch); $status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); $err=curl_error($ch); curl_close($ch);
    if($body===false) throw new RuntimeException($err?:'Could not reach Google');
    return ['status'=>$status,'body'=>(string)$body];
}
function oauth_error(string $message,int $status=400): never {
    http_response_code($status); header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><meta name="viewport" content="width=device-width"><title>Google sign-in</title><h1>Google sign-in</h1><p>'.htmlspecialchars($message,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'</p><p><a href="/">Return to Rebbet AI</a></p>'; exit;
}
function handle_google_start(array $cfg,array $query): never {
    $next=safe_next((string)($query['next']??'/'));
    if(!google_configured($cfg)) oauth_error('Google sign-in is not configured on this server yet.',503);
    if($cfg['auth_access_code']!=='' && !verified_cookie($cfg,'rik_access')) redirect_to('/auth/login?next='.rawurlencode($next));
    $state=bin2hex(random_bytes(24));
    $_SESSION['google_state']=$state; $_SESSION['google_next']=$next;
    $params=['client_id'=>$cfg['google_client_id'],'redirect_uri'=>auth_redirect_uri($cfg),'response_type'=>'code','scope'=>'openid email profile','state'=>$state,'access_type'=>'online','prompt'=>'select_account'];
    redirect_to('https://accounts.google.com/o/oauth2/v2/auth?'.http_build_query($params));
}
function handle_google_callback(array $cfg,array $query): never {
    if(!google_configured($cfg)) oauth_error('Google sign-in is not configured on this server yet.',503);
    if(isset($query['error'])) oauth_error('Google sign-in was cancelled or denied.');
    $state=(string)($query['state']??''); $expected=(string)($_SESSION['google_state']??'');
    if($state==='' || $expected==='' || !hash_equals($expected,$state)) oauth_error('Google sign-in session expired. Please try again.',400);
    unset($_SESSION['google_state']); $next=safe_next((string)($_SESSION['google_next']??'/')); unset($_SESSION['google_next']);
    $code=(string)($query['code']??''); if($code==='') oauth_error('Google did not return an authorization code.');
    try {
        $token=post_form('https://oauth2.googleapis.com/token',['code'=>$code,'client_id'=>$cfg['google_client_id'],'client_secret'=>$cfg['google_client_secret'],'redirect_uri'=>auth_redirect_uri($cfg),'grant_type'=>'authorization_code']);
        $td=json_decode($token['body'],true);
        if($token['status']<200||$token['status']>=300||!is_array($td)||empty($td['access_token'])) oauth_error('Google rejected sign-in. Check the OAuth client and redirect URI.',502);
        $user=http_call('https://openidconnect.googleapis.com/v1/userinfo','GET',null,['Authorization: Bearer '.$td['access_token']],20);
        $u=json_decode($user['body'],true);
        if($user['status']!==200||!is_array($u)||empty($u['email'])||!($u['email_verified']??false)) oauth_error('Google did not return a verified account identity.',502);
        $identity=['sub'=>(string)($u['sub']??''),'email'=>(string)$u['email'],'name'=>(string)($u['name']??$u['email']),'picture'=>(string)($u['picture']??'')];
        $cookie=signed_cookie(['user'=>$identity,'exp'=>time()+30*24*3600],$cfg);
        $access=signed_cookie(['ok'=>true,'exp'=>time()+3600],$cfg);
        redirect_to($next,[$cfg['auth_session_name']=>['value'=>$cookie,'expires'=>time()+30*24*3600], 'rik_access'=>['value'=>$access,'expires'=>time()+3600]]);
    } catch(Throwable $e) { oauth_error('Could not complete Google sign-in. Please try again.',502); }
}
function auth_login_page(string $next,string $error=''): never {
    http_response_code($error===''?200:400); header('Content-Type: text/html; charset=utf-8');
    $e=$error===''?'':'<p style="color:#b42318">'.htmlspecialchars($error,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'</p>';
    echo '<!doctype html><html><meta name="viewport" content="width=device-width"><title>Sign in · Rebbet AI</title><body style="font:16px system-ui;max-width:420px;margin:12vh auto;padding:24px"><h1>Rebbet AI</h1>'.$e.'<form method="post" action="/auth/login"><input type="hidden" name="next" value="'.htmlspecialchars($next,ENT_QUOTES,'UTF-8').'"><label>Access code<input name="code" type="password" autocomplete="current-password" required></label><button>Continue</button></form></body></html>'; exit;
}

function provider_for_model(array $cfg,string $model): string {
    $m=strtolower($model);
    if($m==='pollinations'||str_starts_with($m,'pollinations/')) return 'pollinations';
    if(str_starts_with($m,'deepseek/')) return 'deepseek';
    if(str_starts_with($m,'openrouter/')) return 'openrouter';
    if(str_starts_with($m,'github/')) return 'github';
    if(in_array(strtolower($cfg['provider']),['openai','chatgpt','cheatgpt'],true)) return 'cheatgpt';
    if(strtolower($cfg['provider'])==='pollinations') return 'pollinations';
    if(strtolower($cfg['provider'])==='deepseek') return 'deepseek';
    if(strtolower($cfg['provider'])==='openrouter') return 'openrouter';
    if(strtolower($cfg['provider'])==='github') return 'github';
    if(strtolower($cfg['provider'])==='gemini'||str_starts_with(strtolower($cfg['base_url']),'https://generativelanguage.googleapis.com')) return 'gemini';
    return 'opencode';
}
function provider_spec(array $cfg,string $provider,string $model): array {
    return match($provider) {
        'gemini'=>[rtrim($cfg['base_url']?:GEMINI_BASE,'/').'/chat/completions',$cfg['api_key'],[]],
        'pollinations'=>[POLLINATIONS_CHAT,$cfg['pollinations_api_key'],[]],
        'deepseek'=>['https://api.deepseek.com/chat/completions',$cfg['deepseek_api_key'],[]],
        'openrouter'=>['https://openrouter.ai/api/v1/chat/completions',$cfg['openrouter_api_key'],['HTTP-Referer: '.request_origin(),'X-Title: Rebbet AI']],
        'github'=>[rtrim($cfg['github_base_url'],'/').'/chat/completions',$cfg['github_api_key'],[]],
        'cheatgpt'=>[rtrim($cfg['cheatgpt_base_url'],'/').'/chat/completions',$cfg['cheatgpt_api_key'],[]],
        default=>[rtrim($cfg['base_url'],'/').'/chat/completions',$cfg['api_key'],[]],
    };
}
function chat_reply(array $cfg,array $payload): never {
    $messages=$payload['messages']??null;
    if(!is_array($messages)||count($messages)<1||count($messages)>200) api_error(400,'bad_request','messages must be a non-empty array of at most 200 entries');
    $clean=[];
    foreach($messages as $m) {
        if(!is_array($m)||!in_array($m['role']??'', ['user','assistant'],true)||!is_string($m['content']??null)) api_error(400,'bad_request','Messages need a user/assistant role and text content');
        $content=mb_substr($m['content'],0,120000);
        if(($m['role']==='user')&&trim($content)==='') api_error(400,'bad_request','User messages cannot be empty');
        $clean[]=['role'=>$m['role'],'content'=>$content];
    }
    if(end($clean)['role']!=='user') api_error(400,'bad_request','The last message must be from the user');
    $model=trim((string)($payload['model']??$cfg['default_model']));
    if($model===''||strlen($model)>160) api_error(400,'bad_request','Invalid model id');
    $provider=provider_for_model($cfg,$model);
    $upstreamModel=$model;
    if($model==='pollinations'||$model==='pollinations/default') $upstreamModel=$cfg['pollinations_model']?:'openai-fast';
    elseif(str_starts_with(strtolower($model),'pollinations/')) $upstreamModel=substr($model,13);
    elseif(str_starts_with(strtolower($model),'deepseek/')) $upstreamModel=substr($model,9);
    elseif(str_starts_with(strtolower($model),'openrouter/')) $upstreamModel=substr($model,11);
    elseif(str_starts_with(strtolower($model),'github/')) $upstreamModel=substr($model,7);
    elseif($provider==='cheatgpt' && ($model===''||$model==='default')) $upstreamModel=$cfg['cheatgpt_model'];
    $apiKey=(string)(provider_spec($cfg,$provider,$upstreamModel)[1]??'');
    $fallbackAvailable=(bool)$cfg['enable_free_fallback'] && (bool)($cfg['deepseek_api_key']||$cfg['github_api_key']||$cfg['openrouter_api_key']||$cfg['cheatgpt_api_key']);
    if($apiKey==='' && !($provider==='pollinations' && (bool)$cfg['enable_free_fallback']) && !$fallbackAvailable) api_error(503,'no_key','No API key is configured for the selected provider.');
    $system=$payload['system']??$cfg['system_prompt'];
    if(!is_string($system)) api_error(400,'bad_request','system must be text');
    if(is_array($payload['personality']??null) && !empty($payload['personality']['system'])) $system="You are speaking in the '".substr((string)($payload['personality']['name']??'custom'),0,80)."' personality. Stay in character while remaining helpful and truthful.\n".substr((string)$payload['personality']['system'],0,4000)."\n\n".$system;
    if(is_array($payload['memory']??null)) { $mem=[]; foreach(array_slice($payload['memory'],0,40) as $item) if(is_array($item)&&isset($item['text'])) $mem[]=mb_substr((string)$item['text'],0,500); if($mem)$system.="\n\nRelevant saved context (treat as user-provided facts):\n- ".implode("\n- ",$mem); }
    $last=strtolower((string)end($clean)['content']);
    if(($payload['web_search']??$cfg['enable_web_search']) && preg_match('/\b(news|current|today|latest|weather|price|stock|score|update|now|202[5-9])\b/i',$last)) { $results=web_search_results((string)end($clean)['content'],5); if($results) { $system.="\n\nCurrent web search results (cite these links when relevant):\n"; foreach($results as $result)$system.='- '.$result['title'].' — '.$result['url']."\n"; } }
    $all=[['role'=>'system','content'=>mb_substr($system,0,24000)],...$clean];
    $body=['model'=>$upstreamModel,'messages'=>$all,'stream'=>false];
    if(isset($payload['temperature'])&&is_numeric($payload['temperature'])) $body['temperature']=max(0,min(2,(float)$payload['temperature']));
    if(isset($payload['max_tokens'])&&is_numeric($payload['max_tokens'])) $body['max_tokens']=max(1,min(65536,(int)$payload['max_tokens']));
    $plans=[$provider];
    if($cfg['enable_free_fallback']) foreach(['deepseek','github','openrouter','cheatgpt','pollinations'] as $candidate) if($candidate!==$provider && ($candidate==='pollinations'||provider_spec($cfg,$candidate,$upstreamModel)[1]!=='')) $plans[]=$candidate;
    $lastStatus=0; $lastBody=''; $data=null; $usedProvider=$provider; $usedModel=$upstreamModel; $networkError='';
    foreach($plans as $tryProvider) {
        $tryModel=match($tryProvider) {'deepseek'=>$cfg['deepseek_model'],'openrouter'=>$cfg['openrouter_model'],'github'=>$cfg['github_model'],'cheatgpt'=>$cfg['cheatgpt_model'],'pollinations'=>$cfg['pollinations_model'],default=>$upstreamModel};
        $spec=provider_spec($cfg,$tryProvider,$tryModel); $requestBody=$body; $requestBody['model']=$tryModel;
        $headers=$spec[2]; if($spec[1]!=='') $headers[]='Authorization: Bearer '.$spec[1];
        try {
            $res=http_call($spec[0],'POST',$requestBody,$headers,(int)$cfg['request_timeout']);
            if(in_array($res['status'],[401,403],true)&&$tryProvider==='pollinations'&&$spec[1]!=='') $res=http_call($spec[0],'POST',$requestBody,$spec[2],(int)$cfg['request_timeout']);
        } catch(Throwable $e) { $networkError=substr($e->getMessage(),0,240); continue; }
        $lastStatus=$res['status']; $lastBody=$res['body']; $data=json_decode($res['body'],true);
        if($lastStatus>=200&&$lastStatus<300&&is_array($data)) { $usedProvider=$tryProvider; $usedModel=$tryModel; break; }
        if(!$cfg['enable_free_fallback'] || !in_array($lastStatus,[401,402,403,404,408,429,500,502,503,504],true)) break;
    }
    if(!is_array($data)||$lastStatus<200||$lastStatus>=300) {
        $detail=is_array($data)?(string)($data['error']['message']??$data['message']??'The AI provider rejected the request.'):'The AI provider returned an invalid response.';
        $status=$lastStatus>=400&&$lastStatus<500?$lastStatus:502;
        api_error($status,$lastStatus===0?'network_error':'upstream_error',substr($detail?:$networkError,0,500),['provider'=>$usedProvider]);
    }
    $text=$data['choices'][0]['message']['content']??'';
    if(is_array($text)) $text=implode("\n",array_map(static fn($x)=>(string)($x['text']??''),$text));
    if(!is_string($text)||trim($text)==='') api_error(502,'empty_response','The AI provider returned an empty response.');
    header('Content-Type: text/event-stream; charset=utf-8'); header('Cache-Control: no-cache, no-transform'); header('X-Accel-Buffering: no');
    echo 'data: '.json_encode(['type'=>'meta','model'=>$usedModel,'provider'=>$usedProvider,'family'=>$usedProvider==='gemini'?'google':$usedProvider],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n\n";
    echo 'data: '.json_encode(['type'=>'delta','text'=>$text],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n\n";
    echo 'data: '.json_encode(['type'=>'done','usage'=>$data['usage']??new stdClass()],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n\n";
    exit;
}
function model_family(string $id): string {
    $s=strtolower($id);
    if($s==='pollinations'||str_starts_with($s,'pollinations/'))return 'pollinations';
    if(str_starts_with($s,'gemini')||str_starts_with($s,'gemma'))return 'google';
    if(str_starts_with($s,'claude')||str_starts_with($s,'qwen'))return 'anthropic';
    if(preg_match('/^(gpt|grok|muse|o1|o3|o4)/',$s))return 'responses';
    return 'openai';
}
function model_free(string $id): bool {
    $s=strtolower($id); return str_ends_with($s,'-free')||$s==='big-pickle'||(str_starts_with($s,'gpt')&&str_contains($s,'-nano'))||(str_starts_with($s,'gemini')&&(str_contains($s,'flash')||str_contains($s,'lite')||str_contains($s,'gemma')||str_contains($s,'nano-banana')));
}
function model_label(string $id): string {
    if(strtolower($id)==='pollinations')return 'Pollinations';
    $s=preg_replace('/([A-Za-z])(\\d)/','$1 $2',$id)??$id;
    $s=str_replace(['gemini','gpt','glm','qwen','deepseek','minimax','kimi','claude','grok'],['Gemini','GPT','GLM','Qwen','DeepSeek','MiniMax','Kimi','Claude','Grok'],$s);
    return trim(ucwords(str_replace(['-','_'], ' ', $s)));
}
function model_list(array $cfg): array {
    $provider=strtolower((string)$cfg['provider']);
    if(in_array($provider,['cheatgpt','openai','chatgpt'],true)) $ids=array_values(array_unique([$cfg['cheatgpt_model']?:'gpt-5-nano','gpt-5-nano','gpt-5.4-nano']));
    elseif($provider==='pollinations')$ids=[$cfg['pollinations_model']?:'openai-fast','pollinations'];
    elseif(in_array($provider,['gemini','google'],true))$ids=['gemini-3.8-flash','gemini-3.6-flash','gemini-3.7-flash','gemini-3.5-flash','gemini-3.5-flash-lite','gemini-flash-latest','gemini-flash-lite-latest','gemini-3.1-flash-lite','gemini-3-flash-preview','gemini-3.1-pro-preview'];
    else $ids=['gemini-3.8-flash','gemini-3.6-flash','gemini-3.7-flash','gemini-3.5-flash','gemini-3.5-flash-lite','gemini-flash-latest','gemini-flash-lite-latest','gemini-3.1-flash-lite','glm-5.3-flash','deepseek-v4.1-flash','minimax-m3','qwen3.8-flash','big-pickle','glm-5.3-flash-free','deepseek-v4.1-flash-free'];
    if($cfg['enable_free_fallback'] && $provider!=='pollinations') $ids[]='pollinations';
    $models=[]; foreach(array_unique($ids) as $id) $models[]=['id'=>$id,'label'=>model_label($id),'family'=>model_family($id),'free'=>model_free($id),'recommended'=>in_array($id,['gemini-3.8-flash','gemini-3.7-flash','gpt-5-nano'],true)];
    return $models;
}
function web_search_results(string $q,int $max=5): array {
    $url='https://html.duckduckgo.com/html/?'.http_build_query(['q'=>$q]);
    try {$r=http_call($url,'GET',null,['Accept: text/html'],15);} catch(Throwable $e) {return [];}
    if($r['status']!==200) return [];
    preg_match_all('~<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>~is',$r['body'],$ms,PREG_SET_ORDER);
    $out=[];
    foreach($ms as $m) {
        $href=html_entity_decode(strip_tags($m[1]),ENT_QUOTES|ENT_HTML5,'UTF-8');
        if(str_starts_with($href,'//')) $href='https:'.$href;
        $title=trim(html_entity_decode(strip_tags($m[2]),ENT_QUOTES|ENT_HTML5,'UTF-8'));
        if(!filter_var($href,FILTER_VALIDATE_URL)||$title==='') continue;
        $out[]=['title'=>$title,'url'=>$href,'snippet'=>'']; if(count($out)>=$max) break;
    }
    return $out;
}

function is_banned(string $userId): bool {
    if(!preg_match('/^[A-Za-z0-9_-]{6,80}$/',$userId)) return false;
    $base=rtrim((string)(getenv('REBBET_FIREBASE_DB_URL')?:'https://drip-wire-36ff0-default-rtdb.firebaseio.com'),'/');
    try {$r=http_call($base.'/bans/'.rawurlencode($userId).'.json');} catch(Throwable $e) {return false;}
    if($r['status']!==200) return false;
    $v=json_decode($r['body'],true);
    if(is_array($v)) return ($v['banned']??true)!==false;
    return $v===true || $v===1 || $v==='true';
}
function rate_limited(string $bucket): int {
    $limits=['chat'=>[80,60],'search'=>[40,60],'tts'=>[60,60],'image'=>[30,60],'transcribe'=>[60,60],'upload'=>[40,60],'analyze'=>[40,60],'auth'=>[20,300]];
    if(!isset($limits[$bucket])) return 0;
    $user=(string)($_SERVER['HTTP_X_REBBET_USER']??''); $key=$bucket.':'.(preg_match('/^[A-Za-z0-9_-]{6,80}$/',$user)?$user:($_SERVER['REMOTE_ADDR']??'unknown')); $file=sys_get_temp_dir().'/rebbet-rate-'.hash('sha256',$key); $fh=@fopen($file,'c+');
    if(!$fh) return 0;
    flock($fh,LOCK_EX); $raw=stream_get_contents($fh); $events=json_decode($raw?:'[]',true); if(!is_array($events))$events=[];
    $now=time(); [$max,$window]=$limits[$bucket]; $events=array_values(array_filter($events,static fn($t)=>is_numeric($t)&&(int)$t>$now-$window));
    if(count($events)>=$max) $wait=max(1,(int)$events[0]+$window-$now); else {$events[]=$now;$wait=0;}
    rewind($fh);ftruncate($fh,0);fwrite($fh,json_encode($events));fflush($fh);flock($fh,LOCK_UN);fclose($fh);return $wait;
}
function rate_guard(string $path): void {
    if(!str_starts_with($path,'/api/')) return;
    $bucket=substr($path,5); $wait=rate_limited($bucket);
    if($wait>0) api_error(429,'rate_limited','Too many requests. Please slow down.',['retry_after'=>$wait,'hint'=>'Try again in about '.$wait.' seconds.']);
}
function store_json_upload(array $payload,string $kind='shared'): array {
    $raw=$payload['data']??'';
    if(!is_string($raw)||trim($raw)==='') throw new InvalidArgumentException('Upload data is required');
    if(str_starts_with($raw,'data:')) {[$head,$raw]=array_pad(explode(',',$raw,2),2,''); if(!str_contains(strtolower($head),'base64')) throw new InvalidArgumentException('Upload must be base64 encoded');}
    $raw=preg_replace('/\s+/','',$raw)??''; $bytes=base64_decode($raw,true);
    if($bytes===false) throw new InvalidArgumentException('Upload data is not valid base64');
    $limit=match($kind) {'update'=>200*1024*1024,'icon'=>4*1024*1024,default=>(int)(read_config()['max_upload_mb']??25)*1024*1024};
    if(strlen($bytes)>$limit) throw new LengthException($kind==='update'?'Update file must be 200 MB or smaller':($kind==='icon'?'Icon must be 4 MB or smaller':'File is larger than the upload limit'));
    return store_upload((string)($payload['name']??'file'),(string)($payload['mimeType']??$payload['mime']??''),$bytes,$kind);
}
function serve_uploaded(array $meta,bool $download=false): never {
    $path=(string)$meta['path']; $mime=(string)($meta['mimeType']??'application/octet-stream');
    if(in_array(strtolower($mime),['text/html','application/xhtml+xml','image/svg+xml','application/xml','text/xml'],true)) $mime='text/plain; charset=utf-8';
    $name=trim(preg_replace('/[^A-Za-z0-9._-]+/','_',basename((string)($meta['name']??'file'))),'._'); if($name==='') $name='file';
    header('Content-Type: '.$mime); header('Content-Length: '.filesize($path)); header('Accept-Ranges: bytes');
    header('Content-Disposition: '.($download?'attachment':'inline').'; filename="'.$name.'"'); header('Cache-Control: public, max-age=31536000, immutable'); readfile($path); exit;
}
function admin_payload(array $cfg): array {
    $keys=['host','port','provider','api_key','image_api_key','base_url','default_model','system_prompt','request_timeout','enable_web_search','auto_switch_model','enable_free_fallback','voice_speed','elevenlabs_api_key','elevenlabs_voice_id','elevenlabs_model','image_model','transcribe_model','pollinations_model','pollinations_api_key','pollinations_image_model','pollinations_image_aspect','pollinations_tts_model','pollinations_tts_voice','pollinations_transcribe_model','deepseek_api_key','deepseek_model','openrouter_api_key','openrouter_model','github_api_key','github_model','github_base_url','cheatgpt_api_key','cheatgpt_model','cheatgpt_base_url','admin_token','app_version','app_icon','update_url','update_message','update_available','force_update','max_upload_mb','public_base_url','app_link_scheme','app_package','app_download_url'];
    $out=[]; foreach($keys as $k) $out[$k]=$cfg[$k]??''; return $out;
}
function admin_settings(array $cfg): array {
    $active=(string)($cfg['app_icon']??'');$icons=[];
    foreach(load_upload_index() as $m) if(is_array($m)&&($m['kind']??'')==='icon'&&str_starts_with((string)($m['mimeType']??''),'image/')) {$item=public_meta($m);$item['active']=('/f/'.($m['id']??''))===$active;$icons[]=$item;}
    usort($icons,static fn($a,$b)=>(($b['active']??false)<=>($a['active']??false))?:((int)($b['created']??0)<=>(int)($a['created']??0)));
    return array_merge(app_config($cfg),admin_payload($cfg),['icons'=>$icons,'logo'=>'static/logo.png']);
}
function safe_editor_path(string $path): string {
    $relative=ltrim(str_replace('\\','/',$path),'/'); if($relative===''||str_contains('/'.$relative,'/../')||str_starts_with($relative,'../')) throw new InvalidArgumentException('Invalid file path');
    $skip=['.git','.gradle','.androidide','__pycache__','build','uploads','node_modules'];
    foreach(explode('/',$relative) as $part) if(in_array($part,$skip,true)) throw new InvalidArgumentException('That folder cannot be edited');
    $full=realpath(ROOT_DIR.'/'.$relative); $root=realpath(ROOT_DIR);
    if($full===false||!str_starts_with($full,$root.DIRECTORY_SEPARATOR)||!is_file($full)) throw new InvalidArgumentException('File not found');
    if(filesize($full)>2*1024*1024) throw new InvalidArgumentException('File is too large to edit');
    $ext=strtolower(pathinfo($full,PATHINFO_EXTENSION)); $allowed=['bat','cfg','css','gradle','htm','html','ini','java','js','json','md','mjs','properties','py','sh','svg','toml','txt','xml','yaml','yml'];
    if(!in_array($ext,$allowed,true) && !in_array(basename($full),['.gitignore','Dockerfile','LICENSE','Procfile','gradlew','render.yaml'],true)) throw new InvalidArgumentException('This file type cannot be edited');
    return $full;
}

function gemini_native(array $cfg,string $model,array $body,int $timeout=75): array {
    $key=$cfg['api_key']; if($key==='') throw new RuntimeException('Gemini API key is not configured');
    $base=preg_replace('~/openai$~','',(string)$cfg['base_url']);
    $url=rtrim($base,'/').'/models/'.rawurlencode($model).':generateContent?key='.rawurlencode($key);
    $r=http_call($url,'POST',$body,[],$timeout); $d=json_decode($r['body'],true);
    if($r['status']<200||$r['status']>=300) throw new RuntimeException((string)($d['error']['message']??'Gemini request failed (HTTP '.$r['status'].')'));
    if(!is_array($d)) throw new RuntimeException('Gemini returned invalid JSON'); return $d;
}
function audio_wav(string $pcm,int $rate=24000): string {
    $size=strlen($pcm); return 'RIFF'.pack('V',36+$size).'WAVEfmt '.pack('VvvVVvv',16,1,1,$rate,$rate*2,2,16).'data'.pack('V',$size).$pcm;
}
function send_binary(string $bytes,string $mime,array $headers=[]): never {
    header('Content-Type: '.$mime); header('Content-Length: '.strlen($bytes)); header('Cache-Control: no-store');
    foreach($headers as $k=>$v) header($k.': '.$v); echo $bytes; exit;
}
function tts_audio(array $cfg,array $p): never {
    $text=trim((string)($p['text']??'')); if($text==='') api_error(400,'bad_request','text is required'); $text=mb_substr($text,0,4000);
    $voice=substr(preg_replace('/[^A-Za-z0-9_-]/','',(string)($p['voice']??$cfg['elevenlabs_voice_id']))??'',0,64);
    $speed=strtolower((string)($p['speed']??$cfg['voice_speed'])); $model=(string)($p['model']??'');
    if($cfg['elevenlabs_api_key']!=='' && !str_starts_with($model,'gemini')) {
        $id=$voice?:$cfg['elevenlabs_voice_id']; $m=$model?:$cfg['elevenlabs_model'];
        $b=['text'=>$text,'model_id'=>$m,'voice_settings'=>['stability'=>0.5,'similarity_boost'=>0.75,'speed'=>$speed==='fast'?1.15:($speed==='slow'?0.85:1.0)]];
        $r=http_call('https://api.elevenlabs.io/v1/text-to-speech/'.rawurlencode($id).'?output_format=mp3_44100_128','POST',$b,['xi-api-key: '.$cfg['elevenlabs_api_key'],'Accept: audio/mpeg'],60);
        if($r['status']>=200&&$r['status']<300) send_binary($r['body'],'audio/mpeg',['X-Voice-Model'=>$m,'X-Voice-Provider'=>'elevenlabs']);
    }
    if($cfg['api_key']==='') api_error(503,'no_voice_provider','Configure an ElevenLabs or Gemini API key for server voice.');
    $model=in_array($model,['gemini-3.8-flash-tts','gemini-3.8-flash-lite-tts','gemini-3.1-flash-tts-preview','gemini-2.5-flash-preview-tts','gemini-2.5-pro-preview-tts'],true)?$model:'gemini-3.8-flash-tts';
    $voiceNames=['Kore','Puck','Charon','Fenrir','Aoede','Leda','Orus','Zephyr']; $voiceName=in_array($voice,$voiceNames,true)?$voice:'Kore';
    try {$d=gemini_native($cfg,$model,['contents'=>[['parts'=>[['text'=>$text]]]],'generationConfig'=>['responseModalities'=>['AUDIO'],'speechConfig'=>['voiceConfig'=>['prebuiltVoiceConfig'=>['voiceName'=>$voiceName]]]]],75);} catch(Throwable $e) {api_error(502,'tts_error','Voice generation failed.',['detail'=>substr($e->getMessage(),0,250)]);}
    foreach(($d['candidates']??[]) as $c) foreach(($c['content']['parts']??[]) as $part) {
        $inline=$part['inlineData']??$part['inline_data']??null;
        if(is_array($inline)&&!empty($inline['data'])) { $audio=base64_decode($inline['data'],true); if($audio===false) continue; $mime=(string)($inline['mimeType']??$inline['mime_type']??'audio/wav'); if(!str_contains(strtolower($mime),'wav')) {$rate=24000;if(preg_match('/rate=(\d+)/',$mime,$m))$rate=(int)$m[1];$audio=audio_wav($audio,$rate);$mime='audio/wav';} send_binary($audio,$mime,['X-Voice-Model'=>$model,'X-Voice-Provider'=>'gemini']); }
    }
    api_error(502,'tts_error','Gemini returned no audio.');
}
function image_bytes(array $cfg,string $prompt,int $w=768,int $h=768): array {
    $w=max(256,min(1024,$w));$h=max(256,min(1024,$h));
    $geminiImageKey=(string)($cfg['image_api_key']?:((in_array($cfg['provider'],['gemini','google'],true))?$cfg['api_key']:''));
    if($geminiImageKey!=='') {
        $model=(string)($cfg['image_model']?:'gemini-3.1-flash-image');$savedKey=$cfg['api_key'];$cfg['api_key']=$geminiImageKey;
        try {$d=gemini_native($cfg,$model,['contents'=>[['role'=>'user','parts'=>[['text'=>$prompt]]]],'generationConfig'=>['responseModalities'=>['TEXT','IMAGE']]],90);} catch(Throwable $e) {$d=[];}
        $cfg['api_key']=$savedKey;
        foreach(($d['candidates']??[]) as $c)foreach(($c['content']['parts']??[])as$part){$in=$part['inlineData']??$part['inline_data']??null;if(is_array($in)&&!empty($in['data']))return [base64_decode($in['data'],true),(string)($in['mimeType']??'image/png'),'gemini',$model];}
    }
    if(!$cfg['enable_free_fallback']) throw new RuntimeException('Image generation is not configured.');
    $lockFile=fopen(sys_get_temp_dir().'/rebbet-pollinations-image.lock','c+');$wait=0;
    if($lockFile){flock($lockFile,LOCK_EX);rewind($lockFile);$last=(int)stream_get_contents($lockFile);$wait=45-(time()-$last);if($wait>0)sleep($wait);}
    $url=POLLINATIONS_IMAGE.'/'.rawurlencode($prompt).'?'.http_build_query(['width'=>$w,'height'=>$h,'seed'=>hexdec(substr(hash('sha256',$prompt),0,8)),'nologo'=>'true']);
    try {$r=http_call($url,'GET',null,['Accept: image/*'],90);} finally {if($lockFile){rewind($lockFile);ftruncate($lockFile,0);fwrite($lockFile,(string)time());fflush($lockFile);flock($lockFile,LOCK_UN);fclose($lockFile);}}
    if($r['status']<200||$r['status']>=300) throw new RuntimeException('Pollinations image request failed (HTTP '.$r['status'].')');
    $mime=$r['headers']['content-type']??'image/jpeg';if(!str_starts_with(strtolower($mime),'image/'))throw new RuntimeException('Image provider returned non-image data.');return [$r['body'],$mime,'pollinations','sana'];
}
function transcribe_audio(array $cfg,array $p): never {
    $raw=(string)($p['audio']??''); if($raw==='') api_error(400,'bad_request','audio is required'); $audio=base64_decode($raw,true);
    if($audio===false) api_error(400,'bad_request','audio must be base64 encoded'); if(strlen($audio)>8*1024*1024) api_error(413,'too_large','Audio clip is too large.');
    if($cfg['api_key']==='') api_error(503,'no_key','A Gemini API key is required for transcription.');
    $mime=(string)($p['mimeType']??'audio/wav'); if(!str_starts_with($mime,'audio/')) $mime='audio/wav';
    $model=$cfg['transcribe_model']?:'gemini-3.5-transcribe'; $prompt=(string)($p['prompt']??'Transcribe this audio exactly. Return only the transcript without commentary.');
    try {$d=gemini_native($cfg,$model,['contents'=>[['parts'=>[['text'=>$prompt],['inlineData'=>['mimeType'=>$mime,'data'=>base64_encode($audio)]]]]]],75);} catch(Throwable $e) {api_error(502,'transcribe_error','Transcription failed.',['detail'=>substr($e->getMessage(),0,250)]);}
    $pieces=[]; foreach(($d['candidates'][0]['content']['parts']??[]) as $part) {if(is_string($part['text']??null))$pieces[]=$part['text'];$tr=$part['audioTranscription']['text']??$part['transcription']['text']??null;if(is_string($tr))$pieces[]=$tr;}
    $text=trim(implode(' ',$pieces)); if($text==='') api_error(422,'no_speech','No speech was detected in that recording.'); json_response(200,['text'=>$text,'model'=>$model]);
}
function pdf_text(string $data): array {
    $pages=preg_match_all('~/Type\\s*/Page(?![sA-Za-z])~',$data,$unused); $chunks=[];
    if(preg_match_all('~stream\\s*\\r?\\n(.*?)\\r?\\n?endstream~s',$data,$streams)) foreach($streams[1] as $raw) {
        $decoded=@gzuncompress($raw); if($decoded===false)$decoded=@gzinflate($raw);if($decoded===false)$decoded=$raw;
        if(preg_match_all('~\\((?:\\\\.|[^\\\\()])*\\)|<[0-9A-Fa-f\\s]+>~s',$decoded,$tokens)) foreach($tokens[0] as $tok) {
            if($tok[0]==='(') {$v=substr($tok,1,-1);$v=preg_replace_callback('/\\\\([nrtbf()\\\\]|[0-7]{1,3}|\\r?\\n)/',static function($m){$x=$m[1];$map=['n'=>"\n",'r'=>"\r",'t'=>"\t",'b'=>"\x08",'f'=>"\x0c",'('=>'(',')'=>')','\\'=>'\\'];if(isset($map[$x]))return $map[$x];if(preg_match('/^[0-7]{1,3}$/',$x))return chr(octdec($x)&255);return '';},$v)??$v;}
            else {$hex=preg_replace('/[^0-9A-Fa-f]/','',substr($tok,1,-1))??'';if(strlen($hex)%2)$hex.='0';$v=hex2bin($hex)?:'';}
            if(str_starts_with($v,"\xfe\xff"))$v=@iconv('UTF-16BE','UTF-8//IGNORE',substr($v,2))?:'';elseif(!mb_check_encoding($v,'UTF-8'))$v=mb_convert_encoding($v,'UTF-8','ISO-8859-1');
            $clean=preg_replace('/[^\p{L}\p{N}\p{P}\p{S}\s]/u',' ',$v)??'';$print=mb_strlen(trim($clean));if($print>=2&&$print/max(1,mb_strlen($v))>=0.55)$chunks[]=$clean;
        }
    }
    $text=trim(preg_replace('/[ \t]+/u',' ',preg_replace('/\n{3,}/','\n\n',implode(' ',$chunks))??'')??'');
    if(mb_strlen($text)<20&&preg_match_all('~\\((?:\\\\.|[^\\\\()])*\\)~s',$data,$tokens)) {$fallback=[];foreach($tokens[0]as$t){$v=stripcslashes(substr($t,1,-1));if(mb_strlen(trim($v))>1)$fallback[]=$v;}$candidate=trim(preg_replace('/\s+/u',' ',implode(' ',$fallback))??'');if(mb_strlen($candidate)>mb_strlen($text))$text=$candidate;}
    return [$text,max(1,(int)$pages)];
}
function analyze_document(array $cfg,array $p): never {
    $name=(string)($p['name']??'document');$mime=strtolower((string)($p['mimeType']??$p['mime']??''));$bytes='';
    if(!empty($p['fileId'])) {$m=upload_meta((string)$p['fileId']);if(!$m)api_error(404,'not_found','Uploaded file not found.');$bytes=(string)file_get_contents($m['path']);$name=(string)$m['name'];$mime=(string)$m['mimeType'];}
    else {$raw=(string)($p['data']??'');if(str_starts_with($raw,'data:')){$parts=explode(',',$raw,2);if(count($parts)!==2||!str_contains(strtolower($parts[0]),'base64'))api_error(400,'bad_request','Document data must be base64 encoded');$raw=$parts[1];}$bytes=base64_decode(preg_replace('/\s+/','',$raw)??'',true)?:'';}
    if($bytes==='')api_error(400,'empty_file','Document is empty.'); if(strlen($bytes)>40*1024*1024)api_error(413,'too_large','Document is too large to analyze.');
    $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));$text='';$kind='text';$pages=1;
    if($ext==='pdf'||$mime==='application/pdf') { $kind='pdf'; [$text,$pages]=pdf_text($bytes); }
    elseif(preg_match('/\.(csv|htm|html|ini|log|md|py|js|mjs|json|rst|text|txt|xml|yaml|yml)$/',$name)||str_starts_with($mime,'text/')||in_array($mime,['application/json','application/xml'],true)) { $text=mb_convert_encoding($bytes,'UTF-8','UTF-8'); }
    else api_error(415,'unsupported_document','Only PDF and text documents can be analyzed.');
    $text=trim($text); if($text==='') api_error(422,'no_text','No readable text was found in that document.');$truncated=mb_strlen($text)>180000;$text=mb_substr($text,0,180000);
    json_response(200,['ok'=>true,'name'=>$name,'kind'=>$kind,'pages'=>$pages,'chars'=>mb_strlen($text),'truncated'=>$truncated,'text'=>$text]);
}

function load_upload_index(): array {
    if(!is_file(INDEX_FILE)) return [];
    $data=json_decode((string)file_get_contents(INDEX_FILE),true);
    return is_array($data)?$data:[];
}
function save_upload_index(array $idx): void {
    if(!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR,0770,true);
    $tmp=INDEX_FILE.'.tmp';
    file_put_contents($tmp,json_encode($idx,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n",LOCK_EX);
    rename($tmp,INDEX_FILE);
}
function upload_meta(string $id): ?array {
    if(!preg_match('/^[A-Za-z0-9_-]{4,40}$/',$id)) return null;
    $meta=load_upload_index()[$id]??null;
    if(!is_array($meta)) return null;
    $stored=basename((string)($meta['stored']??''));
    if($stored==='' || !is_file(UPLOAD_DIR.'/'.$stored)) return null;
    $meta['path']=UPLOAD_DIR.'/'.$stored; return $meta;
}
function public_meta(array $m): array {
    return ['id'=>$m['id']??'','name'=>$m['name']??'file','size'=>$m['size']??0,'mimeType'=>$m['mimeType']??'application/octet-stream','kind'=>$m['kind']??'file','created'=>$m['created']??0,'url'=>'/s/'.($m['id']??''),'rawUrl'=>'/f/'.($m['id']??'')];
}
function store_upload(string $name,string $mime,string $bytes,string $kind='shared'): array {
    if(strlen($bytes)>200*1024*1024) throw new LengthException('Upload is too large');
    if(!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR,0770,true);
    $name=basename(str_replace('\\','/',$name)); $name=trim(preg_replace('/[\x00-\x1f\x7f]/u','',$name)??'file'," .\t\n\r\0\x0B");
    if($name==='') $name='file';
    $mime=preg_match('~^[a-z0-9!#$&^_.+-]+/[a-z0-9!#$&^_.+-]+$~i',$mime)?strtolower($mime):'application/octet-stream';
    $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION)); $ext=preg_match('/^[a-z0-9]{1,10}$/',$ext)?'.'.$ext:'';
    $id=rtrim(strtr(base64_encode(random_bytes(9)),'+/','-_'),'=');
    $stored=$id.$ext; file_put_contents(UPLOAD_DIR.'/'.$stored,$bytes,LOCK_EX);
    $m=['id'=>$id,'name'=>substr($name,0,120),'size'=>strlen($bytes),'mimeType'=>$mime,'kind'=>$kind,'stored'=>$stored,'created'=>time()];
    $idx=load_upload_index(); $idx[$id]=$m; save_upload_index($idx); return $m;
}

$secure=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off') || str_starts_with((string)($_SERVER['HTTP_X_FORWARDED_PROTO']??''),'https');
session_set_cookie_params(['lifetime'=>600,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);
session_start();
$cfg=read_config();
send_cors();
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://www.gstatic.com; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob: https:; media-src 'self' data: blob:; connect-src 'self' https: wss:; frame-src 'self' blob: https:; object-src 'none'; base-uri 'self'");
$method=strtoupper((string)($_SERVER['REQUEST_METHOD']??'GET'));
$uri=(string)($_SERVER['REQUEST_URI']??'/');
$path=parse_url($uri,PHP_URL_PATH)?:'/';
$query=[]; parse_str((string)(parse_url($uri,PHP_URL_QUERY)??''),$query);
if($method==='OPTIONS') { http_response_code(204); exit; }

if($method==='POST' && str_starts_with($path,'/api/')) {
    rate_guard($path);
    if(in_array($path,['/api/chat','/api/search','/api/tts','/api/image','/api/transcribe','/api/analyze','/api/upload'],true) && is_banned((string)($_SERVER['HTTP_X_REBBET_USER']??''))) api_error(403,'banned','Your access has been blocked by an administrator.');
}
if(($path==='/health'||$path==='/api/health') && $method==='GET') {
    json_response(200,['ok'=>true,'app'=>APP_NAME,'version'=>APP_VERSION,'module'=>'rebbet-ai','module_id'=>'rebbet_ai',
        'key_configured'=>(bool)($cfg['api_key']||$cfg['cheatgpt_api_key']),'default_model'=>$cfg['default_model'],
        'bind'=>$cfg['host'].':'.$cfg['port'],'provider'=>$cfg['provider'],'web_search'=>(bool)$cfg['enable_web_search'],
        'auto_switch'=>(bool)$cfg['auto_switch_model'],'free_fallback'=>(bool)$cfg['enable_free_fallback'],
        'elevenlabs_voice'=>(bool)$cfg['elevenlabs_api_key'],'image_model'=>$cfg['image_model'],
        'transcribe_model'=>$cfg['transcribe_model'],'github_models'=>(bool)$cfg['github_api_key'],
        'pollinations'=>(bool)$cfg['pollinations_api_key'],'cheatgpt'=>(bool)$cfg['cheatgpt_api_key'],
        'google_login'=>google_configured($cfg)]);
}
if($method==='GET' && $path==='/api/models') {
    $models=model_list($cfg); $source='fallback'; $provider=strtolower((string)$cfg['provider']);
    if(in_array($provider,['pollinations','openai','chatgpt','cheatgpt'],true)) $source='config';
    elseif($cfg['api_key']!=='') {
        try {
            $gemini=$provider==='gemini'||$provider==='google'||str_starts_with(strtolower((string)$cfg['base_url']),'https://generativelanguage.googleapis.com');
            $url=$gemini?'https://generativelanguage.googleapis.com/v1beta/models':rtrim((string)$cfg['base_url'],'/').'/v1/models';
            $headers=$gemini?['x-goog-api-key: '.$cfg['api_key']]:['Authorization: Bearer '.$cfg['api_key']];
            $r=http_call($url,'GET',null,$headers,30); $d=json_decode($r['body'],true); $ids=[];
            if($r['status']>=200&&$r['status']<300&&is_array($d)) foreach(($d['data']??$d['models']??[]) as $item) {
                if(!is_array($item)) continue; $id=(string)($item['id']??$item['name']??''); if(str_starts_with($id,'models/'))$id=substr($id,7);
                if($id===''||($gemini&&!preg_match('/^(gemini-|gemma-)/i',$id)))continue;
                if($gemini&&isset($item['supportedGenerationMethods'])&&!in_array('generateContent',$item['supportedGenerationMethods'],true))continue;
                if(preg_match('/embedding|tts|transcri|image|audio|video|robotics/i',$id))continue;
                $ids[]=$id;
            }
            if($ids) { $models=[]; foreach(array_unique($ids) as $id)$models[]=['id'=>$id,'label'=>model_label($id),'family'=>model_family($id),'free'=>model_free($id),'recommended'=>in_array($id,['gemini-3.8-flash','gemini-3.7-flash','gpt-5-nano'],true)]; $source='live'; }
        } catch(Throwable $e) { /* Keep the configured fallback list when model discovery is unavailable. */ }
    }
    json_response(200,['models'=>$models,'source'=>$source,'default'=>$cfg['default_model']]);
}
if($method==='POST' && $path==='/api/chat') {
    try { $payload=body_json(); } catch(Throwable $e) { api_error(400,'bad_request',$e->getMessage()); }
    chat_reply($cfg,$payload);
}
if($method==='POST' && $path==='/api/search') {
    try {$payload=body_json(65536);} catch(Throwable $e) {api_error(400,'bad_request',$e->getMessage());}
    $q=trim((string)($payload['query']??'')); if($q==='') api_error(400,'bad_request','query is required');
    json_response(200,['results'=>web_search_results($q),'query'=>$q]);
}
if($method==='GET' && $path==='/api/app-config') json_response(200,app_config($cfg));
if($method==='GET' && $path==='/api/voices') {
    $voices=[]; if($cfg['elevenlabs_api_key']!=='') {try {$r=http_call('https://api.elevenlabs.io/v1/voices','GET',null,['xi-api-key: '.$cfg['elevenlabs_api_key']],25);$d=json_decode($r['body'],true);foreach(($d['voices']??[])as$v)if(is_array($v)&&!empty($v['voice_id']))$voices[]=['id'=>$v['voice_id'],'name'=>$v['name']??$v['voice_id'],'category'=>$v['category']??'','labels'=>$v['labels']??[],'preview_url'=>$v['preview_url']??''];}catch(Throwable $e){}}
    if(!$voices)$voices=[['id'=>'21m00Tcm4TlvDq8ikWAM','name'=>'Rachel','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'AZnzlk1XvdvUeBnXmlld','name'=>'Domi','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'EXAVITQu4vr4xnSDxMaL','name'=>'Bella','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'MF3mGyEYCl7XYWbV9V6O','name'=>'Elli','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'ErXwobaYiN019PkySvjV','name'=>'Antoni','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'TxGEqnHWrfWFTfGW9XjX','name'=>'Josh','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'VR6AewLTigWG4xSOukaG','name'=>'Arnold','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'pNInz6obpgDQGcFmaJgB','name'=>'Adam','category'=>'premade','labels'=>[],'preview_url'=>''],['id'=>'yoZ06aMxZJJ28mfd3POQ','name'=>'Sam','category'=>'premade','labels'=>[],'preview_url'=>'']];
    $geminiVoice=in_array($cfg['provider'],['gemini','google'],true)&&$cfg['api_key']!=='';
    json_response(200,['voices'=>$voices,'models'=>$geminiVoice?['gemini-3.8-flash-tts','gemini-3.8-flash-lite-tts','gemini-3.1-flash-tts-preview','gemini-2.5-flash-preview-tts','gemini-2.5-pro-preview-tts']:['eleven_multilingual_v2','eleven_turbo_v2_5','eleven_flash_v2_5','eleven_multilingual_v1','eleven_monolingual_v1'],'default_voice'=>$cfg['elevenlabs_voice_id'],'default_model'=>$geminiVoice?'gemini-3.8-flash-tts':$cfg['elevenlabs_model'],'speed'=>$cfg['voice_speed'],'warning'=>'']);
}
if($method==='POST'&&in_array($path,['/api/tts','/api/image','/api/transcribe','/api/analyze'],true)) {
    try {$payload=body_json($path==='/api/transcribe'?18*1024*1024:($path==='/api/analyze'?42*1024*1024:262144));} catch(Throwable $e) {api_error(400,'bad_request',$e->getMessage());}
    if($path==='/api/tts') tts_audio($cfg,$payload);
    if($path==='/api/transcribe') transcribe_audio($cfg,$payload);
    if($path==='/api/analyze') analyze_document($cfg,$payload);
    $prompt=trim((string)($payload['prompt']??'')); if($prompt==='') api_error(400,'bad_request','prompt is required');
    try {[$bytes,$mime,$provider,$model]=image_bytes($cfg,mb_substr($prompt,0,2000),(int)($payload['width']??768),(int)($payload['height']??768));} catch(Throwable $e) {api_error(502,'image_error','Image generation failed.',['detail'=>substr($e->getMessage(),0,250)]);}
    if(!is_string($bytes)||$bytes==='')api_error(502,'image_error','Image provider returned no picture.');
    send_binary($bytes,$mime,['X-Image-Source'=>$provider,'X-Image-Model'=>$model,'X-Image-Prompt'=>rawurlencode(mb_substr($prompt,0,180))]);
}

if($method==='GET' && str_starts_with($path,'/api/file/')) {
    $m=upload_meta(substr($path,10)); if(!$m) api_error(404,'not_found','File not found'); json_response(200,public_meta($m));
}
if($method==='GET' && str_starts_with($path,'/f/')) {
    $m=upload_meta(substr($path,3)); if(!$m) api_error(404,'not_found','File not found'); serve_uploaded($m,in_array((string)($query['download']??''),['1','true'],true));
}
if($method==='GET' && str_starts_with($path,'/s/')) {
    $m=upload_meta(substr($path,3));
    if(!$m) {http_response_code(404); echo '<h1>File not found</h1>'; exit;}
    $name=htmlspecialchars((string)$m['name'],ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); $url='/f/'.rawurlencode((string)$m['id']);
    header('Content-Type: text/html; charset=utf-8'); echo '<!doctype html><meta name="viewport" content="width=device-width"><title>'.$name.' · Rebbet AI</title><main style="font:16px system-ui;max-width:700px;margin:10vh auto;padding:24px"><h1>'.$name.'</h1><p>'.number_format((int)$m['size']).' bytes</p><a href="'.$url.'?download=1">Download file</a></main>'; exit;
}
if($method==='POST' && $path==='/api/upload') {
    try {$p=body_json(40*1024*1024); $m=store_json_upload($p);} catch(Throwable $e) {api_error(400,'invalid_upload',$e->getMessage());}
    $out=public_meta($m); $origin=(string)($cfg['public_base_url']?:request_origin()); $out['url']=$origin.$out['url']; $out['rawUrl']=$origin.$out['rawUrl']; $out['shareUrl']=$out['url']; $out['downloadUrl']=$out['rawUrl']; $out['deepLink']=''; json_response(201,['ok'=>true,'file'=>$out]);
}
if($method==='GET' && $path==='/api/admin/settings') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token'); json_response(200,admin_settings($cfg));
}
if($method==='POST' && $path==='/api/admin/settings') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token');
    try {$payload=body_json(131072);} catch(Throwable $e) {api_error(400,'invalid_body',$e->getMessage());}
    $restartRequired=false;
    foreach(admin_payload($cfg) as $k=>$old) if(array_key_exists($k,$payload)) {
        $v=$payload[$k];
        if(in_array($k,['enable_web_search','auto_switch_model','enable_free_fallback','update_available','force_update'],true)) $cfg[$k]=filter_var($v,FILTER_VALIDATE_BOOLEAN);
        elseif(in_array($k,['port','request_timeout','max_upload_mb'],true)) {
            $next=max(1,min($k==='port'?65535:($k==='request_timeout'?900:200),(int)$v));
            if($k==='port' && $next!==(int)$cfg[$k]) $restartRequired=true;
            $cfg[$k]=$next;
        } elseif(is_scalar($v)) {
            $next=substr(trim((string)$v),0,20000);
            if($k==='host' && $next!==$cfg[$k]) $restartRequired=true;
            if($k==='provider' && !in_array(strtolower($next),['gemini','google','opencode','pollinations','github','deepseek','openrouter','cheatgpt','openai','chatgpt'],true)) api_error(400,'invalid_setting','Unsupported provider.');
            if($k==='voice_speed' && !in_array(strtolower($next),['fast','normal','slow'],true)) $next='fast';
            $cfg[$k]=$next;
        }
    }
    try {config_save($cfg);} catch(Throwable $e) {api_error(500,'save_failed',$e->getMessage());}
    json_response(200,['ok'=>true,'settings'=>admin_settings($cfg),'restart_required'=>$restartRequired]);
}
if($method==='POST' && in_array($path,['/api/admin/upload-icon','/api/admin/upload-update','/api/admin/set-icon','/api/admin/delete-file','/api/admin/reload-config','/api/admin/restart'],true)) {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token');
    try {$payload=body_json($path==='/api/admin/upload-update'?285*1024*1024:6*1024*1024);} catch(Throwable $e) {api_error(400,'invalid_body',$e->getMessage());}
    if($path==='/api/admin/set-icon') {
        $id=(string)($payload['id']??''); $m=upload_meta($id); if(!$m||($m['kind']??'')!=='icon')api_error(404,'not_found','Icon not found');
        $cfg['app_icon']='/f/'.$id; config_save($cfg); json_response(200,['ok'=>true,'settings'=>admin_settings($cfg)]);
    }
    if($path==='/api/admin/delete-file') {
        $id=(string)($payload['id']??''); $m=upload_meta($id); if(!$m)api_error(404,'not_found','File not found'); @unlink($m['path']);$idx=load_upload_index();unset($idx[$id]);save_upload_index($idx);$changed=false;if(($cfg['app_icon']??'')==='/f/'.$id){$cfg['app_icon']='';$changed=true;}if(($cfg['update_url']??'')==='/f/'.$id){$cfg['update_url']='';$cfg['update_available']=false;$changed=true;}if($changed)config_save($cfg);json_response(200,['ok'=>true]);
    }
    if($path==='/api/admin/reload-config') { $cfg=read_config(); json_response(200,['ok'=>true,'settings'=>admin_settings($cfg)]); }
    if($path==='/api/admin/restart') json_response(200,['ok'=>true,'message'=>'Restart the Render service to apply runtime changes.']);
    if($path==='/api/admin/upload-icon') {
        try {$m=store_json_upload($payload,'icon');}catch(Throwable $e){api_error(400,'invalid_upload',$e->getMessage());}
        $bytes=(string)file_get_contents($m['path']);$mime=(string)$m['mimeType'];
        $valid=($mime==='image/png'&&str_starts_with($bytes,"\x89PNG\r\n\x1a\n"))||($mime==='image/jpeg'&&str_starts_with($bytes,"\xff\xd8\xff"))||($mime==='image/webp'&&substr($bytes,0,4)==='RIFF'&&substr($bytes,8,4)==='WEBP')||($mime==='image/gif'&&in_array(substr($bytes,0,6),['GIF87a','GIF89a'],true));
        if(!$valid){@unlink($m['path']);$idx=load_upload_index();unset($idx[$m['id']]);save_upload_index($idx);api_error(400,'invalid_image','Use a valid PNG, JPEG, WEBP or GIF image.');}
        if(($payload['activate']??true)!==false) {$cfg['app_icon']='/f/'.$m['id'];config_save($cfg);}
        $out=public_meta($m);$out['url']=request_origin().$out['url'];$out['rawUrl']=request_origin().$out['rawUrl'];json_response(200,['ok'=>true,'settings'=>admin_settings($cfg),'file'=>$out]);
    }
    if($path==='/api/admin/upload-update') {
        try {$m=store_json_upload($payload,'update');}catch(Throwable $e){api_error(400,'invalid_upload',$e->getMessage());}
        if(!str_ends_with(strtolower((string)$m['name']),'.apk')) api_error(400,'invalid_file','Update upload must be an APK.');
        $cfg['update_url']='/f/'.$m['id'];$cfg['update_available']=true;
        if(!empty($payload['version']))$cfg['app_version']=substr((string)$payload['version'],0,40);
        if(!empty($payload['update_message']))$cfg['update_message']=substr((string)$payload['update_message'],0,600);
        config_save($cfg);$out=public_meta($m);$out['url']=request_origin().$out['url'];$out['rawUrl']=request_origin().$out['rawUrl'];json_response(200,['ok'=>true,'settings'=>admin_settings($cfg),'file'=>$out]);
    }
}

if($method==='GET' && $path==='/api/admin/files') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token'); $list=[]; foreach(load_upload_index() as $m) if(is_array($m)) $list[]=public_meta($m); usort($list,static fn($a,$b)=>($b['created']??0)<=>($a['created']??0)); json_response(200,['files'=>$list]);
}
if($method==='GET' && $path==='/api/admin/editor') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token');
    $file=(string)($query['path']??'');
    if($file==='') { $files=[]; $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator(ROOT_DIR,FilesystemIterator::SKIP_DOTS)); foreach($it as $f) if($f->isFile()&&$f->getSize()<2*1024*1024&&!str_contains($f->getPathname(),'/uploads/')) $files[]=str_replace(ROOT_DIR.'/','',$f->getPathname()); json_response(200,['files'=>$files]); }
    try {$full=safe_editor_path($file);} catch(Throwable $e) {api_error(400,'invalid_path',$e->getMessage());} json_response(200,['file'=>['path'=>$file,'content'=>(string)file_get_contents($full),'size'=>filesize($full)] ]);
}
if($method==='POST' && $path==='/api/admin/editor') {
    if(!admin_ok($cfg)) api_error(401,'unauthorized','Invalid admin token'); try {$p=body_json(2*1024*1024+8192);$full=safe_editor_path((string)($p['path']??''));} catch(Throwable $e){api_error(400,'invalid_path',$e->getMessage());}
    if(!is_string($p['content']??null)||strlen($p['content'])>2*1024*1024) api_error(400,'invalid_body','File content is invalid or too large.');
    if(file_put_contents($full,$p['content'],LOCK_EX)===false) api_error(500,'write_failed','Could not write file.');$reload=false;if(($p['path']??'')==='config.json'){$cfg=read_config();$reload=true;}json_response(200,['ok'=>true,'file'=>['path'=>$p['path'],'size'=>strlen($p['content'])],'config_reloaded'=>$reload]);
}

if($method==='GET' && ($path==='/api/module'||$path==='/api/rebbet')) {
    json_response(200,['name'=>'rebbet-ai','id'=>'rebbet_ai','display_name'=>APP_NAME,'version'=>APP_VERSION,
        'features'=>['web_search'=>true,'internet_search'=>true,'free_ai_models'=>true,'auto_switch_on_limit'=>true,'better_voice'=>true,'fast_voice'=>true,'image_generation'=>true,'free_fallback'=>(bool)$cfg['enable_free_fallback']],
        'free_models'=>[$cfg['default_model']],'auto_switch_order'=>[$cfg['default_model']],
        'free_fallback_providers'=>array_keys(array_filter(['deepseek'=>$cfg['deepseek_api_key'],'openrouter'=>$cfg['openrouter_api_key'],'github'=>$cfg['github_api_key'],'cheatgpt'=>$cfg['cheatgpt_api_key'],'pollinations'=>$cfg['enable_free_fallback']])),
        'voice_models'=>['eleven_multilingual_v2'],'image_models'=>[$cfg['image_model']]]);
}
if($method==='GET' && $path==='/auth/google') handle_google_start($cfg,$query);
if($method==='GET' && ($path==='/auth-callback.php'||$path==='/auth/callback')) handle_google_callback($cfg,$query);
if($method==='GET' && $path==='/auth/login') {
    if(!google_configured($cfg)) oauth_error('Google sign-in is not configured on this server yet.',503);
    if($cfg['auth_access_code']==='') redirect_to('/auth/google?next='.rawurlencode(safe_next((string)($query['next']??'/'))));
    auth_login_page(safe_next((string)($query['next']??'/')));
}
if($method==='POST' && $path==='/auth/login') {
    $next=safe_next((string)($_POST['next']??'/'));
    if($cfg['auth_access_code']==='' || !hash_equals((string)$cfg['auth_access_code'],(string)($_POST['code']??''))) auth_login_page($next,'Invalid access code.');
    $access=signed_cookie(['ok'=>true,'exp'=>time()+3600],$cfg);
    redirect_to('/auth/google?next='.rawurlencode($next),['rik_access'=>['value'=>$access,'expires'=>time()+3600]]);
}
if(($path==='/auth/logout'||$path==='/api/auth/logout') && in_array($method,['GET','POST'],true)) {
    $expired=['value'=>'','expires'=>time()-3600];
    if($method==='GET') redirect_to('/',[$cfg['auth_session_name']=>$expired,'rik_access'=>$expired]);
    setcookie($cfg['auth_session_name'],'',['expires'=>time()-3600,'path'=>'/','secure'=>str_starts_with(request_origin(),'https://'),'httponly'=>true,'samesite'=>'Lax']); setcookie('rik_access','',['expires'=>time()-3600,'path'=>'/','secure'=>str_starts_with(request_origin(),'https://'),'httponly'=>true,'samesite'=>'Lax']); json_response(200,['ok'=>true]);
}
if($method==='GET' && $path==='/api/auth/session') {
    $token=(string)($_COOKIE[$cfg['auth_session_name']]??'');
    $authenticated=false; $user=null;
    if($token!=='' && ($p=strrpos($token,'.'))!==false) {
        $payload=substr($token,0,$p); $sig=substr($token,$p+1);
        $secret=$cfg['auth_session_secret']?:hash('sha256','rebbet-google-auth:'.$cfg['google_client_secret']);
        if(hash_equals(hash_hmac('sha256',$payload,$secret),$sig)) {
            $decoded=json_decode(base64_decode(strtr($payload,'-_','+/')),true);
            if(is_array($decoded) && ($decoded['exp']??0)>time()) { $authenticated=true; $user=$decoded['user']??null; }
        }
    }
    json_response(200,['ok'=>true,'configured'=>google_configured($cfg),'authenticated'=>$authenticated,'access_code_required'=>$cfg['auth_access_code']!=='','user'=>$user,'login_url'=>'/auth/google']);
}
if($method==='GET' && ($path==='/'||$path==='/index.html'||$path==='/admin'||$path==='/admin/'||$path==='/admin.html'||str_starts_with($path,'/static/')||$path==='/manifest.json'||$path==='/service-worker.js'||$path==='/favicon.ico')) {
    $p=$path==='/favicon.ico'?'/static/icon-192.png':$path;
    if(serve_path($p)) exit;
}
if($method==='GET' && in_array($path,['/api/chat','/api/search','/api/tts','/api/image','/api/transcribe','/api/analyze'],true)) api_error(405,'method_not_allowed','Use POST for '.$path);
if(str_starts_with($path,'/api/')) api_error(404,'not_found','Not found',['path'=>$path]);
http_response_code(404);
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['error'=>['message'=>'Not found','path'=>$path,'hint'=>'Open / for the app or /admin.html for the admin panel.']]);
