const CACHE_NAME = 'rebbet-ai-v1.12.4-gemini-2';
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './static/style.css?v=1.12.4',
  './static/app.js?v=1.12.4',
  './static/app-status.js?v=1.12.4',
  './static/admin.css?v=1.12.4',
  './static/admin.js?v=1.12.4',
  './admin.html?v=1.12.4',
  './static/firebase.js?v=1.12.4',
  './static/logo.png?v=1.12.4',
  './static/icon-192.png?v=1.12.4',
  './static/icon-512.png?v=1.12.4'
];

self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache) {
      return Promise.allSettled(ASSETS.map(function(asset) {
        return cache.add(asset);
      }));
    }).then(function() {
      return self.skipWaiting();
    })
  );
});

self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches.keys().then(function(keys) {
      return Promise.all(keys.map(function(key) {
        if (key !== CACHE_NAME) {
          return caches.delete(key);
        }
      }));
    }).then(function() {
      return self.clients.claim();
    })
  );
});

self.addEventListener('fetch', function(event) {
  var request = event.request;
  var url = new URL(request.url);

  if (url.origin !== self.location.origin || request.method !== 'GET') {
    return;
  }

  if (url.pathname.startsWith('/api/')) {
    return;
  }

  event.respondWith(
    fetch(request, { cache: 'reload' }).then(function(response) {
      if (response && response.status === 200 && response.type === 'basic') {
        var copy = response.clone();
        caches.open(CACHE_NAME).then(function(cache) {
          cache.put(request, copy);
        });
      }
      return response;
    }).catch(function() {
      return caches.match(request).then(function(cached) {
        if (cached) return cached;
        if (request.mode === 'navigate') {
          return caches.match('./index.html').then(function(fallback) {
            return fallback || offlineResponse();
          });
        }
        return offlineResponse();
      });
    })
  );
});

function offlineResponse() {
  return new Response('Offline', {
    status: 503,
    statusText: 'Offline',
    headers: { 'Content-Type': 'text/plain; charset=utf-8' }
  });
}
