# Rebbet Admin keeps JavaScript in the WebView; no Java obfuscation rules are required.
