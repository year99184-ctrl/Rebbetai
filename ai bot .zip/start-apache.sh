#!/bin/sh
set -eu
port="${PORT:-10000}"
sed -i "s/^Listen 80$/Listen ${port}/" /etc/apache2/ports.conf
sed -i "s/<VirtualHost \*:80>/<VirtualHost *:${port}>/" /etc/apache2/sites-available/000-default.conf
cat > /usr/local/etc/php/conf.d/rebbet.ini <<EOF
memory_limit=${PHP_MEMORY_LIMIT:-512M}
post_max_size=300M
upload_max_filesize=200M
max_execution_time=300
max_input_time=300
default_socket_timeout=300
EOF
exec apache2-foreground
