#!/usr/bin/env python3
import base64
import hashlib
import hmac
import html
import io
import json
import mimetypes
import os
import queue
import re
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

APP_NAME = "Rebbet AI"
VERSION = "1.11.0"
MODULE_NAME = "rebbet-ai"
MODULE_ID = "rebbet_ai"
ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
UPLOAD_DIR = ROOT / "uploads"
UPLOAD_INDEX = UPLOAD_DIR / "index.json"
CONFIG_PATH = ROOT / "config.json"
_upload_lock = threading.Lock()
_config_write_lock = threading.Lock()
INDEX_HTML_FALLBACK = zlib.decompress(base64.b64decode("""
eNrlGu2OG7fxv5+C3f6wDXhXWt3pLDWS2vqaBgGcpMhdY+SXQO1SWvp2lwuSkk4pAuQh+gx9sDxJZ8j9IKXV+Q6unRYFrFtyODMk
Z4bzQXr2u798d33749++JJku8sWzGX5ITsvNPGBlgABG08UzQmYF05QkGZWK6Xnw99u/hpOgGyhpwebBjrN9JaQOSCJKzUpA3PNU
Z/OU7XjCQtN5RXjJNad5qBKas3n8ijR04ZrreSJ2TCKSZpImmu8M3QZmlUzxn5gKa+Yn0+uMFQxGcyGdFfx+OBnS+OIEm1ZVCDMp
LkoHO46m0egEN2UqkbzSPu73bLVimvz5a/LrL/8ka6pMG2SkyZ7rjOzZiihGZQJ7plstSCFSlhMFg0nGyw1Ay5TwopKw5ZTsBMgo
6ltnzsJCrDh8gGWIC09oRVc5cxZzYOpxpEpTvVXhikpoHjweq5wmd6GWtFT5NmlFrLnO2aLbbUhuCiqhqRQHbmW93Xew3Ruz3dnA
kiBxzss7Ilk+Dwpa8jVTYB2ZZOuuH71Xovzjbu6IviPiCYpcHyrYDi/ohg2qchMQYwigrenoHn4NR9waTwZIEwI4AtRzfK1otNgm
WWjneDILIz2VMaaPiM1AlCjlUM4G9iTNViI9GEYp35Ekp0qZxRjmAEUsJpsBLSrQUz3m09ih5TJna90iAMpqq7UoGyyzj5WG7fEU
JM7K7RvsUMlpmNMVbuO7ipXWaDPQppAHhxvwU7sNsYc4GKGgGd9k2rbx2L4R9/NgSIZkdAn/ArLmOfAsRQl2pbQUd6C3ZCslGNO1
PZgWGtY842jSgkC0DAx7HkixLdNggbJm5D6eB8D4AJ/XAbkfwdxD6I6wu5gNEOcUMx75qNA/j3vENnb4DmD7jnAHVroOxNHICs5N
6guPFxtvdLmEg3MHG5ZJay252AjPzAjNQcC1kjKepqwEdcst83kfz7xcanavPRxUX0XLIzT0DUF3nGGPgPNhMrVdBYuvWAHem9Dm
5J8SzwawMFdkTrfuPGDNEq3rseZsfeut2GzQi7k2/a71vOA70BVZkPVO5+176Nj38JPbtwt+L3jZ2X3CZZIzksDUcQz++WC/ch5M
0DTtsGPIo9haMn7RkuOr6GpcG7NpPt6eH5K3CVB94rYwG8DAN1Y5h2BkMSoI2ooB8ZrmirXa+AFR//sVUYn8sAFxVADVGG9iMiZX
ZEpG5hdjB/4AOJ7iXyPpmgioKURF2Po38TgaX5JJdHlFx8AAdxHD73U0NK4G8VzsKcDJZTS9oDEgDlv8+DKKLzuCJ+rSJB8Q3Plm
w2QdDxB020Csv6GqEtUWZJNCiiY2NZjdwzFPOz36mnOchTfLcpkK3evIevzGA1yMmTlLfmv6i7eCppBG/frLv/rY7TZnuCUZ2wWN
qcVXnalh+zc1NXOgG1tDM4uNjcUTMm0M66OOMWkaYUgTk98ZmZZsfw3x/yQzuNGY5UEyyfYmQTh/XmPnvMb/KSFOH5EYYJxHzzeu
Hd+o9nrTnnA/9lMDwDlJDR6WqxPLbDrHZB3MZlTxlDXixjambTZINR1Xstd96ZYbD2uq5dJOE/RnHC2W8arB4kexlUZT6jgKPxhG
LZfrXKgjv25Aj8wNP6/Ldk1gYvV6ZdV6VWt10mMBVx6mITxCfbQBnMi01QWcFk+u30LfYenIDBfQ+p7JZ5XZpzw239bu4tkZIfYZ
cM6V9qT2FgELX+B9hGshtH8+TCQ4m93a4TqNrcSeSZb6ON4pN+e67vRNv4KCOZWi8tb+pgEu3IR3VlDeBTho95d1UEnS1LJr2vZI
8h2oHkIA1+wBwSSiqODQnvMYzfByycvSw8I6H+oHClP2IVfbWj8N8GsLkmKPeVFAqpwmLBM5eCvIYSDpg1qdtGqAGA1mWbE8h+ib
3NVpgLkVSQRYcwJHAItwA6AV1zSHCh9TfLyaSDCdxJa8Y4eM41UFDKBFD5o1exvxT2a3jYInR5vAG4XmesFS+R7wKwZSopoRXmPa
9PUIfFw8fWq3OH16eoEiJjDvBZxe8/eMD5IGBwSLBF4lMonGthQxDYnrGLvVSJu/jiAbHufhOBy/HRNIB84krH15y1N09w0Czmvu
ewaGVV+qkcLa4/+CoroyAHI/ekEuTPo/DKG1m3R9KDyGP1y64+HFT73FBFQQuxF9TV7bOiKML8lwF4463JOogC7eDQuji56wUEdd
GKtLzlPcj9K3OeCewm8MxEtQAdLqlqRc4Z1o+nmVPHq6iru6vRZ4E1rjOrQ6MjyuQEcjW3fCF6vOC1uJAtCrPD8s+eMEsTdGoKt1
bopIAhVaQe/gPOHtzx1TEblGd4532EKam2BeroUsKN6UR313P7aJ4c9cgrbx0V2Ardfqm9W26LuxfSnQAXvFKQzTvA0prX2AKawO
LvGtzZJPorkz33FEN0Mn8fxBBpBKYLFq14l5zUrcu7WrSWx6IrfHJINqu71lOS6dz4R+n8FDdYOHaWuHIznXorrOBFYA1L5cPKWo
MARnSwr7EFLx5O44B/n/LinO6UgdX1y61xt2sH7F+K1Ki892ZWlS0TruN1e8ne3WAC8ZtUBrc6rJOYsqZxpYiPXaT0z9+63Hqad5
kHQsv3mi9Nxe3ez3elrQpgaqm9aF2Pe6h6oAZGTfJ+3DQqZ1pf4wGCRpGb1XsBq+k1HJ9KCsigE+QLC0/kRQBgGKuY8zDBZP4pWC
GLeSrw9/uoji6ApWo/TAQj7MuX7+oFUFeN1LWR++1TYIdoueyqVecwkVl2IfwaJ7E/0QE6tGviYvnkN4xBftdwKkKJ9D1CMl3fEN
1UK+JP+o7WXPy1TsI5qmX+7AGNDzY93w4nkuaPr8FVlvywQD5YuOhHR8Im+OSLIN0st27nBvB96r5y+jhOoke9EyZBKXgQ+7Cmwo
gq6QBvgF+fnlF/VcTetnY5LNFsFBmRfK2cD+l4B/AwPW6iY=
""")).decode("utf-8")
MAX_BODY = 4 * 1024 * 1024
MAX_MESSAGES = 200
MAX_MESSAGE_CHARS = 120000
UPSTREAM_USER_AGENT = "opencode/1.0"
GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai"
GEMINI_DEFAULT_MODEL = "gemini-3.6-flash"
GEMINI_DEFAULT_IMAGE = "gemini-3.1-flash-image"
CHEATGPT_BASE_URL = "https://api.openai.com/v1"
CHEATGPT_DEFAULT_MODEL = "gpt-5-nano"
CHEATGPT_PROVIDERS = ("cheatgpt", "openai", "chatgpt")
MODEL_ALIASES = {
    "gemini-2.5-flash": GEMINI_DEFAULT_MODEL,
    "models/gemini-2.5-flash": GEMINI_DEFAULT_MODEL,
}
DEFAULT_SYSTEM_PROMPT = (
    "You are Rebbet AI, a helpful, friendly assistant. Be accurate and clear.please join my telegram channel https://t.me/Panelsalllbay"
    "Use Markdown when it improves readability, and keep answers focused on what the user asked. "
    "When users ask for current information, news, weather, or anything time-sensitive, provide up-to-date information. "
    "When a message includes a [Shared file: ...] link, give the user that exact link if they ask for a file link."
)
ELEVENLABS_BASE_URL = "https://api.elevenlabs.io/v1"
ELEVENLABS_DEFAULT_VOICE = "21m00Tcm4TlvDq8ikWAM"
ELEVENLABS_DEFAULT_MODEL = "eleven_multilingual_v2"
ELEVENLABS_MODEL_IDS = [
    "eleven_multilingual_v2",
    "eleven_turbo_v2_5",
    "eleven_flash_v2_5",
    "eleven_multilingual_v1",
    "eleven_monolingual_v1",
]
ELEVENLABS_FALLBACK_VOICES = [
    {"id": "21m00Tcm4TlvDq8ikWAM", "name": "Rachel", "category": "premade", "labels": {"accent": "american", "gender": "female"}, "preview_url": ""},
    {"id": "AZnzlk1XvdvUeBnXmlld", "name": "Domi", "category": "premade", "labels": {"accent": "american", "gender": "female"}, "preview_url": ""},
    {"id": "EXAVITQu4vr4xnSDxMaL", "name": "Bella", "category": "premade", "labels": {"accent": "american", "gender": "female"}, "preview_url": ""},
    {"id": "MF3mGyEYCl7XYWbV9V6O", "name": "Elli", "category": "premade", "labels": {"accent": "american", "gender": "female"}, "preview_url": ""},
    {"id": "ErXwobaYiN019PkySvjV", "name": "Antoni", "category": "premade", "labels": {"accent": "american", "gender": "male"}, "preview_url": ""},
    {"id": "TxGEqnHWrfWFTfGW9XjX", "name": "Josh", "category": "premade", "labels": {"accent": "american", "gender": "male"}, "preview_url": ""},
    {"id": "VR6AewLTigWG4xSOukaG", "name": "Arnold", "category": "premade", "labels": {"accent": "american", "gender": "male"}, "preview_url": ""},
    {"id": "pNInz6obpgDQGcFmaJgB", "name": "Adam", "category": "premade", "labels": {"accent": "american", "gender": "male"}, "preview_url": ""},
    {"id": "yoZ06aMxZJJ28mfd3POQ", "name": "Sam", "category": "premade", "labels": {"accent": "american", "gender": "male"}, "preview_url": ""},
]
IMAGE_MODEL = os.environ.get("REBBET_IMAGE_MODEL", GEMINI_DEFAULT_IMAGE)
TRANSCRIBE_MODEL = os.environ.get("REBBET_TRANSCRIBE_MODEL", "gemini-3.5-transcribe")
MAX_TTS_CHARS = 4000
MAX_AUDIO_BYTES = 8 * 1024 * 1024
MAX_IMAGE_CHARS = 2000
MAX_ANALYZE_BYTES = 40 * 1024 * 1024
MAX_ANALYZE_TEXT = 180000
MAX_MEMORY_ITEMS = 40
MAX_MEMORY_CHARS = 500
TEXT_ATTACHMENT_EXTENSIONS = (
    ".csv",
    ".htm",
    ".html",
    ".ini",
    ".log",
    ".md",
    ".py",
    ".js",
    ".mjs",
    ".json",
    ".rst",
    ".text",
    ".txt",
    ".xml",
    ".yaml",
    ".yml",
)
RATE_LIMITS = {
    "chat": (80, 60),
    "search": (40, 60),
    "tts": (60, 60),
    "image": (30, 60),
    "transcribe": (60, 60),
    "upload": (40, 60),
    "analyze": (40, 60),
}
_rate_events = {}
_rate_lock = threading.Lock()
POLLINATIONS_TEXT_URL = "https://text.pollinations.ai/openai"
POLLINATIONS_IMAGE_URL = "https://image.pollinations.ai/prompt"
DEEPSEEK_BASE_URL = "https://api.deepseek.com"
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
GITHUB_MODELS_BASE_URL = "https://models.github.ai/inference"
GITHUB_MODELS_API_VERSION = "2026-03-10"

DEFAULT_CONFIG = {
    "host": "127.0.0.1",
    "port": 8765,
    "provider": "gemini",
    "api_key": "",
    "image_api_key": "",
    "base_url": GEMINI_BASE_URL,
    "default_model": GEMINI_DEFAULT_MODEL,
    "system_prompt": DEFAULT_SYSTEM_PROMPT,
    "request_timeout": 300,
    "enable_web_search": True,
    "auto_switch_model": True,
    "enable_free_fallback": True,
    "voice_speed": "fast",
    "elevenlabs_api_key": "",
    "elevenlabs_voice_id": ELEVENLABS_DEFAULT_VOICE,
    "elevenlabs_model": ELEVENLABS_DEFAULT_MODEL,
    "image_model": GEMINI_DEFAULT_IMAGE,
    "transcribe_model": TRANSCRIBE_MODEL,
    "pollinations_model": "openai-fast",
    "deepseek_api_key": "",
    "deepseek_model": "deepseek-chat",
    "openrouter_api_key": "",
    "openrouter_model": "deepseek/deepseek-chat-v3-0324:free",
    "github_api_key": "",
    "github_model": "openai/gpt-4.1",
    "github_base_url": GITHUB_MODELS_BASE_URL,
    "cheatgpt_api_key": "",
    "cheatgpt_model": CHEATGPT_DEFAULT_MODEL,
    "cheatgpt_base_url": CHEATGPT_BASE_URL,
    "admin_token": "",
    "app_version": VERSION,
    "app_icon": "",
    "update_url": "",
    "update_message": "",
    "update_available": False,
    "force_update": False,
    "max_upload_mb": 25,
    "public_base_url": "",
    "app_link_scheme": "rebbetai",
    "app_package": "com.rabbet.ai",
    "app_download_url": "",
}

BRANDS = {
    "glm": "GLM",
    "gpt": "GPT",
    "claude": "Claude",
    "gemini": "Gemini",
    "qwen": "Qwen",
    "deepseek": "DeepSeek",
    "minimax": "MiniMax",
    "kimi": "Kimi",
    "grok": "Grok",
    "muse": "Muse",
    "nemotron": "Nemotron",
    "mimo": "MiMo",
    "flint": "Flint",
    "beam": "Beam",
    "mistral": "Mistral",
    "jev": "Jev",
    "big": "Big",
    "pickle": "Pickle",
}

SHORT_WORDS = {"vl": "VL", "ai": "AI", "api": "API"}

RECOMMENDED_ORDER = [
    "gemini-3.8-flash",
    "gemini-3.7-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.5-flash",
    "gemini-3.6-flash",
    "gemini-flash-latest",
    "gemini-flash-lite-latest",
    "glm-5.3-flash",
    "deepseek-v4.1-flash",
    "minimax-m3",
    "qwen3.8-flash",
    "big-pickle",
    "kimi-k3",
    "claude-sonnet-5-5",
    "claude-haiku-5-5",
    "gpt-6-luna",
    "grok-4.5",
]

AUTO_SWITCH_ORDER = [
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "gemini-3.7-flash",
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-flash-latest",
    "gemini-flash-lite-latest",
    "gemini-3.1-flash-lite",
    "glm-5.3-flash",
    "deepseek-v4.1-flash",
    "minimax-m3",
    "qwen3.8-flash",
    "big-pickle",
]

FREE_MODELS = [
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "gemini-3.7-flash",
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-flash-latest",
    "gemini-flash-lite-latest",
    "gemini-3.1-flash-lite",
    "glm-5.3-flash",
    "deepseek-v4.1-flash",
    "minimax-m3",
    "qwen3.8-flash",
    "big-pickle",
]

FALLBACK_MODEL_IDS = [
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "gemini-3.7-flash",
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-flash-latest",
    "gemini-flash-lite-latest",
    "gemini-3.1-flash-lite",
    "glm-5.3-flash",
    "deepseek-v4.1-flash",
    "minimax-m3",
    "qwen3.8-flash",
    "big-pickle",
    "glm-5.3-flash-free",
    "deepseek-v4.1-flash-free",
]

GEMINI_FALLBACK_MODEL_IDS = [
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "gemini-3.7-flash",
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-flash-latest",
    "gemini-flash-lite-latest",
    "gemini-3.1-flash-lite",
    "gemini-3-flash-preview",
    "gemini-3.1-pro-preview",
]

TRANSCRIBE_MODEL_IDS = [
    TRANSCRIBE_MODEL,
    "gemini-3.6-flash",
    "gemini-3.5-flash",
    "gemini-3.1-flash-lite",
]

GEMINI_IMAGE_MODEL_IDS = [
    GEMINI_DEFAULT_IMAGE,
    "gemini-2.5-flash-image",
    "gemini-3.1-flash-image-preview",
    "gemini-3.1-flash-lite-image",
    "gemini-3-pro-image",
    "gemini-nano-banana-2.1",
]

NON_CHAT_MODEL_PARTS = (
    "tts",
    "image",
    "embedding",
    "embed",
    "live",
    "transcribe",
    "computer-use",
    "robotics",
    "lyria",
    "aqa",
    "nano-banana",
)

MODELS_CACHE_SECONDS = 1800
MODEL_COOLDOWN_SECONDS = 120
QUOTA_COOLDOWN_SECONDS = 300
PROVIDER_COOLDOWN_SECONDS = 35
IMAGE_QUOTA_COOLDOWN_SECONDS = 3600
POLLINATIONS_MIN_INTERVAL_SECONDS = 45
POLLINATIONS_MAX_WAIT_SECONDS = 55
_models_cache = {"at": 0.0, "models": None, "source": "fallback"}
_models_lock = threading.Lock()
_model_cooldowns = {}
_cooldown_lock = threading.Lock()
_pollinations_lock = threading.Lock()
_pollinations_last_at = 0.0
FIREBASE_DB_URL = os.environ.get(
    "REBBET_FIREBASE_DB_URL",
    "https://drip-wire-36ff0-default-rtdb.firebaseio.com"
)
BAN_CACHE_SECONDS = 15
_ban_cache = {}
_ban_cache_lock = threading.Lock()


def normalize_model(model):
    name = str(model or "").strip()
    if name.lower().startswith("models/"):
        name = name[len("models/"):]
    return MODEL_ALIASES.get(name.lower(), name)


def sanitize_app_scheme(value):
    scheme = re.sub(r"[^a-z0-9+.-]", "", str(value or "").strip().lower())[:32]
    if not scheme or not re.fullmatch(r"[a-z][a-z0-9+.-]*", scheme):
        return "rebbetai"
    return scheme


class UpstreamStreamError(Exception):
    def __init__(self, info):
        super().__init__(info.get("message", "Upstream error"))
        self.info = info


def load_config():
    config = dict(DEFAULT_CONFIG)
    if CONFIG_PATH.exists():
        try:
            saved = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                for key in DEFAULT_CONFIG:
                    if key in saved:
                        config[key] = saved[key]
        except (OSError, ValueError) as exc:
            print(f"Could not read config.json: {exc}", file=sys.stderr)

    if os.environ.get("OPENCODE_API_KEY"):
        config["api_key"] = os.environ["OPENCODE_API_KEY"]
    if os.environ.get("GEMINI_API_KEY"):
        config["api_key"] = os.environ["GEMINI_API_KEY"]
        config["provider"] = "gemini"
        config["base_url"] = GEMINI_BASE_URL
    if os.environ.get("REBBET_IMAGE_API_KEY"):
        config["image_api_key"] = os.environ["REBBET_IMAGE_API_KEY"]
    elif os.environ.get("GEMINI_IMAGE_API_KEY"):
        config["image_api_key"] = os.environ["GEMINI_IMAGE_API_KEY"]
    if os.environ.get("OPENCODE_BASE_URL"):
        config["base_url"] = os.environ["OPENCODE_BASE_URL"]
    if os.environ.get("REBBET_BASE_URL"):
        config["base_url"] = os.environ["REBBET_BASE_URL"]
    if os.environ.get("REBBET_HOST"):
        config["host"] = os.environ["REBBET_HOST"]
    if os.environ.get("PORT"):
        config["port"] = os.environ["PORT"]
        if not os.environ.get("REBBET_HOST"):
            config["host"] = "0.0.0.0"
    if os.environ.get("REBBET_PORT"):
        config["port"] = os.environ["REBBET_PORT"]
    if os.environ.get("REBBET_DEFAULT_MODEL"):
        config["default_model"] = os.environ["REBBET_DEFAULT_MODEL"]
    if os.environ.get("REBBET_AUTO_SWITCH"):
        config["auto_switch_model"] = os.environ["REBBET_AUTO_SWITCH"].lower() in ("1", "true", "yes")
    if os.environ.get("REBBET_ENABLE_SEARCH"):
        config["enable_web_search"] = os.environ["REBBET_ENABLE_SEARCH"].lower() in ("1", "true", "yes")
    if os.environ.get("REBBET_FREE_FALLBACK"):
        config["enable_free_fallback"] = os.environ["REBBET_FREE_FALLBACK"].lower() in ("1", "true", "yes")
    if os.environ.get("REBBET_VOICE_MODEL"):
        config["elevenlabs_model"] = os.environ["REBBET_VOICE_MODEL"]
    if os.environ.get("REBBET_TTS_MODEL"):
        config["elevenlabs_model"] = os.environ["REBBET_TTS_MODEL"]
    if os.environ.get("ELEVENLABS_API_KEY"):
        config["elevenlabs_api_key"] = os.environ["ELEVENLABS_API_KEY"]
    if os.environ.get("ELEVENLABS_VOICE_ID"):
        config["elevenlabs_voice_id"] = os.environ["ELEVENLABS_VOICE_ID"]
    if os.environ.get("ELEVENLABS_MODEL"):
        config["elevenlabs_model"] = os.environ["ELEVENLABS_MODEL"]
    if os.environ.get("REBBET_IMAGE_MODEL"):
        config["image_model"] = os.environ["REBBET_IMAGE_MODEL"]
    if os.environ.get("REBBET_TRANSCRIBE_MODEL"):
        config["transcribe_model"] = os.environ["REBBET_TRANSCRIBE_MODEL"]
    if os.environ.get("DEEPSEEK_API_KEY"):
        config["deepseek_api_key"] = os.environ["DEEPSEEK_API_KEY"]
    if os.environ.get("OPENROUTER_API_KEY"):
        config["openrouter_api_key"] = os.environ["OPENROUTER_API_KEY"]
    github_token = os.environ.get("GITHUB_MODELS_TOKEN") or os.environ.get("GITHUB_TOKEN")
    if github_token:
        config["github_api_key"] = github_token
    if os.environ.get("GITHUB_MODELS_MODEL"):
        config["github_model"] = os.environ["GITHUB_MODELS_MODEL"]
    if os.environ.get("GITHUB_MODELS_BASE_URL"):
        config["github_base_url"] = os.environ["GITHUB_MODELS_BASE_URL"]
    cheatgpt_key = os.environ.get("CHEATGPT_API_KEY") or os.environ.get("OPENAI_API_KEY")
    if cheatgpt_key:
        config["cheatgpt_api_key"] = cheatgpt_key
    cheatgpt_model = os.environ.get("CHEATGPT_MODEL") or os.environ.get("OPENAI_MODEL")
    if cheatgpt_model:
        config["cheatgpt_model"] = cheatgpt_model
    cheatgpt_base = os.environ.get("CHEATGPT_BASE_URL") or os.environ.get("OPENAI_BASE_URL")
    if cheatgpt_base:
        config["cheatgpt_base_url"] = cheatgpt_base
    admin_token_env = os.environ.get("REBBET_ADMIN_TOKEN") or os.environ.get("ADMIN_TOKEN")
    if admin_token_env:
        config["admin_token"] = admin_token_env

    config["host"] = str(config.get("host") or "127.0.0.1").strip()
    config["port"] = int(config.get("port") or 8765)
    config["provider"] = str(config.get("provider") or "gemini").strip().lower()
    config["api_key"] = str(config.get("api_key") or "").strip()
    config["image_api_key"] = str(config.get("image_api_key") or "").strip()
    config["base_url"] = str(config.get("base_url") or DEFAULT_CONFIG["base_url"]).rstrip("/")
    config["default_model"] = normalize_model(config.get("default_model") or DEFAULT_CONFIG["default_model"])
    config["system_prompt"] = str(config.get("system_prompt") or DEFAULT_SYSTEM_PROMPT).strip()[:20000]
    config["request_timeout"] = max(30, int(config.get("request_timeout") or 300))
    config["enable_web_search"] = bool(config.get("enable_web_search", True))
    config["auto_switch_model"] = bool(config.get("auto_switch_model", True))
    config["enable_free_fallback"] = bool(config.get("enable_free_fallback", True))
    config["voice_speed"] = str(config.get("voice_speed") or "fast")
    config["elevenlabs_api_key"] = str(config.get("elevenlabs_api_key") or "").strip()
    config["elevenlabs_voice_id"] = str(config.get("elevenlabs_voice_id") or ELEVENLABS_DEFAULT_VOICE).strip()
    config["elevenlabs_model"] = str(config.get("elevenlabs_model") or ELEVENLABS_DEFAULT_MODEL).strip()
    config["image_model"] = str(config.get("image_model") or GEMINI_DEFAULT_IMAGE)
    config["transcribe_model"] = str(config.get("transcribe_model") or TRANSCRIBE_MODEL)
    config["pollinations_model"] = str(config.get("pollinations_model") or "openai-fast")
    config["deepseek_api_key"] = str(config.get("deepseek_api_key") or "").strip()
    config["deepseek_model"] = str(config.get("deepseek_model") or "deepseek-chat")
    config["openrouter_api_key"] = str(config.get("openrouter_api_key") or "").strip()
    config["openrouter_model"] = str(config.get("openrouter_model") or "deepseek/deepseek-chat-v3-0324:free")
    config["github_api_key"] = str(config.get("github_api_key") or "").strip()
    config["github_model"] = str(config.get("github_model") or "openai/gpt-4.1")
    config["github_base_url"] = str(config.get("github_base_url") or GITHUB_MODELS_BASE_URL).rstrip("/")
    config["cheatgpt_api_key"] = str(config.get("cheatgpt_api_key") or "").strip()
    config["cheatgpt_model"] = str(config.get("cheatgpt_model") or CHEATGPT_DEFAULT_MODEL).strip()
    config["cheatgpt_base_url"] = str(config.get("cheatgpt_base_url") or CHEATGPT_BASE_URL).rstrip("/")
    config["admin_token"] = str(config.get("admin_token") or "").strip()
    config["app_version"] = str(config.get("app_version") or VERSION).strip() or VERSION
    config["app_icon"] = str(config.get("app_icon") or "").strip()
    config["update_url"] = str(config.get("update_url") or "").strip()
    config["update_message"] = str(config.get("update_message") or "").strip()
    config["update_available"] = bool(config.get("update_available", False))
    config["force_update"] = bool(config.get("force_update", False))
    try:
        config["max_upload_mb"] = max(1, min(200, int(config.get("max_upload_mb") or 25)))
    except (TypeError, ValueError):
        config["max_upload_mb"] = 25
    config["public_base_url"] = str(config.get("public_base_url") or "").strip().rstrip("/")
    config["app_link_scheme"] = sanitize_app_scheme(config.get("app_link_scheme"))
    config["app_package"] = str(config.get("app_package") or "").strip()
    config["app_download_url"] = str(config.get("app_download_url") or "").strip()

    if config["provider"] in ("gemini", "google") and config["default_model"] == DEFAULT_CONFIG["default_model"]:
        config["default_model"] = GEMINI_DEFAULT_MODEL
    if config["provider"] in CHEATGPT_PROVIDERS and config["default_model"].lower().startswith("gemini"):
        config["default_model"] = config["cheatgpt_model"]

    if config["api_key"].startswith(("AIza", "AQ.")) and "opencode.ai" in config["base_url"]:
        config["provider"] = "gemini"
        config["base_url"] = GEMINI_BASE_URL
        if config["default_model"] == DEFAULT_CONFIG["default_model"]:
            config["default_model"] = GEMINI_DEFAULT_MODEL
    return config


def is_gemini_api(config):
    provider = str(config.get("provider") or "").strip().lower()
    base_url = str(config.get("base_url") or "").lower()
    api_key = str(config.get("api_key") or "").strip()
    if provider in CHEATGPT_PROVIDERS or provider in ("deepseek", "github", "openrouter", "pollinations"):
        return False
    return (
        provider in ("gemini", "google")
        or "generativelanguage.googleapis.com" in base_url
        or api_key.startswith(("AIza", "AQ."))
    )


def gemini_models_url(config):
    base_url = str(config.get("base_url") or GEMINI_BASE_URL).rstrip("/")
    if base_url.endswith("/openai"):
        base_url = base_url[: -len("/openai")]
    return f"{base_url}/models"


def gemini_api_root(config):
    base_url = str(config.get("base_url") or GEMINI_BASE_URL).rstrip("/")
    if base_url.endswith("/openai"):
        base_url = base_url[: -len("/openai")]
    return base_url


def gemini_native_request(config, model, body, timeout=120, api_key=None):
    url = f"{gemini_api_root(config)}/models/{urllib.parse.quote(model, safe='')}:generateContent"
    request = urllib.request.Request(
        url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers={
            "x-goog-api-key": api_key or config["api_key"],
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": UPSTREAM_USER_AGENT,
        },
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.load(response)


def elevenlabs_tts(config, text, voice_id=None, speed="normal", timeout=60, model_id=None):
    api_key = str(config.get("elevenlabs_api_key") or "").strip()
    if not api_key:
        raise ValueError("Missing ElevenLabs API key")
    voice_id = voice_id or config.get("elevenlabs_voice_id") or ELEVENLABS_DEFAULT_VOICE
    voice_id = re.sub(r"[^A-Za-z0-9_-]", "", str(voice_id))[:64] or ELEVENLABS_DEFAULT_VOICE
    model_id = model_id or config.get("elevenlabs_model") or ELEVENLABS_DEFAULT_MODEL
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", str(model_id)):
        model_id = ELEVENLABS_DEFAULT_MODEL
    speed_value = {"fast": 1.15, "quick": 1.15, "slow": 0.85}.get(str(speed).lower(), 1.0)
    body = {
        "text": text,
        "model_id": model_id,
        "voice_settings": {
            "stability": 0.5,
            "similarity_boost": 0.75,
            "speed": speed_value,
        },
    }
    url = f"{ELEVENLABS_BASE_URL}/text-to-speech/{urllib.parse.quote(voice_id, safe='')}?output_format=mp3_44100_128"
    request = urllib.request.Request(
        url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers={
            "xi-api-key": api_key,
            "Content-Type": "application/json",
            "Accept": "audio/mpeg",
            "User-Agent": UPSTREAM_USER_AGENT,
        },
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read(), "audio/mpeg"


def elevenlabs_voices(config, timeout=30):
    api_key = str(config.get("elevenlabs_api_key") or "").strip()
    if not api_key:
        raise ValueError("Missing ElevenLabs API key")
    request = urllib.request.Request(
        f"{ELEVENLABS_BASE_URL}/voices",
        method="GET",
        headers={
            "xi-api-key": api_key,
            "Accept": "application/json",
            "User-Agent": UPSTREAM_USER_AGENT,
        },
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        data = json.load(response)
    voices = []
    for item in data.get("voices") or []:
        if not isinstance(item, dict):
            continue
        voice_id = str(item.get("voice_id") or "").strip()
        if not voice_id:
            continue
        labels = item.get("labels") if isinstance(item.get("labels"), dict) else {}
        voices.append(
            {
                "id": voice_id,
                "name": str(item.get("name") or voice_id),
                "category": str(item.get("category") or ""),
                "labels": {str(key): str(value) for key, value in labels.items() if value},
                "preview_url": str(item.get("preview_url") or ""),
            }
        )
    voices.sort(key=lambda voice: (voice["category"] != "premade", voice["name"].lower()))
    return voices


def clean_html_text(value):
    text = re.sub(r"<[^>]+>", " ", value or "")
    return re.sub(r"\s+", " ", html.unescape(text)).strip()


def decode_search_link(link):
    link = html.unescape((link or "").strip())
    if link.startswith("//"):
        link = "https:" + link
    if "duckduckgo.com/l/" in link:
        parsed = urllib.parse.urlsplit(link)
        target = urllib.parse.parse_qs(parsed.query).get("uddg")
        if target:
            link = target[0]
    return link


def web_search(query, max_results=5):
    try:
        max_results = max(1, min(10, int(max_results)))
    except (TypeError, ValueError):
        max_results = 5
    encoded_query = urllib.parse.quote_plus(query)
    urls = [
        f"https://html.duckduckgo.com/html/?q={encoded_query}",
        f"https://lite.duckduckgo.com/lite/?q={encoded_query}",
    ]
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }
    results = []
    seen = set()
    for url in urls:
        try:
            request = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(request, timeout=12) as response:
                page = response.read().decode("utf-8", errors="ignore")
        except (urllib.error.URLError, urllib.error.HTTPError, OSError, TimeoutError):
            continue
        blocks = re.split(r'<div class="result\b', page)
        if len(blocks) < 2:
            blocks = re.split(r"<tr\b", page)
        for block in blocks[1:]:
            link_match = re.search(r'class="result__a"[^>]*href="([^"]+)"', block)
            if not link_match:
                link_match = re.search(r'<a[^>]+href="([^"]+)"[^>]*class="result-link"', block)
            if not link_match:
                continue
            link = decode_search_link(link_match.group(1))
            title_match = re.search(r'class="result__a"[^>]*>(.*?)</a>', block, re.S)
            if not title_match:
                title_match = re.search(r'class="result-link"[^>]*>(.*?)</a>', block, re.S)
            title = clean_html_text(title_match.group(1)) if title_match else ""
            snippet_match = re.search(r'class="result__snippet"[^>]*>(.*?)</a>', block, re.S)
            if not snippet_match:
                snippet_match = re.search(r'class="result-snippet"[^>]*>(.*?)</td>', block, re.S)
            snippet = clean_html_text(snippet_match.group(1)) if snippet_match else ""
            if not title or not link or link in seen:
                continue
            if not link.startswith(("http://", "https://")):
                continue
            seen.add(link)
            results.append({"title": title, "link": link, "snippet": snippet})
            if len(results) >= max_results:
                return results
        if results:
            break
    if results:
        return results
    try:
        url = "https://api.duckduckgo.com/?format=json&no_html=1&skip_disambig=1&q=" + encoded_query
        request = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(request, timeout=10) as response:
            payload = json.load(response)
        abstract = payload.get("AbstractText") or ""
        if abstract:
            results.append(
                {
                    "title": payload.get("Heading") or query,
                    "link": payload.get("AbstractURL") or f"https://duckduckgo.com/?q={encoded_query}",
                    "snippet": abstract,
                }
            )
        for topic in payload.get("RelatedTopics") or []:
            if len(results) >= max_results:
                break
            if not isinstance(topic, dict) or not topic.get("Text"):
                continue
            results.append(
                {
                    "title": topic.get("Text", "")[:120],
                    "link": topic.get("FirstURL") or f"https://duckduckgo.com/?q={encoded_query}",
                    "snippet": topic.get("Text", ""),
                }
            )
    except (urllib.error.URLError, urllib.error.HTTPError, ValueError, OSError, TimeoutError):
        pass
    return results[:max_results]


def get_web_search_context(query):
    results = web_search(query)
    if not results:
        return ""
    context = "\n\n[Web Search Results - use these and cite the links]\n"
    for i, result in enumerate(results, 1):
        context += f"{i}. {result['title']}\n   {result['link']}\n   {result['snippet']}\n\n"
    context += "Base time-sensitive answers on the results above. Include source links when useful."
    return context


def model_family(model):
    name = model.lower().strip()
    if name.startswith("opencode/"):
        name = name.split("/", 1)[1]
    if name.startswith("gemini"):
        return "google"
    if name.startswith(("claude", "qwen")):
        return "anthropic"
    if name.startswith(("gpt", "grok", "muse", "o1", "o3", "o4")):
        return "responses"
    if name.startswith("jev"):
        return "systemone"
    return "openai"


def is_free_model(model):
    name = model.lower()
    if name.endswith("-free") or name == "big-pickle":
        return True
    if name.startswith("gpt") and "-nano" in name:
        return True
    if name.startswith("gemini"):
        return any(part in name for part in ("flash", "lite", "gemma", "nano-banana"))
    return False


def is_chat_model(model):
    name = str(model or "").lower()
    if not name or name == "test":
        return False
    if model_family(name) == "systemone":
        return False
    return not any(part in name for part in NON_CHAT_MODEL_PARTS)


def mark_model_cooldown(key, seconds):
    with _cooldown_lock:
        _model_cooldowns[key] = time.time() + max(5, int(seconds))


def model_cooldown_left(key):
    now = time.time()
    with _cooldown_lock:
        until = _model_cooldowns.get(key, 0)
        if until <= now:
            _model_cooldowns.pop(key, None)
            return 0
        return int(until - now)


def cooldown_seconds_for_error(info):
    code = (info or {}).get("code")
    if code == "insufficient_funds":
        return QUOTA_COOLDOWN_SECONDS
    if code in ("free_limit", "rate_limited", "model_disabled", "upstream_unavailable"):
        return MODEL_COOLDOWN_SECONDS
    return 60


def model_label(model):
    text = model
    lowered = text.lower()
    for brand, label in sorted(BRANDS.items(), key=lambda item: len(item[0]), reverse=True):
        if lowered.startswith(brand):
            text = label + text[len(brand):]
            break
    text = re.sub(r"([A-Za-z])(\d)", r"\1 \2", text)
    parts = re.split(r"[-_]", text)
    words = []
    for part in parts:
        if not part:
            continue
        low = part.lower()
        if low in SHORT_WORDS:
            words.append(SHORT_WORDS[low])
        elif low == "free":
            words.append("Free")
        elif part.isupper() and len(part) <= 4:
            words.append(part)
        elif any(ch.isdigit() for ch in part):
            words.append(part)
        else:
            words.append(part[:1].upper() + part[1:])
    return " ".join(words) or model


def normalize_models(model_ids):
    seen = set()
    models = []
    for model_id in model_ids:
        if not isinstance(model_id, str):
            continue
        model_id = model_id.strip()
        if not model_id or model_id in seen:
            continue
        seen.add(model_id)
        family = model_family(model_id)
        if family == "systemone" or model_id == "test":
            continue
        models.append(
            {
                "id": model_id,
                "label": model_label(model_id),
                "family": family,
                "free": is_free_model(model_id),
                "recommended": model_id in RECOMMENDED_ORDER,
            }
        )

    def sort_key(item):
        try:
            rank = RECOMMENDED_ORDER.index(item["id"])
        except ValueError:
            rank = len(RECOMMENDED_ORDER)
        return (rank, item["free"], item["label"].lower())

    models.sort(key=sort_key)
    return models


def fetch_models(config, force=False):
    now = time.time()
    provider = str(config.get("provider") or "").strip().lower()
    if provider in CHEATGPT_PROVIDERS:
        models = normalize_models([config.get("cheatgpt_model") or CHEATGPT_DEFAULT_MODEL])
        with _models_lock:
            _models_cache.update({"at": now, "models": models, "source": "config"})
        return models, "config"

    with _models_lock:
        cached = _models_cache["models"]
        if not force and cached is not None and now - _models_cache["at"] < MODELS_CACHE_SECONDS:
            return cached, _models_cache["source"]

    key = config.get("api_key")
    gemini = is_gemini_api(config)
    if key:
        try:
            if gemini:
                url = gemini_models_url(config)
                headers = {
                    "x-goog-api-key": key,
                    "Accept": "application/json",
                    "User-Agent": UPSTREAM_USER_AGENT,
                }
            else:
                url = f"{config['base_url']}/v1/models"
                headers = {
                    "Authorization": f"Bearer {key}",
                    "Accept": "application/json",
                    "User-Agent": UPSTREAM_USER_AGENT,
                }
            request = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(request, timeout=30) as response:
                payload = json.load(response)
            items = payload.get("data") or payload.get("models") or []
            ids = []
            for item in items:
                if not isinstance(item, dict):
                    continue
                model_id = item.get("id") or item.get("name") or ""
                if not isinstance(model_id, str):
                    continue
                if model_id.startswith("models/"):
                    model_id = model_id.split("/", 1)[1]
                methods = item.get("supportedGenerationMethods")
                if gemini and methods and "generateContent" not in methods:
                    continue
                if gemini and not model_id.startswith(("gemini-", "gemma-")):
                    continue
                if gemini and any(part in model_id.lower() for part in NON_CHAT_MODEL_PARTS):
                    continue
                ids.append(model_id)
            models = normalize_models(ids)
            if models:
                with _models_lock:
                    _models_cache.update({"at": now, "models": models, "source": "live"})
                return models, "live"
        except (urllib.error.URLError, urllib.error.HTTPError, ValueError, OSError, TimeoutError) as exc:
            print(f"Model list request failed: {exc}", file=sys.stderr)

    fallback = GEMINI_FALLBACK_MODEL_IDS if gemini else FALLBACK_MODEL_IDS
    models = normalize_models(fallback)
    with _models_lock:
        _models_cache.update({"at": now, "models": models, "source": "fallback"})
    return models, "fallback"


def gemini_usage_from_metadata(metadata):
    if not isinstance(metadata, dict):
        return None
    return {
        "prompt_tokens": metadata.get("promptTokenCount"),
        "completion_tokens": metadata.get("candidatesTokenCount"),
        "total_tokens": metadata.get("totalTokenCount"),
        "cost": metadata.get("cost"),
    }


def gemini_generate_text(config, model, messages, system, temperature, max_tokens, timeout=None):
    contents = []
    for message in messages:
        role = "model" if message["role"] == "assistant" else "user"
        contents.append({"role": role, "parts": [{"text": message["content"]}]})
    body = {"contents": contents}
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    generation = {}
    if temperature is not None:
        generation["temperature"] = temperature
    if max_tokens:
        generation["maxOutputTokens"] = max_tokens
    if generation:
        body["generationConfig"] = generation
    effective_timeout = timeout or min(int(config.get("request_timeout") or 300), 40)
    result = gemini_native_request(config, model, body, timeout=effective_timeout)
    candidates = result.get("candidates") or []
    text_parts = []
    for candidate in candidates:
        content = candidate.get("content") or {}
        for part in content.get("parts") or []:
            if not isinstance(part, dict) or part.get("thought"):
                continue
            text = part.get("text")
            if isinstance(text, str) and text:
                text_parts.append(text)
    text = "".join(text_parts).strip()
    usage = gemini_usage_from_metadata(result.get("usageMetadata"))
    if not text:
        finish = ""
        if candidates and isinstance(candidates[0], dict):
            finish = candidates[0].get("finishReason") or ""
        feedback = result.get("promptFeedback") or {}
        blocked = feedback.get("blockReason") or ""
        if blocked or finish in ("SAFETY", "PROHIBITED_CONTENT", "BLOCKLIST"):
            raise UpstreamStreamError(
                {
                    "code": "blocked",
                    "message": "The model blocked that request.",
                    "hint": "Try rephrasing your message.",
                }
            )
        raise UpstreamStreamError(
            {
                "code": "empty_response",
                "message": "The model returned an empty response.",
                "hint": "Try again or choose a different model.",
                "detail": finish[:120],
            }
        )
    return text, usage


def gemini_chat_candidates(config, requested):
    ordered = [requested]
    with _models_lock:
        cached = list(_models_cache.get("models") or [])
    for model_id in [config.get("default_model")] + GEMINI_FALLBACK_MODEL_IDS:
        if model_id and model_id not in ordered and is_chat_model(model_id):
            ordered.append(model_id)
    for item in cached:
        model_id = item.get("id")
        if model_id and model_id not in ordered and is_chat_model(model_id):
            ordered.append(model_id)
    candidates = [("gemini", model_id) for model_id in ordered]
    if config.get("enable_free_fallback", True):
        if config.get("deepseek_api_key"):
            candidates.append(("deepseek", config.get("deepseek_model") or "deepseek-chat"))
        if config.get("github_api_key"):
            candidates.append(("github", config.get("github_model") or "openai/gpt-4.1"))
        if config.get("openrouter_api_key"):
            candidates.append(("openrouter", config.get("openrouter_model") or "deepseek/deepseek-chat-v3-0324:free"))
        candidates.append(("pollinations", config.get("pollinations_model") or "openai-fast"))
    return candidates


def provider_label(provider):
    return {
        "github": "GitHub Models",
        "deepseek": "DeepSeek",
        "openrouter": "OpenRouter",
        "pollinations": "Pollinations",
        "cheatgpt": "CheatGPT",
        "openai": "OpenAI",
        "chatgpt": "ChatGPT",
    }.get(provider, provider.title())


def provider_failure_info(provider, status, body):
    label = provider_label(provider)
    raw = extract_error_message(status, body)
    low = f"{raw} {body or ''}".lower()
    if provider in CHEATGPT_PROVIDERS and ("no credits" in low or "insufficient" in low):
        return {
            "code": "insufficient_funds",
            "message": f"{label} has no credits.",
            "hint": "Add credits to the OpenAI billing page, or switch to another provider.",
            "url": "https://platform.openai.com/settings/organization/billing/",
            "detail": raw[:400],
        }
    if status in (402, 429) or "free limit" in low or "quota" in low or "rate limit" in low:
        return {
            "code": "free_limit",
            "message": f"{label} free limit reached.",
            "hint": "Switching to the next available model.",
            "detail": raw[:400],
        }
    if status in (401, 403):
        return {
            "code": "unauthorized",
            "message": f"{label} rejected the API key.",
            "hint": "Check the provider key in config.json or remove it.",
            "detail": raw[:400],
        }
    return {
        "code": "upstream_error",
        "message": raw[:400] or f"{label} returned HTTP {status}.",
        "hint": "Trying another model.",
        "detail": raw[:400],
    }


def provider_chat(config, provider, model, messages, system, temperature, max_tokens):
    upstream_messages = []
    if system:
        upstream_messages.append({"role": "system", "content": system})
    upstream_messages.extend(messages)
    body = {"model": model, "messages": upstream_messages, "stream": False}
    if temperature is not None:
        body["temperature"] = temperature
    if max_tokens:
        body["max_tokens"] = max_tokens
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "RebbetAI/1.11.0",
    }
    if provider == "pollinations":
        url = POLLINATIONS_TEXT_URL
        body["referrer"] = "rebbet-ai"
    elif provider == "github":
        url = f"{config.get('github_base_url') or GITHUB_MODELS_BASE_URL}/chat/completions"
        headers["Authorization"] = f"Bearer {config.get('github_api_key', '')}"
        headers["Accept"] = "application/vnd.github+json"
        headers["X-GitHub-Api-Version"] = GITHUB_MODELS_API_VERSION
    elif provider == "deepseek":
        url = f"{DEEPSEEK_BASE_URL}/chat/completions"
        headers["Authorization"] = f"Bearer {config.get('deepseek_api_key', '')}"
    elif provider == "openrouter":
        url = f"{OPENROUTER_BASE_URL}/chat/completions"
        headers["Authorization"] = f"Bearer {config.get('openrouter_api_key', '')}"
        headers["HTTP-Referer"] = "https://rebbet.ai"
        headers["X-Title"] = "Rebbet AI"
    elif provider in CHEATGPT_PROVIDERS:
        url = f"{config.get('cheatgpt_base_url') or CHEATGPT_BASE_URL}/chat/completions"
        headers["Authorization"] = f"Bearer {config.get('cheatgpt_api_key', '')}"
        if max_tokens:
            body.pop("max_tokens", None)
            body["max_completion_tokens"] = max_tokens
        if str(model).lower().startswith(("o1", "o3", "o4", "gpt-5")):
            body.pop("temperature", None)
    else:
        raise ValueError("Unsupported provider")
    request = urllib.request.Request(
        url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers=headers,
    )
    try:
        with urllib.request.urlopen(request, timeout=min(int(config.get("request_timeout") or 300), 45)) as response:
            try:
                payload = json.load(response)
            except ValueError as exc:
                raise UpstreamStreamError(
                    {
                        "code": "empty_response",
                        "message": f"{provider_label(provider)} returned an invalid response.",
                        "hint": "Trying another model.",
                        "detail": str(exc)[:200],
                    }
                )
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read(16384).decode("utf-8", "replace")
        except OSError:
            pass
        raise UpstreamStreamError(provider_failure_info(provider, exc.code, detail))
    choices = payload.get("choices") or []
    text = ""
    if choices:
        message = choices[0].get("message") or {}
        content = message.get("content")
        if isinstance(content, str):
            text = content
        elif isinstance(content, list):
            text = "".join(
                part.get("text", "") for part in content if isinstance(part, dict) and isinstance(part.get("text"), str)
            )
        if not text and isinstance(choices[0].get("text"), str):
            text = choices[0]["text"]
    text = text.strip()
    if not text:
        raise UpstreamStreamError(
            {
                "code": "empty_response",
                "message": f"{provider_label(provider)} returned an empty response.",
                "hint": "Trying another model.",
            }
        )
    return text, payload.get("usage")


def open_provider_stream(config, provider, model, messages, system, temperature, max_tokens):
    upstream_messages = []
    if system:
        upstream_messages.append({"role": "system", "content": system})
    upstream_messages.extend(messages)
    body = {"model": model, "messages": upstream_messages, "stream": True}
    if temperature is not None:
        body["temperature"] = temperature
    if max_tokens:
        body["max_tokens"] = max_tokens
    headers = {
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
        "User-Agent": "RebbetAI/1.11.0",
    }
    if provider == "pollinations":
        url = POLLINATIONS_TEXT_URL
        body["referrer"] = "rebbet-ai"
    elif provider == "github":
        url = f"{config.get('github_base_url') or GITHUB_MODELS_BASE_URL}/chat/completions"
        headers["Authorization"] = f"Bearer {config.get('github_api_key', '')}"
        headers["Accept"] = "application/vnd.github+json"
        headers["X-GitHub-Api-Version"] = GITHUB_MODELS_API_VERSION
    elif provider == "deepseek":
        url = f"{DEEPSEEK_BASE_URL}/chat/completions"
        headers["Authorization"] = f"Bearer {config.get('deepseek_api_key', '')}"
    elif provider == "openrouter":
        url = f"{OPENROUTER_BASE_URL}/chat/completions"
        headers["Authorization"] = f"Bearer {config.get('openrouter_api_key', '')}"
        headers["HTTP-Referer"] = "https://rebbet.ai"
        headers["X-Title"] = "Rebbet AI"
    elif provider in CHEATGPT_PROVIDERS:
        url = f"{config.get('cheatgpt_base_url') or CHEATGPT_BASE_URL}/chat/completions"
        headers["Authorization"] = f"Bearer {config.get('cheatgpt_api_key', '')}"
        if max_tokens:
            body.pop("max_tokens", None)
            body["max_completion_tokens"] = max_tokens
        if str(model).lower().startswith(("o1", "o3", "o4", "gpt-5")):
            body.pop("temperature", None)
    else:
        raise ValueError("Unsupported provider")
    request = urllib.request.Request(
        url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers=headers,
    )
    try:
        response = urllib.request.urlopen(request, timeout=min(int(config.get("request_timeout") or 300), 45))
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read(16384).decode("utf-8", "replace")
        except OSError:
            pass
        raise UpstreamStreamError(provider_failure_info(provider, exc.code, detail))
    return response


def consume_provider_stream(response, on_delta):
    usage = None
    text_parts = []
    buffer = ""
    try:
        while True:
            raw = response.readline()
            if not raw:
                break
            line = raw.decode("utf-8", "replace").strip()
            if not line:
                continue
            if not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                payload = json.loads(data)
            except ValueError:
                continue
            if payload.get("usage"):
                usage = payload.get("usage")
            choices = payload.get("choices") or []
            if not choices:
                continue
            choice = choices[0] or {}
            delta = choice.get("delta") or {}
            piece = delta.get("content")
            if isinstance(piece, list):
                piece = "".join(
                    part.get("text", "") for part in piece if isinstance(part, dict) and isinstance(part.get("text"), str)
                )
            if not isinstance(piece, str):
                piece = choice.get("text") if isinstance(choice.get("text"), str) else ""
            if not piece:
                continue
            text_parts.append(piece)
            buffer += piece
            if len(buffer) >= 24:
                on_delta(buffer)
                buffer = ""
    finally:
        try:
            response.close()
        except OSError:
            pass
    if buffer:
        on_delta(buffer)
    text = "".join(text_parts).strip()
    if not text:
        raise UpstreamStreamError(
            {
                "code": "empty_response",
                "message": "The model returned an empty response.",
                "hint": "Try again or choose a different model.",
            }
        )
    return text, usage


def gemini_image_bytes(config, model, prompt, timeout=90, api_key=None):
    body = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"responseModalities": ["TEXT", "IMAGE"]},
    }
    result = gemini_native_request(config, model, body, timeout=timeout, api_key=api_key)
    text_parts = []
    for candidate in result.get("candidates") or []:
        content = candidate.get("content") or {}
        for part in content.get("parts") or []:
            if not isinstance(part, dict):
                continue
            inline = part.get("inlineData") or part.get("inline_data")
            if isinstance(inline, dict) and isinstance(inline.get("data"), str):
                data = base64.b64decode(inline["data"])
                mime = inline.get("mimeType") or inline.get("mime_type") or "image/png"
                if data:
                    return data, mime, ""
            text = part.get("text")
            if isinstance(text, str) and text:
                text_parts.append(text)
    return None, "", " ".join(text_parts)[:400]


def looks_like_image(data, mime=""):
    if not data:
        return False
    mime = (mime or "").lower()
    return (
        mime.startswith("image/")
        or data[:3] == b"\xff\xd8\xff"
        or data[:8] == b"\x89PNG\r\n\x1a\n"
        or data[:4] == b"RIFF"
        or data[:6] in (b"GIF87a", b"GIF89a")
        or data[:4] == b"WEBP"
    )


def pollinations_retry_after(body):
    match = re.search(r"retry after\s+(\d+)\s*s", body or "", re.IGNORECASE)
    if match:
        return max(1, min(120, int(match.group(1))))
    return None


def pollinations_image(prompt, width=768, height=768):
    seed = int(hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:8], 16)
    query = urllib.parse.urlencode(
        {
            "width": max(256, min(1024, int(width))),
            "height": max(256, min(1024, int(height))),
            "seed": seed,
            "nologo": "true",
        }
    )
    url = f"{POLLINATIONS_IMAGE_URL}/{urllib.parse.quote(prompt, safe='')}?{query}"
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36",
            "Accept": "image/*",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=75) as response:
            data = response.read()
            mime = response.headers.get("Content-Type") or "image/jpeg"
    except urllib.error.HTTPError as exc:
        data = exc.read()
        mime = (exc.headers.get("Content-Type") if exc.headers else "") or ""
        if looks_like_image(data, mime):
            return data, mime or "image/jpeg"
        raise urllib.error.HTTPError(exc.url, exc.code, exc.reason, exc.headers, io.BytesIO(data))
    if not looks_like_image(data, mime):
        raise OSError(f"Free image provider returned {mime or 'unknown content'} instead of an image")
    return data, mime


def pollinations_image_throttled(prompt, width=768, height=768):
    global _pollinations_last_at
    with _pollinations_lock:
        wait = POLLINATIONS_MIN_INTERVAL_SECONDS - (time.time() - _pollinations_last_at) + 1
        if wait > 0:
            time.sleep(min(wait, POLLINATIONS_MAX_WAIT_SECONDS))
        try:
            data, mime = pollinations_image(prompt, width=width, height=height)
            _pollinations_last_at = time.time()
            return data, mime
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                detail = exc.read(8192).decode("utf-8", "replace")
            except OSError:
                pass
            retry_after = pollinations_retry_after(detail)
            if exc.code == 402 and retry_after:
                time.sleep(min(retry_after + 1, POLLINATIONS_MAX_WAIT_SECONDS))
                data, mime = pollinations_image(prompt, width=width, height=height)
                _pollinations_last_at = time.time()
                return data, mime
            raise urllib.error.HTTPError(exc.url, exc.code, exc.reason, exc.headers, io.BytesIO(detail.encode("utf-8")))


def extract_error_message(status, body):
    text = (body or "").strip()
    message = ""
    try:
        payload = json.loads(text)
        if isinstance(payload, dict):
            error = payload.get("error")
            if isinstance(error, dict):
                message = error.get("message") or ""
            elif isinstance(error, str):
                message = error
            if not message:
                detail = payload.get("detail")
                if isinstance(detail, dict):
                    message = detail.get("message") or ""
                elif isinstance(detail, str):
                    message = detail
            if not message:
                message = payload.get("message") or ""
    except ValueError:
        pass
    if not isinstance(message, str):
        message = ""
    if not message:
        message = text[:600]
    return message or f"Upstream returned HTTP {status}."


def describe_upstream_error(status, body):
    raw = extract_error_message(status, body)
    low = f"{raw} {body or ''}".lower()

    if status == 402 or "insufficient account funds" in low or "insufficient" in low and "fund" in low:
        return {
            "code": "insufficient_funds",
            "message": "This OpenCode Console account does not have enough credits for that request.",
            "hint": "Add credits in the OpenCode Console, then try again. Free models only work inside the official OpenCode app.",
            "url": "https://opencode.ai/console",
            "detail": raw[:500],
        }
    if "free usage limit" in low or ("free" in low and status == 429):
        return {
            "code": "free_limit",
            "message": "The free-model limit has been reached for this account.",
            "hint": "Free models are restricted to the official OpenCode app. Add credits or use OpenCode Go, then choose a paid model here.",
            "url": "https://opencode.ai/console",
            "detail": raw[:500],
        }
    if "model access is disabled" in low or "model access disabled" in low:
        return {
            "code": "model_disabled",
            "message": "That model is disabled for this workspace or API key.",
            "hint": "Choose another model, or enable it for the workspace in the OpenCode Console.",
            "url": "https://opencode.ai/console",
            "detail": raw[:500],
        }
    if status == 401 or "invalid api key" in low or "unauthorized" in low:
        return {
            "code": "unauthorized",
            "message": "The OpenCode API key was rejected.",
            "hint": "Check the api_key value in config.json, or create a new key in the Console.",
            "url": "https://opencode.ai/console",
            "detail": raw[:500],
        }
    if status == 403 and "1010" in low:
        return {
            "code": "blocked",
            "message": "The upstream gateway blocked the request.",
            "hint": "Try again in a moment. If it keeps happening, check your network or proxy.",
            "detail": raw[:500],
        }
    if status == 429:
        return {
            "code": "rate_limited",
            "message": "OpenCode is rate limiting requests right now.",
            "hint": "Wait a few seconds and try again.",
            "detail": raw[:500],
        }
    if status >= 500:
        return {
            "code": "upstream_unavailable",
            "message": "The model provider is temporarily unavailable.",
            "hint": "Try again, or choose a different model.",
            "detail": raw[:500],
        }
    return {
        "code": "upstream_error",
        "message": raw[:500] or f"OpenCode returned HTTP {status}.",
        "hint": "Try again or choose a different model.",
        "detail": raw[:500],
    }


def build_upstream_request(config, model, family, messages, system, temperature, max_tokens, direct_gemini=False):
    base = config["base_url"]
    body = None
    url = None

    if direct_gemini:
        url = f"{base}/chat/completions"
        upstream_messages = []
        if system:
            upstream_messages.append({"role": "system", "content": system})
        upstream_messages.extend(messages)
        body = {
            "model": model,
            "messages": upstream_messages,
            "stream": False,
        }
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens:
            body["max_tokens"] = max_tokens

    elif family == "openai":
        url = f"{base}/openai/v1/chat/completions"
        upstream_messages = []
        if system:
            upstream_messages.append({"role": "system", "content": system})
        upstream_messages.extend(messages)
        body = {
            "model": model,
            "messages": upstream_messages,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens:
            body["max_tokens"] = max_tokens

    elif family == "responses":
        url = f"{base}/openai/v1/responses"
        body = {"model": model, "input": messages, "stream": True}
        if system:
            body["instructions"] = system
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens:
            body["max_output_tokens"] = max_tokens

    elif family == "anthropic":
        url = f"{base}/anthropic/v1/messages"
        body = {
            "model": model,
            "max_tokens": max_tokens or 4096,
            "messages": messages,
            "stream": True,
        }
        if system:
            body["system"] = system
        if temperature is not None:
            body["temperature"] = temperature

    elif family == "google":
        encoded_model = urllib.parse.quote(model, safe="")
        url = f"{base}/google/v1beta/models/{encoded_model}:streamGenerateContent?alt=sse"
        contents = []
        for message in messages:
            role = "model" if message["role"] == "assistant" else "user"
            contents.append({"role": role, "parts": [{"text": message["content"]}]})
        body = {"contents": contents}
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}
        generation = {}
        if temperature is not None:
            generation["temperature"] = temperature
        if max_tokens:
            generation["maxOutputTokens"] = max_tokens
        if generation:
            body["generationConfig"] = generation

    if body is None:
        raise ValueError("Unsupported model family")

    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    if direct_gemini:
        headers = {
            "Authorization": f"Bearer {config['api_key']}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "User-Agent": UPSTREAM_USER_AGENT,
        }
    else:
        headers = {
            "Authorization": f"Bearer {config['api_key']}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "User-Agent": UPSTREAM_USER_AGENT,
        }
    request = urllib.request.Request(
        url,
        data=data,
        method="POST",
        headers=headers,
    )
    return request


def normalize_user_id(value):
    user_id = str(value or "").strip()
    if re.fullmatch(r"[A-Za-z0-9_-]{6,80}", user_id):
        return user_id
    return ""


def is_user_banned(user_id):
    user_id = normalize_user_id(user_id)
    if not user_id:
        return False
    now = time.time()
    with _ban_cache_lock:
        cached = _ban_cache.get(user_id)
        if cached and now - cached[0] < BAN_CACHE_SECONDS:
            return cached[1]
    banned = False
    try:
        url = (
            FIREBASE_DB_URL.rstrip("/")
            + "/bans/"
            + urllib.parse.quote(user_id, safe="")
            + ".json"
        )
        request = urllib.request.Request(
            url,
            headers={"User-Agent": f"RebbetAI/{VERSION}"}
        )
        with urllib.request.urlopen(request, timeout=3) as response:
            raw = response.read().decode("utf-8", "replace")
        data = json.loads(raw) if raw.strip() else None
        if isinstance(data, dict):
            banned = data.get("banned", True) is not False
        else:
            banned = bool(data)
    except Exception:
        banned = False
    with _ban_cache_lock:
        _ban_cache[user_id] = (now, banned)
    return banned


def save_config(config):
    payload = dict(config)
    with _config_write_lock:
        try:
            CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
            tmp = CONFIG_PATH.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            os.replace(tmp, CONFIG_PATH)
        except OSError as exc:
            print(f"Could not save config.json: {exc}", file=sys.stderr)


def _read_upload_index():
    try:
        data = json.loads(UPLOAD_INDEX.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _write_upload_index(index):
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    tmp = UPLOAD_INDEX.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(index, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, UPLOAD_INDEX)


def sanitize_upload_name(name, fallback="file"):
    value = os.path.basename(str(name or "").replace("\\", "/")).strip()
    value = re.sub(r"[\x00-\x1f\x7f]", "", value)
    value = re.sub(r"\s+", " ", value).strip(". ")
    if not value:
        value = fallback
    return value[:120]


def store_upload(original_name, mime_type, data, kind="file"):
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    name = sanitize_upload_name(original_name)
    mime = str(mime_type or "").strip().lower()[:120] or "application/octet-stream"
    suffix = Path(name).suffix.lower()
    if not re.fullmatch(r"\.[a-z0-9]{1,10}", suffix or ""):
        suffix = mimetypes.guess_extension(mime) or ""
        if suffix == ".jpe":
            suffix = ".jpg"
    file_id = base64.urlsafe_b64encode(os.urandom(9)).decode("ascii").rstrip("=")
    stored_name = file_id + suffix
    path = UPLOAD_DIR / stored_name
    path.write_bytes(data)
    meta = {
        "id": file_id,
        "name": name,
        "size": len(data),
        "mimeType": mime,
        "kind": kind,
        "stored": stored_name,
        "created": int(time.time()),
    }
    with _upload_lock:
        index = _read_upload_index()
        index[file_id] = meta
        try:
            _write_upload_index(index)
        except OSError as exc:
            print(f"Could not save upload index: {exc}", file=sys.stderr)
    return meta


def get_upload(file_id):
    if not re.fullmatch(r"[A-Za-z0-9_-]{4,40}", str(file_id or "")):
        return None
    with _upload_lock:
        index = _read_upload_index()
    meta = index.get(file_id)
    if not isinstance(meta, dict):
        return None
    stored = sanitize_upload_name(meta.get("stored"), "")
    if not stored:
        return None
    path = UPLOAD_DIR / stored
    try:
        path.resolve().relative_to(UPLOAD_DIR.resolve())
    except (ValueError, OSError):
        return None
    if not path.is_file():
        return None
    meta = dict(meta)
    meta["path"] = path
    return meta


def delete_upload(file_id):
    meta = get_upload(file_id)
    if not meta:
        return False
    try:
        meta["path"].unlink()
    except OSError:
        pass
    with _upload_lock:
        index = _read_upload_index()
        index.pop(file_id, None)
        try:
            _write_upload_index(index)
        except OSError:
            pass
    return True


def public_upload_meta(meta):
    return {
        "id": meta.get("id"),
        "name": meta.get("name"),
        "size": meta.get("size"),
        "mimeType": meta.get("mimeType"),
        "kind": meta.get("kind") or "file",
        "created": meta.get("created"),
        "url": "/s/" + str(meta.get("id")),
        "rawUrl": "/f/" + str(meta.get("id")),
    }


def app_config_payload(config):
    return {
        "app": APP_NAME,
        "version": config.get("app_version") or VERSION,
        "built_version": VERSION,
        "icon": config.get("app_icon") or "",
        "update_url": config.get("update_url") or "",
        "update_message": config.get("update_message") or "",
        "update_available": bool(config.get("update_available")),
        "force_update": bool(config.get("force_update")),
        "max_upload_mb": config.get("max_upload_mb") or 25,
        "app_link_scheme": config.get("app_link_scheme") or "rebbetai",
        "app_package": config.get("app_package") or "",
        "app_download_url": config.get("app_download_url") or "",
        "public_base_url": config.get("public_base_url") or "",
    }


ADMIN_TEXT_FIELDS = {
    "host": 120,
    "provider": 40,
    "api_key": 1000,
    "image_api_key": 1000,
    "base_url": 500,
    "default_model": 120,
    "system_prompt": 20000,
    "voice_speed": 20,
    "elevenlabs_api_key": 500,
    "elevenlabs_voice_id": 120,
    "elevenlabs_model": 120,
    "image_model": 120,
    "transcribe_model": 120,
    "pollinations_model": 120,
    "deepseek_api_key": 1000,
    "deepseek_model": 120,
    "openrouter_api_key": 1000,
    "openrouter_model": 160,
    "github_api_key": 1000,
    "github_model": 160,
    "github_base_url": 500,
    "cheatgpt_api_key": 1000,
    "cheatgpt_model": 160,
    "cheatgpt_base_url": 500,
    "app_version": 40,
    "update_url": 2000,
    "update_message": 600,
    "admin_token": 200,
    "public_base_url": 500,
    "app_link_scheme": 40,
    "app_package": 120,
    "app_download_url": 2000,
}
ADMIN_BOOL_FIELDS = (
    "enable_web_search",
    "auto_switch_model",
    "enable_free_fallback",
    "update_available",
    "force_update",
)
ADMIN_INT_FIELDS = {
    "port": (1, 65535),
    "request_timeout": (30, 900),
    "max_upload_mb": (1, 200),
}
ADMIN_URL_FIELDS = (
    "base_url",
    "github_base_url",
    "cheatgpt_base_url",
    "update_url",
    "app_download_url",
    "public_base_url",
)
ADMIN_PATH_URL_FIELDS = ("update_url", "app_download_url")
ADMIN_LOGO_PATH = "static/logo.png"

EDITOR_MAX_BYTES = 2 * 1024 * 1024
EDITOR_SKIP_DIRS = {
    ".git",
    ".gradle",
    ".androidide",
    ".idea",
    "__pycache__",
    "build",
    "node_modules",
    "uploads",
}
EDITOR_TEXT_EXTENSIONS = {
    ".bat",
    ".cfg",
    ".css",
    ".env",
    ".gradle",
    ".htm",
    ".html",
    ".ini",
    ".java",
    ".js",
    ".json",
    ".md",
    ".mjs",
    ".properties",
    ".py",
    ".sh",
    ".svg",
    ".toml",
    ".txt",
    ".xml",
    ".yaml",
    ".yml",
}
EDITOR_TEXT_NAMES = {
    ".gitignore",
    ".env",
    "Dockerfile",
    "LICENSE",
    "Procfile",
    "gradlew",
    "render.yaml",
}


def editor_resolve(value):
    raw = str(value or "").replace("\\", "/").strip()
    if not raw:
        raise ValueError("File path is required")
    relative = raw.lstrip("/")
    if relative == ".." or relative.startswith("../") or "/../" in relative:
        raise ValueError("Invalid file path")
    root = ROOT.resolve()
    target = (root / relative).resolve()
    try:
        target.relative_to(root)
    except (ValueError, OSError):
        raise ValueError("Invalid file path")
    parts = target.relative_to(root).parts
    if any(part in EDITOR_SKIP_DIRS for part in parts[:-1]):
        raise ValueError("That folder cannot be edited")
    if not target.is_file():
        raise ValueError("File not found")
    return target, str(target.relative_to(root)).replace(os.sep, "/")


def editor_is_text(path):
    if path.name in EDITOR_TEXT_NAMES:
        return True
    return path.suffix.lower() in EDITOR_TEXT_EXTENSIONS


def editor_list_files():
    root = ROOT.resolve()
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in EDITOR_SKIP_DIRS)
        for name in filenames:
            path = Path(dirpath) / name
            if not editor_is_text(path):
                continue
            try:
                size = path.stat().st_size
                relative = path.relative_to(root)
            except (OSError, ValueError):
                continue
            if size > EDITOR_MAX_BYTES:
                continue
            files.append(str(relative).replace(os.sep, "/"))
    files.sort(key=lambda item: (item.count("/"), item.lower()))
    return files


def editor_read(value):
    target, relative = editor_resolve(value)
    if not editor_is_text(target):
        raise ValueError("Not an editable text file")
    size = target.stat().st_size
    if size > EDITOR_MAX_BYTES:
        raise ValueError("File is too large to edit")
    content = target.read_text(encoding="utf-8")
    return {
        "path": relative,
        "content": content,
        "size": size,
        "modified": int(target.stat().st_mtime),
        "editable": True,
    }


def editor_write(value, content):
    target, relative = editor_resolve(value)
    if not editor_is_text(target):
        raise ValueError("Not an editable text file")
    text = "" if content is None else str(content)
    if len(text.encode("utf-8")) > EDITOR_MAX_BYTES:
        raise ValueError("File is too large")
    temporary = target.with_name(target.name + ".tmp")
    temporary.write_text(text, encoding="utf-8")
    os.replace(temporary, target)
    stat = target.stat()
    return {"path": relative, "size": stat.st_size, "modified": int(stat.st_mtime)}


def reload_saved_config(config):
    fresh = load_config()
    config.clear()
    config.update(fresh)
    return config


def truthy(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return str(value or "").strip().lower() in ("1", "true", "yes", "on")


def sanitize_memory(value):
    if not isinstance(value, list):
        return []
    items = []
    seen = set()
    for entry in value:
        if isinstance(entry, str):
            text = entry
        elif isinstance(entry, dict):
            text = entry.get("text") or entry.get("value") or ""
        else:
            continue
        text = re.sub(r"\s+", " ", str(text or "")).strip()[:MAX_MEMORY_CHARS]
        if not text or text.lower() in seen:
            continue
        seen.add(text.lower())
        items.append(text)
        if len(items) >= MAX_MEMORY_ITEMS:
            break
    return items


def system_with_memory(system, memory):
    items = sanitize_memory(memory)
    if not items:
        return system, 0
    block = (
        "\n\n[Long-term user memory - silently use these preferences and facts when relevant. "
        "Do not dump this list back to the user.]\n- "
        + "\n- ".join(items)
    )
    return (system + block)[:24000], len(items)


def rate_limit_key(self, bucket):
    user = normalize_user_id(self.headers.get("X-Rebbet-User", ""))
    ip = self.client_address[0] if self.client_address else "unknown"
    return f"{bucket}:{user or ip}"


def check_rate_limit(self, bucket):
    limit, window = RATE_LIMITS.get(bucket, (60, 60))
    key = rate_limit_key(self, bucket)
    now = time.time()
    with _rate_lock:
        events = [stamp for stamp in _rate_events.get(key, []) if now - stamp < window]
        if len(events) >= limit:
            retry = max(1, int(window - (now - events[0])))
            _rate_events[key] = events
            return retry
        events.append(now)
        _rate_events[key] = events
    if len(_rate_events) > 4000:
        with _rate_lock:
            for stale_key in list(_rate_events)[:1000]:
                if not _rate_events.get(stale_key):
                    _rate_events.pop(stale_key, None)
    return 0


def _pdf_unescape(raw):
    out = bytearray()
    index = 0
    length = len(raw)
    mapping = {
        ord("n"): 10,
        ord("r"): 13,
        ord("t"): 9,
        ord("b"): 8,
        ord("f"): 12,
        ord("("): 40,
        ord(")"): 41,
        ord("\\"): 92,
    }
    while index < length:
        char = raw[index]
        if char != 92:
            out.append(char)
            index += 1
            continue
        index += 1
        if index >= length:
            break
        nxt = raw[index]
        if nxt in mapping:
            out.append(mapping[nxt])
            index += 1
        elif 48 <= nxt <= 55:
            digits = bytes([nxt])
            index += 1
            while index < length and len(digits) < 3 and 48 <= raw[index] <= 55:
                digits += bytes([raw[index]])
                index += 1
            try:
                out.append(int(digits, 8) & 0xFF)
            except ValueError:
                pass
        elif nxt in (10, 13):
            index += 1
            if nxt == 13 and index < length and raw[index] == 10:
                index += 1
        else:
            out.append(nxt)
            index += 1
    return bytes(out)


def _pdf_decode_literal(raw):
    data = _pdf_unescape(raw)
    if data.startswith(b"\xfe\xff"):
        try:
            return data[2:].decode("utf-16-be", "ignore")
        except (UnicodeDecodeError, ValueError):
            return ""
    try:
        text = data.decode("utf-8")
    except (UnicodeDecodeError, ValueError):
        text = data.decode("latin-1", "ignore")
    return text


def _pdf_decode_hex(raw):
    cleaned = re.sub(rb"[^0-9A-Fa-f]", b"", raw)
    if len(cleaned) % 2:
        cleaned += b"0"
    try:
        data = bytes.fromhex(cleaned.decode("ascii"))
    except (ValueError, UnicodeDecodeError):
        return ""
    if data.startswith(b"\xfe\xff"):
        try:
            return data[2:].decode("utf-16-be", "ignore")
        except (UnicodeDecodeError, ValueError):
            return ""
    try:
        return data.decode("utf-8")
    except (UnicodeDecodeError, ValueError):
        return data.decode("latin-1", "ignore")


def _pdf_decode_stream(raw):
    for wbits in (zlib.MAX_WBITS, -zlib.MAX_WBITS):
        try:
            return zlib.decompress(raw, wbits)
        except zlib.error:
            continue
    return raw


def _clean_pdf_text(text):
    text = text.replace("\x00", " ").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def extract_pdf_text(data):
    if not data:
        return "", 0
    pages = 0
    try:
        pages = len(re.findall(rb"/Type\s*/Page(?![sA-Za-z])", data))
    except Exception:
        pages = 0
    chunks = []
    for match in re.finditer(rb"stream\s*\r?\n(.*?)\r?\n?endstream", data, re.S):
        raw = match.group(1)
        decoded = _pdf_decode_stream(raw)
        if not decoded:
            continue
        for token in re.finditer(rb"\((?:\\.|[^\\()])*\)|<[0-9A-Fa-f\s]+>", decoded, re.S):
            value = token.group(0)
            text = ""
            if value.startswith(b"("):
                text = _pdf_decode_literal(value[1:-1])
            elif value.startswith(b"<"):
                text = _pdf_decode_hex(value[1:-1])
            if not text:
                continue
            printable = sum(1 for char in text if char.isprintable() or char in "\n\t ")
            if len(text.strip()) < 2 or printable / max(1, len(text)) < 0.55:
                continue
            chunks.append(text)
    text = _clean_pdf_text(" ".join(chunks))
    if len(text) < 20:
        fallback = []
        for token in re.finditer(rb"\((?:\\.|[^\\()])*\)", data, re.S):
            value = _pdf_decode_literal(token.group(0)[1:-1])
            if value and sum(1 for char in value if char.isprintable()) / max(1, len(value)) > 0.75:
                fallback.append(value)
        candidate = _clean_pdf_text(" ".join(fallback))
        if len(candidate) > len(text):
            text = candidate
    return text, max(1, pages)


def extract_attachment_text(meta, data):
    mime = str(meta.get("mimeType") or "").lower()
    name = str(meta.get("name") or "").lower()
    if mime == "application/pdf" or name.endswith(".pdf") or data[:5] == b"%PDF-":
        text, pages = extract_pdf_text(data)
        return {
            "kind": "pdf",
            "text": text[:MAX_ANALYZE_TEXT],
            "pages": pages,
            "truncated": len(text) > MAX_ANALYZE_TEXT,
        }
    text_extension = any(name.endswith(ext) for ext in TEXT_ATTACHMENT_EXTENSIONS)
    if mime.startswith("text/") or mime in ("application/json", "application/xml") or text_extension:
        try:
            text = data.decode("utf-8")
        except (UnicodeDecodeError, ValueError):
            text = data.decode("latin-1", "ignore")
        text = _clean_pdf_text(text)
        return {
            "kind": "text",
            "text": text[:MAX_ANALYZE_TEXT],
            "pages": max(1, text.count("\f") + 1),
            "truncated": len(text) > MAX_ANALYZE_TEXT,
        }
    return None


def admin_config_payload(config):
    payload = {}
    for key in ADMIN_TEXT_FIELDS:
        payload[key] = config.get(key, "")
    for key in ADMIN_BOOL_FIELDS:
        payload[key] = bool(config.get(key))
    for key in ADMIN_INT_FIELDS:
        payload[key] = config.get(key)
    return payload


def admin_icons_payload(config):
    with _upload_lock:
        index = _read_upload_index()
    active = str(config.get("app_icon") or "")
    icons = []
    for meta in index.values():
        if not isinstance(meta, dict) or meta.get("kind") != "icon":
            continue
        if not str(meta.get("mimeType") or "").startswith("image/"):
            continue
        item = public_upload_meta(meta)
        item["active"] = ("/f/" + str(meta.get("id"))) == active
        icons.append(item)
    icons.sort(key=lambda item: (not item.get("active"), -(item.get("created") or 0)))
    return icons


def admin_settings_payload(config):
    result = app_config_payload(config)
    result["config"] = admin_config_payload(config)
    result["icons"] = admin_icons_payload(config)
    result["logo"] = ADMIN_LOGO_PATH
    return result


def apply_admin_config(config, payload):
    restart_required = False
    for key, limit in ADMIN_TEXT_FIELDS.items():
        if key not in payload:
            continue
        value = str(payload.get(key) or "").strip()[:limit]
        if key == "admin_token" and not value:
            continue
        if key == "admin_token" and len(value) < 8:
            raise ValueError("Admin token must be at least 8 characters")
        if key == "provider":
            value = value.lower() or "gemini"
            if value not in (
                "gemini",
                "google",
                "opencode",
                "pollinations",
                "github",
                "deepseek",
                "openrouter",
                "cheatgpt",
                "openai",
                "chatgpt",
            ):
                raise ValueError("Unsupported provider")
        if key == "host" and not value:
            raise ValueError("Host cannot be empty")
        if key == "voice_speed":
            value = value.lower()
            if value not in ("fast", "normal", "slow"):
                value = "fast"
        if key in ADMIN_URL_FIELDS:
            if key in ADMIN_PATH_URL_FIELDS:
                if value and not (value.startswith("http://") or value.startswith("https://") or value.startswith("/")):
                    raise ValueError(f"{key} must start with http://, https:// or /")
            else:
                if value and not (value.startswith("http://") or value.startswith("https://")):
                    raise ValueError(f"{key} must start with http:// or https://")
            if value and len(value) > 1:
                value = value.rstrip("/")
        if key == "app_link_scheme":
            value = sanitize_app_scheme(value)
        if key == "app_package" and value and not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+", value):
            raise ValueError("app_package must look like com.example.app")
        if key == "host" and value != str(config.get("host") or ""):
            restart_required = True
        config[key] = value

    for key in ADMIN_BOOL_FIELDS:
        if key in payload:
            config[key] = truthy(payload.get(key))

    for key, bounds in ADMIN_INT_FIELDS.items():
        if key not in payload:
            continue
        try:
            value = int(payload.get(key))
        except (TypeError, ValueError):
            raise ValueError(f"{key} must be a number")
        value = max(bounds[0], min(bounds[1], value))
        if key == "port" and value != int(config.get("port") or 0):
            restart_required = True
        config[key] = value

    if payload.get("clear_icon"):
        config["app_icon"] = ""
    return restart_required


def admin_token_ok(headers, config):
    expected = str(config.get("admin_token") or "").strip()
    if not expected:
        return False
    provided = str(headers.get("X-Admin-Token") or "").strip()
    if not provided:
        authorization = str(headers.get("Authorization") or "").strip()
        if authorization.lower().startswith("bearer "):
            provided = authorization[7:].strip()
    return hmac.compare_digest(expected, provided)


def human_size(value):
    try:
        size = float(value)
    except (TypeError, ValueError):
        return "—"
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return (f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}")
        size /= 1024
    return f"{size:.1f} GB"


def share_page_html(meta, app_icon="", origin="", app_scheme="rebbetai", app_package="com.rabbet.ai", app_download_url=""):
    file_id = str(meta.get("id") or "")
    name = html.escape(str(meta.get("name") or "Shared file"))
    mime = str(meta.get("mimeType") or "")
    size = human_size(meta.get("size"))
    raw_url = "/f/" + urllib.parse.quote(file_id)
    share_path = "/s/" + urllib.parse.quote(file_id)
    origin = str(origin or "").rstrip("/")
    web_url = (origin + share_path) if origin else share_path
    web_fallback = web_url + ("&" if "?" in web_url else "?") + "web=1"
    icon_url = app_icon or "/static/icon-192.png"
    icon_abs_url = (origin + icon_url) if origin and icon_url.startswith("/") else icon_url
    raw_abs_url = (origin + raw_url) if origin else raw_url
    app_scheme = sanitize_app_scheme(app_scheme)
    app_package = str(app_package or "").strip()
    deep_link = ""
    intent_url = ""
    if app_package:
        query = "url=" + urllib.parse.quote(web_url, safe="") + "&share=" + urllib.parse.quote(file_id, safe="")
        deep_link = f"{app_scheme}://open?{query}"
        intent_url = (
            f"intent://open?{query}"
            f"#Intent;scheme={app_scheme};package={app_package};"
            f"S.browser_fallback_url={urllib.parse.quote(web_fallback, safe='')};end"
        )
    download_url = ""
    if app_download_url:
        download_url = app_download_url
        if download_url.startswith("/") and origin:
            download_url = origin + download_url
    if mime.startswith("image/"):
        preview = f'<img class="share__media" src="{raw_url}" alt="{name}">'
        og_image = f'<meta property="og:image" content="{html.escape(raw_abs_url)}">'
    elif mime.startswith("video/"):
        preview = f'<video class="share__media" src="{raw_url}" controls playsinline preload="metadata"></video>'
        og_image = ""
    elif mime.startswith("audio/"):
        preview = f'<audio class="share__audio" src="{raw_url}" controls preload="metadata"></audio>'
        og_image = ""
    elif mime == "application/pdf":
        preview = f'<iframe class="share__frame" src="{raw_url}" title="{name}"></iframe>'
        og_image = ""
    else:
        preview = (
            '<div class="share__file">'
            '<svg width="54" height="54" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">'
            '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>'
            '<polyline points="14 2 14 8 20 8"></polyline>'
            '</svg>'
            '<div class="share__file-name">' + name + '</div>'
            '<div class="share__file-size">' + html.escape(size) + '</div>'
            '</div>'
        )
        og_image = ""
    app_button = ""
    if deep_link:
        app_button = (
            f'<a class="btn btn--primary" id="openApp" href="{html.escape(web_fallback)}" '
            f'data-intent="{html.escape(intent_url)}" data-deeplink="{html.escape(deep_link)}">Open in app</a>'
        )
    download_app_button = ""
    if download_url:
        download_app_button = f'<a class="btn" href="{html.escape(download_url)}">Get Rebbet AI app</a>'
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#080a13">
<title>{name} — Rebbet AI</title>
<meta property="og:title" content="{name} — Rebbet AI">
<meta property="og:description" content="Shared with Rebbet AI">
<meta property="og:url" content="{html.escape(web_url)}">
{og_image}
<link rel="icon" type="image/png" href="{html.escape(icon_abs_url)}">
<style>
:root {{ color-scheme: dark; }}
* {{ box-sizing: border-box; }}
body {{ margin: 0; min-height: 100dvh; display: flex; flex-direction: column; background:
  radial-gradient(900px 520px at 50% -10%, rgba(124,92,255,.22), transparent 70%),
  radial-gradient(600px 400px at 100% 100%, rgba(55,120,255,.1), transparent 70%), #080a13;
  color: #f5f7ff; font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; }}
header {{ display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 16px 18px; border-bottom: 1px solid rgba(163,174,208,.14); }}
.brand {{ display: flex; align-items: center; gap: 10px; font-weight: 650; }}
.brand img {{ width: 34px; height: 34px; border-radius: 10px; }}
.open {{ padding: 9px 15px; border-radius: 999px; background: linear-gradient(135deg,#7c5cff,#a78bfa); color: #fff; text-decoration: none; font-size: 13px; font-weight: 650; }}
main {{ flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 18px; padding: 22px 16px; }}
.share__meta {{ text-align: center; }}
.share__name {{ font-size: 17px; font-weight: 650; word-break: break-word; }}
.share__size {{ margin-top: 4px; color: rgba(229,234,255,.5); font-size: 12.5px; }}
.share__media {{ max-width: min(100%, 900px); max-height: 68dvh; border-radius: 16px; border: 1px solid rgba(163,174,208,.16); background: #070912; }}
.share__audio {{ width: min(100%, 520px); }}
.share__frame {{ width: min(100%, 900px); height: 68dvh; border: 1px solid rgba(163,174,208,.16); border-radius: 16px; background: #070912; }}
.share__file {{ display: flex; flex-direction: column; align-items: center; gap: 8px; padding: 34px 26px; border: 1px dashed rgba(163,174,208,.3); border-radius: 18px; background: rgba(255,255,255,.03); color: #cfc7ff; text-align: center; }}
.share__file-name {{ color: #f5f7ff; font-weight: 600; word-break: break-word; }}
.share__file-size {{ color: rgba(229,234,255,.5); font-size: 12.5px; }}
.actions {{ display: flex; gap: 10px; flex-wrap: wrap; justify-content: center; }}
.btn {{ padding: 11px 18px; border-radius: 999px; border: 1px solid rgba(163,174,208,.24); background: rgba(255,255,255,.05); color: #e5eaff; text-decoration: none; font-size: 13.5px; font-weight: 600; cursor: pointer; }}
.btn--primary {{ border: 0; background: linear-gradient(135deg,#7c5cff,#a78bfa); color: #fff; }}
.hint {{ margin: 0; color: rgba(229,234,255,.45); font-size: 12px; text-align: center; }}
footer {{ padding: 14px; text-align: center; color: rgba(229,234,255,.4); font-size: 11.5px; }}
</style>
</head>
<body>
<header>
  <div class="brand"><img src="{html.escape(icon_abs_url)}" alt=""><span>Rebbet AI</span></div>
  <a class="open" href="{html.escape(web_url)}">Open app</a>
</header>
<main>
  <div class="share__meta">
    <div class="share__name">{name}</div>
    <div class="share__size">{html.escape(size)} · Shared file</div>
  </div>
  {preview}
  <div class="actions">
    {app_button}
    <a class="btn" href="{raw_url}" download="{name}">Download file</a>
    <button class="btn" type="button" id="copyLink">Copy link</button>
    {download_app_button}
  </div>
  <p class="hint" id="openHint" hidden>Opening the Rebbet AI app…</p>
</main>
<footer>Shared securely with Rebbet AI</footer>
<script>
(function() {{
  var openApp = document.getElementById('openApp');
  var hint = document.getElementById('openHint');
  var ua = navigator.userAgent || '';
  var insideApp = /RebbetAIApp/i.test(ua);
  var android = /Android/i.test(ua) && !insideApp;
  if (openApp && (insideApp || !/Android/i.test(ua))) openApp.hidden = true;
  function openInApp(event) {{
    if (!openApp || !android) return;
    var intent = openApp.getAttribute('data-intent') || '';
    if (!intent) return;
    if (event) event.preventDefault();
    if (hint) hint.hidden = false;
    window.location.href = intent;
  }}
  if (openApp && android) {{
    openApp.addEventListener('click', openInApp);
    var alreadyFallback = /(?:[?&])web=1(?:&|$)/.test(location.search);
    if (!alreadyFallback) {{
      setTimeout(function() {{ openInApp(null); }}, 500);
    }}
  }}
  var copy = document.getElementById('copyLink');
  if (copy) {{
    copy.addEventListener('click', function() {{
      var link = location.href;
      if (navigator.clipboard && navigator.clipboard.writeText) {{
        navigator.clipboard.writeText(link).then(function() {{
          copy.textContent = 'Copied';
        }});
      }}
    }});
  }}
}})();
</script>
</body>
</html>"""


class AppHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = f"RebbetAI/{VERSION}"

    def log_message(self, fmt, *args):
        if os.environ.get("REBBET_LOG") == "1":
            super().log_message(fmt, *args)

    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
        self.send_header("Permissions-Policy", "microphone=(self), camera=(), geolocation=()")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://www.gstatic.com; "
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com data:; "
            "img-src 'self' data: blob: https:; "
            "media-src 'self' data: blob:; "
            "connect-src 'self' https: wss:; "
            "frame-src 'self' blob: https:; "
            "object-src 'none'; base-uri 'self'",
        )
        super().end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlsplit(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if path in ("/api/health", "/health"):
            config = self.server.config
            self.send_json(
                200,
                {
                    "ok": True,
                    "app": APP_NAME,
                    "version": VERSION,
                    "module": MODULE_NAME,
                    "module_id": MODULE_ID,
                    "key_configured": bool(config["api_key"] or config.get("cheatgpt_api_key")),
                    "default_model": config["default_model"],
                    "bind": f"{config['host']}:{config['port']}",
                    "provider": config.get("provider"),
                    "web_search": config.get("enable_web_search", True),
                    "auto_switch": config.get("auto_switch_model", True),
                    "free_fallback": config.get("enable_free_fallback", True),
                    "voice_model": config.get("elevenlabs_model", ELEVENLABS_DEFAULT_MODEL),
                    "voice_provider": "elevenlabs",
                    "elevenlabs_voice": bool(config.get("elevenlabs_api_key")),
                    "image_model": config.get("image_model", GEMINI_DEFAULT_IMAGE),
                    "transcribe_model": config.get("transcribe_model", TRANSCRIBE_MODEL),
                    "github_models": bool(config.get("github_api_key")),
                    "cheatgpt": bool(config.get("cheatgpt_api_key")),
                },
            )
            return
        
        if path == "/api/module" or path == "/api/rebbet":
            self.send_json(
                200,
                {
                    "name": MODULE_NAME,
                    "id": MODULE_ID,
                    "display_name": APP_NAME,
                    "version": VERSION,
                    "features": {
                        "web_search": True,
                        "internet_search": True,
                        "free_ai_models": True,
                        "auto_switch_on_limit": True,
                        "better_voice": True,
                        "fast_voice": True,
                        "image_generation": True,
                        "free_fallback": bool(self.server.config.get("enable_free_fallback", True)),
                    },
                    "free_models": (
                        [self.server.config.get("cheatgpt_model") or CHEATGPT_DEFAULT_MODEL]
                        if str(self.server.config.get("provider") or "").lower() in CHEATGPT_PROVIDERS
                        else GEMINI_FALLBACK_MODEL_IDS
                        if is_gemini_api(self.server.config)
                        else FREE_MODELS
                    ),
                    "auto_switch_order": (
                        [self.server.config.get("cheatgpt_model") or CHEATGPT_DEFAULT_MODEL]
                        if str(self.server.config.get("provider") or "").lower() in CHEATGPT_PROVIDERS
                        else GEMINI_FALLBACK_MODEL_IDS
                        if is_gemini_api(self.server.config)
                        else AUTO_SWITCH_ORDER
                    ),
                    "free_fallback_providers": [
                        name for name, enabled in (
                            ("deepseek", bool(self.server.config.get("deepseek_api_key"))),
                            ("github", bool(self.server.config.get("github_api_key"))),
                            ("openrouter", bool(self.server.config.get("openrouter_api_key"))),
                            ("cheatgpt", bool(self.server.config.get("cheatgpt_api_key"))),
                            ("pollinations", bool(self.server.config.get("enable_free_fallback", True))),
                        ) if enabled
                    ],
                    "voice_models": ELEVENLABS_MODEL_IDS,
                    "image_models": GEMINI_IMAGE_MODEL_IDS,
                },
            )
            return

        if path == "/api/voices":
            config = self.server.config
            if not str(config.get("elevenlabs_api_key") or "").strip():
                self.send_api_error(
                    503,
                    {
                        "code": "no_voice_key",
                        "message": "No ElevenLabs API key is configured.",
                        "hint": "Add an elevenlabs_api_key to config.json, then restart the server.",
                    },
                )
                return
            voices = []
            warning = ""
            try:
                voices = elevenlabs_voices(config)
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode("utf-8", "replace")
                warning = extract_error_message(exc.code, detail)
            except (urllib.error.URLError, OSError, TimeoutError, ValueError) as exc:
                warning = "Could not reach the ElevenLabs voice service: " + str(exc)[:200]
            if not voices:
                voices = [dict(voice) for voice in ELEVENLABS_FALLBACK_VOICES]
            self.send_json(
                200,
                {
                    "voices": voices,
                    "models": ELEVENLABS_MODEL_IDS,
                    "default_voice": config.get("elevenlabs_voice_id") or ELEVENLABS_DEFAULT_VOICE,
                    "default_model": config.get("elevenlabs_model") or ELEVENLABS_DEFAULT_MODEL,
                    "speed": config.get("voice_speed") or "fast",
                    "warning": warning,
                },
            )
            return

        if path == "/api/models":
            force = query.get("refresh", ["0"])[0] in ("1", "true", "yes")
            models, source = fetch_models(self.server.config, force=force)
            self.send_json(200, {"models": models, "source": source, "default": self.server.config["default_model"]})
            return

        if path == "/api/app-config":
            self.send_json(200, app_config_payload(self.server.config))
            return

        if path.startswith("/api/file/"):
            meta = get_upload(path[len("/api/file/"):])
            if not meta:
                self.send_api_error(404, {"code": "not_found", "message": "File not found"})
                return
            self.send_json(200, public_upload_meta(meta))
            return

        if path == "/api/admin/settings":
            if not admin_token_ok(self.headers, self.server.config):
                self.send_api_error(401, {"code": "unauthorized", "message": "Invalid admin token"})
                return
            self.send_json(200, {"settings": admin_settings_payload(self.server.config)})
            return

        if path == "/api/admin/editor":
            if not admin_token_ok(self.headers, self.server.config):
                self.send_api_error(401, {"code": "unauthorized", "message": "Invalid admin token"})
                return
            file_path = (query.get("path") or [""])[0]
            try:
                if not file_path:
                    self.send_json(200, {"files": editor_list_files()})
                else:
                    self.send_json(200, {"file": editor_read(file_path)})
            except ValueError as exc:
                self.send_api_error(400, {"code": "invalid_path", "message": str(exc)})
            except OSError as exc:
                self.send_api_error(500, {"code": "read_failed", "message": str(exc)})
            return

        if path == "/api/admin/files":
            if not admin_token_ok(self.headers, self.server.config):
                self.send_api_error(401, {"code": "unauthorized", "message": "Invalid admin token"})
                return
            with _upload_lock:
                index = _read_upload_index()
            files = [public_upload_meta(meta) for meta in index.values() if isinstance(meta, dict)]
            files.sort(key=lambda item: item.get("created") or 0, reverse=True)
            self.send_json(200, {"files": files})
            return

        if path.startswith("/f/"):
            meta = get_upload(path[len("/f/"):])
            if not meta:
                self.send_api_error(404, {"code": "not_found", "message": "File not found"})
                return
            self.serve_upload_file(meta, download=query.get("download", ["0"])[0] in ("1", "true", "yes"))
            return

        if path.startswith("/s/"):
            config = self.server.config
            meta = get_upload(path[len("/s/"):])
            if not meta:
                self.send_bytes(
                    404,
                    share_page_html(
                        {"id": "missing", "name": "File not found", "mimeType": "", "size": 0},
                        config.get("app_icon") or "",
                        self.request_origin(),
                        config.get("app_link_scheme") or "rebbetai",
                        config.get("app_package") or "",
                        config.get("app_download_url") or "",
                    ).encode("utf-8"),
                    "text/html; charset=utf-8",
                )
                return
            page = share_page_html(
                meta,
                config.get("app_icon") or "",
                self.request_origin(),
                config.get("app_link_scheme") or "rebbetai",
                config.get("app_package") or "",
                config.get("app_download_url") or "",
            ).encode("utf-8")
            self.send_bytes(200, page, "text/html; charset=utf-8")
            return

        if path in ("/api/chat", "/api/search", "/api/tts", "/api/image", "/api/transcribe", "/api/analyze"):
            self.send_api_error(
                405,
                {
                    "code": "method_not_allowed",
                    "message": f"Use POST for {path}",
                },
            )
            return

        if path == "/favicon.ico":
            self.serve_file(STATIC_DIR / "icon-192.png", cache=True)
            return

        if path.startswith("/static/") and not STATIC_DIR.is_dir():
            self.send_json(
                500,
                {
                    "error": {
                        "message": "static folder is missing on the server",
                        "hint": "Upload the whole static folder next to app.py, then redeploy.",
                    }
                },
            )
            return

        if path in ("/", "/index.html") and not (ROOT / "index.html").is_file():
            self.send_bytes(
                200,
                INDEX_HTML_FALLBACK.encode("utf-8"),
                "text/html; charset=utf-8",
            )
            return

        if path in ("/admin", "/admin/", "/admin.html") and not (ROOT / "admin.html").is_file():
            self.send_json(
                500,
                {
                    "error": {
                        "message": "admin.html is missing on the server",
                        "hint": "Upload admin.html next to app.py, then redeploy.",
                    }
                },
            )
            return

        file_path = self.resolve_file(path)
        if file_path is None:
            self.send_json(
                404,
                {
                    "error": {
                        "message": "Not found",
                        "path": path,
                        "hint": "Open / for the app or /admin.html for the admin panel.",
                    }
                },
            )
            return
        self.serve_file(file_path, cache=path.startswith("/static/"))

    def do_HEAD(self):
        self.do_GET()

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_cors_headers()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_POST(self):
        parsed = urllib.parse.urlsplit(self.path)
        if parsed.path in (
            "/api/chat",
            "/api/search",
            "/api/tts",
            "/api/image",
            "/api/transcribe",
            "/api/analyze",
            "/api/upload",
        ):
            if is_user_banned(self.headers.get("X-Rebbet-User", "")):
                self.send_api_error(
                    403,
                    {
                        "code": "banned",
                        "message": "Your access has been blocked by an administrator."
                    }
                )
                return
        bucket = parsed.path[len("/api/"):] if parsed.path.startswith("/api/") else ""
        if bucket in RATE_LIMITS:
            retry = check_rate_limit(self, bucket)
            if retry:
                self.send_api_error(
                    429,
                    {
                        "code": "rate_limited",
                        "message": "Too many requests. Please slow down.",
                        "hint": f"Try again in about {retry} seconds.",
                        "retry_after": retry,
                    },
                )
                return
        if parsed.path == "/api/chat":
            self.handle_chat()
            return
        if parsed.path == "/api/search":
            self.handle_search()
            return
        if parsed.path == "/api/tts":
            self.handle_tts()
            return
        if parsed.path == "/api/image":
            self.handle_image()
            return
        if parsed.path == "/api/transcribe":
            self.handle_transcribe()
            return
        if parsed.path == "/api/analyze":
            self.handle_analyze()
            return
        if parsed.path == "/api/upload":
            self.handle_upload()
            return
        if parsed.path == "/api/admin/settings":
            self.handle_admin_settings()
            return
        if parsed.path == "/api/admin/upload-icon":
            self.handle_admin_upload_icon()
            return
        if parsed.path == "/api/admin/set-icon":
            self.handle_admin_set_icon()
            return
        if parsed.path == "/api/admin/upload-update":
            self.handle_admin_upload_update()
            return
        if parsed.path == "/api/admin/delete-file":
            self.handle_admin_delete_file()
            return
        if parsed.path == "/api/admin/editor":
            self.handle_admin_editor()
            return
        if parsed.path == "/api/admin/reload-config":
            self.handle_admin_reload_config()
            return
        if parsed.path == "/api/admin/restart":
            self.handle_admin_restart()
            return
        self.send_json(
            404,
            {
                "error": {
                    "message": "Not found",
                    "path": parsed.path,
                    "hint": "API routes: /api/health, /api/models, /api/app-config, /api/chat, /api/search, /api/tts, /api/image, /api/transcribe, /api/upload.",
                }
            },
        )

    def resolve_file(self, path):
        relative = path.lstrip("/")
        if relative in ("", "index.html"):
            target = ROOT / "index.html"
        elif relative in ("admin", "admin/", "admin.html"):
            target = ROOT / "admin.html"
        elif relative in ("manifest.json", "service-worker.js"):
            target = ROOT / relative
        elif relative.startswith("static/"):
            target = ROOT / relative
        else:
            return None
        try:
            resolved = target.resolve()
            resolved.relative_to(ROOT)
        except (ValueError, OSError):
            return None
        if not resolved.is_file():
            return None
        return resolved

    def content_type_for(self, path):
        suffix = path.suffix.lower()
        overrides = {
            ".html": "text/html; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".js": "text/javascript; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".webmanifest": "application/manifest+json; charset=utf-8",
            ".svg": "image/svg+xml",
            ".png": "image/png",
            ".ico": "image/x-icon",
            ".txt": "text/plain; charset=utf-8",
        }
        return overrides.get(suffix) or mimetypes.guess_type(str(path))[0] or "application/octet-stream"

    def serve_file(self, path, cache=False):
        try:
            data = path.read_bytes()
        except OSError:
            self.send_json(404, {"error": {"message": "Not found"}})
            return
        self.send_response(200)
        self.send_header("Content-Type", self.content_type_for(path))
        self.send_header("Content-Length", str(len(data)))
        if cache:
            self.send_header("Cache-Control", "public, max-age=3600")
        else:
            self.send_header("Cache-Control", "no-cache")
        if path.name == "service-worker.js":
            self.send_header("Service-Worker-Allowed", "/")
        self.send_cors_headers()
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type, X-Rebbet-User, X-Admin-Token")
        self.send_header("Access-Control-Expose-Headers", "X-Voice-Model, X-Image-Source, X-Image-Model, X-Image-Prompt")
        self.send_header("Access-Control-Max-Age", "86400")

    def send_bytes(self, status, data, content_type, extra_headers=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        for name, value in (extra_headers or {}).items():
            self.send_header(name, value)
        self.send_cors_headers()
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def send_json(self, status, payload):
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_cors_headers()
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def send_api_error(self, status, info):
        if status == 401 and isinstance(info, dict):
            info = dict(info)
            provided = str(self.headers.get("X-Admin-Token") or "").strip()
            if not provided:
                authorization = str(self.headers.get("Authorization") or "").strip()
                if authorization.lower().startswith("bearer "):
                    provided = authorization[7:].strip()
            info.setdefault("token_received", bool(provided))
        self.send_json(status, {"error": info})

    def request_origin(self):
        configured = str(self.server.config.get("public_base_url") or "").strip().rstrip("/")
        if configured:
            return configured
        proto = (self.headers.get("X-Forwarded-Proto") or "http").split(",")[0].strip() or "http"
        host = self.headers.get("X-Forwarded-Host") or self.headers.get("Host") or f"{self.server.config['host']}:{self.server.config['port']}"
        host = host.split(",")[0].strip() or f"{self.server.config['host']}:{self.server.config['port']}"
        return f"{proto}://{host}"

    def serve_upload_file(self, meta, download=False):
        try:
            data = meta["path"].read_bytes()
        except OSError:
            self.send_api_error(404, {"code": "not_found", "message": "File not found"})
            return
        total = len(data)
        status = 200
        start = 0
        end = total - 1
        range_header = (self.headers.get("Range") or "").strip()
        if range_header.lower().startswith("bytes=") and total > 0:
            spec = range_header[6:].split(",")[0].strip()
            first, _, last = spec.partition("-")
            try:
                if first == "" and last.isdigit():
                    start = max(0, total - int(last))
                    end = total - 1
                    status = 206
                elif first.isdigit():
                    start = int(first)
                    end = min(int(last) if last.isdigit() else total - 1, total - 1)
                    if 0 <= start <= end < total:
                        status = 206
                    else:
                        start, end, status = 0, total - 1, 200
            except ValueError:
                start, end, status = 0, total - 1, 200
        body = data[start:end + 1] if status == 206 else data
        mime = str(meta.get("mimeType") or "").strip().lower()
        if mime in ("text/html", "application/xhtml+xml", "image/svg+xml", "application/xml", "text/xml"):
            mime = "text/plain; charset=utf-8"
        if not mime:
            mime = mimetypes.guess_type(str(meta.get("name") or ""))[0] or "application/octet-stream"
        name = sanitize_upload_name(meta.get("name"), "file")
        ascii_name = re.sub(r"[^A-Za-z0-9._-]+", "_", name) or "file"
        disposition = "attachment" if download else "inline"
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Accept-Ranges", "bytes")
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{total}")
        self.send_header("Content-Disposition", f'{disposition}; filename="{ascii_name}"; filename*=UTF-8\'\'{urllib.parse.quote(name)}')
        self.send_header("Cache-Control", "public, max-age=31536000, immutable")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_cors_headers()
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def read_upload_payload(self, max_bytes):
        payload = self.read_json_body(max_bytes=max_bytes)
        raw = payload.get("data")
        if not isinstance(raw, str) or not raw.strip():
            raise ValueError("Upload data is required")
        if raw.startswith("data:"):
            header, _, raw = raw.partition(",")
            if "base64" not in header.lower():
                raise ValueError("Upload must be base64 encoded")
        raw = re.sub(r"\s+", "", raw)
        try:
            return payload, base64.b64decode(raw, validate=True)
        except Exception:
            raise ValueError("Upload data is not valid base64")

    def handle_upload(self):
        config = self.server.config
        limit_mb = int(config.get("max_upload_mb") or 25)
        max_bytes = int(limit_mb * 1024 * 1024 * 1.4) + 131072
        try:
            payload, data = self.read_upload_payload(max_bytes)
        except ValueError as exc:
            self.send_api_error(400, {"code": "invalid_upload", "message": str(exc)})
            return
        if not data:
            self.send_api_error(400, {"code": "empty_file", "message": "File is empty"})
            return
        if len(data) > limit_mb * 1024 * 1024:
            self.send_api_error(413, {"code": "too_large", "message": f"File is larger than {limit_mb} MB"})
            return
        name = payload.get("name") or "file"
        mime = payload.get("mimeType") or payload.get("mime") or "application/octet-stream"
        meta = store_upload(name, mime, data, kind="shared")
        origin = self.request_origin()
        result = public_upload_meta(meta)
        result["url"] = origin + result["url"]
        result["rawUrl"] = origin + result["rawUrl"]
        result["shareUrl"] = result["url"]
        result["downloadUrl"] = result["rawUrl"]
        result["deepLink"] = ""
        scheme = sanitize_app_scheme(self.server.config.get("app_link_scheme"))
        pkg = str(self.server.config.get("app_package") or "").strip()
        if pkg and origin:
            query = "url=" + urllib.parse.quote(result["shareUrl"], safe="") + "&share=" + urllib.parse.quote(str(meta.get("id") or ""), safe="")
            result["deepLink"] = f"{scheme}://open?{query}"
            result["intentUrl"] = (
                f"intent://open?{query}"
                f"#Intent;scheme={scheme};package={pkg};"
                f"S.browser_fallback_url={urllib.parse.quote(result['shareUrl'] + ('&' if '?' in result['shareUrl'] else '?') + 'web=1', safe='')};end"
            )
        self.send_json(201, {"ok": True, "file": result})

    def handle_admin_settings(self):
        if not admin_token_ok(self.headers, self.server.config):
            self.send_api_error(401, {"code": "unauthorized", "message": "Invalid admin token"})
            return
        try:
            payload = self.read_json_body(max_bytes=131072)
        except ValueError as exc:
            self.send_api_error(400, {"code": "invalid_body", "message": str(exc)})
            return
        config = self.server.config
        try:
            restart_required = apply_admin_config(config, payload)
        except ValueError as exc:
            self.send_api_error(400, {"code": "invalid_setting", "message": str(exc)})
            return
        save_config(config)
        self.send_json(
            200,
            {
                "ok": True,
                "settings": admin_settings_payload(config),
                "restart_required": restart_required,
            },
        )

    def handle_admin_upload_icon(self):
        if not admin_token_ok(self.headers, self.server.config):
            self.send_api_error(401, {"code": "unauthorized", "message": "Invalid admin token"})
            return
        try:
            payload, data = self.read_upload_payload(6 * 1024 * 1024)
        except ValueError as exc:
            self.send_api_error(400, {"code": "invalid_upload", "message": str(exc)})
            return
        if len(data) > 4 * 1024 * 1024:
            self.send_api_error(413, {"code": "too_large", "message": "Icon must be 4 MB or smaller"})
            return
        mime = str(payload.get("mimeType") or payload.get("mime") or "").lower().strip()
        if mime == "image/jpg":
            mime = "image/jpeg"
        valid = (
            (mime == "image/png" and data.startswith(b"\x89PNG\r\n\x1a\n"))
            or (mime == "image/jpeg" and data.startswith(b"\xff\xd8\xff"))
            or (mime == "image/webp" and data[:4] == b"RIFF" and data[8:12] == b"WEBP")
            or (mime == "image/gif" and data[:6] in (b"GIF87a", b"GIF89a"))
            or (mime in ("image/x-icon", "image/vnd.microsoft.icon") and data[:4] in (b"\x00\x00\x01\x00", b"\x00\x00\x02\x00"))
        )
        if not valid:
            self.send_api_error(400, {"code": "invalid_image", "message": "Use a PNG, JPEG, WEBP, GIF or ICO image"})
            return
        meta = store_upload(payload.get("name") or "app-icon.png", mime, data, kind="icon")
        config = self.server.config
        if truthy(payload.get("activate", True)):
            config["app_icon"] = "/f/" + str(meta["id"])
            save_config(config)
        result = public_upload_meta(meta)
        result["url"] = self.request_origin() + result["url"]
        result["rawUrl"] = self.request_origin() + result["rawUrl"]
        self.send_json(200, {"ok": True, "settings": admin_settings_payload(config), "file": result})

    def handle_admin_set_icon(self):
        if not admin_token_ok(self.headers, self.server.config):
            self.send_api_error(401, {"code": "unauthorized", "message": "Invalid admin token"})
            return
        try:
            payload = self.read_json_body(max_bytes=8192)
        except ValueError as exc:
            self.send_api_error(400, {"code": "invalid_body", "message": str(exc)})
            return
        file_id = str(payload.get("id") or "").strip()
        meta = get_upload(file_id)
        if not meta or meta.get("kind") != "icon" or not str(meta.get("mimeType") or "").startswith("image/"):
            self.send_api_error(404, {"code": "not_found", "message": "Icon not found"})
            return
        config = self.server.config
        config["app_icon"] = "/f/" + str(meta["id"])
        save_config(config)
        self.send_json(200, {"ok": True, "settings": admin_settings_payload(config)})

    def handle_admin_upload_update(self):
        if not admin_token_ok(self.headers, self.server.config):
            self.send_api_error(401, {"code": "unauthorized", "message": "Invalid admin token"})
            return
        try:
            payload, data = self.read_upload_payload(285 * 1024 * 1024)
        except ValueError as exc:
            self.send_api_error(400, {"code": "invalid_upload", "message": str(exc)})
            return
        if not data:
            self.send_api_error(400, {"code": "empty_file", "message": "File is empty"})
            return
        if len(data) > 200 * 1024 * 1024:
            self.send_api_error(413, {"code": "too_large", "message": "Update file must be 200 MB or smaller"})
            return
        name = payload.get("name") or "rebbet-ai-update.apk"
        mime = payload.get("mimeType") or payload.get("mime") or "application/vnd.android.package-archive"
        meta = store_upload(name, mime, data, kind="update")
        config = self.server.config
        config["update_url"] = "/f/" + str(meta["id"])
        config["update_available"] = True
        version = str(payload.get("version") or "").strip()[:40]
        if version:
            config["app_version"] = version
        message = str(payload.get("update_message") or "").strip()[:600]
        if message:
            config["update_message"] = message
        save_config(config)
        result = public_upload_meta(meta)
        result["url"] = self.request_origin() + result["url"]
        result["rawUrl"] = self.request_origin() + result["rawUrl"]
        self.send_json(200, {"ok": True, "settings": admin_settings_payload(config), "file": result})

    def handle_admin_delete_file(self):
        if not admin_token_ok(self.headers, self.server.config):
            self.send_api_error(401, {"code": "unauthorized", "message": "Invalid admin token"})
            return
        try:
            payload = self.read_json_body(max_bytes=8192)
        except ValueError as exc:
            self.send_api_error(400, {"code": "invalid_body", "message": str(exc)})
            return
        file_id = str(payload.get("id") or "").strip()
        if not delete_upload(file_id):
            self.send_api_error(404, {"code": "not_found", "message": "File not found"})
            return
        config = self.server.config
        if config.get("app_icon") == "/f/" + file_id:
            config["app_icon"] = ""
            save_config(config)
        self.send_json(200, {"ok": True})

    def handle_admin_editor(self):
        if not admin_token_ok(self.headers, self.server.config):
            self.send_api_error(401, {"code": "unauthorized", "message": "Invalid admin token"})
            return
        try:
            payload = self.read_json_body(max_bytes=EDITOR_MAX_BYTES + 16384)
        except ValueError as exc:
            self.send_api_error(400, {"code": "invalid_body", "message": str(exc)})
            return
        try:
            info = editor_write(payload.get("path"), payload.get("content"))
        except ValueError as exc:
            self.send_api_error(400, {"code": "invalid_path", "message": str(exc)})
            return
        except OSError as exc:
            self.send_api_error(500, {"code": "write_failed", "message": str(exc)})
            return
        reloaded = False
        if info.get("path") == "config.json":
            try:
                reload_saved_config(self.server.config)
                reloaded = True
            except Exception:
                reloaded = False
        self.send_json(200, {"ok": True, "file": info, "config_reloaded": reloaded})

    def handle_admin_reload_config(self):
        if not admin_token_ok(self.headers, self.server.config):
            self.send_api_error(401, {"code": "unauthorized", "message": "Invalid admin token"})
            return
        try:
            reload_saved_config(self.server.config)
        except (OSError, ValueError) as exc:
            self.send_api_error(500, {"code": "reload_failed", "message": str(exc)})
            return
        self.send_json(200, {"ok": True, "settings": admin_settings_payload(self.server.config)})

    def handle_admin_restart(self):
        if not admin_token_ok(self.headers, self.server.config):
            self.send_api_error(401, {"code": "unauthorized", "message": "Invalid admin token"})
            return
        self.send_json(200, {"ok": True, "message": "Restarting the server…"})

        def restart():
            time.sleep(0.7)
            script = sys.argv[0] or "app.py"
            if not os.path.isabs(script):
                script = str(ROOT / script)
            command = [sys.executable, script] + sys.argv[1:]
            try:
                log = open(os.path.join(tempfile.gettempdir(), "rebbet-ai.log"), "ab")
            except OSError:
                log = subprocess.DEVNULL
            helper = "import os, sys, time\ntime.sleep(1.2)\nos.execv(sys.argv[1], sys.argv[1:])\n"
            try:
                subprocess.Popen(
                    [sys.executable, "-c", helper] + command,
                    cwd=str(ROOT),
                    stdin=subprocess.DEVNULL,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                    close_fds=True,
                )
            except OSError as exc:
                print("Server restart failed: %s" % exc, file=sys.stderr)
                return
            os._exit(0)

        threading.Thread(target=restart, daemon=True).start()

    def handle_search(self):
        try:
            payload = self.read_json_body()
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return
        query = payload.get("query", "")
        if not isinstance(query, str) or not query.strip():
            self.send_api_error(400, {"code": "bad_request", "message": "query is required"})
            return
        results = web_search(query.strip(), max_results=payload.get("max_results", 5))
        self.send_json(200, {"results": results, "query": query.strip()})

    def read_json_body(self, max_bytes=MAX_BODY):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise ValueError("Invalid Content-Length")
        if length <= 0:
            raise ValueError("Request body is required")
        if length > max_bytes:
            raise ValueError("Request body is too large")
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            raise ValueError("Request body must be valid JSON")
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object")
        return payload

    def handle_chat(self):
        config = self.server.config
        provider = str(config.get("provider") or "").strip().lower()
        if (
            not config["api_key"]
            and not config.get("cheatgpt_api_key")
            and not config.get("enable_free_fallback", True)
        ):
            self.send_api_error(
                503,
                {
                    "code": "no_key",
                    "message": "No API key is configured.",
                    "hint": "Add an OpenCode, Gemini or CheatGPT api_key to config.json, then restart the server.",
                    "url": "https://opencode.ai/console",
                },
            )
            return

        direct_gemini = is_gemini_api(config)

        try:
            payload = self.read_json_body()
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return

        raw_messages = payload.get("messages")
        if not isinstance(raw_messages, list) or not raw_messages:
            self.send_api_error(400, {"code": "bad_request", "message": "messages must be a non-empty array"})
            return
        if len(raw_messages) > MAX_MESSAGES:
            self.send_api_error(400, {"code": "bad_request", "message": f"Too many messages (max {MAX_MESSAGES})"})
            return

        messages = []
        for item in raw_messages:
            if not isinstance(item, dict):
                self.send_api_error(400, {"code": "bad_request", "message": "Each message must be an object"})
                return
            role = item.get("role")
            content = item.get("content")
            if role not in ("user", "assistant") or not isinstance(content, str):
                self.send_api_error(400, {"code": "bad_request", "message": "Messages need a user/assistant role and text content"})
                return
            content = content[:MAX_MESSAGE_CHARS]
            if not content.strip() and role == "user":
                self.send_api_error(400, {"code": "bad_request", "message": "User messages cannot be empty"})
                return
            messages.append({"role": role, "content": content})

        if messages[-1]["role"] != "user":
            self.send_api_error(400, {"code": "bad_request", "message": "The last message must be from the user"})
            return

        model = payload.get("model") or config["default_model"]
        if not isinstance(model, str) or not model.strip() or len(model) > 160:
            self.send_api_error(400, {"code": "bad_request", "message": "Invalid model id"})
            return
        model = normalize_model(model)
        family = model_family(model)
        if family == "systemone":
            self.send_api_error(400, {"code": "bad_request", "message": "That model is not a chat model"})
            return

        system = payload.get("system")
        if system is None:
            system = config.get("system_prompt") or DEFAULT_SYSTEM_PROMPT
        if not isinstance(system, str):
            self.send_api_error(400, {"code": "bad_request", "message": "system must be text"})
            return
        system = system.strip()[:20000]
        personality = payload.get("personality")
        if isinstance(personality, dict):
            personality_name = str(personality.get("name") or "").strip()[:80]
            personality_prompt = str(personality.get("system") or "").strip()[:4000]
            if personality_prompt:
                system = (
                    f"You are speaking in the '{personality_name or 'custom'}' personality. "
                    f"Stay in character while remaining helpful and truthful.\n{personality_prompt}\n\n{system}"
                )[:24000]
        system, memory_count = system_with_memory(system, payload.get("memory"))

        # Auto web search for time-sensitive queries
        enable_search = payload.get("web_search", config.get("enable_web_search", True))
        if enable_search and messages:
            last_user_msg = messages[-1]["content"].lower()
            if any(keyword in last_user_msg for keyword in ["news", "current", "today", "latest", "weather", "price", "stock", "score", "update", "now", "2025", "2026"]):
                try:
                    search_ctx = get_web_search_context(messages[-1]["content"])
                    if search_ctx:
                        system += search_ctx
                except:
                    pass

        temperature = payload.get("temperature")
        if temperature is not None:
            if not isinstance(temperature, (int, float)) or isinstance(temperature, bool):
                self.send_api_error(400, {"code": "bad_request", "message": "temperature must be a number"})
                return
            temperature = max(0.0, min(2.0, float(temperature)))

        max_tokens = payload.get("max_tokens")
        if max_tokens is not None:
            if not isinstance(max_tokens, int) or isinstance(max_tokens, bool) or not 1 <= max_tokens <= 65536:
                self.send_api_error(400, {"code": "bad_request", "message": "max_tokens must be an integer from 1 to 65536"})
                return

        if provider in CHEATGPT_PROVIDERS:
            self.handle_cheatgpt_chat(config, model, messages, system, temperature, max_tokens)
            return

        if direct_gemini:
            self.handle_gemini_chat(config, model, messages, system, temperature, max_tokens)
            return

        try:
            request = build_upstream_request(
                config,
                model,
                family,
                messages,
                system,
                temperature,
                max_tokens,
                direct_gemini=direct_gemini,
            )
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return

        try:
            upstream = urllib.request.urlopen(request, timeout=config["request_timeout"])
        except urllib.error.HTTPError as exc:
            body = ""
            try:
                body = exc.read(16384).decode("utf-8", "replace")
            except OSError:
                pass
            info = describe_upstream_error(exc.code, body)
            if config.get("auto_switch_model", True) and info.get("code") in (
                "free_limit",
                "rate_limited",
                "insufficient_funds",
                "model_disabled",
                "upstream_unavailable",
            ):
                switched = False
                for alt_model in AUTO_SWITCH_ORDER:
                    if alt_model == model or not is_chat_model(alt_model):
                        continue
                    try:
                        alt_family = model_family(alt_model)
                        alt_request = build_upstream_request(
                            config,
                            alt_model,
                            alt_family,
                            messages,
                            system,
                            temperature,
                            max_tokens,
                            direct_gemini=False,
                        )
                        upstream = urllib.request.urlopen(alt_request, timeout=config["request_timeout"])
                        model = alt_model
                        family = alt_family
                        switched = True
                        break
                    except Exception:
                        continue
                if not switched:
                    status = exc.code if 400 <= exc.code < 500 else 502
                    self.send_api_error(status, info)
                    return
            else:
                status = exc.code if 400 <= exc.code < 500 else 502
                self.send_api_error(status, info)
                return
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            self.send_api_error(
                502,
                {
                    "code": "network_error",
                    "message": "Could not reach OpenCode.",
                    "hint": "Check your internet connection and try again.",
                    "detail": str(exc)[:300],
                },
            )
            return

        with upstream:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache, no-transform")
            self.send_header("Connection", "close")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            self.close_connection = True

            try:
                self.send_event(
                    {
                        "type": "meta",
                        "model": model,
                        "family": family,
                    }
                )
                if direct_gemini:
                    raw = upstream.read()
                    try:
                        payload = json.loads(raw.decode('utf-8'))
                    except Exception:
                        raise UpstreamStreamError({"code": "upstream_error", "message": "Bad response from Gemini"})
                    usage = None
                    if isinstance(payload, dict):
                        if payload.get('usage'):
                            usage = payload.get('usage')
                        choices = payload.get('choices') or []
                        for choice in choices:
                            msg = choice.get('message') or {}
                            text = msg.get('content')
                            if isinstance(text, str) and text:
                                self.emit_delta(text)
                            elif isinstance(text, list):
                                for part in text:
                                    if isinstance(part, dict) and isinstance(part.get('text'), str):
                                        self.emit_delta(part['text'])
                    self.send_event({"type": "done", "usage": usage})
                else:
                    usage = self.stream_upstream(upstream, family)
                    self.send_event({"type": "done", "usage": usage})
            except UpstreamStreamError as exc:
                try:
                    self.send_event({"type": "error", **exc.info})
                except (BrokenPipeError, ConnectionResetError):
                    pass
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass
            except (TimeoutError, socket.timeout, OSError) as exc:
                try:
                    self.send_event(
                        {
                            "type": "error",
                            "code": "stream_interrupted",
                            "message": "The response stream was interrupted.",
                            "hint": "Try again.",
                            "detail": str(exc)[:300],
                        }
                    )
                except (BrokenPipeError, ConnectionResetError):
                    pass

    def start_event_stream(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-transform")
        self.send_header("Connection", "close")
        self.send_header("X-Accel-Buffering", "no")
        self.send_cors_headers()
        self.end_headers()
        self.close_connection = True

    def emit_text_chunks(self, text):
        chunk_size = 420
        for index in range(0, len(text), chunk_size):
            self.emit_delta(text[index:index + chunk_size])

    def free_chat_fallback(self, config, requested_model, messages, system, temperature, max_tokens, reason=None):
        candidates = []
        if config.get("deepseek_api_key"):
            candidates.append(("deepseek", config.get("deepseek_model") or "deepseek-chat"))
        if config.get("github_api_key"):
            candidates.append(("github", config.get("github_model") or "openai/gpt-4.1"))
        if config.get("openrouter_api_key"):
            candidates.append(("openrouter", config.get("openrouter_model") or "deepseek/deepseek-chat-v3-0324:free"))
        if config.get("enable_free_fallback", True):
            candidates.append(("pollinations", config.get("pollinations_model") or "openai-fast"))
        last_info = reason
        for provider, model in candidates:
            key = f"{provider}:{model}"
            if model_cooldown_left(key):
                continue
            try:
                text, usage = provider_chat(
                    config, provider, model, messages, system, temperature, max_tokens
                )
            except UpstreamStreamError as exc:
                last_info = exc.info
                mark_model_cooldown(key, cooldown_seconds_for_error(exc.info))
                continue
            except (urllib.error.URLError, OSError, TimeoutError) as exc:
                last_info = {
                    "code": "network_error",
                    "message": "Could not reach the free fallback.",
                    "hint": "Check your internet connection and try again.",
                    "detail": str(exc)[:300],
                }
                mark_model_cooldown(key, 20)
                continue
            except ValueError:
                continue
            try:
                self.start_event_stream()
                self.send_event(
                    {
                        "type": "meta",
                        "model": model,
                        "provider": provider,
                        "requested_model": requested_model,
                        "switched": True,
                        "fallback": True,
                    }
                )
                self.emit_text_chunks(text)
                self.send_event({"type": "done", "usage": usage})
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass
            return True
        info = last_info or {
            "code": "upstream_error",
            "message": "All available models are unavailable right now.",
            "hint": "Wait a moment and try again.",
        }
        if info.get("code") in ("insufficient_funds", "unauthorized", "free_limit", "rate_limited"):
            if info.get("code") == "insufficient_funds":
                info = {
                    "code": "no_credits",
                    "message": "The configured provider has no credits and the free fallback is unavailable.",
                    "hint": "Add credits or another provider key, then try again.",
                    "detail": info.get("detail", "")[:300],
                }
            status = 429 if info.get("code") in ("free_limit", "rate_limited") else 502
        else:
            status = 502
        self.send_api_error(status, info)
        return False

    def handle_cheatgpt_chat(self, config, requested_model, messages, system, temperature, max_tokens):
        model = requested_model or config.get("cheatgpt_model") or CHEATGPT_DEFAULT_MODEL
        has_key = bool(str(config.get("cheatgpt_api_key") or "").strip())
        if not has_key:
            if config.get("enable_free_fallback", True):
                self.free_chat_fallback(
                    config,
                    requested_model,
                    messages,
                    system,
                    temperature,
                    max_tokens,
                    reason={
                        "code": "no_key",
                        "message": "No CheatGPT API key is configured, using a free model instead.",
                        "hint": "Add cheatgpt_api_key to config.json for the selected model.",
                    },
                )
                return
            self.send_api_error(
                503,
                {
                    "code": "no_key",
                    "message": "No CheatGPT API key is configured.",
                    "hint": "Add cheatgpt_api_key to config.json, then restart the server.",
                },
            )
            return
        stream_response = None
        try:
            stream_response = open_provider_stream(
                config, "cheatgpt", model, messages, system, temperature, max_tokens
            )
        except UpstreamStreamError as exc:
            if config.get("enable_free_fallback", True):
                self.free_chat_fallback(
                    config, requested_model, messages, system, temperature, max_tokens, reason=exc.info
                )
                return
            info = exc.info
            code = info.get("code")
            status = 429 if code in ("free_limit", "rate_limited") else 401 if code == "unauthorized" else 502
            self.send_api_error(status, info)
            return
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            if config.get("enable_free_fallback", True):
                self.free_chat_fallback(
                    config,
                    requested_model,
                    messages,
                    system,
                    temperature,
                    max_tokens,
                    reason={
                        "code": "network_error",
                        "message": "Could not reach CheatGPT.",
                        "hint": "Switching to a free model.",
                        "detail": str(exc)[:300],
                    },
                )
                return
            self.send_api_error(
                502,
                {
                    "code": "network_error",
                    "message": "Could not reach CheatGPT.",
                    "hint": "Check your internet connection and try again.",
                    "detail": str(exc)[:300],
                },
            )
            return
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return

        with stream_response:
            try:
                self.start_event_stream()
                self.send_event(
                    {
                        "type": "meta",
                        "model": model,
                        "provider": "cheatgpt",
                        "requested_model": requested_model,
                        "switched": model != requested_model,
                        "streaming": True,
                    }
                )
                text, usage = consume_provider_stream(stream_response, self.emit_delta)
                self.send_event({"type": "done", "usage": usage, "chars": len(text)})
            except UpstreamStreamError as exc:
                try:
                    self.send_event({"type": "error", **exc.info})
                except (BrokenPipeError, ConnectionResetError):
                    pass
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass
            except (TimeoutError, socket.timeout, OSError) as exc:
                try:
                    self.send_event(
                        {
                            "type": "error",
                            "code": "stream_interrupted",
                            "message": "The response stream was interrupted.",
                            "hint": "Try again.",
                            "detail": str(exc)[:300],
                        }
                    )
                except (BrokenPipeError, ConnectionResetError):
                    pass

    def handle_gemini_chat(self, config, requested_model, messages, system, temperature, max_tokens):
        candidates = gemini_chat_candidates(config, requested_model)
        if not config.get("auto_switch_model", True):
            candidates = candidates[:1]
        planned = []
        for index, candidate in enumerate(candidates):
            key = f"{candidate[0]}:{candidate[1]}"
            if index > 0 and model_cooldown_left(key):
                continue
            planned.append(candidate)
        if not planned:
            planned = candidates[:1]
        last_info = None
        winner = None
        stop = threading.Event()
        results = queue.Queue()

        def attempt(provider, candidate_model, timeout=None):
            key = f"{provider}:{candidate_model}"
            try:
                if provider == "gemini":
                    if not config.get("api_key"):
                        raise UpstreamStreamError(
                            {
                                "code": "no_key",
                                "message": "No Gemini API key is configured.",
                                "hint": "Add api_key to config.json or use the free fallback.",
                            }
                        )
                    text, usage = gemini_generate_text(
                        config, candidate_model, messages, system, temperature, max_tokens, timeout=timeout
                    )
                else:
                    text, usage = provider_chat(
                        config, provider, candidate_model, messages, system, temperature, max_tokens
                    )
                return {
                    "ok": True,
                    "provider": provider,
                    "model": candidate_model,
                    "text": text,
                    "usage": usage,
                }
            except UpstreamStreamError as exc:
                info = exc.info
                mark_model_cooldown(key, cooldown_seconds_for_error(info))
            except urllib.error.HTTPError as exc:
                detail = ""
                try:
                    detail = exc.read(16384).decode("utf-8", "replace")
                except OSError:
                    pass
                info = describe_upstream_error(exc.code, detail)
                mark_model_cooldown(key, cooldown_seconds_for_error(info))
            except (urllib.error.URLError, OSError, TimeoutError) as exc:
                info = {
                    "code": "network_error",
                    "message": "Could not reach the model provider.",
                    "hint": "Check your internet connection.",
                    "detail": str(exc)[:300],
                }
                mark_model_cooldown(key, 20)
            except ValueError as exc:
                info = {
                    "code": "bad_request",
                    "message": str(exc),
                    "hint": "Try another model.",
                }
                mark_model_cooldown(key, 60)
            return {"ok": False, "info": info, "provider": provider, "model": candidate_model}

        def worker(provider, candidate_model, delay):
            if stop.wait(delay):
                return
            results.put(attempt(provider, candidate_model, timeout=25))

        hedge = [item for item in planned if item[0] == "gemini"][:4]
        hedge += [item for item in planned if item[0] != "gemini"][:1]
        if not hedge:
            hedge = planned[:1]
        for index, (provider, candidate_model) in enumerate(hedge):
            threading.Thread(
                target=worker,
                args=(provider, candidate_model, min(index * 3, 12)),
                daemon=True,
            ).start()
        deadline = time.time() + 30
        received = 0
        while received < len(hedge) and time.time() < deadline:
            try:
                outcome = results.get(timeout=0.4)
            except queue.Empty:
                continue
            received += 1
            if outcome.get("ok"):
                winner = outcome
                break
            last_info = outcome.get("info")
        stop.set()

        if not winner:
            used = set(hedge)
            remaining = [item for item in planned if item not in used]
            if any(item[0] == "gemini" for item in hedge):
                remaining = [item for item in remaining if item[0] != "gemini"]
            for provider, candidate_model in remaining:
                key = f"{provider}:{candidate_model}"
                if model_cooldown_left(key):
                    continue
                outcome = attempt(provider, candidate_model)
                if outcome.get("ok"):
                    winner = outcome
                    break
                last_info = outcome.get("info")

        if winner:
            try:
                self.start_event_stream()
                self.send_event(
                    {
                        "type": "meta",
                        "model": winner["model"],
                        "provider": winner["provider"],
                        "requested_model": requested_model,
                        "switched": winner["model"] != requested_model,
                    }
                )
                self.emit_text_chunks(winner["text"])
                self.send_event({"type": "done", "usage": winner.get("usage")})
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass
            return

        info = last_info or {
            "code": "rate_limited",
            "message": "All available models are cooling down after hitting free limits.",
            "hint": "Wait about a minute and try again.",
        }
        if info.get("code") in ("free_limit", "rate_limited", "insufficient_funds"):
            info["message"] = info.get("message") or "All free models have reached their limit."
            info["hint"] = "Rebbet AI tried several free models. Wait a moment or add another provider key."
        status = 429 if info.get("code") in ("free_limit", "rate_limited") else 502
        self.send_api_error(status, info)

    def elevenlabs_config_error(self):
        config = self.server.config
        if str(config.get("elevenlabs_api_key") or "").strip():
            return False
        self.send_api_error(
            503,
            {
                "code": "no_voice_key",
                "message": "No ElevenLabs API key is configured.",
                "hint": "Add an elevenlabs_api_key to config.json, then restart the server.",
            },
        )
        return True

    def transcribe_config_error(self):
        config = self.server.config
        if not config["api_key"]:
            self.send_api_error(
                503,
                {
                    "code": "no_key",
                    "message": "No API key is configured.",
                    "hint": "Add a Gemini api_key to config.json, then restart the server.",
                },
            )
            return True
        if not is_gemini_api(config):
            self.send_api_error(
                400,
                {
                    "code": "voice_unsupported",
                    "message": "Voice input needs the Gemini provider.",
                    "hint": "Set provider to gemini in config.json.",
                },
            )
            return True
        return False

    def handle_tts(self):
        if self.elevenlabs_config_error():
            return
        config = self.server.config
        try:
            payload = self.read_json_body(max_bytes=256 * 1024)
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return

        text = payload.get("text")
        if not isinstance(text, str) or not text.strip():
            self.send_api_error(400, {"code": "bad_request", "message": "text is required"})
            return
        text = text.strip()[:MAX_TTS_CHARS]

        voice = payload.get("voice")
        if not isinstance(voice, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", voice):
            voice = None

        speed = payload.get("speed")
        if not isinstance(speed, str):
            speed = config.get("voice_speed", "fast")
        speed = speed.lower().strip()

        model = payload.get("model")
        if not isinstance(model, str) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", model):
            model = None

        used_model = model or config.get("elevenlabs_model") or ELEVENLABS_DEFAULT_MODEL
        try:
            audio, mime = elevenlabs_tts(config, text, voice_id=voice, speed=speed, model_id=model)
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")
            status = 429 if exc.code == 429 else 502
            self.send_api_error(
                status,
                {
                    "code": "tts_error",
                    "message": extract_error_message(exc.code, detail),
                    "detail": detail[:500],
                },
            )
            return
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            self.send_api_error(
                502,
                {
                    "code": "tts_unavailable",
                    "message": "Could not reach the ElevenLabs voice service.",
                    "hint": "Check your internet connection and try again.",
                    "detail": str(exc)[:300],
                },
            )
            return
        except ValueError as exc:
            self.send_api_error(503, {"code": "no_voice_key", "message": str(exc)})
            return

        if not audio:
            self.send_api_error(
                502,
                {
                    "code": "tts_error",
                    "message": "The ElevenLabs voice service returned no audio.",
                },
            )
            return

        mime = mime or "audio/mpeg"
        self.send_bytes(200, audio, mime, {"X-Voice-Model": used_model})

    def handle_image(self):
        config = self.server.config
        if not config.get("api_key") and not config.get("enable_free_fallback", True):
            self.send_api_error(
                503,
                {
                    "code": "no_key",
                    "message": "No API key is configured.",
                    "hint": "Add a Gemini api_key to config.json, then restart the server.",
                },
            )
            return
        try:
            payload = self.read_json_body(max_bytes=64 * 1024)
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return
        prompt = payload.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            self.send_api_error(400, {"code": "bad_request", "message": "prompt is required"})
            return
        prompt = prompt.strip()[:MAX_IMAGE_CHARS]
        width = payload.get("width", 768)
        height = payload.get("height", 768)
        if not isinstance(width, int) or isinstance(width, bool):
            width = 768
        if not isinstance(height, int) or isinstance(height, bool):
            height = 768
        width = max(256, min(1024, width))
        height = max(256, min(1024, height))
        last_error = None
        image_key = config.get("image_api_key") or ""
        gemini_image_key = image_key or config.get("api_key") or ""
        if gemini_image_key and is_gemini_api(config):
            image_model = config.get("image_model") or IMAGE_MODEL
            models = [image_model] + [model for model in GEMINI_IMAGE_MODEL_IDS if model != image_model]
            for index, model in enumerate(models):
                key = f"image:{model}"
                if index > 0 and model_cooldown_left(key):
                    continue
                try:
                    data, mime, text = gemini_image_bytes(
                        config, model, prompt, timeout=90, api_key=gemini_image_key
                    )
                except urllib.error.HTTPError as exc:
                    detail = exc.read().decode("utf-8", "replace")
                    last_error = {
                        "code": "image_error",
                        "message": extract_error_message(exc.code, detail),
                        "detail": detail[:500],
                    }
                    if exc.code in (400, 403, 404, 429):
                        quota_exhausted = exc.code == 429 and "limit: 0" in detail.lower()
                        mark_model_cooldown(
                            key,
                            IMAGE_QUOTA_COOLDOWN_SECONDS if quota_exhausted else MODEL_COOLDOWN_SECONDS,
                        )
                    if exc.code == 429:
                        break
                    continue
                except (urllib.error.URLError, OSError, TimeoutError) as exc:
                    last_error = {
                        "code": "image_unavailable",
                        "message": "Could not reach the image service.",
                        "hint": "Trying the free image provider.",
                        "detail": str(exc)[:300],
                    }
                    break
                if data:
                    self.send_bytes(
                        200,
                        data,
                        mime,
                        {
                            "X-Image-Source": "gemini",
                            "X-Image-Model": model,
                            "X-Image-Prompt": urllib.parse.quote(prompt[:180]),
                        },
                    )
                    return
                last_error = {
                    "code": "image_error",
                    "message": "The image model returned no picture.",
                    "hint": "Trying the free image provider.",
                    "detail": text[:300],
                }
                mark_model_cooldown(key, 60)
        if config.get("enable_free_fallback", True):
            try:
                data, mime = pollinations_image_throttled(prompt, width=width, height=height)
                self.send_bytes(
                    200,
                    data,
                    mime,
                    {
                        "X-Image-Source": "pollinations",
                        "X-Image-Model": "sana",
                        "X-Image-Prompt": urllib.parse.quote(prompt[:180]),
                    },
                )
                return
            except urllib.error.HTTPError as exc:
                detail = ""
                try:
                    detail = exc.read(8192).decode("utf-8", "replace")
                except OSError:
                    pass
                if exc.code == 402:
                    retry_after = pollinations_retry_after(detail) or POLLINATIONS_MIN_INTERVAL_SECONDS
                    last_error = {
                        "code": "image_rate_limited",
                        "message": f"Free image limit reached. Please wait about {retry_after} seconds and try again.",
                        "hint": "The free provider allows one image every 45 seconds. Add an image API key for faster generation.",
                        "retry_after": retry_after,
                    }
                else:
                    last_error = {
                        "code": "image_error",
                        "message": extract_error_message(exc.code, detail),
                        "hint": "The free image provider is busy. Try again shortly.",
                        "detail": detail[:400],
                    }
            except (urllib.error.URLError, TimeoutError) as exc:
                last_error = {
                    "code": "image_unavailable",
                    "message": "Could not reach the free image provider.",
                    "hint": "Check your internet connection and try again.",
                    "detail": str(exc)[:300],
                }
            except OSError as exc:
                last_error = {
                    "code": "image_unavailable",
                    "message": "The free image provider did not return an image.",
                    "hint": "Try again shortly, or add an image API key.",
                    "detail": str(exc)[:300],
                }
        self.send_api_error(502, last_error or {"code": "image_error", "message": "Image generation failed."})

    def handle_analyze(self):
        config = self.server.config
        try:
            payload = self.read_json_body(max_bytes=MAX_ANALYZE_BYTES)
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return
        file_id = str(payload.get("fileId") or "").strip()
        data = b""
        name = str(payload.get("name") or "document")
        mime = str(payload.get("mimeType") or payload.get("mime") or "").strip().lower()
        if file_id:
            meta = get_upload(file_id)
            if not meta:
                self.send_api_error(404, {"code": "not_found", "message": "Uploaded file not found."})
                return
            try:
                data = meta["path"].read_bytes()
            except OSError:
                self.send_api_error(404, {"code": "not_found", "message": "File is no longer available."})
                return
            name = str(meta.get("name") or name)
            mime = str(meta.get("mimeType") or mime)
        else:
            raw = payload.get("data")
            if not isinstance(raw, str) or not raw.strip():
                self.send_api_error(400, {"code": "bad_request", "message": "fileId or base64 data is required"})
                return
            if raw.startswith("data:"):
                header, _, raw = raw.partition(",")
                if "base64" not in header.lower():
                    self.send_api_error(400, {"code": "bad_request", "message": "Document data must be base64 encoded"})
                    return
            raw = re.sub(r"\s+", "", raw)
            try:
                data = base64.b64decode(raw, validate=True)
            except (ValueError, TypeError):
                self.send_api_error(400, {"code": "bad_request", "message": "Document data is not valid base64"})
                return
        if not data:
            self.send_api_error(400, {"code": "empty_file", "message": "Document is empty."})
            return
        if len(data) > MAX_ANALYZE_BYTES:
            self.send_api_error(413, {"code": "too_large", "message": "Document is too large to analyze."})
            return
        result = extract_attachment_text({"name": name, "mimeType": mime}, data)
        if not result:
            self.send_api_error(
                415,
                {
                    "code": "unsupported_document",
                    "message": "Only PDF and text documents can be analyzed.",
                    "hint": "Attach a PDF, TXT, Markdown, CSV, JSON or code file.",
                },
            )
            return
        text = (result.get("text") or "").strip()
        if not text:
            self.send_api_error(
                422,
                {
                    "code": "no_text",
                    "message": "No readable text was found in that document.",
                    "hint": "It may be a scanned/image-only PDF. Try a text-based PDF or paste the text instead.",
                },
            )
            return
        self.send_json(
            200,
            {
                "ok": True,
                "name": name,
                "kind": result.get("kind"),
                "pages": result.get("pages") or 1,
                "chars": len(text),
                "truncated": bool(result.get("truncated")),
                "text": text,
            },
        )

    def handle_transcribe(self):
        if self.transcribe_config_error():
            return
        config = self.server.config
        try:
            payload = self.read_json_body(max_bytes=MAX_AUDIO_BYTES * 2)
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return

        encoded = payload.get("audio")
        if not isinstance(encoded, str) or not encoded.strip():
            self.send_api_error(400, {"code": "bad_request", "message": "audio is required"})
            return
        try:
            audio = base64.b64decode(encoded)
        except (ValueError, TypeError):
            self.send_api_error(400, {"code": "bad_request", "message": "audio must be base64 encoded"})
            return
        if not audio:
            self.send_api_error(400, {"code": "bad_request", "message": "audio is empty"})
            return
        if len(audio) > MAX_AUDIO_BYTES:
            self.send_api_error(413, {"code": "too_large", "message": "Audio clip is too large."})
            return

        mime = payload.get("mimeType")
        if not isinstance(mime, str) or not mime.startswith("audio/"):
            mime = "audio/wav"
        prompt = payload.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            prompt = "Transcribe this audio exactly. Return only the transcript without commentary."

        body = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt},
                        {
                            "inlineData": {
                                "mimeType": mime,
                                "data": base64.b64encode(audio).decode("ascii"),
                            }
                        },
                    ]
                }
            ]
        }

        text = ""
        used_model = ""
        last_error = None
        models = [config.get("transcribe_model") or TRANSCRIBE_MODEL]
        models += [model for model in TRANSCRIBE_MODEL_IDS if model not in models]
        for index, model in enumerate(models):
            key = f"transcribe:{model}"
            if index > 0 and model_cooldown_left(key):
                continue
            try:
                result = gemini_native_request(config, model, body, timeout=75)
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode("utf-8", "replace")
                last_error = {
                    "code": "transcribe_error",
                    "message": extract_error_message(exc.code, detail),
                    "detail": detail[:500],
                }
                if exc.code in (400, 403, 404, 429):
                    mark_model_cooldown(key, MODEL_COOLDOWN_SECONDS)
                continue
            except (urllib.error.URLError, OSError, TimeoutError) as exc:
                last_error = {
                    "code": "transcribe_unavailable",
                    "message": "Could not reach the transcription service.",
                    "hint": "Check your internet connection and try again.",
                    "detail": str(exc)[:300],
                }
                break
            parts = []
            try:
                candidates = result.get("candidates") or []
                parts = (candidates[0].get("content") or {}).get("parts") or []
            except (IndexError, AttributeError, TypeError):
                parts = []
            pieces = []
            for part in parts:
                if not isinstance(part, dict):
                    continue
                transcription = (
                    part.get("audioTranscription")
                    or part.get("audio_transcription")
                    or part.get("transcription")
                )
                if isinstance(transcription, dict) and isinstance(transcription.get("text"), str):
                    pieces.append(transcription["text"])
                elif isinstance(part.get("text"), str):
                    pieces.append(part["text"])
            text = " ".join(piece.strip() for piece in pieces if piece.strip()).strip()
            if text:
                used_model = model
                break
            last_error = {
                "code": "no_speech",
                "message": "No speech was detected in that recording.",
                "hint": "Try recording again in a quieter place.",
            }
            mark_model_cooldown(key, 45)

        if not text:
            status = 429 if last_error and "429" in str(last_error.get("detail", "")) else 422
            self.send_api_error(status, last_error or {"code": "transcribe_error", "message": "Transcription failed."})
            return
        self.send_json(200, {"text": text, "model": used_model})

    def send_event(self, event):
        data = json.dumps(event, ensure_ascii=False).encode("utf-8")
        self.wfile.write(b"data: " + data + b"\n\n")
        self.wfile.flush()

    def stream_upstream(self, upstream, family):
        if family == "anthropic":
            return self.stream_anthropic(upstream)
        if family == "google":
            return self.stream_google(upstream)
        if family == "responses":
            return self.stream_responses(upstream)
        return self.stream_openai(upstream)

    def emit_delta(self, text):
        if text:
            self.send_event({"type": "delta", "text": text})

    def emit_thinking(self):
        self.send_event({"type": "thinking"})

    def stream_openai(self, upstream):
        usage = None
        for raw_line in upstream:
            line = raw_line.decode("utf-8", "replace").strip()
            if not line or line.startswith(":") or not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                payload = json.loads(data)
            except ValueError:
                continue
            if not isinstance(payload, dict):
                continue
            if "error" in payload:
                raise UpstreamStreamError(describe_upstream_error(502, json.dumps(payload)))
            if payload.get("usage"):
                usage = payload["usage"]
            for choice in payload.get("choices") or []:
                delta = choice.get("delta") or {}
                text = delta.get("content")
                if isinstance(text, str) and text:
                    self.emit_delta(text)
                reasoning = delta.get("reasoning_content") or delta.get("reasoning")
                if reasoning:
                    self.emit_thinking()
        return usage

    def stream_responses(self, upstream):
        usage = None
        emitted = False
        for raw_line in upstream:
            line = raw_line.decode("utf-8", "replace").strip()
            if not line or line.startswith(":") or not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                payload = json.loads(data)
            except ValueError:
                continue
            if not isinstance(payload, dict):
                continue
            event_type = payload.get("type")
            if event_type == "response.output_text.delta":
                delta = payload.get("delta")
                if isinstance(delta, str) and delta:
                    emitted = True
                    self.emit_delta(delta)
            elif event_type in ("response.output_text.done", "response.refusal.delta"):
                delta = payload.get("text") or payload.get("delta")
                if not emitted and isinstance(delta, str) and delta:
                    emitted = True
                    self.emit_delta(delta)
            elif event_type in ("response.reasoning_summary_text.delta", "response.reasoning_text.delta"):
                self.emit_thinking()
            elif event_type == "response.completed":
                response = payload.get("response") or {}
                usage = response.get("usage") or usage
                if not emitted:
                    emitted = self.emit_response_output(response)
            elif event_type in ("response.failed", "response.incomplete"):
                response = payload.get("response") or {}
                error = response.get("error") or {}
                message = error.get("message") or "The model did not complete the response."
                raise UpstreamStreamError(
                    {
                        "code": "upstream_error",
                        "message": message,
                        "hint": "Try again or choose a different model.",
                    }
                )
            elif event_type == "error" or "error" in payload:
                raise UpstreamStreamError(describe_upstream_error(502, json.dumps(payload)))
        return usage

    def emit_response_output(self, response):
        emitted = False
        for item in response.get("output") or []:
            if not isinstance(item, dict) or item.get("type") != "message":
                continue
            for content in item.get("content") or []:
                if isinstance(content, dict) and content.get("type") in ("output_text", "text"):
                    text = content.get("text")
                    if isinstance(text, str) and text:
                        self.emit_delta(text)
                        emitted = True
        return emitted

    def stream_anthropic(self, upstream):
        usage = {}
        for raw_line in upstream:
            line = raw_line.decode("utf-8", "replace").strip()
            if not line or line.startswith(":") or not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                payload = json.loads(data)
            except ValueError:
                continue
            if not isinstance(payload, dict):
                continue
            event_type = payload.get("type")
            if event_type == "content_block_delta":
                delta = payload.get("delta") or {}
                if delta.get("type") == "text_delta":
                    self.emit_delta(delta.get("text"))
                elif delta.get("type") == "thinking_delta":
                    self.emit_thinking()
                elif isinstance(delta.get("text"), str):
                    self.emit_delta(delta["text"])
            elif event_type == "content_block_start":
                block = payload.get("content_block") or {}
                if isinstance(block.get("text"), str) and block["text"]:
                    self.emit_delta(block["text"])
            elif event_type == "message_start":
                block_usage = (payload.get("message") or {}).get("usage") or {}
                usage.update(block_usage)
            elif event_type == "message_delta":
                usage.update(payload.get("usage") or {})
            elif event_type == "message_stop":
                break
            elif event_type == "error":
                error = payload.get("error") or {}
                message = error.get("message") or "The model returned an error."
                raise UpstreamStreamError(
                    {
                        "code": "upstream_error",
                        "message": message,
                        "hint": "Try again or choose a different model.",
                    }
                )
        return usage or None

    def stream_google(self, upstream):
        usage = None
        for raw_line in upstream:
            line = raw_line.decode("utf-8", "replace").strip()
            if not line or line.startswith(":") or not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                payload = json.loads(data)
            except ValueError:
                continue
            if not isinstance(payload, dict):
                continue
            if "error" in payload and not payload.get("candidates"):
                raise UpstreamStreamError(describe_upstream_error(502, json.dumps(payload)))
            metadata = payload.get("usageMetadata")
            if metadata:
                usage = {
                    "prompt_tokens": metadata.get("promptTokenCount"),
                    "completion_tokens": metadata.get("candidatesTokenCount"),
                    "total_tokens": metadata.get("totalTokenCount"),
                    "cost": metadata.get("cost"),
                }
            for candidate in payload.get("candidates") or []:
                content = candidate.get("content") or {}
                for part in content.get("parts") or []:
                    text = part.get("text")
                    if isinstance(text, str) and text:
                        if part.get("thought"):
                            self.emit_thinking()
                        else:
                            self.emit_delta(text)
        return usage


class RebbetServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 32


def start_server(config):
    host = config["host"]
    port = config["port"]
    last_error = None
    for candidate in range(port, port + 11):
        try:
            server = RebbetServer((host, candidate), AppHandler)
            server.config = config
            config["port"] = candidate
            return server
        except OSError as exc:
            last_error = exc
            if exc.errno in (48, 98, 10048):
                continue
            raise
    raise last_error or OSError("Could not bind a port")


def main():
    config = load_config()
    required = (
        "index.html",
        "admin.html",
        "static/app.js",
        "static/app-status.js",
        "static/style.css",
        "static/admin.js",
        "static/admin.css",
        "static/firebase.js",
    )
    missing = [name for name in required if not (ROOT / name).is_file()]
    if missing:
        print(
            "Warning: missing web files: " + ", ".join(missing) + ". Upload them next to app.py.",
            file=sys.stderr,
        )
    if not (ROOT / "index.html").is_file():
        print(
            "index.html is missing; serving the embedded Rebbet AI page instead.",
            file=sys.stderr,
        )
    try:
        server = start_server(config)
    except OSError as exc:
        print(f"Could not start {APP_NAME}: {exc}", file=sys.stderr)
        return 1

    display_host = "127.0.0.1" if config["host"] in ("0.0.0.0", "::") else config["host"]
    print(f"{APP_NAME} {VERSION}")
    print(f"Open: http://{display_host}:{config['port']}")
    print(f"Model: {config['default_model']}")
    if not config["api_key"]:
        print("Warning: no API key configured. Add api_key to config.json or set OPENCODE_API_KEY.", file=sys.stderr)
    print("Press Ctrl+C to stop.")

    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("\nStopping.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
