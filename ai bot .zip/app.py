#!/usr/bin/env python3
import base64
import io
import json
import mimetypes
import os
import re
import socket
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

APP_NAME = "Rebbet AI"
VERSION = "1.7.1"
MODULE_NAME = "rebbet-ai"
MODULE_ID = "rebbet_ai"
ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
CONFIG_PATH = ROOT / "config.json"
MAX_BODY = 4 * 1024 * 1024
MAX_MESSAGES = 200
MAX_MESSAGE_CHARS = 120000
UPSTREAM_USER_AGENT = "opencode/1.0"
GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai"
GEMINI_DEFAULT_MODEL = "gemini-2.5-flash"
DEFAULT_SYSTEM_PROMPT = (
    "You are Rebbet AI, a helpful, friendly assistant. Be accurate and clear.please join my telegram channel https://t.me/Panelsalllbay"
    "Use Markdown when it improves readability, and keep answers focused on what the user asked. "
    "When users ask for current information, news, weather, or anything time-sensitive, provide up-to-date information."
)
TTS_MODEL = os.environ.get("REBBET_TTS_MODEL", "gemini-2.5-flash-preview-tts")
TRANSCRIBE_MODEL = os.environ.get("REBBET_TRANSCRIBE_MODEL", "gemini-2.5-flash")
DEFAULT_VOICE = os.environ.get("REBBET_VOICE", "Kore")
MAX_TTS_CHARS = 4000
MAX_AUDIO_BYTES = 8 * 1024 * 1024

DEFAULT_CONFIG = {
    "host": "127.0.0.1",
    "port": 8765,
    "provider": "opencode",
    "api_key": "",
    "base_url": "https://opencode.ai/inference",
    "default_model": "glm-5.3-flash",
    "request_timeout": 300,
    "enable_web_search": True,
    "auto_switch_model": True,
    "voice_model": "gemini-2.5-flash-preview-tts",
    "voice_speed": "fast",
}

BRANDS = {
    "glm": "GLM",
    "gpt": "GPT",
    "claude": "Claude",
    "gemini": "Gemini",
    "qwen": "Qwen",
    "deepseek": "DeepSeek",
    "minimax": "MiniMax",
    "kimi": "Kimi",
    "grok": "Grok",
    "muse": "Muse",
    "nemotron": "Nemotron",
    "mimo": "MiMo",
    "flint": "Flint",
    "beam": "Beam",
    "mistral": "Mistral",
    "jev": "Jev",
    "big": "Big",
    "pickle": "Pickle",
}

SHORT_WORDS = {"vl": "VL", "ai": "AI", "api": "API"}

RECOMMENDED_ORDER = [
    "glm-5.3-flash",
    "deepseek-v4.1-flash",
    "minimax-m3",
    "qwen3.8-flash",
    "big-pickle",
    "gemini-2.5-flash",
    "glm-5.3",
    "kimi-k3",
    "claude-sonnet-5-5",
    "claude-haiku-5-5",
    "gpt-6-luna",
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "grok-4.5",
]

# Auto-switch order for when free limits are hit
AUTO_SWITCH_ORDER = [
    "glm-5.3-flash",
    "deepseek-v4.1-flash",
    "minimax-m3",
    "qwen3.8-flash",
    "big-pickle",
    "gemini-2.5-flash",
    "glm-5.3-flash-free",
    "deepseek-v4.1-flash-free",
]

# Free models that work well without heavy limits
FREE_MODELS = [
    "glm-5.3-flash",
    "deepseek-v4.1-flash",
    "minimax-m3",
    "qwen3.8-flash",
    "big-pickle",
    "glm-5.3-flash-free",
    "deepseek-v4.1-flash-free",
    "gemini-2.5-flash",
]

FALLBACK_MODEL_IDS = [
    "glm-5.3-flash",
    "deepseek-v4.1-flash",
    "minimax-m3",
    "qwen3.8-flash",
    "big-pickle",
    "glm-5.3",
    "kimi-k3",
    "claude-sonnet-5-5",
    "claude-haiku-5-5",
    "gpt-6-luna",
    "gemini-2.5-flash",
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "grok-4.5",
    "mistral-large-4",
    "glm-5.3-flash-free",
    "deepseek-v4.1-flash-free",
]

GEMINI_FALLBACK_MODEL_IDS = [
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.1-pro",
    "gemini-2.5-flash",
    "gemini-3.8-flash",
]

MODELS_CACHE_SECONDS = 1800
_models_cache = {"at": 0.0, "models": None, "source": "fallback"}
_models_lock = threading.Lock()


class UpstreamStreamError(Exception):
    def __init__(self, info):
        super().__init__(info.get("message", "Upstream error"))
        self.info = info


def load_config():
    config = dict(DEFAULT_CONFIG)
    if CONFIG_PATH.exists():
        try:
            saved = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                for key in DEFAULT_CONFIG:
                    if key in saved:
                        config[key] = saved[key]
        except (OSError, ValueError) as exc:
            print(f"Could not read config.json: {exc}", file=sys.stderr)

    if os.environ.get("OPENCODE_API_KEY"):
        config["api_key"] = os.environ["OPENCODE_API_KEY"]
    if os.environ.get("GEMINI_API_KEY"):
        config["api_key"] = os.environ["GEMINI_API_KEY"]
        config["provider"] = "gemini"
        config["base_url"] = GEMINI_BASE_URL
    if os.environ.get("OPENCODE_BASE_URL"):
        config["base_url"] = os.environ["OPENCODE_BASE_URL"]
    if os.environ.get("REBBET_BASE_URL"):
        config["base_url"] = os.environ["REBBET_BASE_URL"]
    if os.environ.get("REBBET_HOST"):
        config["host"] = os.environ["REBBET_HOST"]
    if os.environ.get("PORT"):
        config["port"] = os.environ["PORT"]
        if not os.environ.get("REBBET_HOST"):
            config["host"] = "0.0.0.0"
    if os.environ.get("REBBET_PORT"):
        config["port"] = os.environ["REBBET_PORT"]
    if os.environ.get("REBBET_DEFAULT_MODEL"):
        config["default_model"] = os.environ["REBBET_DEFAULT_MODEL"]
    if os.environ.get("REBBET_AUTO_SWITCH"):
        config["auto_switch_model"] = os.environ["REBBET_AUTO_SWITCH"].lower() in ("1", "true", "yes")
    if os.environ.get("REBBET_ENABLE_SEARCH"):
        config["enable_web_search"] = os.environ["REBBET_ENABLE_SEARCH"].lower() in ("1", "true", "yes")

    config["host"] = str(config.get("host") or "127.0.0.1").strip()
    config["port"] = int(config.get("port") or 8765)
    config["provider"] = str(config.get("provider") or "opencode").strip().lower()
    config["api_key"] = str(config.get("api_key") or "").strip()
    config["base_url"] = str(config.get("base_url") or DEFAULT_CONFIG["base_url"]).rstrip("/")
    config["default_model"] = str(config.get("default_model") or DEFAULT_CONFIG["default_model"]).strip()
    config["request_timeout"] = max(30, int(config.get("request_timeout") or 300))
    config["enable_web_search"] = bool(config.get("enable_web_search", True))
    config["auto_switch_model"] = bool(config.get("auto_switch_model", True))
    config["voice_model"] = str(config.get("voice_model") or "gemini-2.5-flash-preview-tts")
    config["voice_speed"] = str(config.get("voice_speed") or "fast")

    if config["provider"] in ("gemini", "google") and config["default_model"] == DEFAULT_CONFIG["default_model"]:
        config["default_model"] = GEMINI_DEFAULT_MODEL

    if config["api_key"].startswith(("AIza", "AQ.")) and "opencode.ai" in config["base_url"]:
        config["provider"] = "gemini"
        config["base_url"] = GEMINI_BASE_URL
        if config["default_model"] == DEFAULT_CONFIG["default_model"]:
            config["default_model"] = GEMINI_DEFAULT_MODEL
    return config


def is_gemini_api(config):
    provider = str(config.get("provider") or "").strip().lower()
    base_url = str(config.get("base_url") or "").lower()
    api_key = str(config.get("api_key") or "").strip()
    return (
        provider in ("gemini", "google")
        or "generativelanguage.googleapis.com" in base_url
        or api_key.startswith(("AIza", "AQ."))
    )


def gemini_models_url(config):
    base_url = str(config.get("base_url") or GEMINI_BASE_URL).rstrip("/")
    if base_url.endswith("/openai"):
        base_url = base_url[: -len("/openai")]
    return f"{base_url}/models"


def gemini_api_root(config):
    base_url = str(config.get("base_url") or GEMINI_BASE_URL).rstrip("/")
    if base_url.endswith("/openai"):
        base_url = base_url[: -len("/openai")]
    return base_url


def gemini_native_request(config, model, body, timeout=120):
    url = f"{gemini_api_root(config)}/models/{urllib.parse.quote(model, safe='')}:generateContent"
    request = urllib.request.Request(
        url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers={
            "x-goog-api-key": config["api_key"],
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": UPSTREAM_USER_AGENT,
        },
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.load(response)


def web_search(query, max_results=5):
    """Perform web search using DuckDuckGo HTML scraping (no API key needed)"""
    try:
        encoded_query = urllib.parse.quote_plus(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded_query}"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
        }
        request = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(request, timeout=10) as response:
            html = response.read().decode('utf-8', errors='ignore')
        
        results = []
        # Simple regex to extract results
        for match in re.finditer(r'<a rel="nofollow" class="result__a" href="([^"]+)"[^>]*>([^<]+)</a>', html):
            link = match.group(1)
            title = match.group(2)
            # Extract snippet if available
            snippet_match = re.search(r'<a class="result__snippet" href="[^"]+">([^<]+)</a>', html[match.start():match.start()+500])
            snippet = snippet_match.group(1) if snippet_match else ""
            if link and title and not link.startswith('/'):
                results.append({
                    "title": title.strip(),
                    "link": link.strip(),
                    "snippet": snippet.strip()
                })
                if len(results) >= max_results:
                    break
        return results
    except Exception as e:
        return []


def get_web_search_context(query):
    """Get search results and format as context"""
    results = web_search(query)
    if not results:
        return ""
    context = "\n\n[Web Search Results]\n"
    for i, result in enumerate(results, 1):
        context += f"{i}. {result['title']}\n   {result['link']}\n   {result['snippet']}\n\n"
    return context


def pcm_to_wav(pcm, rate=24000, channels=1, sample_width=2):
    buffer = io.BytesIO()
    with wave.open(buffer, "wb") as wav_file:
        wav_file.setnchannels(channels)
        wav_file.setsampwidth(sample_width)
        wav_file.setframerate(rate)
        wav_file.writeframes(pcm)
    return buffer.getvalue()


def parse_audio_mime(mime):
    rate = 24000
    channels = 1
    match = re.search(r"rate=(\d+)", mime or "")
    if match:
        rate = int(match.group(1))
    match = re.search(r"channels=(\d+)", mime or "")
    if match:
        channels = int(match.group(1))
    return rate, channels


def model_family(model):
    name = model.lower().strip()
    if name.startswith("opencode/"):
        name = name.split("/", 1)[1]
    if name.startswith("gemini"):
        return "google"
    if name.startswith(("claude", "qwen")):
        return "anthropic"
    if name.startswith(("gpt", "grok", "muse", "o1", "o3", "o4")):
        return "responses"
    if name.startswith("jev"):
        return "systemone"
    return "openai"


def is_free_model(model):
    name = model.lower()
    return name.endswith("-free") or name == "big-pickle"


def model_label(model):
    text = model
    lowered = text.lower()
    for brand, label in sorted(BRANDS.items(), key=lambda item: len(item[0]), reverse=True):
        if lowered.startswith(brand):
            text = label + text[len(brand):]
            break
    text = re.sub(r"([A-Za-z])(\d)", r"\1 \2", text)
    parts = re.split(r"[-_]", text)
    words = []
    for part in parts:
        if not part:
            continue
        low = part.lower()
        if low in SHORT_WORDS:
            words.append(SHORT_WORDS[low])
        elif low == "free":
            words.append("Free")
        elif part.isupper() and len(part) <= 4:
            words.append(part)
        elif any(ch.isdigit() for ch in part):
            words.append(part)
        else:
            words.append(part[:1].upper() + part[1:])
    return " ".join(words) or model


def normalize_models(model_ids):
    seen = set()
    models = []
    for model_id in model_ids:
        if not isinstance(model_id, str):
            continue
        model_id = model_id.strip()
        if not model_id or model_id in seen:
            continue
        seen.add(model_id)
        family = model_family(model_id)
        if family == "systemone" or model_id == "test":
            continue
        models.append(
            {
                "id": model_id,
                "label": model_label(model_id),
                "family": family,
                "free": is_free_model(model_id),
                "recommended": model_id in RECOMMENDED_ORDER,
            }
        )

    def sort_key(item):
        try:
            rank = RECOMMENDED_ORDER.index(item["id"])
        except ValueError:
            rank = len(RECOMMENDED_ORDER)
        return (rank, item["free"], item["label"].lower())

    models.sort(key=sort_key)
    return models


def fetch_models(config, force=False):
    now = time.time()
    with _models_lock:
        cached = _models_cache["models"]
        if not force and cached is not None and now - _models_cache["at"] < MODELS_CACHE_SECONDS:
            return cached, _models_cache["source"]

    key = config.get("api_key")
    gemini = is_gemini_api(config)
    if key:
        try:
            if gemini:
                url = gemini_models_url(config)
                headers = {
                    "x-goog-api-key": key,
                    "Accept": "application/json",
                    "User-Agent": UPSTREAM_USER_AGENT,
                }
            else:
                url = f"{config['base_url']}/v1/models"
                headers = {
                    "Authorization": f"Bearer {key}",
                    "Accept": "application/json",
                    "User-Agent": UPSTREAM_USER_AGENT,
                }
            request = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(request, timeout=30) as response:
                payload = json.load(response)
            items = payload.get("data") or payload.get("models") or []
            ids = []
            for item in items:
                if not isinstance(item, dict):
                    continue
                model_id = item.get("id") or item.get("name") or ""
                if not isinstance(model_id, str):
                    continue
                if model_id.startswith("models/"):
                    model_id = model_id.split("/", 1)[1]
                methods = item.get("supportedGenerationMethods")
                if gemini and methods and "generateContent" not in methods:
                    continue
                if gemini and not model_id.startswith("gemini-"):
                    continue
                if gemini and any(part in model_id.lower() for part in ("embedding", "image", "tts", "computer-use")):
                    continue
                ids.append(model_id)
            models = normalize_models(ids)
            if models:
                with _models_lock:
                    _models_cache.update({"at": now, "models": models, "source": "live"})
                return models, "live"
        except (urllib.error.URLError, urllib.error.HTTPError, ValueError, OSError, TimeoutError) as exc:
            print(f"Model list request failed: {exc}", file=sys.stderr)

    fallback = GEMINI_FALLBACK_MODEL_IDS if gemini else FALLBACK_MODEL_IDS
    models = normalize_models(fallback)
    with _models_lock:
        _models_cache.update({"at": now, "models": models, "source": "fallback"})
    return models, "fallback"


def extract_error_message(status, body):
    text = (body or "").strip()
    message = ""
    try:
        payload = json.loads(text)
        if isinstance(payload, dict):
            error = payload.get("error")
            if isinstance(error, dict):
                message = error.get("message") or ""
            elif isinstance(error, str):
                message = error
            if not message:
                message = payload.get("message") or payload.get("detail") or ""
    except ValueError:
        pass
    if not message:
        message = text[:600]
    return message or f"OpenCode returned HTTP {status}."


def describe_upstream_error(status, body):
    raw = extract_error_message(status, body)
    low = f"{raw} {body or ''}".lower()

    if status == 402 or "insufficient account funds" in low or "insufficient" in low and "fund" in low:
        return {
            "code": "insufficient_funds",
            "message": "This OpenCode Console account does not have enough credits for that request.",
            "hint": "Add credits in the OpenCode Console, then try again. Free models only work inside the official OpenCode app.",
            "url": "https://opencode.ai/console",
            "detail": raw[:500],
        }
    if "free usage limit" in low or ("free" in low and status == 429):
        return {
            "code": "free_limit",
            "message": "The free-model limit has been reached for this account.",
            "hint": "Free models are restricted to the official OpenCode app. Add credits or use OpenCode Go, then choose a paid model here.",
            "url": "https://opencode.ai/console",
            "detail": raw[:500],
        }
    if "model access is disabled" in low or "model access disabled" in low:
        return {
            "code": "model_disabled",
            "message": "That model is disabled for this workspace or API key.",
            "hint": "Choose another model, or enable it for the workspace in the OpenCode Console.",
            "url": "https://opencode.ai/console",
            "detail": raw[:500],
        }
    if status == 401 or "invalid api key" in low or "unauthorized" in low:
        return {
            "code": "unauthorized",
            "message": "The OpenCode API key was rejected.",
            "hint": "Check the api_key value in config.json, or create a new key in the Console.",
            "url": "https://opencode.ai/console",
            "detail": raw[:500],
        }
    if status == 403 and "1010" in low:
        return {
            "code": "blocked",
            "message": "The upstream gateway blocked the request.",
            "hint": "Try again in a moment. If it keeps happening, check your network or proxy.",
            "detail": raw[:500],
        }
    if status == 429:
        return {
            "code": "rate_limited",
            "message": "OpenCode is rate limiting requests right now.",
            "hint": "Wait a few seconds and try again.",
            "detail": raw[:500],
        }
    if status >= 500:
        return {
            "code": "upstream_unavailable",
            "message": "The model provider is temporarily unavailable.",
            "hint": "Try again, or choose a different model.",
            "detail": raw[:500],
        }
    return {
        "code": "upstream_error",
        "message": raw[:500] or f"OpenCode returned HTTP {status}.",
        "hint": "Try again or choose a different model.",
        "detail": raw[:500],
    }


def build_upstream_request(config, model, family, messages, system, temperature, max_tokens, direct_gemini=False):
    base = config["base_url"]
    body = None
    url = None

    if direct_gemini:
        url = f"{base}/chat/completions"
        upstream_messages = []
        if system:
            upstream_messages.append({"role": "system", "content": system})
        upstream_messages.extend(messages)
        body = {
            "model": model,
            "messages": upstream_messages,
            "stream": False,
        }
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens:
            body["max_tokens"] = max_tokens

    elif family == "openai":
        url = f"{base}/openai/v1/chat/completions"
        upstream_messages = []
        if system:
            upstream_messages.append({"role": "system", "content": system})
        upstream_messages.extend(messages)
        body = {
            "model": model,
            "messages": upstream_messages,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens:
            body["max_tokens"] = max_tokens

    elif family == "responses":
        url = f"{base}/openai/v1/responses"
        body = {"model": model, "input": messages, "stream": True}
        if system:
            body["instructions"] = system
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens:
            body["max_output_tokens"] = max_tokens

    elif family == "anthropic":
        url = f"{base}/anthropic/v1/messages"
        body = {
            "model": model,
            "max_tokens": max_tokens or 4096,
            "messages": messages,
            "stream": True,
        }
        if system:
            body["system"] = system
        if temperature is not None:
            body["temperature"] = temperature

    elif family == "google":
        encoded_model = urllib.parse.quote(model, safe="")
        url = f"{base}/google/v1beta/models/{encoded_model}:streamGenerateContent?alt=sse"
        contents = []
        for message in messages:
            role = "model" if message["role"] == "assistant" else "user"
            contents.append({"role": role, "parts": [{"text": message["content"]}]})
        body = {"contents": contents}
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}
        generation = {}
        if temperature is not None:
            generation["temperature"] = temperature
        if max_tokens:
            generation["maxOutputTokens"] = max_tokens
        if generation:
            body["generationConfig"] = generation

    if body is None:
        raise ValueError("Unsupported model family")

    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    if direct_gemini:
        headers = {
            "Authorization": f"Bearer {config['api_key']}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "User-Agent": UPSTREAM_USER_AGENT,
        }
    else:
        headers = {
            "Authorization": f"Bearer {config['api_key']}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "User-Agent": UPSTREAM_USER_AGENT,
        }
    request = urllib.request.Request(
        url,
        data=data,
        method="POST",
        headers=headers,
    )
    return request


class AppHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = f"RebbetAI/{VERSION}"

    def log_message(self, fmt, *args):
        if os.environ.get("REBBET_LOG") == "1":
            super().log_message(fmt, *args)

    def do_GET(self):
        parsed = urllib.parse.urlsplit(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if path == "/api/health":
            config = self.server.config
            self.send_json(
                200,
                {
                    "ok": True,
                    "app": APP_NAME,
                    "version": VERSION,
                    "module": MODULE_NAME,
                    "module_id": MODULE_ID,
                    "key_configured": bool(config["api_key"]),
                    "default_model": config["default_model"],
                    "bind": f"{config['host']}:{config['port']}",
                    "web_search": config.get("enable_web_search", True),
                    "auto_switch": config.get("auto_switch_model", True),
                    "voice_model": config.get("voice_model", "gemini-2.5-flash-preview-tts"),
                },
            )
            return
        
        if path == "/api/module" or path == "/api/rebbet":
            self.send_json(
                200,
                {
                    "name": MODULE_NAME,
                    "id": MODULE_ID,
                    "display_name": APP_NAME,
                    "version": VERSION,
                    "features": {
                        "web_search": True,
                        "internet_search": True,
                        "free_ai_models": True,
                        "auto_switch_on_limit": True,
                        "better_voice": True,
                        "fast_voice": True,
                    },
                    "free_models": FREE_MODELS,
                    "auto_switch_order": AUTO_SWITCH_ORDER,
                },
            )
            return

        if path == "/api/models":
            force = query.get("refresh", ["0"])[0] in ("1", "true", "yes")
            models, source = fetch_models(self.server.config, force=force)
            self.send_json(200, {"models": models, "source": source, "default": self.server.config["default_model"]})
            return

        if path == "/favicon.ico":
            self.serve_file(STATIC_DIR / "icon-192.png", cache=True)
            return

        file_path = self.resolve_file(path)
        if file_path is None:
            self.send_json(404, {"error": {"message": "Not found"}})
            return
        self.serve_file(file_path, cache=path.startswith("/static/"))

    def do_HEAD(self):
        self.do_GET()

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_cors_headers()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_POST(self):
        parsed = urllib.parse.urlsplit(self.path)
        if parsed.path == "/api/chat":
            self.handle_chat()
            return
        if parsed.path == "/api/search":
            self.handle_search()
            return
        if parsed.path == "/api/tts":
            self.handle_tts()
            return
        if parsed.path == "/api/transcribe":
            self.handle_transcribe()
            return
        self.send_json(404, {"error": {"message": "Not found"}})

    def resolve_file(self, path):
        relative = path.lstrip("/")
        if relative in ("", "index.html"):
            target = ROOT / "index.html"
        elif relative in ("manifest.json", "service-worker.js"):
            target = ROOT / relative
        elif relative.startswith("static/"):
            target = ROOT / relative
        else:
            return None
        try:
            resolved = target.resolve()
            resolved.relative_to(ROOT)
        except (ValueError, OSError):
            return None
        if not resolved.is_file():
            return None
        return resolved

    def content_type_for(self, path):
        suffix = path.suffix.lower()
        overrides = {
            ".html": "text/html; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".js": "text/javascript; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".webmanifest": "application/manifest+json; charset=utf-8",
            ".svg": "image/svg+xml",
            ".png": "image/png",
            ".ico": "image/x-icon",
            ".txt": "text/plain; charset=utf-8",
        }
        return overrides.get(suffix) or mimetypes.guess_type(str(path))[0] or "application/octet-stream"

    def serve_file(self, path, cache=False):
        try:
            data = path.read_bytes()
        except OSError:
            self.send_json(404, {"error": {"message": "Not found"}})
            return
        self.send_response(200)
        self.send_header("Content-Type", self.content_type_for(path))
        self.send_header("Content-Length", str(len(data)))
        if cache:
            self.send_header("Cache-Control", "public, max-age=3600")
        else:
            self.send_header("Cache-Control", "no-cache")
        if path.name == "service-worker.js":
            self.send_header("Service-Worker-Allowed", "/")
        self.send_cors_headers()
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "86400")

    def send_bytes(self, status, data, content_type):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_cors_headers()
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def send_json(self, status, payload):
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_cors_headers()
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def send_api_error(self, status, info):
        self.send_json(status, {"error": info})

    def handle_search(self):
        try:
            payload = self.read_json_body()
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return
        query = payload.get("query", "")
        if not isinstance(query, str) or not query.strip():
            self.send_api_error(400, {"code": "bad_request", "message": "query is required"})
            return
        results = web_search(query.strip(), max_results=payload.get("max_results", 5))
        self.send_json(200, {"results": results, "query": query.strip()})

    def read_json_body(self, max_bytes=MAX_BODY):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise ValueError("Invalid Content-Length")
        if length <= 0:
            raise ValueError("Request body is required")
        if length > max_bytes:
            raise ValueError("Request body is too large")
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            raise ValueError("Request body must be valid JSON")
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object")
        return payload

    def handle_chat(self):
        config = self.server.config
        if not config["api_key"]:
            self.send_api_error(
                503,
                {
                    "code": "no_key",
                    "message": "No API key is configured.",
                    "hint": "Add an OpenCode or Gemini api_key to config.json, then restart the server.",
                    "url": "https://opencode.ai/console",
                },
            )
            return

        direct_gemini = is_gemini_api(config)

        try:
            payload = self.read_json_body()
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return

        raw_messages = payload.get("messages")
        if not isinstance(raw_messages, list) or not raw_messages:
            self.send_api_error(400, {"code": "bad_request", "message": "messages must be a non-empty array"})
            return
        if len(raw_messages) > MAX_MESSAGES:
            self.send_api_error(400, {"code": "bad_request", "message": f"Too many messages (max {MAX_MESSAGES})"})
            return

        messages = []
        for item in raw_messages:
            if not isinstance(item, dict):
                self.send_api_error(400, {"code": "bad_request", "message": "Each message must be an object"})
                return
            role = item.get("role")
            content = item.get("content")
            if role not in ("user", "assistant") or not isinstance(content, str):
                self.send_api_error(400, {"code": "bad_request", "message": "Messages need a user/assistant role and text content"})
                return
            content = content[:MAX_MESSAGE_CHARS]
            if not content.strip() and role == "user":
                self.send_api_error(400, {"code": "bad_request", "message": "User messages cannot be empty"})
                return
            messages.append({"role": role, "content": content})

        if messages[-1]["role"] != "user":
            self.send_api_error(400, {"code": "bad_request", "message": "The last message must be from the user"})
            return

        model = payload.get("model") or config["default_model"]
        if not isinstance(model, str) or not model.strip() or len(model) > 160:
            self.send_api_error(400, {"code": "bad_request", "message": "Invalid model id"})
            return
        model = model.strip()
        family = "openai" if direct_gemini else model_family(model)
        if family == "systemone":
            self.send_api_error(400, {"code": "bad_request", "message": "That model is not a chat model"})
            return

        system = payload.get("system")
        if system is None:
            system = DEFAULT_SYSTEM_PROMPT
        if not isinstance(system, str):
            self.send_api_error(400, {"code": "bad_request", "message": "system must be text"})
            return
        system = system.strip()[:20000]
        
        # Auto web search for time-sensitive queries
        enable_search = payload.get("web_search", config.get("enable_web_search", True))
        if enable_search and messages:
            last_user_msg = messages[-1]["content"].lower()
            if any(keyword in last_user_msg for keyword in ["news", "current", "today", "latest", "weather", "price", "stock", "score", "update", "now", "2025", "2026"]):
                try:
                    search_ctx = get_web_search_context(messages[-1]["content"])
                    if search_ctx:
                        system += search_ctx
                except:
                    pass

        temperature = payload.get("temperature")
        if temperature is not None:
            if not isinstance(temperature, (int, float)) or isinstance(temperature, bool):
                self.send_api_error(400, {"code": "bad_request", "message": "temperature must be a number"})
                return
            temperature = max(0.0, min(2.0, float(temperature)))

        max_tokens = payload.get("max_tokens")
        if max_tokens is not None:
            if not isinstance(max_tokens, int) or isinstance(max_tokens, bool) or not 1 <= max_tokens <= 65536:
                self.send_api_error(400, {"code": "bad_request", "message": "max_tokens must be an integer from 1 to 65536"})
                return

        try:
            request = build_upstream_request(
                config,
                model,
                family,
                messages,
                system,
                temperature,
                max_tokens,
                direct_gemini=direct_gemini,
            )
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return

        try:
            upstream = urllib.request.urlopen(request, timeout=config["request_timeout"])
        except urllib.error.HTTPError as exc:
            body = ""
            try:
                body = exc.read(16384).decode("utf-8", "replace")
            except OSError:
                pass
            info = describe_upstream_error(exc.code, body)
            # Auto-switch to free model if limit hit
            if config.get("auto_switch_model", True) and info.get("code") in ("free_limit", "rate_limited") and model not in FREE_MODELS:
                for alt_model in AUTO_SWITCH_ORDER:
                    if alt_model == model:
                        continue
                    try:
                        alt_family = "openai" if direct_gemini else model_family(alt_model)
                        if alt_family == "systemone":
                            continue
                        alt_request = build_upstream_request(
                            config,
                            alt_model,
                            alt_family,
                            messages,
                            system,
                            temperature,
                            max_tokens,
                            direct_gemini=direct_gemini,
                        )
                        upstream = urllib.request.urlopen(alt_request, timeout=config["request_timeout"])
                        model = alt_model
                        family = alt_family
                        break
                    except Exception:
                        continue
                else:
                    status = exc.code if 400 <= exc.code < 500 else 502
                    self.send_api_error(status, info)
                    return
            else:
                status = exc.code if 400 <= exc.code < 500 else 502
                self.send_api_error(status, info)
                return
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            self.send_api_error(
                502,
                {
                    "code": "network_error",
                    "message": "Could not reach OpenCode.",
                    "hint": "Check your internet connection and try again.",
                    "detail": str(exc)[:300],
                },
            )
            return

        with upstream:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache, no-transform")
            self.send_header("Connection", "close")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            self.close_connection = True

            try:
                self.send_event(
                    {
                        "type": "meta",
                        "model": model,
                        "family": family,
                    }
                )
                if direct_gemini:
                    raw = upstream.read()
                    try:
                        payload = json.loads(raw.decode('utf-8'))
                    except Exception:
                        raise UpstreamStreamError({"code": "upstream_error", "message": "Bad response from Gemini"})
                    usage = None
                    if isinstance(payload, dict):
                        if payload.get('usage'):
                            usage = payload.get('usage')
                        choices = payload.get('choices') or []
                        for choice in choices:
                            msg = choice.get('message') or {}
                            text = msg.get('content')
                            if isinstance(text, str) and text:
                                self.emit_delta(text)
                            elif isinstance(text, list):
                                for part in text:
                                    if isinstance(part, dict) and isinstance(part.get('text'), str):
                                        self.emit_delta(part['text'])
                    self.send_event({"type": "done", "usage": usage})
                else:
                    usage = self.stream_upstream(upstream, family)
                    self.send_event({"type": "done", "usage": usage})
            except UpstreamStreamError as exc:
                try:
                    self.send_event({"type": "error", **exc.info})
                except (BrokenPipeError, ConnectionResetError):
                    pass
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass
            except (TimeoutError, socket.timeout, OSError) as exc:
                try:
                    self.send_event(
                        {
                            "type": "error",
                            "code": "stream_interrupted",
                            "message": "The response stream was interrupted.",
                            "hint": "Try again.",
                            "detail": str(exc)[:300],
                        }
                    )
                except (BrokenPipeError, ConnectionResetError):
                    pass

    def voice_config_error(self):
        config = self.server.config
        if not config["api_key"]:
            self.send_api_error(
                503,
                {
                    "code": "no_key",
                    "message": "No API key is configured.",
                    "hint": "Add a Gemini api_key to config.json, then restart the server.",
                },
            )
            return True
        if not is_gemini_api(config):
            self.send_api_error(
                400,
                {
                    "code": "voice_unsupported",
                    "message": "Voice features need the Gemini provider.",
                    "hint": "Set provider to gemini in config.json.",
                },
            )
            return True
        return False

    def handle_tts(self):
        if self.voice_config_error():
            return
        config = self.server.config
        try:
            payload = self.read_json_body(max_bytes=256 * 1024)
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return

        text = payload.get("text")
        if not isinstance(text, str) or not text.strip():
            self.send_api_error(400, {"code": "bad_request", "message": "text is required"})
            return
        text = text.strip()[:MAX_TTS_CHARS]

        voice = payload.get("voice")
        if not isinstance(voice, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", voice):
            voice = DEFAULT_VOICE

        # Use faster voice model if configured
        tts_model = config.get("voice_model", TTS_MODEL)
        if not tts_model or tts_model == "":
            tts_model = TTS_MODEL

        body = {
            "contents": [{"parts": [{"text": text}]}],
            "generationConfig": {
                "responseModalities": ["AUDIO"],
                "speechConfig": {
                    "voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}
                },
            },
        }

        try:
            result = gemini_native_request(config, tts_model, body, timeout=60)
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")
            status = exc.code if exc.code in (400, 401, 403, 404, 429) else 502
            self.send_api_error(
                status,
                {
                    "code": "tts_error",
                    "message": extract_error_message(exc.code, detail),
                    "detail": detail[:500],
                },
            )
            return
        except (urllib.error.URLError, OSError) as exc:
            self.send_api_error(
                502,
                {
                    "code": "tts_unavailable",
                    "message": "Could not reach the voice service.",
                    "hint": "Check your internet connection and try again.",
                    "detail": str(exc)[:300],
                },
            )
            return

        audio = bytearray()
        mime = ""
        try:
            candidates = result.get("candidates") or []
            parts = (candidates[0].get("content") or {}).get("parts") or []
            for part in parts:
                inline = part.get("inlineData") or part.get("inline_data")
                if not isinstance(inline, dict):
                    continue
                data = inline.get("data")
                if not isinstance(data, str):
                    continue
                audio.extend(base64.b64decode(data))
                mime = inline.get("mimeType") or inline.get("mime_type") or mime
        except (IndexError, AttributeError, ValueError, TypeError):
            audio = bytearray()

        if not audio:
            self.send_api_error(
                502,
                {
                    "code": "tts_error",
                    "message": "The voice service returned no audio.",
                    "hint": "Try a shorter message or try again.",
                },
            )
            return

        if mime.startswith(("audio/wav", "audio/x-wav")):
            self.send_bytes(200, bytes(audio), "audio/wav")
        elif mime.startswith(("audio/mpeg", "audio/mp3")):
            self.send_bytes(200, bytes(audio), "audio/mpeg")
        else:
            rate, channels = parse_audio_mime(mime)
            wav = pcm_to_wav(bytes(audio), rate=rate, channels=channels)
            self.send_bytes(200, wav, "audio/wav")

    def handle_transcribe(self):
        if self.voice_config_error():
            return
        config = self.server.config
        try:
            payload = self.read_json_body(max_bytes=MAX_AUDIO_BYTES * 2)
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return

        encoded = payload.get("audio")
        if not isinstance(encoded, str) or not encoded.strip():
            self.send_api_error(400, {"code": "bad_request", "message": "audio is required"})
            return
        try:
            audio = base64.b64decode(encoded)
        except (ValueError, TypeError):
            self.send_api_error(400, {"code": "bad_request", "message": "audio must be base64 encoded"})
            return
        if not audio:
            self.send_api_error(400, {"code": "bad_request", "message": "audio is empty"})
            return
        if len(audio) > MAX_AUDIO_BYTES:
            self.send_api_error(413, {"code": "too_large", "message": "Audio clip is too large."})
            return

        mime = payload.get("mimeType")
        if not isinstance(mime, str) or not mime.startswith("audio/"):
            mime = "audio/wav"
        prompt = payload.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            prompt = "Transcribe this audio exactly. Return only the transcript without commentary."

        body = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt},
                        {
                            "inlineData": {
                                "mimeType": mime,
                                "data": base64.b64encode(audio).decode("ascii"),
                            }
                        },
                    ]
                }
            ]
        }

        try:
            result = gemini_native_request(config, TRANSCRIBE_MODEL, body, timeout=120)
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")
            status = exc.code if exc.code in (400, 401, 403, 404, 429) else 502
            self.send_api_error(
                status,
                {
                    "code": "transcribe_error",
                    "message": extract_error_message(exc.code, detail),
                    "detail": detail[:500],
                },
            )
            return
        except (urllib.error.URLError, OSError) as exc:
            self.send_api_error(
                502,
                {
                    "code": "transcribe_unavailable",
                    "message": "Could not reach the transcription service.",
                    "hint": "Check your internet connection and try again.",
                    "detail": str(exc)[:300],
                },
            )
            return

        text = ""
        try:
            candidates = result.get("candidates") or []
            parts = (candidates[0].get("content") or {}).get("parts") or []
            text = "".join(part.get("text", "") for part in parts if isinstance(part, dict)).strip()
        except (IndexError, AttributeError, TypeError):
            text = ""

        if not text:
            self.send_api_error(
                422,
                {
                    "code": "no_speech",
                    "message": "No speech was detected in that recording.",
                    "hint": "Try recording again in a quieter place.",
                },
            )
            return
        self.send_json(200, {"text": text})

    def send_event(self, event):
        data = json.dumps(event, ensure_ascii=False).encode("utf-8")
        self.wfile.write(b"data: " + data + b"\n\n")
        self.wfile.flush()

    def stream_upstream(self, upstream, family):
        if family == "anthropic":
            return self.stream_anthropic(upstream)
        if family == "google":
            return self.stream_google(upstream)
        if family == "responses":
            return self.stream_responses(upstream)
        return self.stream_openai(upstream)

    def emit_delta(self, text):
        if text:
            self.send_event({"type": "delta", "text": text})

    def emit_thinking(self):
        self.send_event({"type": "thinking"})

    def stream_openai(self, upstream):
        usage = None
        for raw_line in upstream:
            line = raw_line.decode("utf-8", "replace").strip()
            if not line or line.startswith(":") or not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                payload = json.loads(data)
            except ValueError:
                continue
            if not isinstance(payload, dict):
                continue
            if "error" in payload:
                raise UpstreamStreamError(describe_upstream_error(502, json.dumps(payload)))
            if payload.get("usage"):
                usage = payload["usage"]
            for choice in payload.get("choices") or []:
                delta = choice.get("delta") or {}
                text = delta.get("content")
                if isinstance(text, str) and text:
                    self.emit_delta(text)
                reasoning = delta.get("reasoning_content") or delta.get("reasoning")
                if reasoning:
                    self.emit_thinking()
        return usage

    def stream_responses(self, upstream):
        usage = None
        emitted = False
        for raw_line in upstream:
            line = raw_line.decode("utf-8", "replace").strip()
            if not line or line.startswith(":") or not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                payload = json.loads(data)
            except ValueError:
                continue
            if not isinstance(payload, dict):
                continue
            event_type = payload.get("type")
            if event_type == "response.output_text.delta":
                delta = payload.get("delta")
                if isinstance(delta, str) and delta:
                    emitted = True
                    self.emit_delta(delta)
            elif event_type in ("response.output_text.done", "response.refusal.delta"):
                delta = payload.get("text") or payload.get("delta")
                if not emitted and isinstance(delta, str) and delta:
                    emitted = True
                    self.emit_delta(delta)
            elif event_type in ("response.reasoning_summary_text.delta", "response.reasoning_text.delta"):
                self.emit_thinking()
            elif event_type == "response.completed":
                response = payload.get("response") or {}
                usage = response.get("usage") or usage
                if not emitted:
                    emitted = self.emit_response_output(response)
            elif event_type in ("response.failed", "response.incomplete"):
                response = payload.get("response") or {}
                error = response.get("error") or {}
                message = error.get("message") or "The model did not complete the response."
                raise UpstreamStreamError(
                    {
                        "code": "upstream_error",
                        "message": message,
                        "hint": "Try again or choose a different model.",
                    }
                )
            elif event_type == "error" or "error" in payload:
                raise UpstreamStreamError(describe_upstream_error(502, json.dumps(payload)))
        return usage

    def emit_response_output(self, response):
        emitted = False
        for item in response.get("output") or []:
            if not isinstance(item, dict) or item.get("type") != "message":
                continue
            for content in item.get("content") or []:
                if isinstance(content, dict) and content.get("type") in ("output_text", "text"):
                    text = content.get("text")
                    if isinstance(text, str) and text:
                        self.emit_delta(text)
                        emitted = True
        return emitted

    def stream_anthropic(self, upstream):
        usage = {}
        for raw_line in upstream:
            line = raw_line.decode("utf-8", "replace").strip()
            if not line or line.startswith(":") or not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                payload = json.loads(data)
            except ValueError:
                continue
            if not isinstance(payload, dict):
                continue
            event_type = payload.get("type")
            if event_type == "content_block_delta":
                delta = payload.get("delta") or {}
                if delta.get("type") == "text_delta":
                    self.emit_delta(delta.get("text"))
                elif delta.get("type") == "thinking_delta":
                    self.emit_thinking()
                elif isinstance(delta.get("text"), str):
                    self.emit_delta(delta["text"])
            elif event_type == "content_block_start":
                block = payload.get("content_block") or {}
                if isinstance(block.get("text"), str) and block["text"]:
                    self.emit_delta(block["text"])
            elif event_type == "message_start":
                block_usage = (payload.get("message") or {}).get("usage") or {}
                usage.update(block_usage)
            elif event_type == "message_delta":
                usage.update(payload.get("usage") or {})
            elif event_type == "message_stop":
                break
            elif event_type == "error":
                error = payload.get("error") or {}
                message = error.get("message") or "The model returned an error."
                raise UpstreamStreamError(
                    {
                        "code": "upstream_error",
                        "message": message,
                        "hint": "Try again or choose a different model.",
                    }
                )
        return usage or None

    def stream_google(self, upstream):
        usage = None
        for raw_line in upstream:
            line = raw_line.decode("utf-8", "replace").strip()
            if not line or line.startswith(":") or not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                payload = json.loads(data)
            except ValueError:
                continue
            if not isinstance(payload, dict):
                continue
            if "error" in payload and not payload.get("candidates"):
                raise UpstreamStreamError(describe_upstream_error(502, json.dumps(payload)))
            metadata = payload.get("usageMetadata")
            if metadata:
                usage = {
                    "prompt_tokens": metadata.get("promptTokenCount"),
                    "completion_tokens": metadata.get("candidatesTokenCount"),
                    "total_tokens": metadata.get("totalTokenCount"),
                    "cost": metadata.get("cost"),
                }
            for candidate in payload.get("candidates") or []:
                content = candidate.get("content") or {}
                for part in content.get("parts") or []:
                    text = part.get("text")
                    if isinstance(text, str) and text:
                        if part.get("thought"):
                            self.emit_thinking()
                        else:
                            self.emit_delta(text)
        return usage


class RebbetServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 32


def start_server(config):
    host = config["host"]
    port = config["port"]
    last_error = None
    for candidate in range(port, port + 11):
        try:
            server = RebbetServer((host, candidate), AppHandler)
            server.config = config
            config["port"] = candidate
            return server
        except OSError as exc:
            last_error = exc
            if exc.errno in (48, 98, 10048):
                continue
            raise
    raise last_error or OSError("Could not bind a port")


def main():
    config = load_config()
    try:
        server = start_server(config)
    except OSError as exc:
        print(f"Could not start {APP_NAME}: {exc}", file=sys.stderr)
        return 1

    display_host = "127.0.0.1" if config["host"] in ("0.0.0.0", "::") else config["host"]
    print(f"{APP_NAME} {VERSION}")
    print(f"Open: http://{display_host}:{config['port']}")
    print(f"Model: {config['default_model']}")
    if not config["api_key"]:
        print("Warning: no API key configured. Add api_key to config.json or set OPENCODE_API_KEY.", file=sys.stderr)
    print("Press Ctrl+C to stop.")

    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("\nStopping.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
