# Rebbet AI

A clean, mobile-first chat app for the [OpenCode Console](https://opencode.ai/console) API.

## Features
- Fast streaming chat with OpenCode models
- Model picker with search, recommendations, and free badges
- Multi-chat history saved locally
- PWA support (installable, offline shell)
- Clean dark UI optimized for phones
- Smart error messages for common limits (credits, free-model restrictions)

## Quick start
1. Put your OpenCode API key in `config.json` (or set `OPENCODE_API_KEY`).
2. Run the server:
   ```bash
   python3 app.py
   ```
   Or:
   ```bash
   ./run.sh
   ```
3. Open `http://127.0.0.1:8765` in your browser.

## Config
Edit `config.json`:
- `api_key` - OpenCode Console API key
- `default_model` - Model id to use by default
- `host` / `port` - Bind address/port
- `base_url` - Usually `https://opencode.ai/inference`

## Notes
- Free models are often restricted to the official OpenCode app. If you hit free limits, add credits or use a paid model.
- Some models use different API families; this app handles OpenAI Chat Completions, Responses, Anthropic Messages, and Gemini.
