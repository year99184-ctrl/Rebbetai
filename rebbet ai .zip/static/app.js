const DEFAULT_MODEL = 'gemini-3.5-flash';
const API_PORTS = [8765, 8766, 8767, 8768, 8769, 8770, 8771, 8772, 8773, 8774, 8775];

let apiBase = null;
let apiBasePromise = null;

function candidateApiBases() {
  const bases = [];
  if (location.protocol === 'http:' || location.protocol === 'https:') {
    bases.push(location.origin);
  }
  API_PORTS.forEach(function(port) {
    bases.push('http://127.0.0.1:' + port);
    bases.push('http://localhost:' + port);
  });
  return bases.filter(function(base, index) {
    return bases.indexOf(base) === index;
  });
}

async function probeApiBase(base) {
  const controller = new AbortController();
  const timer = setTimeout(function() { controller.abort(); }, 1500);
  try {
    const res = await fetch(base + '/api/health', {
      cache: 'no-store',
      signal: controller.signal
    });
    if (!res.ok) return false;
    const data = await res.json();
    return !!(data && data.ok);
  } catch (e) {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

function resolveApiBase() {
  if (apiBase !== null) return Promise.resolve(apiBase);
  if (!apiBasePromise) {
    apiBasePromise = (async function() {
      const bases = candidateApiBases();
      for (let i = 0; i < bases.length; i++) {
        if (await probeApiBase(bases[i])) {
          apiBase = bases[i];
          return apiBase;
        }
      }
      apiBase = '';
      return apiBase;
    })();
  }
  return apiBasePromise;
}

function resetApiBase() {
  apiBase = null;
  apiBasePromise = null;
}

async function apiFetch(path, options) {
  const base = await resolveApiBase();
  return fetch(base + path, options);
}

var voice = {
  enabled: false,
  recording: false,
  chunks: [],
  stream: null,
  audioContext: null,
  source: null,
  processor: null,
  recordTimer: null,
  audio: null,
  audioUrl: null
};

function loadVoicePref() {
  try {
    voice.enabled = localStorage.getItem('rebbet_voice') === '1';
  } catch (e) {
    voice.enabled = false;
  }
  updateVoiceToggle();
}

function updateVoiceToggle() {
  if (!els.voiceToggle) return;
  els.voiceToggle.classList.toggle('is-on', voice.enabled);
  els.voiceToggle.setAttribute('aria-pressed', voice.enabled ? 'true' : 'false');
  els.voiceToggle.setAttribute('aria-label', voice.enabled ? 'Voice replies on' : 'Voice replies off');
}

function toggleVoice() {
  voice.enabled = !voice.enabled;
  try {
    localStorage.setItem('rebbet_voice', voice.enabled ? '1' : '0');
  } catch (e) {}
  updateVoiceToggle();
  showToast(voice.enabled ? 'Voice replies on' : 'Voice replies off');
  if (!voice.enabled) stopSpeaking();
}

function speakableText(text) {
  var out = String(text || '');
  out = out.replace(/```[\s\S]*?```/g, ' ');
  out = out.replace(/`([^`]*)`/g, '$1');
  out = out.replace(/!\[[^\]]*\]\([^)]*\)/g, ' ');
  out = out.replace(/\[([^\]]+)\]\([^)]*\)/g, '$1');
  out = out.replace(/[*_#>|~]/g, ' ');
  out = out.replace(/\s+/g, ' ').trim();
  if (out.length > 3500) out = out.slice(0, 3500);
  return out;
}

function stopSpeaking() {
  if (voice.audio) {
    try { voice.audio.pause(); } catch (e) {}
    voice.audio = null;
  }
  if (voice.audioUrl) {
    URL.revokeObjectURL(voice.audioUrl);
    voice.audioUrl = null;
  }
}

async function speak(text) {
  var clean = speakableText(text);
  if (!clean) return;
  stopSpeaking();
  try {
    var res = await apiFetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: clean })
    });
    if (!res.ok) {
      var info = null;
      try { info = await res.json(); } catch (e) {}
      var message = info && info.error && info.error.message ? info.error.message : 'Voice failed';
      showToast('Voice: ' + message);
      return;
    }
    var blob = await res.blob();
    voice.audioUrl = URL.createObjectURL(blob);
    voice.audio = new Audio(voice.audioUrl);
    voice.audio.onended = function() { stopSpeaking(); };
    await voice.audio.play();
  } catch (e) {
    showToast('Voice unavailable');
  }
}

function downsampleBuffer(buffer, inRate, outRate) {
  if (outRate >= inRate) return buffer;
  var ratio = inRate / outRate;
  var length = Math.round(buffer.length / ratio);
  var result = new Float32Array(length);
  var offsetResult = 0;
  var offsetBuffer = 0;
  while (offsetResult < length) {
    var nextOffsetBuffer = Math.round((offsetResult + 1) * ratio);
    var accum = 0;
    var count = 0;
    for (var i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i++) {
      accum += buffer[i];
      count++;
    }
    result[offsetResult] = count ? accum / count : 0;
    offsetResult++;
    offsetBuffer = nextOffsetBuffer;
  }
  return result;
}

function encodeWav(samples, sampleRate) {
  var buffer = new ArrayBuffer(44 + samples.length * 2);
  var view = new DataView(buffer);
  function writeString(offset, str) {
    for (var i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
  }
  writeString(0, 'RIFF');
  view.setUint32(4, 36 + samples.length * 2, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, samples.length * 2, true);
  var offset = 44;
  for (var i = 0; i < samples.length; i++, offset += 2) {
    var s = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return buffer;
}

function arrayBufferToBase64(buffer) {
  var bytes = new Uint8Array(buffer);
  var binary = '';
  var chunk = 0x8000;
  for (var i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

async function startRecording() {
  if (voice.recording) return;
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    showToast('Voice input is not supported here');
    return;
  }
  if (!window.isSecureContext) {
    showToast('Voice input needs HTTPS or localhost');
    return;
  }
  try {
    var stream = await navigator.mediaDevices.getUserMedia({
      audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true }
    });
    var Ctx = window.AudioContext || window.webkitAudioContext;
    var ctx = new Ctx();
    if (ctx.state === 'suspended') await ctx.resume();
    var source = ctx.createMediaStreamSource(stream);
    var processor = ctx.createScriptProcessor(4096, 1, 1);
    voice.chunks = [];
    processor.onaudioprocess = function(e) {
      voice.chunks.push(new Float32Array(e.inputBuffer.getChannelData(0)));
    };
    source.connect(processor);
    processor.connect(ctx.destination);
    voice.stream = stream;
    voice.audioContext = ctx;
    voice.source = source;
    voice.processor = processor;
    voice.recording = true;
    els.composerMic.classList.add('is-recording');
    els.composerMic.setAttribute('aria-label', 'Stop recording');
    showToast('Recording… tap mic to stop');
    voice.recordTimer = setTimeout(function() { stopRecording(); }, 45000);
  } catch (e) {
    showToast('Microphone permission denied');
  }
}

function stopRecording() {
  if (!voice.recording) return;
  voice.recording = false;
  clearTimeout(voice.recordTimer);
  els.composerMic.classList.remove('is-recording');
  els.composerMic.setAttribute('aria-label', 'Record voice message');
  try { voice.processor.disconnect(); } catch (e) {}
  try { voice.source.disconnect(); } catch (e) {}
  try { voice.stream.getTracks().forEach(function(track) { track.stop(); }); } catch (e) {}
  var ctx = voice.audioContext;
  var sampleRate = ctx ? ctx.sampleRate : 48000;
  try { if (ctx) ctx.close(); } catch (e) {}
  voice.processor = null;
  voice.source = null;
  voice.stream = null;
  voice.audioContext = null;

  var chunks = voice.chunks || [];
  voice.chunks = [];
  if (!chunks.length) {
    showToast('No audio recorded');
    return;
  }
  var total = 0;
  chunks.forEach(function(c) { total += c.length; });
  var merged = new Float32Array(total);
  var offset = 0;
  chunks.forEach(function(c) {
    merged.set(c, offset);
    offset += c.length;
  });
  var downsampled = downsampleBuffer(merged, sampleRate, 16000);
  var wav = encodeWav(downsampled, 16000);
  transcribeAudio(wav);
}

async function transcribeAudio(wavBuffer) {
  showToast('Transcribing…');
  try {
    var res = await apiFetch('/api/transcribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        audio: arrayBufferToBase64(wavBuffer),
        mimeType: 'audio/wav'
      })
    });
    var data = null;
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) {
      var message = data && data.error && data.error.message ? data.error.message : 'Transcription failed';
      showToast('Voice: ' + message);
      return;
    }
    var text = data && data.text ? String(data.text).trim() : '';
    if (!text) {
      showToast('No speech detected');
      return;
    }
    var current = els.composerInput.value.trim();
    els.composerInput.value = (current ? current + ' ' : '') + text;
    autoResize();
    els.composerSend.disabled = state.sending || !els.composerInput.value.trim();
    els.composerInput.focus();
  } catch (e) {
    showToast('Transcription unavailable');
  }
}

function toggleRecording() {
  if (voice.recording) {
    stopRecording();
  } else {
    startRecording();
  }
}

const state = {
  models: [],
  modelsById: new Map(),
  selectedModel: null,
  chats: [],
  activeChatId: null,
  sending: false
};

const els = {
  menuBtn: document.getElementById('menuBtn'),
  sidebar: document.getElementById('sidebar'),
  sidebarClose: document.getElementById('sidebarClose'),
  sidebarBackdrop: document.getElementById('sidebarBackdrop'),
  sidebarList: document.getElementById('sidebarList'),
  sidebarNew: document.getElementById('sidebarNew'),
  newChatBtn: document.getElementById('newChatBtn'),
  modelTrigger: document.getElementById('modelTrigger'),
  modelSheet: document.getElementById('modelSheet'),
  modelBackdrop: document.getElementById('modelBackdrop'),
  modelClose: document.getElementById('modelClose'),
  modelLabel: document.getElementById('modelLabel'),
  modelContent: document.getElementById('modelContent'),
  modelSearch: document.getElementById('modelSearch'),
  thread: document.getElementById('thread'),
  composerInput: document.getElementById('composerInput'),
  composerMic: document.getElementById('composerMic'),
  composerSend: document.getElementById('composerSend'),
  voiceToggle: document.getElementById('voiceToggle'),
  toast: document.getElementById('toast')
};

function uid() {
  return 'c_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function nowTime() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function showToast(message) {
  els.toast.textContent = message;
  els.toast.classList.add('is-show');
  setTimeout(function() { els.toast.classList.remove('is-show'); }, 1800);
}

function openSidebar() {
  els.sidebar.classList.add('is-open');
  els.sidebarBackdrop.classList.add('is-open');
}

function closeSidebar() {
  els.sidebar.classList.remove('is-open');
  els.sidebarBackdrop.classList.remove('is-open');
}

function openModelSheet() {
  els.modelSheet.classList.add('is-open');
  els.modelTrigger.setAttribute('aria-expanded', 'true');
  els.modelSearch.value = '';
  renderModels(els.modelSearch.value);
  if (window.matchMedia('(min-width: 900px)').matches) {
    setTimeout(function() { els.modelSearch.focus(); }, 180);
  }
}

function closeModelSheet() {
  els.modelSheet.classList.remove('is-open');
  els.modelTrigger.setAttribute('aria-expanded', 'false');
}

function loadChats() {
  try {
    var raw = localStorage.getItem('rebbet_chats');
    if (raw) state.chats = JSON.parse(raw);
  } catch (e) {
    state.chats = [];
  }
  if (!state.chats.length) {
    createChat(true);
  } else if (!state.activeChatId || !state.chats.find(function(c){ return c.id === state.activeChatId; })) {
    state.activeChatId = state.chats[0].id;
  }
  renderSidebar();
  renderThread();
}

function saveChats() {
  try {
    localStorage.setItem('rebbet_chats', JSON.stringify(state.chats));
  } catch (e) {}
}

function createChat(silent) {
  var chat = {
    id: uid(),
    title: 'New chat',
    model: state.selectedModel || DEFAULT_MODEL,
    messages: [],
    createdAt: Date.now()
  };
  state.chats.unshift(chat);
  state.activeChatId = chat.id;
  saveChats();
  renderSidebar();
  renderThread();
  if (!silent) showToast('New chat created');
  closeSidebar();
}

function getActiveChat() {
  return state.chats.find(function(c){ return c.id === state.activeChatId; }) || null;
}

function deleteChat(chatId) {
  var idx = state.chats.findIndex(function(c){ return c.id === chatId; });
  if (idx === -1) return;
  state.chats.splice(idx, 1);
  if (state.activeChatId === chatId) {
    if (state.chats.length) {
      state.activeChatId = state.chats[0].id;
    } else {
      state.activeChatId = null;
      createChat(true);
      return;
    }
  }
  saveChats();
  renderSidebar();
  renderThread();
  closeSidebar();
  showToast('Chat deleted');
}

function renameChat(chatId) {
  var chat = state.chats.find(function(c){ return c.id === chatId; });
  if (!chat) return;
  var current = chat.title || 'New chat';
  var name = prompt('Rename chat', current);
  if (name === null) return;
  name = name.trim();
  if (!name) name = current;
  if (name.length > 60) name = name.slice(0, 60);
  chat.title = name;
  saveChats();
  renderSidebar();
  showToast('Renamed');
}

function editUserMessage(idx) {
  var chat = getActiveChat();
  if (!chat) return;
  var msg = chat.messages[idx];
  if (!msg || msg.role !== 'user') return;
  var newText = prompt('Edit message', msg.content);
  if (newText === null) return;
  newText = newText.replace(/\r\n/g, '\n').trim();
  if (!newText) return;
  msg.content = newText;
  if (chat.title === 'New chat') {
    updateChatTitle(chat);
  }
  chat.messages = chat.messages.slice(0, idx + 1);
  saveChats();
  renderThread();
  showToast('Message edited');
}

function updateChatTitle(chat) {
  if (!chat || chat.title !== 'New chat') return;
  var firstUser = chat.messages.find(function(m){ return m.role === 'user'; });
  if (!firstUser) return;
  var text = firstUser.content.replace(/\n+/g, ' ').trim();
  if (!text) return;
  chat.title = text.length > 32 ? text.slice(0, 32) + '…' : text;
  saveChats();
  renderSidebar();
}

function renderSidebar() {
  els.sidebarList.innerHTML = '';
  state.chats.forEach(function(chat) {
    var wrap = document.createElement('div');
    wrap.className = 'sidebar__row' + (chat.id === state.activeChatId ? ' is-active' : '');

    var btn = document.createElement('button');
    btn.className = 'sidebar__item-main';
    btn.type = 'button';
    var text = document.createElement('span');
    text.className = 'sidebar__item-text';
    text.textContent = chat.title || 'New chat';
    btn.appendChild(text);
    btn.addEventListener('click', function(e) {
      if (e.target.closest('.sidebar__menu')) return;
      state.activeChatId = chat.id;
      renderSidebar();
      renderThread();
      closeSidebar();
      setModel(chat.model || state.selectedModel);
    });

    var menuBtn = document.createElement('button');
    menuBtn.className = 'sidebar__menu';
    menuBtn.type = 'button';
    menuBtn.setAttribute('aria-label', 'Chat options');
    menuBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.6"></circle><circle cx="12" cy="12" r="1.6"></circle><circle cx="12" cy="19" r="1.6"></circle></svg>';
    menuBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      var existing = document.querySelector('.sidebar__dropdown');
      if (existing) existing.remove();
      var menu = document.createElement('div');
      menu.className = 'sidebar__dropdown';
      var rename = document.createElement('button');
      rename.className = 'sidebar__dropdown-item';
      rename.textContent = 'Rename';
      rename.addEventListener('click', function(ev) {
        ev.stopPropagation();
        menu.remove();
        renameChat(chat.id);
      });
      var del = document.createElement('button');
      del.className = 'sidebar__dropdown-item sidebar__dropdown-item--danger';
      del.textContent = 'Delete';
      del.addEventListener('click', function(ev) {
        ev.stopPropagation();
        menu.remove();
        if (confirm('Delete this chat?')) {
          deleteChat(chat.id);
        }
      });
      menu.appendChild(rename);
      menu.appendChild(del);
      document.body.appendChild(menu);
      var rect = menuBtn.getBoundingClientRect();
      menu.style.left = Math.min(rect.right - 140, window.innerWidth - 150) + 'px';
      menu.style.top = rect.bottom + 6 + 'px';
      setTimeout(function() {
        document.addEventListener('click', function closeMenu(ev) {
          if (!menu.contains(ev.target) && ev.target !== menuBtn) {
            menu.remove();
            document.removeEventListener('click', closeMenu);
          }
        });
      }, 0);
    });

    wrap.appendChild(btn);
    wrap.appendChild(menuBtn);
    els.sidebarList.appendChild(wrap);
  });
}

function setModel(modelId) {
  if (!modelId) return;
  if (state.modelsById.has(modelId)) {
    state.selectedModel = modelId;
  } else if (!state.selectedModel) {
    state.selectedModel = modelId;
  }
  var chat = getActiveChat();
  if (chat) chat.model = state.selectedModel;
  saveChats();
  var model = state.modelsById.get(state.selectedModel);
  els.modelLabel.textContent = model ? model.label : state.selectedModel;
  closeModelSheet();
}

function renderModels(filter) {
  var f = (filter || '').toLowerCase().trim();
  var list = state.models.filter(function(m) {
    if (!f) return true;
    return m.id.toLowerCase().indexOf(f) !== -1 || m.label.toLowerCase().indexOf(f) !== -1;
  });
  els.modelContent.innerHTML = '';
  if (!list.length) {
    var empty = document.createElement('div');
    empty.style.padding = '18px 12px';
    empty.style.color = 'var(--text-dim)';
    empty.textContent = 'No models match';
    els.modelContent.appendChild(empty);
    return;
  }
  var groups = {};
  list.forEach(function(m) {
    var key = m.recommended ? 'Recommended' : (m.free ? 'Free' : 'Models');
    if (!groups[key]) groups[key] = [];
    groups[key].push(m);
  });
  var order = ['Recommended', 'Free', 'Models'];
  order.forEach(function(key) {
    if (!groups[key] || !groups[key].length) return;
    var label = document.createElement('div');
    label.className = 'model-group__label';
    label.textContent = key;
    els.modelContent.appendChild(label);
    groups[key].forEach(function(m) {
      var btn = document.createElement('button');
      btn.className = 'model-item' + (m.id === state.selectedModel ? ' is-active' : '');
      var main = document.createElement('div');
      main.className = 'model-item__main';
      var name = document.createElement('div');
      name.className = 'model-item__name';
      name.textContent = m.label;
      var meta = document.createElement('div');
      meta.className = 'model-item__meta';
      meta.textContent = m.id;
      main.appendChild(name);
      main.appendChild(meta);
      var badges = document.createElement('div');
      badges.className = 'model-item__badges';
      if (m.recommended) {
        var rec = document.createElement('span');
        rec.className = 'badge badge--rec';
        rec.textContent = 'Rec';
        badges.appendChild(rec);
      }
      if (m.free) {
        var fr = document.createElement('span');
        fr.className = 'badge badge--free';
        fr.textContent = 'Free';
        badges.appendChild(fr);
      }
      btn.appendChild(main);
      btn.appendChild(badges);
      btn.addEventListener('click', function() {
        setModel(m.id);
        var chat = getActiveChat();
        if (chat) {
          chat.model = m.id;
          saveChats();
        }
      });
      els.modelContent.appendChild(btn);
    });
  });
}

async function loadModels() {
  try {
    var res = await apiFetch('/api/models');
    if (!res.ok) throw new Error('Failed');
    var data = await res.json();
    state.models = data.models || [];
    state.modelsById.clear();
    state.models.forEach(function(m) { state.modelsById.set(m.id, m); });
    if (!state.selectedModel && data.default) {
      state.selectedModel = data.default;
    }
    if (!state.modelsById.has(state.selectedModel) && state.models.length) {
      state.selectedModel = state.models[0].id;
    }
    var chat = getActiveChat();
    if (chat && chat.model && state.modelsById.has(chat.model)) {
      state.selectedModel = chat.model;
    }
    setModel(state.selectedModel);
    renderModels(els.modelSearch.value);
  } catch (e) {
    els.modelLabel.textContent = 'Select model';
  }
}

function scrollThread() {
  requestAnimationFrame(function() {
    els.thread.scrollTop = els.thread.scrollHeight;
  });
}

function renderEmptyState() {
  var empty = document.createElement('div');
  empty.className = 'thread-empty';

  var mark = document.createElement('img');
  mark.className = 'thread-empty__mark';
  mark.src = 'static/logo.png?v=1.6.0';
  mark.alt = '';

  var title = document.createElement('div');
  title.className = 'thread-empty__title';
  title.textContent = 'How can I help?';

  var sub = document.createElement('div');
  sub.className = 'thread-empty__subtitle';
  sub.textContent = 'Ask a question, write code, or explore a new idea.';

  var chips = document.createElement('div');
  chips.className = 'thread-empty__chips';
  [
    'Explain something simply',
    'Write code',
    'Fix my writing'
  ].forEach(function(text) {
    var chip = document.createElement('button');
    chip.className = 'suggestion';
    chip.type = 'button';
    chip.textContent = text;
    chip.addEventListener('click', function() {
      els.composerInput.value = text + ' ';
      els.composerInput.focus();
      autoResize();
      els.composerSend.disabled = false;
    });
    chips.appendChild(chip);
  });

  empty.appendChild(mark);
  empty.appendChild(title);
  empty.appendChild(sub);
  empty.appendChild(chips);
  els.thread.appendChild(empty);
}

function renderThread() {
  var chat = getActiveChat();
  els.thread.innerHTML = '';
  if (!chat || chat.messages.length === 0) {
    renderEmptyState();
    return;
  }
  chat.messages.forEach(function(msg) {
    if (msg.role === 'user') {
      renderUserMessage(msg);
    } else {
      renderAssistantMessage(msg);
    }
  });
  scrollThread();
}

function renderUserMessage(msg) {
  var chat = getActiveChat();
  var idx = chat ? chat.messages.indexOf(msg) : -1;
  var wrap = document.createElement('div');
  wrap.className = 'message';
  var meta = document.createElement('div');
  meta.className = 'message__meta';
  meta.style.justifyContent = 'flex-end';
  var name = document.createElement('div');
  name.className = 'message__name';
  name.textContent = 'You';
  var time = document.createElement('div');
  time.className = 'message__time';
  time.textContent = msg.time || nowTime();
  meta.appendChild(time);
  meta.appendChild(name);
  var avatar = document.createElement('div');
  avatar.className = 'message__avatar message__avatar--user';
  avatar.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="8" r="4"></circle><path d="M12 14c-6 0-8 3-8 4v2h16v-2c0-1-2-4-8-4z"></path></svg>';
  meta.appendChild(avatar);
  var bubble = document.createElement('div');
  bubble.className = 'message__bubble message__bubble--user';
  var content = document.createElement('div');
  content.className = 'message__content';
  var p = document.createElement('p');
  p.textContent = msg.content;
  content.appendChild(p);
  bubble.appendChild(content);
  var actions = document.createElement('div');
  actions.className = 'message__actions';
  actions.style.justifyContent = 'flex-end';
  var editBtn = document.createElement('button');
  editBtn.className = 'chip';
  editBtn.textContent = 'Edit';
  editBtn.addEventListener('click', function() {
    if (idx >= 0) editUserMessage(idx);
  });
  actions.appendChild(editBtn);
  wrap.appendChild(meta);
  wrap.appendChild(bubble);
  wrap.appendChild(actions);
  els.thread.appendChild(wrap);
}

function copyText(text) {
  if (!text) return;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(function() {
      showToast('Copied');
    }).catch(function() {
      fallbackCopy(text);
    });
    return;
  }
  fallbackCopy(text);
}

function fallbackCopy(text) {
  var area = document.createElement('textarea');
  area.value = text;
  area.setAttribute('readonly', '');
  area.style.position = 'fixed';
  area.style.opacity = '0';
  document.body.appendChild(area);
  area.select();
  try {
    document.execCommand('copy');
    showToast('Copied');
  } catch (e) {
    showToast('Could not copy');
  }
  area.remove();
}

function renderAssistantMessage(msg) {
  var wrap = document.createElement('div');
  wrap.className = 'message';
  var meta = document.createElement('div');
  meta.className = 'message__meta';
  var avatar = document.createElement('div');
  avatar.className = 'message__avatar message__avatar--assistant';
  avatar.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"></circle><path d="M12 1v6m0 6v6M4.22 4.22l4.24 4.24m5.08 5.08l4.24 4.24M1 12h6m6 0h6M4.22 19.78l4.24-4.24m5.08-5.08l4.24-4.24"></path></svg>';
  var name = document.createElement('div');
  name.className = 'message__name';
  name.textContent = msg.modelLabel || 'Rebbet AI';
  var time = document.createElement('div');
  time.className = 'message__time';
  time.textContent = msg.time || nowTime();
  meta.appendChild(avatar);
  meta.appendChild(name);
  meta.appendChild(time);
  var bubble = document.createElement('div');
  bubble.className = 'message__bubble message__bubble--assistant';
  var content = document.createElement('div');
  content.className = 'message__content';
  if (msg.html) {
    content.innerHTML = msg.html;
  } else {
    var p = document.createElement('p');
    p.textContent = msg.content;
    content.appendChild(p);
  }
  bubble.appendChild(content);
  var actions = document.createElement('div');
  actions.className = 'message__actions';
  var copyBtn = document.createElement('button');
  copyBtn.className = 'chip';
  copyBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg> Copy';
  copyBtn.addEventListener('click', function() {
    copyText(msg.raw || msg.content || '');
  });
  actions.appendChild(copyBtn);
  var speakBtn = document.createElement('button');
  speakBtn.className = 'chip';
  speakBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path><path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path></svg> Speak';
  speakBtn.addEventListener('click', function() {
    speak(msg.content || msg.raw || '');
  });
  actions.appendChild(speakBtn);
  var regenBtn = document.createElement('button');
  regenBtn.className = 'chip';
  regenBtn.textContent = 'Regenerate';
  regenBtn.addEventListener('click', function() {
    var chat = getActiveChat();
    if (!chat) return;
    chat.messages = chat.messages.slice(0, -1);
    saveChats();
    renderThread();
    sendMessage();
  });
  actions.appendChild(regenBtn);
  wrap.appendChild(meta);
  wrap.appendChild(bubble);
  wrap.appendChild(actions);
  els.thread.appendChild(wrap);
}

function renderStreamingPlaceholder(chat) {
  var wrap = document.createElement('div');
  wrap.className = 'message';
  wrap.id = 'streamingWrap';
  var meta = document.createElement('div');
  meta.className = 'message__meta';
  var avatar = document.createElement('div');
  avatar.className = 'message__avatar message__avatar--assistant';
  avatar.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"></circle><path d="M12 1v6m0 6v6M4.22 4.22l4.24 4.24m5.08 5.08l4.24 4.24M1 12h6m6 0h6M4.22 19.78l4.24-4.24m5.08-5.08l4.24-4.24"></path></svg>';
  var name = document.createElement('div');
  name.className = 'message__name';
  name.textContent = state.modelsById.get(state.selectedModel)?.label || state.selectedModel || 'Rebbet AI';
  var time = document.createElement('div');
  time.className = 'message__time';
  time.textContent = nowTime();
  meta.appendChild(avatar);
  meta.appendChild(name);
  meta.appendChild(time);
  var typing = document.createElement('div');
  typing.className = 'typing';
  var dots = document.createElement('div');
  dots.className = 'typing__dots';
  var d1 = document.createElement('div');
  d1.className = 'typing__dot';
  var d2 = document.createElement('div');
  d2.className = 'typing__dot';
  var d3 = document.createElement('div');
  d3.className = 'typing__dot';
  dots.appendChild(d1);
  dots.appendChild(d2);
  dots.appendChild(d3);
  typing.appendChild(dots);
  typing.innerHTML += '<span>Thinking</span>';
  wrap.appendChild(meta);
  wrap.appendChild(typing);
  els.thread.appendChild(wrap);
  scrollThread();
}

function updateStreamingBubble(text, thinking) {
  var existing = document.getElementById('streamingWrap');
  if (!existing) return;
  var typing = existing.querySelector('.typing');
  if (typing) typing.remove();
  var bubble = existing.querySelector('.message__bubble');
  if (!bubble) {
    bubble = document.createElement('div');
    bubble.className = 'message__bubble message__bubble--assistant';
    existing.appendChild(bubble);
  }
  var content = bubble.querySelector('.message__content');
  if (!content) {
    content = document.createElement('div');
    content.className = 'message__content';
    bubble.appendChild(content);
  }
  if (text && text.length) {
    if (window.marked && window.DOMPurify) {
      var html = DOMPurify.sanitize(marked.parse(text));
      content.innerHTML = html;
    } else {
      content.textContent = text;
    }
  }
  scrollThread();
}

function removeStreamingPlaceholder() {
  var existing = document.getElementById('streamingWrap');
  if (existing) existing.remove();
}

async function sendMessage() {
  var chat = getActiveChat();
  if (!chat) return;
  var text = els.composerInput.value.replace(/\r\n/g, '\n').trim();
  if (!text || state.sending) return;
  var model = chat.model || state.selectedModel || DEFAULT_MODEL;
  var userMsg = {
    role: 'user',
    content: text,
    time: nowTime()
  };
  chat.messages.push(userMsg);
  updateChatTitle(chat);
  saveChats();
  renderThread();
  els.composerInput.value = '';
  autoResize();
  state.sending = true;
  els.composerSend.disabled = true;
  renderStreamingPlaceholder(chat);

  try {
    var history = chat.messages.slice(-20).map(function(m) {
      return { role: m.role, content: m.content };
    });
    var res;
    try {
      res = await apiFetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: model,
          messages: history
        })
      });
    } catch (e) {
      resetApiBase();
      removeStreamingPlaceholder();
      var assistantMsgNet2 = {
        role: 'assistant',
        content: 'Network error. Check that the server is running at http://127.0.0.1:8765 and reachable. (' + e + ')',
        raw: String(e),
        time: nowTime(),
        modelLabel: state.modelsById.get(model)?.label || model
      };
      if (window.marked && window.DOMPurify) {
        assistantMsgNet2.html = DOMPurify.sanitize(marked.parse(assistantMsgNet2.content));
      }
      chat.messages.push(assistantMsgNet2);
      saveChats();
      renderThread();
      showToast('Connection failed');
      state.sending = false;
      els.composerSend.disabled = false;
      return;
    }

    if (!res.ok) {
      var errJson = null;
      try { errJson = await res.json(); } catch(e) {}
      var errMsg = errJson && errJson.error && errJson.error.message ? errJson.error.message : ('Error: ' + res.status);
      var hint = errJson && errJson.error && errJson.error.hint ? errJson.error.hint : '';
      removeStreamingPlaceholder();
      var assistantMsg = {
        role: 'assistant',
        content: errMsg + (hint ? '\n\n' + hint : ''),
        raw: errMsg,
        time: nowTime(),
        modelLabel: state.modelsById.get(model)?.label || model
      };
      if (window.marked && window.DOMPurify) {
        assistantMsg.html = DOMPurify.sanitize(marked.parse(assistantMsg.content));
      }
      chat.messages.push(assistantMsg);
      saveChats();
      renderThread();
      showToast('Request failed');
      return;
    }

    var reader = res.body.getReader();
    var decoder = new TextDecoder();
    var buffer = '';
    var fullText = '';
    var usage = null;

    while (true) {
      var result = await reader.read();
      if (result.done) break;
      buffer += decoder.decode(result.value, { stream: true });
      var parts = buffer.split('\n\n');
      buffer = parts.pop();
      for (var i = 0; i < parts.length; i++) {
        var chunk = parts[i];
        if (!chunk.startsWith('data:')) continue;
        var jsonStr = chunk.slice(5).trim();
        if (!jsonStr) continue;
        try {
          var ev = JSON.parse(jsonStr);
        } catch(e) {
          continue;
        }
        if (ev.type === 'delta' && typeof ev.text === 'string') {
          fullText += ev.text;
          updateStreamingBubble(fullText);
        } else if (ev.type === 'thinking') {
          // show subtle indicator is handled by placeholder
        } else if (ev.type === 'error') {
          removeStreamingPlaceholder();
          var errContent = ev.message || 'Unknown error';
          if (ev.hint) errContent += '\n\n' + ev.hint;
          var assistantMsgErr = {
            role: 'assistant',
            content: errContent,
            raw: ev.message || errContent,
            time: nowTime(),
            modelLabel: state.modelsById.get(model)?.label || model
          };
          if (window.marked && window.DOMPurify) {
            assistantMsgErr.html = DOMPurify.sanitize(marked.parse(assistantMsgErr.content));
          }
          chat.messages.push(assistantMsgErr);
          saveChats();
          renderThread();
          showToast('Error');
          state.sending = false;
          els.composerSend.disabled = false;
          return;
        } else if (ev.type === 'done') {
          usage = ev.usage || null;
        }
      }
    }

    removeStreamingPlaceholder();
    if (fullText.length) {
      var assistantMsg = {
        role: 'assistant',
        content: fullText,
        raw: fullText,
        time: nowTime(),
        modelLabel: state.modelsById.get(model)?.label || model
      };
      if (window.marked && window.DOMPurify) {
        assistantMsg.html = DOMPurify.sanitize(marked.parse(fullText));
      }
      chat.messages.push(assistantMsg);
      saveChats();
      renderThread();
      if (voice.enabled) speak(fullText);
    } else {
      showToast('Empty response');
    }
  } catch (e) {
    resetApiBase();
    removeStreamingPlaceholder();
    var assistantMsgNet = {
      role: 'assistant',
      content: 'Network error. Check that the server is running and reachable.',
      raw: 'Network error',
      time: nowTime(),
      modelLabel: state.modelsById.get(model)?.label || model
    };
    if (window.marked && window.DOMPurify) {
      assistantMsgNet.html = DOMPurify.sanitize(marked.parse(assistantMsgNet.content));
    }
    chat.messages.push(assistantMsgNet);
    saveChats();
    renderThread();
    showToast('Connection failed');
  } finally {
    state.sending = false;
    els.composerSend.disabled = false;
  }
}

function autoResize() {
  var ta = els.composerInput;
  ta.style.height = 'auto';
  ta.style.height = Math.min(140, ta.scrollHeight) + 'px';
}

els.menuBtn.addEventListener('click', openSidebar);
els.sidebarClose.addEventListener('click', closeSidebar);
els.sidebarBackdrop.addEventListener('click', closeSidebar);
els.sidebarNew.addEventListener('click', function() { createChat(false); });
els.newChatBtn.addEventListener('click', function() { createChat(false); });

els.modelTrigger.addEventListener('click', openModelSheet);
els.modelBackdrop.addEventListener('click', closeModelSheet);
els.modelClose.addEventListener('click', closeModelSheet);
els.modelSearch.addEventListener('input', function() {
  renderModels(els.modelSearch.value);
});

els.composerInput.addEventListener('input', function() {
  autoResize();
  els.composerSend.disabled = state.sending || !els.composerInput.value.trim();
});

els.composerInput.addEventListener('keydown', function(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

els.composerSend.addEventListener('click', sendMessage);
els.composerSend.disabled = true;
els.composerMic.addEventListener('click', toggleRecording);
els.voiceToggle.addEventListener('click', toggleVoice);

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    closeModelSheet();
    closeSidebar();
  }
});

loadChats();
loadModels();
loadVoicePref();
autoResize();
