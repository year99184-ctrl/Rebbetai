import { app } from "./firebase.js?v=1.9.2";
import {
  get,
  getDatabase,
  onDisconnect,
  onValue,
  ref,
  serverTimestamp,
  set,
  update as updateRecord
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-database.js";

const DB_PATH = "appStatus";
const DISMISS_KEY = "rebbet_update_dismissed";
const VERSION = document.querySelector('meta[name="app-version"]')?.content || "0.0.0";
const DEFAULT_UPDATE_MESSAGE = "A newer version of Rebbet AI is available.";
const DEFAULT_MAINTENANCE_MESSAGE = "Rebbet AI is under maintenance. Please check back shortly.";
const DEFAULT_BAN_MESSAGE = "Your access to Rebbet AI has been blocked by an administrator.";

function truthy(value) {
  return value === true || value === "true" || value === 1 || value === "1";
}

function readCookie(name) {
  try {
    const prefix = name + "=";
    const parts = document.cookie ? document.cookie.split("; ") : [];
    for (let index = 0; index < parts.length; index++) {
      if (parts[index].indexOf(prefix) === 0) {
        return decodeURIComponent(parts[index].slice(prefix.length));
      }
    }
  } catch (error) {}
  return "";
}

function newUserId() {
  let raw = "";
  try {
    if (window.crypto && typeof window.crypto.randomUUID === "function") {
      raw = window.crypto.randomUUID().replace(/-/g, "");
    }
  } catch (error) {}
  if (!raw) {
    raw = Math.random().toString(36).slice(2) + Date.now().toString(36) +
      Math.random().toString(36).slice(2);
  }
  return "u_" + raw.replace(/[^A-Za-z0-9]/g, "").slice(0, 40);
}

function ensureUserId() {
  let id = String(window.rebbetUserId || "");
  if (!id) {
    try { id = localStorage.getItem("rebbet_client_id") || ""; } catch (error) {}
  }
  if (!id) id = readCookie("rebbet_client_id");
  if (!/^[A-Za-z0-9_-]{6,80}$/.test(id)) id = newUserId();
  try { localStorage.setItem("rebbet_client_id", id); } catch (error) {}
  try {
    document.cookie = "rebbet_client_id=" + encodeURIComponent(id) +
      "; Max-Age=31536000; Path=/; SameSite=Lax";
  } catch (error) {}
  window.rebbetUserId = id;
  return id;
}

const USER_ID = ensureUserId();

function versionParts(value) {
  return String(value || "")
    .trim()
    .replace(/^v/i, "")
    .split(/[.+-]/)
    .map(function(part) {
      const match = String(part).match(/\d+/);
      return match ? Number(match[0]) : 0;
    });
}

function compareVersions(left, right) {
  const a = versionParts(left);
  const b = versionParts(right);
  const length = Math.max(a.length, b.length);
  for (let index = 0; index < length; index++) {
    const av = a[index] || 0;
    const bv = b[index] || 0;
    if (av > bv) return 1;
    if (av < bv) return -1;
  }
  return 0;
}

function element(tag, className, id) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (id) node.id = id;
  return node;
}

function buildMaintenanceGate() {
  const root = element("div", "remote-gate");
  root.id = "maintenanceGate";
  root.hidden = true;
  root.innerHTML = [
    '<div class="remote-gate__backdrop"></div>',
    '<section class="remote-gate__card" role="dialog" aria-modal="true" aria-labelledby="maintenanceTitle">',
    '  <div class="remote-gate__icon" aria-hidden="true">',
    '    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a4 4 0 0 0-5 5L3 18v3h3l6.7-6.7a4 4 0 0 0 5-5l-2.5 2.5-3-3z"></path></svg>',
    "  </div>",
    '  <div class="remote-gate__eyebrow">Service notice</div>',
    '  <h2 id="maintenanceTitle">Rebbet AI is under maintenance</h2>',
    '  <p class="remote-gate__text" id="maintenanceText"></p>',
    '  <button class="remote-btn remote-btn--primary" id="maintenanceRetry" type="button">Check again</button>',
    "</section>"
  ].join("");
  document.body.appendChild(root);
  return {
    root: root,
    text: root.querySelector("#maintenanceText"),
    retry: root.querySelector("#maintenanceRetry")
  };
}

function buildUpdateGate() {
  const root = element("div", "remote-modal");
  root.id = "updateGate";
  root.hidden = true;
  root.innerHTML = [
    '<div class="remote-modal__backdrop"></div>',
    '<section class="remote-modal__card" role="dialog" aria-modal="true" aria-labelledby="updateTitle">',
    '  <div class="remote-modal__eyebrow">Rebbet AI update</div>',
    '  <h2 id="updateTitle">Update available</h2>',
    '  <p class="remote-modal__text" id="updateText"></p>',
    '  <div class="remote-modal__actions">',
    '    <button class="remote-btn remote-btn--ghost" id="updateLater" type="button">Later</button>',
    '    <button class="remote-btn remote-btn--primary" id="updateNow" type="button">Update now</button>',
    "  </div>",
    '  <p class="remote-modal__hint" id="updateHint"></p>',
    "</section>"
  ].join("");
  document.body.appendChild(root);
  return {
    root: root,
    title: root.querySelector("#updateTitle"),
    text: root.querySelector("#updateText"),
    hint: root.querySelector("#updateHint"),
    later: root.querySelector("#updateLater"),
    now: root.querySelector("#updateNow")
  };
}

function buildBanGate() {
  const root = element("div", "remote-gate");
  root.id = "banGate";
  root.hidden = true;
  root.innerHTML = [
    '<div class="remote-gate__backdrop"></div>',
    '<section class="remote-gate__card" role="dialog" aria-modal="true" aria-labelledby="banTitle">',
    '  <div class="remote-gate__icon remote-gate__icon--danger" aria-hidden="true">',
    '    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"></circle><line x1="5.6" y1="5.6" x2="18.4" y2="18.4"></line></svg>',
    "  </div>",
    '  <div class="remote-gate__eyebrow">Access blocked</div>',
    '  <h2 id="banTitle">You have been banned</h2>',
    '  <p class="remote-gate__text" id="banText"></p>',
    '  <p class="remote-gate__hint" id="banId"></p>',
    "</section>"
  ].join("");
  document.body.appendChild(root);
  return {
    root: root,
    text: root.querySelector("#banText"),
    id: root.querySelector("#banId")
  };
}

const maintenance = buildMaintenanceGate();
const update = buildUpdateGate();
const ban = buildBanGate();
let currentStatus = null;
let currentUpdateVersion = "";
let currentBan = null;

function safeUpdateUrl(value) {
  if (!value) return location.href;
  try {
    const url = new URL(String(value), location.href);
    if (url.protocol === "http:" || url.protocol === "https:") {
      return url.href;
    }
  } catch (error) {}
  return location.href;
}

function hideUpdate() {
  update.root.hidden = true;
}

function showUpdate(status, latestVersion, force) {
  const message = String(status.updateMessage || "").trim() || DEFAULT_UPDATE_MESSAGE;
  const updateUrl = safeUpdateUrl(status.updateUrl);
  const sameVersion = latestVersion && currentUpdateVersion === latestVersion &&
    !update.root.hidden;
  currentUpdateVersion = latestVersion;
  const sameAsCurrent = latestVersion && compareVersions(latestVersion, VERSION) === 0;
  update.title.textContent = force ? "Update required" : "Update available";
  update.text.textContent = latestVersion && !sameAsCurrent
    ? message + " You are on version " + VERSION + "; the latest is " + latestVersion + "."
    : message;
  update.hint.textContent = force
    ? "This update is required before you can continue."
    : "Your chats stay saved on this device.";
  update.later.hidden = force;
  update.now.textContent = status.updateUrl ? "Update now" : "Reload app";
  update.now.onclick = function() {
    if (updateUrl === location.href) {
      if (latestVersion) {
        try {
          localStorage.setItem(DISMISS_KEY, latestVersion);
        } catch (error) {}
      }
      location.reload();
    } else {
      location.assign(updateUrl);
    }
  };
  update.later.onclick = function() {
    if (latestVersion) {
      try {
        localStorage.setItem(DISMISS_KEY, latestVersion);
      } catch (error) {}
    }
    hideUpdate();
  };
  if (!sameVersion) {
    update.root.hidden = false;
  }
}

function applyStatus(status) {
  currentStatus = status && typeof status === "object" ? status : {};
  const maintenanceOn = truthy(currentStatus.maintenance);
  const maintenanceMessage = String(currentStatus.maintenanceMessage || "").trim() ||
    DEFAULT_MAINTENANCE_MESSAGE;

  if (maintenanceOn) {
    maintenance.text.textContent = maintenanceMessage;
    maintenance.root.hidden = false;
    hideUpdate();
    document.documentElement.classList.add("is-maintenance");
    return;
  }

  maintenance.root.hidden = true;
  document.documentElement.classList.remove("is-maintenance");

  const latestVersion = String(currentStatus.latestVersion || "").trim();
  const forced = truthy(currentStatus.forceUpdate);
  const announced = truthy(currentStatus.updateAvailable) ||
    (latestVersion && compareVersions(latestVersion, VERSION) > 0);
  if (!announced) {
    hideUpdate();
    return;
  }

  let dismissed = "";
  try {
    dismissed = localStorage.getItem(DISMISS_KEY) || "";
  } catch (error) {}
  if (!forced && latestVersion && dismissed === latestVersion) {
    hideUpdate();
    return;
  }
  showUpdate(currentStatus, latestVersion, forced);
}

function applyBan(value) {
  currentBan = value;
  const banned = value === true || value === 1 || value === "1" || value === "true" ||
    (typeof value === "string" && value.length > 0 && value !== "false") ||
    (value && typeof value === "object" && value.banned !== false);

  if (banned) {
    const reason = value && typeof value === "object" && value.reason
      ? String(value.reason).trim()
      : "";
    ban.text.textContent = reason || DEFAULT_BAN_MESSAGE;
    ban.id.textContent = "User ID: " + USER_ID;
    ban.root.hidden = false;
    document.documentElement.classList.add("is-banned");
    hideUpdate();
    return;
  }

  ban.root.hidden = true;
  document.documentElement.classList.remove("is-banned");
}

async function registerUser(db) {
  const userRef = ref(db, "users/" + USER_ID);
  const payload = {
    lastSeen: serverTimestamp(),
    appVersion: VERSION,
    platform: (navigator.userAgentData && navigator.userAgentData.platform) ||
      navigator.platform || "",
    language: navigator.language || "",
    userAgent: String(navigator.userAgent || "").slice(0, 220),
    online: true
  };
  try {
    const snapshot = await get(userRef);
    if (snapshot.exists()) {
      await updateRecord(userRef, payload);
    } else {
      payload.firstSeen = serverTimestamp();
      await set(userRef, payload);
    }
    try {
      onDisconnect(ref(db, "users/" + USER_ID + "/online")).set(false);
    } catch (error) {}
  } catch (error) {
    console.warn("Rebbet AI user registration failed:", error);
  }
}

maintenance.retry.addEventListener("click", function() {
  location.reload();
});

let db = null;
try {
  db = getDatabase(app);
} catch (error) {
  console.warn("Rebbet AI status unavailable:", error);
}

if (db) {
  registerUser(db);
  setInterval(function() {
    registerUser(db);
  }, 5 * 60 * 1000);
  document.addEventListener("visibilitychange", function() {
    if (!document.hidden) registerUser(db);
  });

  onValue(
    ref(db, "bans/" + USER_ID),
    function(snapshot) {
      applyBan(snapshot.val());
    },
    function(error) {
      console.warn("Rebbet AI ban status unavailable:", error);
    }
  );

  onValue(
    ref(db, DB_PATH),
    function(snapshot) {
      applyStatus(snapshot.val());
    },
    function(error) {
      console.warn("Rebbet AI status unavailable:", error);
    }
  );
}
