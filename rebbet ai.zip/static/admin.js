import { app } from "./firebase.js?v=1.9.2";
import {
  getDatabase,
  onValue,
  ref,
  remove,
  serverTimestamp,
  set
} from "https://www.gstatic.com/firebasejs/13.1.0/firebase-database.js";

const db = getDatabase(app);
const statusRef = ref(db, "appStatus");
const usersRef = ref(db, "users");
const bansRef = ref(db, "bans");
const APP_VERSION = document.querySelector('meta[name="app-version"]')?.content || "1.9.2";
const DEFAULT_UPDATE_MESSAGE = "A newer version of Rebbet AI is available.";
const DEFAULT_MAINTENANCE_MESSAGE = "Rebbet AI is under maintenance. Please check back shortly.";

const panelStatus = document.getElementById("panelStatus");
const liveStatus = document.getElementById("liveStatus");
const liveBadge = document.getElementById("liveBadge");
const liveMaintenance = document.getElementById("liveMaintenance");
const liveVersion = document.getElementById("liveVersion");
const liveUpdate = document.getElementById("liveUpdate");
const liveUpdated = document.getElementById("liveUpdated");
const statusForm = document.getElementById("statusForm");
const latestVersion = document.getElementById("latestVersion");
const publisher = document.getElementById("publisher");
const updateUrl = document.getElementById("updateUrl");
const updateMessage = document.getElementById("updateMessage");
const updateAvailable = document.getElementById("updateAvailable");
const forceUpdate = document.getElementById("forceUpdate");
const maintenance = document.getElementById("maintenance");
const maintenanceMessage = document.getElementById("maintenanceMessage");
const appVersion = document.getElementById("appVersion");
const userCount = document.getElementById("userCount");
const userSearch = document.getElementById("userSearch");
const banReason = document.getElementById("banReason");
const userList = document.getElementById("userList");
const userStatus = document.getElementById("userStatus");

let currentStatus = null;
let formDirty = false;
let users = {};
let bans = {};

appVersion.textContent = APP_VERSION;

function truthy(value) {
  return value === true || value === "true" || value === 1 || value === "1";
}

function versionParts(value) {
  return String(value || "")
    .trim()
    .replace(/^v/i, "")
    .split(/[.+-]/)
    .map(function(part) {
      const match = String(part).match(/\d+/);
      return match ? Number(match[0]) : 0;
    });
}

function compareVersions(left, right) {
  const a = versionParts(left);
  const b = versionParts(right);
  const length = Math.max(a.length, b.length);
  for (let index = 0; index < length; index++) {
    const av = a[index] || 0;
    const bv = b[index] || 0;
    if (av > bv) return 1;
    if (av < bv) return -1;
  }
  return 0;
}

function setMessage(node, message, isError) {
  node.textContent = message || "";
  node.classList.toggle("is-error", !!isError);
}

function formatTime(value) {
  const time = Number(value);
  if (!Number.isFinite(time) || time <= 0) return "—";
  try {
    return new Intl.DateTimeFormat(undefined, {
      dateStyle: "medium",
      timeStyle: "short"
    }).format(new Date(time));
  } catch (error) {
    return new Date(time).toLocaleString();
  }
}

function statusData() {
  return currentStatus && typeof currentStatus === "object" ? currentStatus : {};
}

function isValidUserId(value) {
  return /^[A-Za-z0-9_-]{6,80}$/.test(String(value || "").trim());
}

function isBanned(id) {
  const value = bans[id];
  if (value === true || value === 1 || value === "1" || value === "true") return true;
  if (value && typeof value === "object") return value.banned !== false;
  if (typeof value === "string" && value.length > 0 && value !== "false") return true;
  return false;
}

function buildUserRow(entry) {
  const row = document.createElement("article");
  row.className = "admin__user";

  const head = document.createElement("div");
  head.className = "admin__user-head";
  const idEl = document.createElement("code");
  idEl.className = "admin__user-id";
  idEl.textContent = entry.id;
  const state = document.createElement("span");
  state.className = "admin__user-state" + (entry.banned ? " is-banned" : "");
  state.textContent = entry.banned ? "Banned" : "Active";
  head.appendChild(idEl);
  head.appendChild(state);

  const meta = document.createElement("div");
  meta.className = "admin__user-meta";
  meta.textContent = [
    "Last seen: " + (entry.lastSeen ? formatTime(entry.lastSeen) : "—"),
    "App: v" + (entry.data.appVersion || "?"),
    entry.data.platform || "",
    entry.data.language || ""
  ].filter(Boolean).join(" · ");

  row.appendChild(head);
  row.appendChild(meta);

  const ban = bans[entry.id];
  if (entry.banned && ban && typeof ban === "object" && ban.reason) {
    const reason = document.createElement("div");
    reason.className = "admin__user-reason";
    reason.textContent = "Reason: " + ban.reason;
    row.appendChild(reason);
  }

  const actions = document.createElement("div");
  actions.className = "admin__user-actions";
  const button = document.createElement("button");
  button.type = "button";
  button.className = "admin__button " +
    (entry.banned ? "admin__button--ghost" : "admin__button--danger");
  button.dataset.action = entry.banned ? "unban" : "ban";
  button.dataset.id = entry.id;
  button.textContent = entry.banned ? "Unban" : "Ban";
  actions.appendChild(button);
  row.appendChild(actions);

  return row;
}

function renderUsers() {
  const filter = userSearch.value.trim().toLowerCase();
  const all = Object.keys(users);
  const bannedTotal = all.filter(isBanned).length;
  userCount.textContent = all.length + (all.length === 1 ? " user" : " users") +
    " · " + bannedTotal + " banned";

  const entries = all.map(function(id) {
    const data = users[id] && typeof users[id] === "object" ? users[id] : {};
    return {
      id: id,
      data: data,
      banned: isBanned(id),
      lastSeen: Number(data.lastSeen) || 0
    };
  }).filter(function(entry) {
    return !filter || entry.id.toLowerCase().indexOf(filter) !== -1;
  }).sort(function(a, b) {
    return b.lastSeen - a.lastSeen || a.id.localeCompare(b.id);
  });

  userList.textContent = "";
  if (!entries.length) {
    const empty = document.createElement("p");
    empty.className = "admin__empty";
    empty.textContent = filter
      ? "No user matches that search."
      : "No users have opened the app yet.";
    userList.appendChild(empty);
    return;
  }

  entries.slice(0, 200).forEach(function(entry) {
    userList.appendChild(buildUserRow(entry));
  });
  if (entries.length > 200) {
    const note = document.createElement("p");
    note.className = "admin__empty";
    note.textContent = "Showing the 200 most recent of " + entries.length + " users.";
    userList.appendChild(note);
  }
}

async function banUser(id, reasonOverride) {
  id = String(id || "").trim();
  if (!isValidUserId(id)) {
    setMessage(userStatus, "Enter a valid user ID (letters, numbers, _ or -).", true);
    return;
  }
  const reason = reasonOverride !== undefined ? reasonOverride : banReason.value.trim();
  setMessage(userStatus, "Banning " + id + "…");
  try {
    await set(ref(db, "bans/" + id), {
      banned: true,
      reason: reason || "",
      at: serverTimestamp(),
      by: publisher.value.trim() || "admin"
    });
    setMessage(userStatus, "Banned " + id + ". The app blocks them immediately.");
  } catch (error) {
    setMessage(
      userStatus,
      "Ban failed: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
}

async function unbanUser(id) {
  id = String(id || "").trim();
  if (!isValidUserId(id)) {
    setMessage(userStatus, "Enter a valid user ID (letters, numbers, _ or -).", true);
    return;
  }
  setMessage(userStatus, "Unbanning " + id + "…");
  try {
    await remove(ref(db, "bans/" + id));
    setMessage(userStatus, "Unbanned " + id + ".");
  } catch (error) {
    setMessage(
      userStatus,
      "Unban failed: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
}

function renderLive(status) {
  const data = status && typeof status === "object" ? status : {};
  const maintenanceOn = truthy(data.maintenance);
  const publishedVersion = String(data.latestVersion || "").trim();
  const hasUpdate = truthy(data.updateAvailable) ||
    (!!publishedVersion && compareVersions(publishedVersion, APP_VERSION) > 0);

  liveBadge.textContent = maintenanceOn ? "Maintenance ON" : "Live";
  liveBadge.classList.toggle("is-maintenance", maintenanceOn);
  liveMaintenance.textContent = maintenanceOn
    ? "On — the app is blocked for everyone"
    : "Off — the app is available";
  liveVersion.textContent = publishedVersion || "—";
  liveUpdate.textContent = hasUpdate
    ? "Shown — clients will see the update notice"
    : "Hidden — app is up to date (v" + APP_VERSION + ")";
  liveUpdate.classList.toggle("is-active", hasUpdate);
  liveUpdated.textContent = data.updatedAt ? formatTime(data.updatedAt) : "—";
}

function fillForm(status) {
  const data = status && typeof status === "object" ? status : {};
  latestVersion.value = data.latestVersion || APP_VERSION;
  publisher.value = data.updatedBy || "admin";
  updateUrl.value = data.updateUrl || "";
  updateMessage.value = data.updateMessage || DEFAULT_UPDATE_MESSAGE;
  updateAvailable.checked = truthy(data.updateAvailable);
  forceUpdate.checked = truthy(data.forceUpdate);
  maintenance.checked = truthy(data.maintenance);
  maintenanceMessage.value = data.maintenanceMessage || DEFAULT_MAINTENANCE_MESSAGE;
  formDirty = false;
}

function collectForm() {
  return {
    latestVersion: latestVersion.value.trim(),
    updateUrl: updateUrl.value.trim(),
    updateMessage: updateMessage.value.trim() || DEFAULT_UPDATE_MESSAGE,
    updateAvailable: updateAvailable.checked,
    forceUpdate: forceUpdate.checked,
    maintenance: maintenance.checked,
    maintenanceMessage: maintenanceMessage.value.trim() || DEFAULT_MAINTENANCE_MESSAGE,
    updatedBy: publisher.value.trim() || "admin"
  };
}

async function writeStatus(payload) {
  await set(statusRef, {
    latestVersion: payload.latestVersion,
    updateUrl: payload.updateUrl || "",
    updateMessage: payload.updateMessage || DEFAULT_UPDATE_MESSAGE,
    updateAvailable: !!payload.updateAvailable,
    forceUpdate: !!payload.forceUpdate,
    maintenance: !!payload.maintenance,
    maintenanceMessage: payload.maintenanceMessage || DEFAULT_MAINTENANCE_MESSAGE,
    updatedAt: serverTimestamp(),
    updatedBy: payload.updatedBy || "admin"
  });
}

async function publishStatus(event) {
  event.preventDefault();
  const payload = collectForm();
  if (!payload.latestVersion) {
    setMessage(panelStatus, "Latest version is required.", true);
    latestVersion.focus();
    return;
  }
  setMessage(panelStatus, "Publishing…");
  try {
    await writeStatus(payload);
    formDirty = false;
    setMessage(
      panelStatus,
      "Published. Rebbet AI clients will update live. " +
      (payload.maintenance ? "Maintenance mode is ON." : "Maintenance mode is OFF.")
    );
  } catch (error) {
    setMessage(
      panelStatus,
      "Publish failed: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
}

async function quickUpdate(changes, successMessage) {
  const payload = Object.assign({}, statusData(), changes);
  if (!payload.latestVersion) payload.latestVersion = APP_VERSION;
  if (!payload.updateMessage) payload.updateMessage = DEFAULT_UPDATE_MESSAGE;
  if (!payload.maintenanceMessage) payload.maintenanceMessage = DEFAULT_MAINTENANCE_MESSAGE;
  payload.updatedBy = publisher.value.trim() || "admin";
  setMessage(liveStatus, "Publishing…");
  try {
    await writeStatus(payload);
    setMessage(liveStatus, successMessage);
  } catch (error) {
    setMessage(
      liveStatus,
      "Update failed: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
}

async function loadStatus() {
  setMessage(panelStatus, "Loading current status…");
  try {
    const snapshot = await get(statusRef);
    const data = snapshot.val();
    currentStatus = data || {};
    renderLive(currentStatus);
    if (!formDirty) fillForm(currentStatus);
    setMessage(
      panelStatus,
      data && data.updatedBy
        ? "Loaded. Last published by " + data.updatedBy + "."
        : "Current status loaded."
    );
  } catch (error) {
    setMessage(
      panelStatus,
      "Could not read /appStatus: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
}

statusForm.addEventListener("input", function() {
  formDirty = true;
});
statusForm.addEventListener("change", function() {
  formDirty = true;
});
statusForm.addEventListener("submit", publishStatus);
document.getElementById("reloadStatus").addEventListener("click", loadStatus);

document.getElementById("quickMaintenanceOn").addEventListener("click", function() {
  quickUpdate(
    { maintenance: true },
    "Maintenance mode is ON. Clients are blocked immediately."
  );
});

document.getElementById("quickMaintenanceOff").addEventListener("click", function() {
  quickUpdate(
    { maintenance: false },
    "Maintenance mode is OFF. Clients can use the app again."
  );
});

document.getElementById("quickClearUpdate").addEventListener("click", function() {
  quickUpdate(
    { latestVersion: APP_VERSION, updateAvailable: false, forceUpdate: false },
    "Update notice cleared. Clients will not be asked to update."
  );
});

onValue(
  statusRef,
  function(snapshot) {
    currentStatus = snapshot.val() || {};
    renderLive(currentStatus);
    if (!formDirty) fillForm(currentStatus);
  },
  function(error) {
    liveBadge.textContent = "Offline";
    liveBadge.classList.add("is-maintenance");
    setMessage(
      liveStatus,
      "Live status unavailable: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
);

userSearch.addEventListener("input", renderUsers);

userList.addEventListener("click", function(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  if (button.dataset.action === "ban") {
    banUser(button.dataset.id);
  } else {
    unbanUser(button.dataset.id);
  }
});

document.getElementById("banById").addEventListener("click", function() {
  banUser(userSearch.value.trim());
});

document.getElementById("unbanById").addEventListener("click", function() {
  unbanUser(userSearch.value.trim());
});

onValue(
  usersRef,
  function(snapshot) {
    users = snapshot.val() || {};
    renderUsers();
  },
  function(error) {
    userCount.textContent = "Offline";
    setMessage(
      userStatus,
      "Users unavailable: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
);

onValue(
  bansRef,
  function(snapshot) {
    bans = snapshot.val() || {};
    renderUsers();
  },
  function(error) {
    setMessage(
      userStatus,
      "Ban list unavailable: " + (error && error.message ? error.message : "permission denied."),
      true
    );
  }
);

renderUsers();
