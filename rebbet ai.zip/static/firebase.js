import { initializeApp } from "https://www.gstatic.com/firebasejs/13.1.0/firebase-app.js";

export const firebaseConfig = {
  apiKey: "AIzaSyDtd8DO5l7kzAxoe9Zcn-tQH6-WMJKqzRU",
  authDomain: "drip-wire-36ff0.firebaseapp.com",
  databaseURL: "https://drip-wire-36ff0-default-rtdb.firebaseio.com",
  projectId: "drip-wire-36ff0",
  storageBucket: "drip-wire-36ff0.firebasestorage.app",
  messagingSenderId: "375795271359",
  appId: "1:375795271359:web:cc413a1bb44200e9cee80a",
  measurementId: "G-8KG4YP1V5N"
};

export const app = initializeApp(firebaseConfig);
window.rebbetFirebase = {
  app: app,
  analytics: null,
  logEvent: null,
  trackEvent: function(name, params) {
    if (!this.analytics || typeof this.logEvent !== "function") return;
    try {
      this.logEvent(this.analytics, name, params || {});
    } catch (error) {
      console.warn("Firebase event failed:", error);
    }
  }
};

export function trackEvent(name, params) {
  window.rebbetFirebase.trackEvent(name, params);
}

(async function initAnalytics() {
  try {
    const analyticsSdk = await import("https://www.gstatic.com/firebasejs/13.1.0/firebase-analytics.js");
    window.rebbetFirebase.logEvent = analyticsSdk.logEvent;
    if (await analyticsSdk.isSupported()) {
      window.rebbetFirebase.analytics = analyticsSdk.getAnalytics(app);
    }
  } catch (error) {
    console.warn("Firebase Analytics unavailable:", error);
  }
})();
