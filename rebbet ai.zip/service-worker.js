const CACHE_NAME = 'rebbet-ai-v1.9.2';
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './static/style.css?v=1.9.2',
  './static/app.js?v=1.9.2',
  './static/app-status.js?v=1.9.2',
  './static/admin.css?v=1.9.2',
  './static/admin.js?v=1.9.2',
  './admin.html?v=1.9.2',
  './static/firebase.js?v=1.9.2',
  './static/logo.png?v=1.9.2',
  './static/icon-192.png?v=1.9.2',
  './static/icon-512.png?v=1.9.2'
];

self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache) {
      return cache.addAll(ASSETS);
    }).then(function() {
      return self.skipWaiting();
    })
  );
});

self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches.keys().then(function(keys) {
      return Promise.all(keys.map(function(key) {
        if (key !== CACHE_NAME) {
          return caches.delete(key);
        }
      }));
    }).then(function() {
      return self.clients.claim();
    })
  );
});

self.addEventListener('fetch', function(event) {
  var request = event.request;
  var url = new URL(request.url);

  if (url.origin !== self.location.origin || request.method !== 'GET') {
    return;
  }

  if (url.pathname.startsWith('/api/')) {
    return;
  }

  event.respondWith(
    fetch(request).then(function(response) {
      if (response && response.status === 200 && response.type === 'basic') {
        var copy = response.clone();
        caches.open(CACHE_NAME).then(function(cache) {
          cache.put(request, copy);
        });
      }
      return response;
    }).catch(function() {
      return caches.match(request).then(function(cached) {
        return cached || caches.match('./index.html');
      });
    })
  );
});
