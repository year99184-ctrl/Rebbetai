#!/usr/bin/env python3
import base64
import hashlib
import html
import io
import json
import mimetypes
import os
import queue
import re
import socket
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import wave
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

APP_NAME = "Rebbet AI"
VERSION = "1.9.2"
MODULE_NAME = "rebbet-ai"
MODULE_ID = "rebbet_ai"
ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
CONFIG_PATH = ROOT / "config.json"
INDEX_HTML_FALLBACK = zlib.decompress(base64.b64decode("""
eNrlGu2OG7fxv5+C3f6wDXhXWt3pLDWS2vqaBgGcpMhdY+SXQO1SWvp2lwuSkk4pAuQh+gx9sDxJZ8j9IKXV+Q6unRYFrFtyODMk
Z4bzQXr2u798d33749++JJku8sWzGX5ITsvNPGBlgABG08UzQmYF05QkGZWK6Xnw99u/hpOgGyhpwebBjrN9JaQOSCJKzUpA3PNU
Z/OU7XjCQtN5RXjJNad5qBKas3n8ijR04ZrreSJ2TCKSZpImmu8M3QZmlUzxn5gKa+Yn0+uMFQxGcyGdFfx+OBnS+OIEm1ZVCDMp
LkoHO46m0egEN2UqkbzSPu73bLVimvz5a/LrL/8ka6pMG2SkyZ7rjOzZiihGZQJ7plstSCFSlhMFg0nGyw1Ay5TwopKw5ZTsBMgo
6ltnzsJCrDh8gGWIC09oRVc5cxZzYOpxpEpTvVXhikpoHjweq5wmd6GWtFT5NmlFrLnO2aLbbUhuCiqhqRQHbmW93Xew3Ruz3dnA
kiBxzss7Ilk+Dwpa8jVTYB2ZZOuuH71Xovzjbu6IviPiCYpcHyrYDi/ohg2qchMQYwigrenoHn4NR9waTwZIEwI4AtRzfK1otNgm
WWjneDILIz2VMaaPiM1AlCjlUM4G9iTNViI9GEYp35Ekp0qZxRjmAEUsJpsBLSrQUz3m09ih5TJna90iAMpqq7UoGyyzj5WG7fEU
JM7K7RvsUMlpmNMVbuO7ipXWaDPQppAHhxvwU7sNsYc4GKGgGd9k2rbx2L4R9/NgSIZkdAn/ArLmOfAsRQl2pbQUd6C3ZCslGNO1
PZgWGtY842jSgkC0DAx7HkixLdNggbJm5D6eB8D4AJ/XAbkfwdxD6I6wu5gNEOcUMx75qNA/j3vENnb4DmD7jnAHVroOxNHICs5N
6guPFxtvdLmEg3MHG5ZJay252AjPzAjNQcC1kjKepqwEdcst83kfz7xcanavPRxUX0XLIzT0DUF3nGGPgPNhMrVdBYuvWAHem9Dm
5J8SzwawMFdkTrfuPGDNEq3rseZsfeut2GzQi7k2/a71vOA70BVZkPVO5+176Nj38JPbtwt+L3jZ2X3CZZIzksDUcQz++WC/ch5M
0DTtsGPIo9haMn7RkuOr6GpcG7NpPt6eH5K3CVB94rYwG8DAN1Y5h2BkMSoI2ooB8ZrmirXa+AFR//sVUYn8sAFxVADVGG9iMiZX
ZEpG5hdjB/4AOJ7iXyPpmgioKURF2Po38TgaX5JJdHlFx8AAdxHD73U0NK4G8VzsKcDJZTS9oDEgDlv8+DKKLzuCJ+rSJB8Q3Plm
w2QdDxB020Csv6GqEtUWZJNCiiY2NZjdwzFPOz36mnOchTfLcpkK3evIevzGA1yMmTlLfmv6i7eCppBG/frLv/rY7TZnuCUZ2wWN
qcVXnalh+zc1NXOgG1tDM4uNjcUTMm0M66OOMWkaYUgTk98ZmZZsfw3x/yQzuNGY5UEyyfYmQTh/XmPnvMb/KSFOH5EYYJxHzzeu
Hd+o9nrTnnA/9lMDwDlJDR6WqxPLbDrHZB3MZlTxlDXixjambTZINR1Xstd96ZYbD2uq5dJOE/RnHC2W8arB4kexlUZT6jgKPxhG
LZfrXKgjv25Aj8wNP6/Ldk1gYvV6ZdV6VWt10mMBVx6mITxCfbQBnMi01QWcFk+u30LfYenIDBfQ+p7JZ5XZpzw239bu4tkZIfYZ
cM6V9qT2FgELX+B9hGshtH8+TCQ4m93a4TqNrcSeSZb6ON4pN+e67vRNv4KCOZWi8tb+pgEu3IR3VlDeBTho95d1UEnS1LJr2vZI
8h2oHkIA1+wBwSSiqODQnvMYzfByycvSw8I6H+oHClP2IVfbWj8N8GsLkmKPeVFAqpwmLBM5eCvIYSDpg1qdtGqAGA1mWbE8h+ib
3NVpgLkVSQRYcwJHAItwA6AV1zSHCh9TfLyaSDCdxJa8Y4eM41UFDKBFD5o1exvxT2a3jYInR5vAG4XmesFS+R7wKwZSopoRXmPa
9PUIfFw8fWq3OH16eoEiJjDvBZxe8/eMD5IGBwSLBF4lMonGthQxDYnrGLvVSJu/jiAbHufhOBy/HRNIB84krH15y1N09w0Czmvu
ewaGVV+qkcLa4/+CoroyAHI/ekEuTPo/DKG1m3R9KDyGP1y64+HFT73FBFQQuxF9TV7bOiKML8lwF4463JOogC7eDQuji56wUEdd
GKtLzlPcj9K3OeCewm8MxEtQAdLqlqRc4Z1o+nmVPHq6iru6vRZ4E1rjOrQ6MjyuQEcjW3fCF6vOC1uJAtCrPD8s+eMEsTdGoKt1
bopIAhVaQe/gPOHtzx1TEblGd4532EKam2BeroUsKN6UR313P7aJ4c9cgrbx0V2Ardfqm9W26LuxfSnQAXvFKQzTvA0prX2AKawO
LvGtzZJPorkz33FEN0Mn8fxBBpBKYLFq14l5zUrcu7WrSWx6IrfHJINqu71lOS6dz4R+n8FDdYOHaWuHIznXorrOBFYA1L5cPKWo
MARnSwr7EFLx5O44B/n/LinO6UgdX1y61xt2sH7F+K1Ki892ZWlS0TruN1e8ne3WAC8ZtUBrc6rJOYsqZxpYiPXaT0z9+63Hqad5
kHQsv3mi9Nxe3ez3elrQpgaqm9aF2Pe6h6oAZGTfJ+3DQqZ1pf4wGCRpGb1XsBq+k1HJ9KCsigE+QLC0/kRQBgGKuY8zDBZP4pWC
GLeSrw9/uoji6ApWo/TAQj7MuX7+oFUFeN1LWR++1TYIdoueyqVecwkVl2IfwaJ7E/0QE6tGviYvnkN4xBftdwKkKJ9D1CMl3fEN
1UK+JP+o7WXPy1TsI5qmX+7AGNDzY93w4nkuaPr8FVlvywQD5YuOhHR8Im+OSLIN0st27nBvB96r5y+jhOoke9EyZBKXgQ+7Cmwo
gq6QBvgF+fnlF/VcTetnY5LNFsFBmRfK2cD+l4B/AwPW6iY=
""")).decode("utf-8")
MAX_BODY = 4 * 1024 * 1024
MAX_MESSAGES = 200
MAX_MESSAGE_CHARS = 120000
UPSTREAM_USER_AGENT = "opencode/1.0"
GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai"
GEMINI_DEFAULT_MODEL = "gemini-3.6-flash"
GEMINI_DEFAULT_VOICE = "gemini-3.8-flash-tts"
GEMINI_DEFAULT_IMAGE = "gemini-3.1-flash-image"
MODEL_ALIASES = {
    "gemini-2.5-flash": GEMINI_DEFAULT_MODEL,
    "models/gemini-2.5-flash": GEMINI_DEFAULT_MODEL,
}
DEFAULT_SYSTEM_PROMPT = (
    "You are Rebbet AI, a helpful, friendly assistant. Be accurate and clear.please join my telegram channel https://t.me/Panelsalllbay"
    "Use Markdown when it improves readability, and keep answers focused on what the user asked. "
    "When users ask for current information, news, weather, or anything time-sensitive, provide up-to-date information."
)
TTS_MODEL = os.environ.get("REBBET_TTS_MODEL", GEMINI_DEFAULT_VOICE)
IMAGE_MODEL = os.environ.get("REBBET_IMAGE_MODEL", GEMINI_DEFAULT_IMAGE)
TRANSCRIBE_MODEL = os.environ.get("REBBET_TRANSCRIBE_MODEL", "gemini-3.5-transcribe")
DEFAULT_VOICE = os.environ.get("REBBET_VOICE", "Kore")
MAX_TTS_CHARS = 4000
MAX_AUDIO_BYTES = 8 * 1024 * 1024
MAX_IMAGE_CHARS = 2000
POLLINATIONS_TEXT_URL = "https://text.pollinations.ai/openai"
POLLINATIONS_IMAGE_URL = "https://image.pollinations.ai/prompt"
DEEPSEEK_BASE_URL = "https://api.deepseek.com"
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
GITHUB_MODELS_BASE_URL = "https://models.github.ai/inference"
GITHUB_MODELS_API_VERSION = "2026-03-10"

DEFAULT_CONFIG = {
    "host": "127.0.0.1",
    "port": 8765,
    "provider": "gemini",
    "api_key": "",
    "base_url": GEMINI_BASE_URL,
    "default_model": GEMINI_DEFAULT_MODEL,
    "request_timeout": 300,
    "enable_web_search": True,
    "auto_switch_model": True,
    "enable_free_fallback": True,
    "voice_model": GEMINI_DEFAULT_VOICE,
    "voice_speed": "fast",
    "image_model": GEMINI_DEFAULT_IMAGE,
    "transcribe_model": TRANSCRIBE_MODEL,
    "pollinations_model": "openai-fast",
    "deepseek_api_key": "",
    "deepseek_model": "deepseek-chat",
    "openrouter_api_key": "",
    "openrouter_model": "deepseek/deepseek-chat-v3-0324:free",
    "github_api_key": "",
    "github_model": "openai/gpt-4.1",
    "github_base_url": GITHUB_MODELS_BASE_URL,
}

BRANDS = {
    "glm": "GLM",
    "gpt": "GPT",
    "claude": "Claude",
    "gemini": "Gemini",
    "qwen": "Qwen",
    "deepseek": "DeepSeek",
    "minimax": "MiniMax",
    "kimi": "Kimi",
    "grok": "Grok",
    "muse": "Muse",
    "nemotron": "Nemotron",
    "mimo": "MiMo",
    "flint": "Flint",
    "beam": "Beam",
    "mistral": "Mistral",
    "jev": "Jev",
    "big": "Big",
    "pickle": "Pickle",
}

SHORT_WORDS = {"vl": "VL", "ai": "AI", "api": "API"}

RECOMMENDED_ORDER = [
    "gemini-3.8-flash",
    "gemini-3.7-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.5-flash",
    "gemini-3.6-flash",
    "gemini-flash-latest",
    "gemini-flash-lite-latest",
    "glm-5.3-flash",
    "deepseek-v4.1-flash",
    "minimax-m3",
    "qwen3.8-flash",
    "big-pickle",
    "kimi-k3",
    "claude-sonnet-5-5",
    "claude-haiku-5-5",
    "gpt-6-luna",
    "grok-4.5",
]

AUTO_SWITCH_ORDER = [
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "gemini-3.7-flash",
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-flash-latest",
    "gemini-flash-lite-latest",
    "gemini-3.1-flash-lite",
    "glm-5.3-flash",
    "deepseek-v4.1-flash",
    "minimax-m3",
    "qwen3.8-flash",
    "big-pickle",
]

FREE_MODELS = [
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "gemini-3.7-flash",
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-flash-latest",
    "gemini-flash-lite-latest",
    "gemini-3.1-flash-lite",
    "glm-5.3-flash",
    "deepseek-v4.1-flash",
    "minimax-m3",
    "qwen3.8-flash",
    "big-pickle",
]

FALLBACK_MODEL_IDS = [
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "gemini-3.7-flash",
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-flash-latest",
    "gemini-flash-lite-latest",
    "gemini-3.1-flash-lite",
    "glm-5.3-flash",
    "deepseek-v4.1-flash",
    "minimax-m3",
    "qwen3.8-flash",
    "big-pickle",
    "glm-5.3-flash-free",
    "deepseek-v4.1-flash-free",
]

GEMINI_FALLBACK_MODEL_IDS = [
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "gemini-3.7-flash",
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-flash-latest",
    "gemini-flash-lite-latest",
    "gemini-3.1-flash-lite",
    "gemini-3-flash-preview",
    "gemini-3.1-pro-preview",
]

GEMINI_TTS_MODEL_IDS = [
    GEMINI_DEFAULT_VOICE,
    "gemini-3.8-flash-lite-tts",
    "gemini-3.1-flash-tts-preview",
    "gemini-2.5-flash-preview-tts",
]

TRANSCRIBE_MODEL_IDS = [
    TRANSCRIBE_MODEL,
    "gemini-3.6-flash",
    "gemini-3.5-flash",
    "gemini-3.1-flash-lite",
]

GEMINI_IMAGE_MODEL_IDS = [
    GEMINI_DEFAULT_IMAGE,
    "gemini-2.5-flash-image",
    "gemini-3.1-flash-image-preview",
    "gemini-3.1-flash-lite-image",
    "gemini-3-pro-image",
    "gemini-nano-banana-2.1",
]

NON_CHAT_MODEL_PARTS = (
    "tts",
    "image",
    "embedding",
    "embed",
    "live",
    "transcribe",
    "computer-use",
    "robotics",
    "lyria",
    "aqa",
    "nano-banana",
)

MODELS_CACHE_SECONDS = 1800
MODEL_COOLDOWN_SECONDS = 120
QUOTA_COOLDOWN_SECONDS = 300
PROVIDER_COOLDOWN_SECONDS = 35
_models_cache = {"at": 0.0, "models": None, "source": "fallback"}
_models_lock = threading.Lock()
_model_cooldowns = {}
_cooldown_lock = threading.Lock()
FIREBASE_DB_URL = os.environ.get(
    "REBBET_FIREBASE_DB_URL",
    "https://drip-wire-36ff0-default-rtdb.firebaseio.com"
)
BAN_CACHE_SECONDS = 15
_ban_cache = {}
_ban_cache_lock = threading.Lock()


def normalize_model(model):
    name = str(model or "").strip()
    if name.lower().startswith("models/"):
        name = name[len("models/"):]
    return MODEL_ALIASES.get(name.lower(), name)


class UpstreamStreamError(Exception):
    def __init__(self, info):
        super().__init__(info.get("message", "Upstream error"))
        self.info = info


def load_config():
    config = dict(DEFAULT_CONFIG)
    if CONFIG_PATH.exists():
        try:
            saved = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                for key in DEFAULT_CONFIG:
                    if key in saved:
                        config[key] = saved[key]
        except (OSError, ValueError) as exc:
            print(f"Could not read config.json: {exc}", file=sys.stderr)

    if os.environ.get("OPENCODE_API_KEY"):
        config["api_key"] = os.environ["OPENCODE_API_KEY"]
    if os.environ.get("GEMINI_API_KEY"):
        config["api_key"] = os.environ["GEMINI_API_KEY"]
        config["provider"] = "gemini"
        config["base_url"] = GEMINI_BASE_URL
    if os.environ.get("OPENCODE_BASE_URL"):
        config["base_url"] = os.environ["OPENCODE_BASE_URL"]
    if os.environ.get("REBBET_BASE_URL"):
        config["base_url"] = os.environ["REBBET_BASE_URL"]
    if os.environ.get("REBBET_HOST"):
        config["host"] = os.environ["REBBET_HOST"]
    if os.environ.get("PORT"):
        config["port"] = os.environ["PORT"]
        if not os.environ.get("REBBET_HOST"):
            config["host"] = "0.0.0.0"
    if os.environ.get("REBBET_PORT"):
        config["port"] = os.environ["REBBET_PORT"]
    if os.environ.get("REBBET_DEFAULT_MODEL"):
        config["default_model"] = os.environ["REBBET_DEFAULT_MODEL"]
    if os.environ.get("REBBET_AUTO_SWITCH"):
        config["auto_switch_model"] = os.environ["REBBET_AUTO_SWITCH"].lower() in ("1", "true", "yes")
    if os.environ.get("REBBET_ENABLE_SEARCH"):
        config["enable_web_search"] = os.environ["REBBET_ENABLE_SEARCH"].lower() in ("1", "true", "yes")
    if os.environ.get("REBBET_FREE_FALLBACK"):
        config["enable_free_fallback"] = os.environ["REBBET_FREE_FALLBACK"].lower() in ("1", "true", "yes")
    if os.environ.get("REBBET_VOICE_MODEL"):
        config["voice_model"] = os.environ["REBBET_VOICE_MODEL"]
    if os.environ.get("REBBET_IMAGE_MODEL"):
        config["image_model"] = os.environ["REBBET_IMAGE_MODEL"]
    if os.environ.get("REBBET_TRANSCRIBE_MODEL"):
        config["transcribe_model"] = os.environ["REBBET_TRANSCRIBE_MODEL"]
    if os.environ.get("DEEPSEEK_API_KEY"):
        config["deepseek_api_key"] = os.environ["DEEPSEEK_API_KEY"]
    if os.environ.get("OPENROUTER_API_KEY"):
        config["openrouter_api_key"] = os.environ["OPENROUTER_API_KEY"]
    github_token = os.environ.get("GITHUB_MODELS_TOKEN") or os.environ.get("GITHUB_TOKEN")
    if github_token:
        config["github_api_key"] = github_token
    if os.environ.get("GITHUB_MODELS_MODEL"):
        config["github_model"] = os.environ["GITHUB_MODELS_MODEL"]
    if os.environ.get("GITHUB_MODELS_BASE_URL"):
        config["github_base_url"] = os.environ["GITHUB_MODELS_BASE_URL"]

    config["host"] = str(config.get("host") or "127.0.0.1").strip()
    config["port"] = int(config.get("port") or 8765)
    config["provider"] = str(config.get("provider") or "gemini").strip().lower()
    config["api_key"] = str(config.get("api_key") or "").strip()
    config["base_url"] = str(config.get("base_url") or DEFAULT_CONFIG["base_url"]).rstrip("/")
    config["default_model"] = normalize_model(config.get("default_model") or DEFAULT_CONFIG["default_model"])
    config["request_timeout"] = max(30, int(config.get("request_timeout") or 300))
    config["enable_web_search"] = bool(config.get("enable_web_search", True))
    config["auto_switch_model"] = bool(config.get("auto_switch_model", True))
    config["enable_free_fallback"] = bool(config.get("enable_free_fallback", True))
    config["voice_model"] = str(config.get("voice_model") or GEMINI_DEFAULT_VOICE)
    config["voice_speed"] = str(config.get("voice_speed") or "fast")
    config["image_model"] = str(config.get("image_model") or GEMINI_DEFAULT_IMAGE)
    config["transcribe_model"] = str(config.get("transcribe_model") or TRANSCRIBE_MODEL)
    config["pollinations_model"] = str(config.get("pollinations_model") or "openai-fast")
    config["deepseek_api_key"] = str(config.get("deepseek_api_key") or "").strip()
    config["deepseek_model"] = str(config.get("deepseek_model") or "deepseek-chat")
    config["openrouter_api_key"] = str(config.get("openrouter_api_key") or "").strip()
    config["openrouter_model"] = str(config.get("openrouter_model") or "deepseek/deepseek-chat-v3-0324:free")
    config["github_api_key"] = str(config.get("github_api_key") or "").strip()
    config["github_model"] = str(config.get("github_model") or "openai/gpt-4.1")
    config["github_base_url"] = str(config.get("github_base_url") or GITHUB_MODELS_BASE_URL).rstrip("/")

    if config["provider"] in ("gemini", "google") and config["default_model"] == DEFAULT_CONFIG["default_model"]:
        config["default_model"] = GEMINI_DEFAULT_MODEL

    if config["api_key"].startswith(("AIza", "AQ.")) and "opencode.ai" in config["base_url"]:
        config["provider"] = "gemini"
        config["base_url"] = GEMINI_BASE_URL
        if config["default_model"] == DEFAULT_CONFIG["default_model"]:
            config["default_model"] = GEMINI_DEFAULT_MODEL
    return config


def is_gemini_api(config):
    provider = str(config.get("provider") or "").strip().lower()
    base_url = str(config.get("base_url") or "").lower()
    api_key = str(config.get("api_key") or "").strip()
    return (
        provider in ("gemini", "google")
        or "generativelanguage.googleapis.com" in base_url
        or api_key.startswith(("AIza", "AQ."))
    )


def gemini_models_url(config):
    base_url = str(config.get("base_url") or GEMINI_BASE_URL).rstrip("/")
    if base_url.endswith("/openai"):
        base_url = base_url[: -len("/openai")]
    return f"{base_url}/models"


def gemini_api_root(config):
    base_url = str(config.get("base_url") or GEMINI_BASE_URL).rstrip("/")
    if base_url.endswith("/openai"):
        base_url = base_url[: -len("/openai")]
    return base_url


def gemini_native_request(config, model, body, timeout=120):
    url = f"{gemini_api_root(config)}/models/{urllib.parse.quote(model, safe='')}:generateContent"
    request = urllib.request.Request(
        url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers={
            "x-goog-api-key": config["api_key"],
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": UPSTREAM_USER_AGENT,
        },
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.load(response)


def clean_html_text(value):
    text = re.sub(r"<[^>]+>", " ", value or "")
    return re.sub(r"\s+", " ", html.unescape(text)).strip()


def decode_search_link(link):
    link = html.unescape((link or "").strip())
    if link.startswith("//"):
        link = "https:" + link
    if "duckduckgo.com/l/" in link:
        parsed = urllib.parse.urlsplit(link)
        target = urllib.parse.parse_qs(parsed.query).get("uddg")
        if target:
            link = target[0]
    return link


def web_search(query, max_results=5):
    try:
        max_results = max(1, min(10, int(max_results)))
    except (TypeError, ValueError):
        max_results = 5
    encoded_query = urllib.parse.quote_plus(query)
    urls = [
        f"https://html.duckduckgo.com/html/?q={encoded_query}",
        f"https://lite.duckduckgo.com/lite/?q={encoded_query}",
    ]
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }
    results = []
    seen = set()
    for url in urls:
        try:
            request = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(request, timeout=12) as response:
                page = response.read().decode("utf-8", errors="ignore")
        except (urllib.error.URLError, urllib.error.HTTPError, OSError, TimeoutError):
            continue
        blocks = re.split(r'<div class="result\b', page)
        if len(blocks) < 2:
            blocks = re.split(r"<tr\b", page)
        for block in blocks[1:]:
            link_match = re.search(r'class="result__a"[^>]*href="([^"]+)"', block)
            if not link_match:
                link_match = re.search(r'<a[^>]+href="([^"]+)"[^>]*class="result-link"', block)
            if not link_match:
                continue
            link = decode_search_link(link_match.group(1))
            title_match = re.search(r'class="result__a"[^>]*>(.*?)</a>', block, re.S)
            if not title_match:
                title_match = re.search(r'class="result-link"[^>]*>(.*?)</a>', block, re.S)
            title = clean_html_text(title_match.group(1)) if title_match else ""
            snippet_match = re.search(r'class="result__snippet"[^>]*>(.*?)</a>', block, re.S)
            if not snippet_match:
                snippet_match = re.search(r'class="result-snippet"[^>]*>(.*?)</td>', block, re.S)
            snippet = clean_html_text(snippet_match.group(1)) if snippet_match else ""
            if not title or not link or link in seen:
                continue
            if not link.startswith(("http://", "https://")):
                continue
            seen.add(link)
            results.append({"title": title, "link": link, "snippet": snippet})
            if len(results) >= max_results:
                return results
        if results:
            break
    if results:
        return results
    try:
        url = "https://api.duckduckgo.com/?format=json&no_html=1&skip_disambig=1&q=" + encoded_query
        request = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(request, timeout=10) as response:
            payload = json.load(response)
        abstract = payload.get("AbstractText") or ""
        if abstract:
            results.append(
                {
                    "title": payload.get("Heading") or query,
                    "link": payload.get("AbstractURL") or f"https://duckduckgo.com/?q={encoded_query}",
                    "snippet": abstract,
                }
            )
        for topic in payload.get("RelatedTopics") or []:
            if len(results) >= max_results:
                break
            if not isinstance(topic, dict) or not topic.get("Text"):
                continue
            results.append(
                {
                    "title": topic.get("Text", "")[:120],
                    "link": topic.get("FirstURL") or f"https://duckduckgo.com/?q={encoded_query}",
                    "snippet": topic.get("Text", ""),
                }
            )
    except (urllib.error.URLError, urllib.error.HTTPError, ValueError, OSError, TimeoutError):
        pass
    return results[:max_results]


def get_web_search_context(query):
    results = web_search(query)
    if not results:
        return ""
    context = "\n\n[Web Search Results - use these and cite the links]\n"
    for i, result in enumerate(results, 1):
        context += f"{i}. {result['title']}\n   {result['link']}\n   {result['snippet']}\n\n"
    context += "Base time-sensitive answers on the results above. Include source links when useful."
    return context


def pcm_to_wav(pcm, rate=24000, channels=1, sample_width=2):
    buffer = io.BytesIO()
    with wave.open(buffer, "wb") as wav_file:
        wav_file.setnchannels(channels)
        wav_file.setsampwidth(sample_width)
        wav_file.setframerate(rate)
        wav_file.writeframes(pcm)
    return buffer.getvalue()


def parse_audio_mime(mime):
    rate = 24000
    channels = 1
    match = re.search(r"rate=(\d+)", mime or "")
    if match:
        rate = int(match.group(1))
    match = re.search(r"channels=(\d+)", mime or "")
    if match:
        channels = int(match.group(1))
    return rate, channels


def model_family(model):
    name = model.lower().strip()
    if name.startswith("opencode/"):
        name = name.split("/", 1)[1]
    if name.startswith("gemini"):
        return "google"
    if name.startswith(("claude", "qwen")):
        return "anthropic"
    if name.startswith(("gpt", "grok", "muse", "o1", "o3", "o4")):
        return "responses"
    if name.startswith("jev"):
        return "systemone"
    return "openai"


def is_free_model(model):
    name = model.lower()
    if name.endswith("-free") or name == "big-pickle":
        return True
    if name.startswith("gemini"):
        return any(part in name for part in ("flash", "lite", "gemma", "nano-banana"))
    return False


def is_chat_model(model):
    name = str(model or "").lower()
    if not name or name == "test":
        return False
    if model_family(name) == "systemone":
        return False
    return not any(part in name for part in NON_CHAT_MODEL_PARTS)


def mark_model_cooldown(key, seconds):
    with _cooldown_lock:
        _model_cooldowns[key] = time.time() + max(5, int(seconds))


def model_cooldown_left(key):
    now = time.time()
    with _cooldown_lock:
        until = _model_cooldowns.get(key, 0)
        if until <= now:
            _model_cooldowns.pop(key, None)
            return 0
        return int(until - now)


def cooldown_seconds_for_error(info):
    code = (info or {}).get("code")
    if code == "insufficient_funds":
        return QUOTA_COOLDOWN_SECONDS
    if code in ("free_limit", "rate_limited", "model_disabled", "upstream_unavailable"):
        return MODEL_COOLDOWN_SECONDS
    return 60


def model_label(model):
    text = model
    lowered = text.lower()
    for brand, label in sorted(BRANDS.items(), key=lambda item: len(item[0]), reverse=True):
        if lowered.startswith(brand):
            text = label + text[len(brand):]
            break
    text = re.sub(r"([A-Za-z])(\d)", r"\1 \2", text)
    parts = re.split(r"[-_]", text)
    words = []
    for part in parts:
        if not part:
            continue
        low = part.lower()
        if low in SHORT_WORDS:
            words.append(SHORT_WORDS[low])
        elif low == "free":
            words.append("Free")
        elif part.isupper() and len(part) <= 4:
            words.append(part)
        elif any(ch.isdigit() for ch in part):
            words.append(part)
        else:
            words.append(part[:1].upper() + part[1:])
    return " ".join(words) or model


def normalize_models(model_ids):
    seen = set()
    models = []
    for model_id in model_ids:
        if not isinstance(model_id, str):
            continue
        model_id = model_id.strip()
        if not model_id or model_id in seen:
            continue
        seen.add(model_id)
        family = model_family(model_id)
        if family == "systemone" or model_id == "test":
            continue
        models.append(
            {
                "id": model_id,
                "label": model_label(model_id),
                "family": family,
                "free": is_free_model(model_id),
                "recommended": model_id in RECOMMENDED_ORDER,
            }
        )

    def sort_key(item):
        try:
            rank = RECOMMENDED_ORDER.index(item["id"])
        except ValueError:
            rank = len(RECOMMENDED_ORDER)
        return (rank, item["free"], item["label"].lower())

    models.sort(key=sort_key)
    return models


def fetch_models(config, force=False):
    now = time.time()
    with _models_lock:
        cached = _models_cache["models"]
        if not force and cached is not None and now - _models_cache["at"] < MODELS_CACHE_SECONDS:
            return cached, _models_cache["source"]

    key = config.get("api_key")
    gemini = is_gemini_api(config)
    if key:
        try:
            if gemini:
                url = gemini_models_url(config)
                headers = {
                    "x-goog-api-key": key,
                    "Accept": "application/json",
                    "User-Agent": UPSTREAM_USER_AGENT,
                }
            else:
                url = f"{config['base_url']}/v1/models"
                headers = {
                    "Authorization": f"Bearer {key}",
                    "Accept": "application/json",
                    "User-Agent": UPSTREAM_USER_AGENT,
                }
            request = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(request, timeout=30) as response:
                payload = json.load(response)
            items = payload.get("data") or payload.get("models") or []
            ids = []
            for item in items:
                if not isinstance(item, dict):
                    continue
                model_id = item.get("id") or item.get("name") or ""
                if not isinstance(model_id, str):
                    continue
                if model_id.startswith("models/"):
                    model_id = model_id.split("/", 1)[1]
                methods = item.get("supportedGenerationMethods")
                if gemini and methods and "generateContent" not in methods:
                    continue
                if gemini and not model_id.startswith(("gemini-", "gemma-")):
                    continue
                if gemini and any(part in model_id.lower() for part in NON_CHAT_MODEL_PARTS):
                    continue
                ids.append(model_id)
            models = normalize_models(ids)
            if models:
                with _models_lock:
                    _models_cache.update({"at": now, "models": models, "source": "live"})
                return models, "live"
        except (urllib.error.URLError, urllib.error.HTTPError, ValueError, OSError, TimeoutError) as exc:
            print(f"Model list request failed: {exc}", file=sys.stderr)

    fallback = GEMINI_FALLBACK_MODEL_IDS if gemini else FALLBACK_MODEL_IDS
    models = normalize_models(fallback)
    with _models_lock:
        _models_cache.update({"at": now, "models": models, "source": "fallback"})
    return models, "fallback"


def gemini_usage_from_metadata(metadata):
    if not isinstance(metadata, dict):
        return None
    return {
        "prompt_tokens": metadata.get("promptTokenCount"),
        "completion_tokens": metadata.get("candidatesTokenCount"),
        "total_tokens": metadata.get("totalTokenCount"),
        "cost": metadata.get("cost"),
    }


def gemini_generate_text(config, model, messages, system, temperature, max_tokens, timeout=None):
    contents = []
    for message in messages:
        role = "model" if message["role"] == "assistant" else "user"
        contents.append({"role": role, "parts": [{"text": message["content"]}]})
    body = {"contents": contents}
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    generation = {}
    if temperature is not None:
        generation["temperature"] = temperature
    if max_tokens:
        generation["maxOutputTokens"] = max_tokens
    if generation:
        body["generationConfig"] = generation
    effective_timeout = timeout or min(int(config.get("request_timeout") or 300), 40)
    result = gemini_native_request(config, model, body, timeout=effective_timeout)
    candidates = result.get("candidates") or []
    text_parts = []
    for candidate in candidates:
        content = candidate.get("content") or {}
        for part in content.get("parts") or []:
            if not isinstance(part, dict) or part.get("thought"):
                continue
            text = part.get("text")
            if isinstance(text, str) and text:
                text_parts.append(text)
    text = "".join(text_parts).strip()
    usage = gemini_usage_from_metadata(result.get("usageMetadata"))
    if not text:
        finish = ""
        if candidates and isinstance(candidates[0], dict):
            finish = candidates[0].get("finishReason") or ""
        feedback = result.get("promptFeedback") or {}
        blocked = feedback.get("blockReason") or ""
        if blocked or finish in ("SAFETY", "PROHIBITED_CONTENT", "BLOCKLIST"):
            raise UpstreamStreamError(
                {
                    "code": "blocked",
                    "message": "The model blocked that request.",
                    "hint": "Try rephrasing your message.",
                }
            )
        raise UpstreamStreamError(
            {
                "code": "empty_response",
                "message": "The model returned an empty response.",
                "hint": "Try again or choose a different model.",
                "detail": finish[:120],
            }
        )
    return text, usage


def gemini_chat_candidates(config, requested):
    ordered = [requested]
    with _models_lock:
        cached = list(_models_cache.get("models") or [])
    for model_id in [config.get("default_model")] + GEMINI_FALLBACK_MODEL_IDS:
        if model_id and model_id not in ordered and is_chat_model(model_id):
            ordered.append(model_id)
    for item in cached:
        model_id = item.get("id")
        if model_id and model_id not in ordered and is_chat_model(model_id):
            ordered.append(model_id)
    candidates = [("gemini", model_id) for model_id in ordered]
    if config.get("enable_free_fallback", True):
        if config.get("deepseek_api_key"):
            candidates.append(("deepseek", config.get("deepseek_model") or "deepseek-chat"))
        if config.get("github_api_key"):
            candidates.append(("github", config.get("github_model") or "openai/gpt-4.1"))
        if config.get("openrouter_api_key"):
            candidates.append(("openrouter", config.get("openrouter_model") or "deepseek/deepseek-chat-v3-0324:free"))
        candidates.append(("pollinations", config.get("pollinations_model") or "openai-fast"))
    return candidates


def provider_label(provider):
    return {"github": "GitHub Models", "deepseek": "DeepSeek", "openrouter": "OpenRouter", "pollinations": "Pollinations"}.get(
        provider, provider.title()
    )


def provider_failure_info(provider, status, body):
    label = provider_label(provider)
    raw = extract_error_message(status, body)
    low = f"{raw} {body or ''}".lower()
    if status in (402, 429) or "free limit" in low or "quota" in low or "rate limit" in low:
        return {
            "code": "free_limit",
            "message": f"{label} free limit reached.",
            "hint": "Switching to the next available model.",
            "detail": raw[:400],
        }
    if status in (401, 403):
        return {
            "code": "unauthorized",
            "message": f"{label} rejected the API key.",
            "hint": "Check the provider key in config.json or remove it.",
            "detail": raw[:400],
        }
    return {
        "code": "upstream_error",
        "message": raw[:400] or f"{label} returned HTTP {status}.",
        "hint": "Trying another model.",
        "detail": raw[:400],
    }


def provider_chat(config, provider, model, messages, system, temperature, max_tokens):
    upstream_messages = []
    if system:
        upstream_messages.append({"role": "system", "content": system})
    upstream_messages.extend(messages)
    body = {"model": model, "messages": upstream_messages, "stream": False}
    if temperature is not None:
        body["temperature"] = temperature
    if max_tokens:
        body["max_tokens"] = max_tokens
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "RebbetAI/1.9.2",
    }
    if provider == "pollinations":
        url = POLLINATIONS_TEXT_URL
        body["referrer"] = "rebbet-ai"
    elif provider == "github":
        url = f"{config.get('github_base_url') or GITHUB_MODELS_BASE_URL}/chat/completions"
        headers["Authorization"] = f"Bearer {config.get('github_api_key', '')}"
        headers["Accept"] = "application/vnd.github+json"
        headers["X-GitHub-Api-Version"] = GITHUB_MODELS_API_VERSION
    elif provider == "deepseek":
        url = f"{DEEPSEEK_BASE_URL}/chat/completions"
        headers["Authorization"] = f"Bearer {config.get('deepseek_api_key', '')}"
    elif provider == "openrouter":
        url = f"{OPENROUTER_BASE_URL}/chat/completions"
        headers["Authorization"] = f"Bearer {config.get('openrouter_api_key', '')}"
        headers["HTTP-Referer"] = "https://rebbet.ai"
        headers["X-Title"] = "Rebbet AI"
    else:
        raise ValueError("Unsupported provider")
    request = urllib.request.Request(
        url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers=headers,
    )
    try:
        with urllib.request.urlopen(request, timeout=min(int(config.get("request_timeout") or 300), 45)) as response:
            try:
                payload = json.load(response)
            except ValueError as exc:
                raise UpstreamStreamError(
                    {
                        "code": "empty_response",
                        "message": f"{provider_label(provider)} returned an invalid response.",
                        "hint": "Trying another model.",
                        "detail": str(exc)[:200],
                    }
                )
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read(16384).decode("utf-8", "replace")
        except OSError:
            pass
        raise UpstreamStreamError(provider_failure_info(provider, exc.code, detail))
    choices = payload.get("choices") or []
    text = ""
    if choices:
        message = choices[0].get("message") or {}
        content = message.get("content")
        if isinstance(content, str):
            text = content
        elif isinstance(content, list):
            text = "".join(
                part.get("text", "") for part in content if isinstance(part, dict) and isinstance(part.get("text"), str)
            )
        if not text and isinstance(choices[0].get("text"), str):
            text = choices[0]["text"]
    text = text.strip()
    if not text:
        raise UpstreamStreamError(
            {
                "code": "empty_response",
                "message": f"{provider_label(provider)} returned an empty response.",
                "hint": "Trying another model.",
            }
        )
    return text, payload.get("usage")


def gemini_image_bytes(config, model, prompt, timeout=90):
    body = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"responseModalities": ["TEXT", "IMAGE"]},
    }
    result = gemini_native_request(config, model, body, timeout=timeout)
    text_parts = []
    for candidate in result.get("candidates") or []:
        content = candidate.get("content") or {}
        for part in content.get("parts") or []:
            if not isinstance(part, dict):
                continue
            inline = part.get("inlineData") or part.get("inline_data")
            if isinstance(inline, dict) and isinstance(inline.get("data"), str):
                data = base64.b64decode(inline["data"])
                mime = inline.get("mimeType") or inline.get("mime_type") or "image/png"
                if data:
                    return data, mime, ""
            text = part.get("text")
            if isinstance(text, str) and text:
                text_parts.append(text)
    return None, "", " ".join(text_parts)[:400]


def pollinations_image(prompt, width=768, height=768):
    seed = int(hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:8], 16)
    query = urllib.parse.urlencode(
        {
            "width": max(256, min(1024, int(width))),
            "height": max(256, min(1024, int(height))),
            "seed": seed,
            "nologo": "true",
        }
    )
    url = f"{POLLINATIONS_IMAGE_URL}/{urllib.parse.quote(prompt, safe='')}?{query}"
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36",
            "Accept": "image/*",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=75) as response:
            data = response.read()
            mime = response.headers.get("Content-Type") or "image/jpeg"
    except urllib.error.HTTPError as exc:
        data = exc.read()
        mime = (exc.headers.get("Content-Type") if exc.headers else "") or ""
        is_image = (
            mime.startswith("image/")
            or data[:3] == b"\xff\xd8\xff"
            or data[:8] == b"\x89PNG\r\n\x1a\n"
            or data[:4] == b"RIFF"
        )
        if data and is_image:
            return data, mime or "image/jpeg"
        raise
    if not data:
        raise OSError("Empty image response")
    return data, mime


def extract_error_message(status, body):
    text = (body or "").strip()
    message = ""
    try:
        payload = json.loads(text)
        if isinstance(payload, dict):
            error = payload.get("error")
            if isinstance(error, dict):
                message = error.get("message") or ""
            elif isinstance(error, str):
                message = error
            if not message:
                message = payload.get("message") or payload.get("detail") or ""
    except ValueError:
        pass
    if not message:
        message = text[:600]
    return message or f"OpenCode returned HTTP {status}."


def describe_upstream_error(status, body):
    raw = extract_error_message(status, body)
    low = f"{raw} {body or ''}".lower()

    if status == 402 or "insufficient account funds" in low or "insufficient" in low and "fund" in low:
        return {
            "code": "insufficient_funds",
            "message": "This OpenCode Console account does not have enough credits for that request.",
            "hint": "Add credits in the OpenCode Console, then try again. Free models only work inside the official OpenCode app.",
            "url": "https://opencode.ai/console",
            "detail": raw[:500],
        }
    if "free usage limit" in low or ("free" in low and status == 429):
        return {
            "code": "free_limit",
            "message": "The free-model limit has been reached for this account.",
            "hint": "Free models are restricted to the official OpenCode app. Add credits or use OpenCode Go, then choose a paid model here.",
            "url": "https://opencode.ai/console",
            "detail": raw[:500],
        }
    if "model access is disabled" in low or "model access disabled" in low:
        return {
            "code": "model_disabled",
            "message": "That model is disabled for this workspace or API key.",
            "hint": "Choose another model, or enable it for the workspace in the OpenCode Console.",
            "url": "https://opencode.ai/console",
            "detail": raw[:500],
        }
    if status == 401 or "invalid api key" in low or "unauthorized" in low:
        return {
            "code": "unauthorized",
            "message": "The OpenCode API key was rejected.",
            "hint": "Check the api_key value in config.json, or create a new key in the Console.",
            "url": "https://opencode.ai/console",
            "detail": raw[:500],
        }
    if status == 403 and "1010" in low:
        return {
            "code": "blocked",
            "message": "The upstream gateway blocked the request.",
            "hint": "Try again in a moment. If it keeps happening, check your network or proxy.",
            "detail": raw[:500],
        }
    if status == 429:
        return {
            "code": "rate_limited",
            "message": "OpenCode is rate limiting requests right now.",
            "hint": "Wait a few seconds and try again.",
            "detail": raw[:500],
        }
    if status >= 500:
        return {
            "code": "upstream_unavailable",
            "message": "The model provider is temporarily unavailable.",
            "hint": "Try again, or choose a different model.",
            "detail": raw[:500],
        }
    return {
        "code": "upstream_error",
        "message": raw[:500] or f"OpenCode returned HTTP {status}.",
        "hint": "Try again or choose a different model.",
        "detail": raw[:500],
    }


def build_upstream_request(config, model, family, messages, system, temperature, max_tokens, direct_gemini=False):
    base = config["base_url"]
    body = None
    url = None

    if direct_gemini:
        url = f"{base}/chat/completions"
        upstream_messages = []
        if system:
            upstream_messages.append({"role": "system", "content": system})
        upstream_messages.extend(messages)
        body = {
            "model": model,
            "messages": upstream_messages,
            "stream": False,
        }
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens:
            body["max_tokens"] = max_tokens

    elif family == "openai":
        url = f"{base}/openai/v1/chat/completions"
        upstream_messages = []
        if system:
            upstream_messages.append({"role": "system", "content": system})
        upstream_messages.extend(messages)
        body = {
            "model": model,
            "messages": upstream_messages,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens:
            body["max_tokens"] = max_tokens

    elif family == "responses":
        url = f"{base}/openai/v1/responses"
        body = {"model": model, "input": messages, "stream": True}
        if system:
            body["instructions"] = system
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens:
            body["max_output_tokens"] = max_tokens

    elif family == "anthropic":
        url = f"{base}/anthropic/v1/messages"
        body = {
            "model": model,
            "max_tokens": max_tokens or 4096,
            "messages": messages,
            "stream": True,
        }
        if system:
            body["system"] = system
        if temperature is not None:
            body["temperature"] = temperature

    elif family == "google":
        encoded_model = urllib.parse.quote(model, safe="")
        url = f"{base}/google/v1beta/models/{encoded_model}:streamGenerateContent?alt=sse"
        contents = []
        for message in messages:
            role = "model" if message["role"] == "assistant" else "user"
            contents.append({"role": role, "parts": [{"text": message["content"]}]})
        body = {"contents": contents}
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}
        generation = {}
        if temperature is not None:
            generation["temperature"] = temperature
        if max_tokens:
            generation["maxOutputTokens"] = max_tokens
        if generation:
            body["generationConfig"] = generation

    if body is None:
        raise ValueError("Unsupported model family")

    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    if direct_gemini:
        headers = {
            "Authorization": f"Bearer {config['api_key']}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "User-Agent": UPSTREAM_USER_AGENT,
        }
    else:
        headers = {
            "Authorization": f"Bearer {config['api_key']}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "User-Agent": UPSTREAM_USER_AGENT,
        }
    request = urllib.request.Request(
        url,
        data=data,
        method="POST",
        headers=headers,
    )
    return request


def normalize_user_id(value):
    user_id = str(value or "").strip()
    if re.fullmatch(r"[A-Za-z0-9_-]{6,80}", user_id):
        return user_id
    return ""


def is_user_banned(user_id):
    user_id = normalize_user_id(user_id)
    if not user_id:
        return False
    now = time.time()
    with _ban_cache_lock:
        cached = _ban_cache.get(user_id)
        if cached and now - cached[0] < BAN_CACHE_SECONDS:
            return cached[1]
    banned = False
    try:
        url = (
            FIREBASE_DB_URL.rstrip("/")
            + "/bans/"
            + urllib.parse.quote(user_id, safe="")
            + ".json"
        )
        request = urllib.request.Request(
            url,
            headers={"User-Agent": f"RebbetAI/{VERSION}"}
        )
        with urllib.request.urlopen(request, timeout=3) as response:
            raw = response.read().decode("utf-8", "replace")
        data = json.loads(raw) if raw.strip() else None
        if isinstance(data, dict):
            banned = data.get("banned", True) is not False
        else:
            banned = bool(data)
    except Exception:
        banned = False
    with _ban_cache_lock:
        _ban_cache[user_id] = (now, banned)
    return banned


class AppHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = f"RebbetAI/{VERSION}"

    def log_message(self, fmt, *args):
        if os.environ.get("REBBET_LOG") == "1":
            super().log_message(fmt, *args)

    def do_GET(self):
        parsed = urllib.parse.urlsplit(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if path in ("/api/health", "/health"):
            config = self.server.config
            self.send_json(
                200,
                {
                    "ok": True,
                    "app": APP_NAME,
                    "version": VERSION,
                    "module": MODULE_NAME,
                    "module_id": MODULE_ID,
                    "key_configured": bool(config["api_key"]),
                    "default_model": config["default_model"],
                    "bind": f"{config['host']}:{config['port']}",
                    "provider": "gemini" if is_gemini_api(config) else config.get("provider"),
                    "web_search": config.get("enable_web_search", True),
                    "auto_switch": config.get("auto_switch_model", True),
                    "free_fallback": config.get("enable_free_fallback", True),
                    "voice_model": config.get("voice_model", GEMINI_DEFAULT_VOICE),
                    "image_model": config.get("image_model", GEMINI_DEFAULT_IMAGE),
                    "transcribe_model": config.get("transcribe_model", TRANSCRIBE_MODEL),
                    "github_models": bool(config.get("github_api_key")),
                },
            )
            return
        
        if path == "/api/module" or path == "/api/rebbet":
            self.send_json(
                200,
                {
                    "name": MODULE_NAME,
                    "id": MODULE_ID,
                    "display_name": APP_NAME,
                    "version": VERSION,
                    "features": {
                        "web_search": True,
                        "internet_search": True,
                        "free_ai_models": True,
                        "auto_switch_on_limit": True,
                        "better_voice": True,
                        "fast_voice": True,
                        "image_generation": True,
                        "free_fallback": bool(self.server.config.get("enable_free_fallback", True)),
                    },
                    "free_models": GEMINI_FALLBACK_MODEL_IDS if is_gemini_api(self.server.config) else FREE_MODELS,
                    "auto_switch_order": GEMINI_FALLBACK_MODEL_IDS if is_gemini_api(self.server.config) else AUTO_SWITCH_ORDER,
                    "free_fallback_providers": [
                        name for name, enabled in (
                            ("deepseek", bool(self.server.config.get("deepseek_api_key"))),
                            ("github", bool(self.server.config.get("github_api_key"))),
                            ("openrouter", bool(self.server.config.get("openrouter_api_key"))),
                            ("pollinations", bool(self.server.config.get("enable_free_fallback", True))),
                        ) if enabled
                    ],
                    "voice_models": GEMINI_TTS_MODEL_IDS,
                    "image_models": GEMINI_IMAGE_MODEL_IDS,
                },
            )
            return

        if path == "/api/models":
            force = query.get("refresh", ["0"])[0] in ("1", "true", "yes")
            models, source = fetch_models(self.server.config, force=force)
            self.send_json(200, {"models": models, "source": source, "default": self.server.config["default_model"]})
            return

        if path in ("/api/chat", "/api/search", "/api/tts", "/api/image", "/api/transcribe"):
            self.send_api_error(
                405,
                {
                    "code": "method_not_allowed",
                    "message": f"Use POST for {path}",
                },
            )
            return

        if path == "/favicon.ico":
            self.serve_file(STATIC_DIR / "icon-192.png", cache=True)
            return

        if path.startswith("/static/") and not STATIC_DIR.is_dir():
            self.send_json(
                500,
                {
                    "error": {
                        "message": "static folder is missing on the server",
                        "hint": "Upload the whole static folder next to app.py, then redeploy.",
                    }
                },
            )
            return

        if path in ("/", "/index.html") and not (ROOT / "index.html").is_file():
            self.send_bytes(
                200,
                INDEX_HTML_FALLBACK.encode("utf-8"),
                "text/html; charset=utf-8",
            )
            return

        if path in ("/admin", "/admin/", "/admin.html") and not (ROOT / "admin.html").is_file():
            self.send_json(
                500,
                {
                    "error": {
                        "message": "admin.html is missing on the server",
                        "hint": "Upload admin.html next to app.py, then redeploy.",
                    }
                },
            )
            return

        file_path = self.resolve_file(path)
        if file_path is None:
            self.send_json(
                404,
                {
                    "error": {
                        "message": "Not found",
                        "path": path,
                        "hint": "Open / for the app or /admin.html for the admin panel.",
                    }
                },
            )
            return
        self.serve_file(file_path, cache=path.startswith("/static/"))

    def do_HEAD(self):
        self.do_GET()

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_cors_headers()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_POST(self):
        parsed = urllib.parse.urlsplit(self.path)
        if parsed.path in (
            "/api/chat",
            "/api/search",
            "/api/tts",
            "/api/image",
            "/api/transcribe",
        ):
            if is_user_banned(self.headers.get("X-Rebbet-User", "")):
                self.send_api_error(
                    403,
                    {
                        "code": "banned",
                        "message": "Your access has been blocked by an administrator."
                    }
                )
                return
        if parsed.path == "/api/chat":
            self.handle_chat()
            return
        if parsed.path == "/api/search":
            self.handle_search()
            return
        if parsed.path == "/api/tts":
            self.handle_tts()
            return
        if parsed.path == "/api/image":
            self.handle_image()
            return
        if parsed.path == "/api/transcribe":
            self.handle_transcribe()
            return
        self.send_json(
            404,
            {
                "error": {
                    "message": "Not found",
                    "path": parsed.path,
                    "hint": "API routes: /api/health, /api/models, /api/chat, /api/search, /api/tts, /api/image, /api/transcribe.",
                }
            },
        )

    def resolve_file(self, path):
        relative = path.lstrip("/")
        if relative in ("", "index.html"):
            target = ROOT / "index.html"
        elif relative in ("admin", "admin/", "admin.html"):
            target = ROOT / "admin.html"
        elif relative in ("manifest.json", "service-worker.js"):
            target = ROOT / relative
        elif relative.startswith("static/"):
            target = ROOT / relative
        else:
            return None
        try:
            resolved = target.resolve()
            resolved.relative_to(ROOT)
        except (ValueError, OSError):
            return None
        if not resolved.is_file():
            return None
        return resolved

    def content_type_for(self, path):
        suffix = path.suffix.lower()
        overrides = {
            ".html": "text/html; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".js": "text/javascript; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".webmanifest": "application/manifest+json; charset=utf-8",
            ".svg": "image/svg+xml",
            ".png": "image/png",
            ".ico": "image/x-icon",
            ".txt": "text/plain; charset=utf-8",
        }
        return overrides.get(suffix) or mimetypes.guess_type(str(path))[0] or "application/octet-stream"

    def serve_file(self, path, cache=False):
        try:
            data = path.read_bytes()
        except OSError:
            self.send_json(404, {"error": {"message": "Not found"}})
            return
        self.send_response(200)
        self.send_header("Content-Type", self.content_type_for(path))
        self.send_header("Content-Length", str(len(data)))
        if cache:
            self.send_header("Cache-Control", "public, max-age=3600")
        else:
            self.send_header("Cache-Control", "no-cache")
        if path.name == "service-worker.js":
            self.send_header("Service-Worker-Allowed", "/")
        self.send_cors_headers()
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Rebbet-User")
        self.send_header("Access-Control-Expose-Headers", "X-Voice-Model, X-Image-Source, X-Image-Model, X-Image-Prompt")
        self.send_header("Access-Control-Max-Age", "86400")

    def send_bytes(self, status, data, content_type, extra_headers=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        for name, value in (extra_headers or {}).items():
            self.send_header(name, value)
        self.send_cors_headers()
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def send_json(self, status, payload):
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_cors_headers()
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def send_api_error(self, status, info):
        self.send_json(status, {"error": info})

    def handle_search(self):
        try:
            payload = self.read_json_body()
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return
        query = payload.get("query", "")
        if not isinstance(query, str) or not query.strip():
            self.send_api_error(400, {"code": "bad_request", "message": "query is required"})
            return
        results = web_search(query.strip(), max_results=payload.get("max_results", 5))
        self.send_json(200, {"results": results, "query": query.strip()})

    def read_json_body(self, max_bytes=MAX_BODY):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise ValueError("Invalid Content-Length")
        if length <= 0:
            raise ValueError("Request body is required")
        if length > max_bytes:
            raise ValueError("Request body is too large")
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            raise ValueError("Request body must be valid JSON")
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object")
        return payload

    def handle_chat(self):
        config = self.server.config
        if not config["api_key"] and not config.get("enable_free_fallback", True):
            self.send_api_error(
                503,
                {
                    "code": "no_key",
                    "message": "No API key is configured.",
                    "hint": "Add an OpenCode or Gemini api_key to config.json, then restart the server.",
                    "url": "https://opencode.ai/console",
                },
            )
            return

        direct_gemini = is_gemini_api(config)

        try:
            payload = self.read_json_body()
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return

        raw_messages = payload.get("messages")
        if not isinstance(raw_messages, list) or not raw_messages:
            self.send_api_error(400, {"code": "bad_request", "message": "messages must be a non-empty array"})
            return
        if len(raw_messages) > MAX_MESSAGES:
            self.send_api_error(400, {"code": "bad_request", "message": f"Too many messages (max {MAX_MESSAGES})"})
            return

        messages = []
        for item in raw_messages:
            if not isinstance(item, dict):
                self.send_api_error(400, {"code": "bad_request", "message": "Each message must be an object"})
                return
            role = item.get("role")
            content = item.get("content")
            if role not in ("user", "assistant") or not isinstance(content, str):
                self.send_api_error(400, {"code": "bad_request", "message": "Messages need a user/assistant role and text content"})
                return
            content = content[:MAX_MESSAGE_CHARS]
            if not content.strip() and role == "user":
                self.send_api_error(400, {"code": "bad_request", "message": "User messages cannot be empty"})
                return
            messages.append({"role": role, "content": content})

        if messages[-1]["role"] != "user":
            self.send_api_error(400, {"code": "bad_request", "message": "The last message must be from the user"})
            return

        model = payload.get("model") or config["default_model"]
        if not isinstance(model, str) or not model.strip() or len(model) > 160:
            self.send_api_error(400, {"code": "bad_request", "message": "Invalid model id"})
            return
        model = normalize_model(model)
        family = model_family(model)
        if family == "systemone":
            self.send_api_error(400, {"code": "bad_request", "message": "That model is not a chat model"})
            return

        system = payload.get("system")
        if system is None:
            system = DEFAULT_SYSTEM_PROMPT
        if not isinstance(system, str):
            self.send_api_error(400, {"code": "bad_request", "message": "system must be text"})
            return
        system = system.strip()[:20000]
        
        # Auto web search for time-sensitive queries
        enable_search = payload.get("web_search", config.get("enable_web_search", True))
        if enable_search and messages:
            last_user_msg = messages[-1]["content"].lower()
            if any(keyword in last_user_msg for keyword in ["news", "current", "today", "latest", "weather", "price", "stock", "score", "update", "now", "2025", "2026"]):
                try:
                    search_ctx = get_web_search_context(messages[-1]["content"])
                    if search_ctx:
                        system += search_ctx
                except:
                    pass

        temperature = payload.get("temperature")
        if temperature is not None:
            if not isinstance(temperature, (int, float)) or isinstance(temperature, bool):
                self.send_api_error(400, {"code": "bad_request", "message": "temperature must be a number"})
                return
            temperature = max(0.0, min(2.0, float(temperature)))

        max_tokens = payload.get("max_tokens")
        if max_tokens is not None:
            if not isinstance(max_tokens, int) or isinstance(max_tokens, bool) or not 1 <= max_tokens <= 65536:
                self.send_api_error(400, {"code": "bad_request", "message": "max_tokens must be an integer from 1 to 65536"})
                return

        if direct_gemini:
            self.handle_gemini_chat(config, model, messages, system, temperature, max_tokens)
            return

        try:
            request = build_upstream_request(
                config,
                model,
                family,
                messages,
                system,
                temperature,
                max_tokens,
                direct_gemini=direct_gemini,
            )
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return

        try:
            upstream = urllib.request.urlopen(request, timeout=config["request_timeout"])
        except urllib.error.HTTPError as exc:
            body = ""
            try:
                body = exc.read(16384).decode("utf-8", "replace")
            except OSError:
                pass
            info = describe_upstream_error(exc.code, body)
            if config.get("auto_switch_model", True) and info.get("code") in (
                "free_limit",
                "rate_limited",
                "insufficient_funds",
                "model_disabled",
                "upstream_unavailable",
            ):
                switched = False
                for alt_model in AUTO_SWITCH_ORDER:
                    if alt_model == model or not is_chat_model(alt_model):
                        continue
                    try:
                        alt_family = model_family(alt_model)
                        alt_request = build_upstream_request(
                            config,
                            alt_model,
                            alt_family,
                            messages,
                            system,
                            temperature,
                            max_tokens,
                            direct_gemini=False,
                        )
                        upstream = urllib.request.urlopen(alt_request, timeout=config["request_timeout"])
                        model = alt_model
                        family = alt_family
                        switched = True
                        break
                    except Exception:
                        continue
                if not switched:
                    status = exc.code if 400 <= exc.code < 500 else 502
                    self.send_api_error(status, info)
                    return
            else:
                status = exc.code if 400 <= exc.code < 500 else 502
                self.send_api_error(status, info)
                return
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            self.send_api_error(
                502,
                {
                    "code": "network_error",
                    "message": "Could not reach OpenCode.",
                    "hint": "Check your internet connection and try again.",
                    "detail": str(exc)[:300],
                },
            )
            return

        with upstream:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache, no-transform")
            self.send_header("Connection", "close")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            self.close_connection = True

            try:
                self.send_event(
                    {
                        "type": "meta",
                        "model": model,
                        "family": family,
                    }
                )
                if direct_gemini:
                    raw = upstream.read()
                    try:
                        payload = json.loads(raw.decode('utf-8'))
                    except Exception:
                        raise UpstreamStreamError({"code": "upstream_error", "message": "Bad response from Gemini"})
                    usage = None
                    if isinstance(payload, dict):
                        if payload.get('usage'):
                            usage = payload.get('usage')
                        choices = payload.get('choices') or []
                        for choice in choices:
                            msg = choice.get('message') or {}
                            text = msg.get('content')
                            if isinstance(text, str) and text:
                                self.emit_delta(text)
                            elif isinstance(text, list):
                                for part in text:
                                    if isinstance(part, dict) and isinstance(part.get('text'), str):
                                        self.emit_delta(part['text'])
                    self.send_event({"type": "done", "usage": usage})
                else:
                    usage = self.stream_upstream(upstream, family)
                    self.send_event({"type": "done", "usage": usage})
            except UpstreamStreamError as exc:
                try:
                    self.send_event({"type": "error", **exc.info})
                except (BrokenPipeError, ConnectionResetError):
                    pass
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass
            except (TimeoutError, socket.timeout, OSError) as exc:
                try:
                    self.send_event(
                        {
                            "type": "error",
                            "code": "stream_interrupted",
                            "message": "The response stream was interrupted.",
                            "hint": "Try again.",
                            "detail": str(exc)[:300],
                        }
                    )
                except (BrokenPipeError, ConnectionResetError):
                    pass

    def start_event_stream(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-transform")
        self.send_header("Connection", "close")
        self.send_header("X-Accel-Buffering", "no")
        self.send_cors_headers()
        self.end_headers()
        self.close_connection = True

    def emit_text_chunks(self, text):
        chunk_size = 420
        for index in range(0, len(text), chunk_size):
            self.emit_delta(text[index:index + chunk_size])

    def handle_gemini_chat(self, config, requested_model, messages, system, temperature, max_tokens):
        candidates = gemini_chat_candidates(config, requested_model)
        if not config.get("auto_switch_model", True):
            candidates = candidates[:1]
        planned = []
        for index, candidate in enumerate(candidates):
            key = f"{candidate[0]}:{candidate[1]}"
            if index > 0 and model_cooldown_left(key):
                continue
            planned.append(candidate)
        if not planned:
            planned = candidates[:1]
        last_info = None
        winner = None
        stop = threading.Event()
        results = queue.Queue()

        def attempt(provider, candidate_model, timeout=None):
            key = f"{provider}:{candidate_model}"
            try:
                if provider == "gemini":
                    if not config.get("api_key"):
                        raise UpstreamStreamError(
                            {
                                "code": "no_key",
                                "message": "No Gemini API key is configured.",
                                "hint": "Add api_key to config.json or use the free fallback.",
                            }
                        )
                    text, usage = gemini_generate_text(
                        config, candidate_model, messages, system, temperature, max_tokens, timeout=timeout
                    )
                else:
                    text, usage = provider_chat(
                        config, provider, candidate_model, messages, system, temperature, max_tokens
                    )
                return {
                    "ok": True,
                    "provider": provider,
                    "model": candidate_model,
                    "text": text,
                    "usage": usage,
                }
            except UpstreamStreamError as exc:
                info = exc.info
                mark_model_cooldown(key, cooldown_seconds_for_error(info))
            except urllib.error.HTTPError as exc:
                detail = ""
                try:
                    detail = exc.read(16384).decode("utf-8", "replace")
                except OSError:
                    pass
                info = describe_upstream_error(exc.code, detail)
                mark_model_cooldown(key, cooldown_seconds_for_error(info))
            except (urllib.error.URLError, OSError, TimeoutError) as exc:
                info = {
                    "code": "network_error",
                    "message": "Could not reach the model provider.",
                    "hint": "Check your internet connection.",
                    "detail": str(exc)[:300],
                }
                mark_model_cooldown(key, 20)
            except ValueError as exc:
                info = {
                    "code": "bad_request",
                    "message": str(exc),
                    "hint": "Try another model.",
                }
                mark_model_cooldown(key, 60)
            return {"ok": False, "info": info, "provider": provider, "model": candidate_model}

        def worker(provider, candidate_model, delay):
            if stop.wait(delay):
                return
            results.put(attempt(provider, candidate_model, timeout=25))

        hedge = [item for item in planned if item[0] == "gemini"][:4]
        hedge += [item for item in planned if item[0] != "gemini"][:1]
        if not hedge:
            hedge = planned[:1]
        for index, (provider, candidate_model) in enumerate(hedge):
            threading.Thread(
                target=worker,
                args=(provider, candidate_model, min(index * 3, 12)),
                daemon=True,
            ).start()
        deadline = time.time() + 30
        received = 0
        while received < len(hedge) and time.time() < deadline:
            try:
                outcome = results.get(timeout=0.4)
            except queue.Empty:
                continue
            received += 1
            if outcome.get("ok"):
                winner = outcome
                break
            last_info = outcome.get("info")
        stop.set()

        if not winner:
            used = set(hedge)
            remaining = [item for item in planned if item not in used]
            if any(item[0] == "gemini" for item in hedge):
                remaining = [item for item in remaining if item[0] != "gemini"]
            for provider, candidate_model in remaining:
                key = f"{provider}:{candidate_model}"
                if model_cooldown_left(key):
                    continue
                outcome = attempt(provider, candidate_model)
                if outcome.get("ok"):
                    winner = outcome
                    break
                last_info = outcome.get("info")

        if winner:
            try:
                self.start_event_stream()
                self.send_event(
                    {
                        "type": "meta",
                        "model": winner["model"],
                        "provider": winner["provider"],
                        "requested_model": requested_model,
                        "switched": winner["model"] != requested_model,
                    }
                )
                self.emit_text_chunks(winner["text"])
                self.send_event({"type": "done", "usage": winner.get("usage")})
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass
            return

        info = last_info or {
            "code": "rate_limited",
            "message": "All available models are cooling down after hitting free limits.",
            "hint": "Wait about a minute and try again.",
        }
        if info.get("code") in ("free_limit", "rate_limited", "insufficient_funds"):
            info["message"] = info.get("message") or "All free models have reached their limit."
            info["hint"] = "Rebbet AI tried several free models. Wait a moment or add another provider key."
        status = 429 if info.get("code") in ("free_limit", "rate_limited") else 502
        self.send_api_error(status, info)

    def voice_config_error(self):
        config = self.server.config
        if not config["api_key"]:
            self.send_api_error(
                503,
                {
                    "code": "no_key",
                    "message": "No API key is configured.",
                    "hint": "Add a Gemini api_key to config.json, then restart the server.",
                },
            )
            return True
        if not is_gemini_api(config):
            self.send_api_error(
                400,
                {
                    "code": "voice_unsupported",
                    "message": "Voice features need the Gemini provider.",
                    "hint": "Set provider to gemini in config.json.",
                },
            )
            return True
        return False

    def handle_tts(self):
        if self.voice_config_error():
            return
        config = self.server.config
        try:
            payload = self.read_json_body(max_bytes=256 * 1024)
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return

        text = payload.get("text")
        if not isinstance(text, str) or not text.strip():
            self.send_api_error(400, {"code": "bad_request", "message": "text is required"})
            return
        text = text.strip()[:MAX_TTS_CHARS]

        voice = payload.get("voice")
        if not isinstance(voice, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", voice):
            voice = DEFAULT_VOICE

        speed = payload.get("speed")
        if not isinstance(speed, str):
            speed = config.get("voice_speed", "fast")
        speed = speed.lower().strip()
        if speed in ("fast", "quick"):
            speak_prompt = "Say this quickly, clearly and naturally at a fast pace: " + text
        elif speed == "slow":
            speak_prompt = "Say this slowly and clearly: " + text
        else:
            speak_prompt = text

        body = {
            "contents": [{"parts": [{"text": speak_prompt}]}],
            "generationConfig": {
                "responseModalities": ["AUDIO"],
                "speechConfig": {
                    "voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}
                },
            },
        }

        tts_model = config.get("voice_model") or TTS_MODEL
        models = [tts_model] + [model for model in GEMINI_TTS_MODEL_IDS if model != tts_model]
        audio = bytearray()
        mime = ""
        used_model = ""
        last_error = None
        for index, model in enumerate(models):
            key = f"tts:{model}"
            if index > 0 and model_cooldown_left(key):
                continue
            try:
                result = gemini_native_request(config, model, body, timeout=60)
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode("utf-8", "replace")
                last_error = {
                    "code": "tts_error",
                    "message": extract_error_message(exc.code, detail),
                    "detail": detail[:500],
                }
                if exc.code in (400, 403, 404, 429):
                    mark_model_cooldown(key, MODEL_COOLDOWN_SECONDS)
                continue
            except (urllib.error.URLError, OSError, TimeoutError) as exc:
                last_error = {
                    "code": "tts_unavailable",
                    "message": "Could not reach the voice service.",
                    "hint": "The device voice will be used instead.",
                    "detail": str(exc)[:300],
                }
                break
            audio = bytearray()
            mime = ""
            try:
                candidates = result.get("candidates") or []
                parts = (candidates[0].get("content") or {}).get("parts") or []
                for part in parts:
                    inline = part.get("inlineData") or part.get("inline_data")
                    if not isinstance(inline, dict):
                        continue
                    data = inline.get("data")
                    if not isinstance(data, str):
                        continue
                    audio.extend(base64.b64decode(data))
                    mime = inline.get("mimeType") or inline.get("mime_type") or mime
            except (IndexError, AttributeError, ValueError, TypeError):
                audio = bytearray()
            if audio:
                used_model = model
                break
            last_error = {
                "code": "tts_error",
                "message": "The voice service returned no audio.",
                "hint": "The device voice will be used instead.",
            }
            mark_model_cooldown(key, 60)

        if not audio:
            status = 429 if last_error and last_error.get("code") == "tts_error" else 502
            self.send_api_error(status, last_error or {"code": "tts_error", "message": "Voice generation failed."})
            return

        if mime.startswith(("audio/wav", "audio/x-wav")):
            self.send_bytes(200, bytes(audio), "audio/wav", {"X-Voice-Model": used_model})
        elif mime.startswith(("audio/mpeg", "audio/mp3")):
            self.send_bytes(200, bytes(audio), "audio/mpeg", {"X-Voice-Model": used_model})
        else:
            rate, channels = parse_audio_mime(mime)
            wav = pcm_to_wav(bytes(audio), rate=rate, channels=channels)
            self.send_bytes(200, wav, "audio/wav", {"X-Voice-Model": used_model})

    def handle_image(self):
        config = self.server.config
        if not config.get("api_key") and not config.get("enable_free_fallback", True):
            self.send_api_error(
                503,
                {
                    "code": "no_key",
                    "message": "No API key is configured.",
                    "hint": "Add a Gemini api_key to config.json, then restart the server.",
                },
            )
            return
        try:
            payload = self.read_json_body(max_bytes=64 * 1024)
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return
        prompt = payload.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            self.send_api_error(400, {"code": "bad_request", "message": "prompt is required"})
            return
        prompt = prompt.strip()[:MAX_IMAGE_CHARS]
        width = payload.get("width", 768)
        height = payload.get("height", 768)
        if not isinstance(width, int) or isinstance(width, bool):
            width = 768
        if not isinstance(height, int) or isinstance(height, bool):
            height = 768
        width = max(256, min(1024, width))
        height = max(256, min(1024, height))
        last_error = None
        if config.get("api_key") and is_gemini_api(config):
            image_model = config.get("image_model") or IMAGE_MODEL
            models = [image_model] + [model for model in GEMINI_IMAGE_MODEL_IDS if model != image_model]
            for index, model in enumerate(models):
                key = f"image:{model}"
                if index > 0 and model_cooldown_left(key):
                    continue
                try:
                    data, mime, text = gemini_image_bytes(config, model, prompt, timeout=90)
                except urllib.error.HTTPError as exc:
                    detail = exc.read().decode("utf-8", "replace")
                    info = describe_upstream_error(exc.code, detail)
                    last_error = {
                        "code": "image_error",
                        "message": extract_error_message(exc.code, detail),
                        "detail": detail[:500],
                    }
                    if exc.code in (400, 403, 404, 429):
                        mark_model_cooldown(key, MODEL_COOLDOWN_SECONDS)
                    continue
                except (urllib.error.URLError, OSError, TimeoutError) as exc:
                    last_error = {
                        "code": "image_unavailable",
                        "message": "Could not reach the image service.",
                        "hint": "Trying the free image provider.",
                        "detail": str(exc)[:300],
                    }
                    break
                if data:
                    self.send_bytes(
                        200,
                        data,
                        mime,
                        {
                            "X-Image-Source": "gemini",
                            "X-Image-Model": model,
                            "X-Image-Prompt": urllib.parse.quote(prompt[:180]),
                        },
                    )
                    return
                last_error = {
                    "code": "image_error",
                    "message": "The image model returned no picture.",
                    "hint": "Trying the free image provider.",
                    "detail": text[:300],
                }
                mark_model_cooldown(key, 60)
        if config.get("enable_free_fallback", True):
            try:
                data, mime = pollinations_image(prompt, width=width, height=height)
                self.send_bytes(
                    200,
                    data,
                    mime,
                    {
                        "X-Image-Source": "pollinations",
                        "X-Image-Model": "sana",
                        "X-Image-Prompt": urllib.parse.quote(prompt[:180]),
                    },
                )
                return
            except urllib.error.HTTPError as exc:
                detail = ""
                try:
                    detail = exc.read(8192).decode("utf-8", "replace")
                except OSError:
                    pass
                last_error = {
                    "code": "image_error",
                    "message": extract_error_message(exc.code, detail),
                    "hint": "The free image provider is busy. Try again shortly.",
                    "detail": detail[:400],
                }
            except (urllib.error.URLError, OSError, TimeoutError) as exc:
                last_error = {
                    "code": "image_unavailable",
                    "message": "Could not reach the free image provider.",
                    "hint": "Check your internet connection and try again.",
                    "detail": str(exc)[:300],
                }
        self.send_api_error(502, last_error or {"code": "image_error", "message": "Image generation failed."})

    def handle_transcribe(self):
        if self.voice_config_error():
            return
        config = self.server.config
        try:
            payload = self.read_json_body(max_bytes=MAX_AUDIO_BYTES * 2)
        except ValueError as exc:
            self.send_api_error(400, {"code": "bad_request", "message": str(exc)})
            return

        encoded = payload.get("audio")
        if not isinstance(encoded, str) or not encoded.strip():
            self.send_api_error(400, {"code": "bad_request", "message": "audio is required"})
            return
        try:
            audio = base64.b64decode(encoded)
        except (ValueError, TypeError):
            self.send_api_error(400, {"code": "bad_request", "message": "audio must be base64 encoded"})
            return
        if not audio:
            self.send_api_error(400, {"code": "bad_request", "message": "audio is empty"})
            return
        if len(audio) > MAX_AUDIO_BYTES:
            self.send_api_error(413, {"code": "too_large", "message": "Audio clip is too large."})
            return

        mime = payload.get("mimeType")
        if not isinstance(mime, str) or not mime.startswith("audio/"):
            mime = "audio/wav"
        prompt = payload.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            prompt = "Transcribe this audio exactly. Return only the transcript without commentary."

        body = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt},
                        {
                            "inlineData": {
                                "mimeType": mime,
                                "data": base64.b64encode(audio).decode("ascii"),
                            }
                        },
                    ]
                }
            ]
        }

        text = ""
        used_model = ""
        last_error = None
        models = [config.get("transcribe_model") or TRANSCRIBE_MODEL]
        models += [model for model in TRANSCRIBE_MODEL_IDS if model not in models]
        for index, model in enumerate(models):
            key = f"transcribe:{model}"
            if index > 0 and model_cooldown_left(key):
                continue
            try:
                result = gemini_native_request(config, model, body, timeout=75)
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode("utf-8", "replace")
                last_error = {
                    "code": "transcribe_error",
                    "message": extract_error_message(exc.code, detail),
                    "detail": detail[:500],
                }
                if exc.code in (400, 403, 404, 429):
                    mark_model_cooldown(key, MODEL_COOLDOWN_SECONDS)
                continue
            except (urllib.error.URLError, OSError, TimeoutError) as exc:
                last_error = {
                    "code": "transcribe_unavailable",
                    "message": "Could not reach the transcription service.",
                    "hint": "Check your internet connection and try again.",
                    "detail": str(exc)[:300],
                }
                break
            parts = []
            try:
                candidates = result.get("candidates") or []
                parts = (candidates[0].get("content") or {}).get("parts") or []
            except (IndexError, AttributeError, TypeError):
                parts = []
            pieces = []
            for part in parts:
                if not isinstance(part, dict):
                    continue
                transcription = (
                    part.get("audioTranscription")
                    or part.get("audio_transcription")
                    or part.get("transcription")
                )
                if isinstance(transcription, dict) and isinstance(transcription.get("text"), str):
                    pieces.append(transcription["text"])
                elif isinstance(part.get("text"), str):
                    pieces.append(part["text"])
            text = " ".join(piece.strip() for piece in pieces if piece.strip()).strip()
            if text:
                used_model = model
                break
            last_error = {
                "code": "no_speech",
                "message": "No speech was detected in that recording.",
                "hint": "Try recording again in a quieter place.",
            }
            mark_model_cooldown(key, 45)

        if not text:
            status = 429 if last_error and "429" in str(last_error.get("detail", "")) else 422
            self.send_api_error(status, last_error or {"code": "transcribe_error", "message": "Transcription failed."})
            return
        self.send_json(200, {"text": text, "model": used_model})

    def send_event(self, event):
        data = json.dumps(event, ensure_ascii=False).encode("utf-8")
        self.wfile.write(b"data: " + data + b"\n\n")
        self.wfile.flush()

    def stream_upstream(self, upstream, family):
        if family == "anthropic":
            return self.stream_anthropic(upstream)
        if family == "google":
            return self.stream_google(upstream)
        if family == "responses":
            return self.stream_responses(upstream)
        return self.stream_openai(upstream)

    def emit_delta(self, text):
        if text:
            self.send_event({"type": "delta", "text": text})

    def emit_thinking(self):
        self.send_event({"type": "thinking"})

    def stream_openai(self, upstream):
        usage = None
        for raw_line in upstream:
            line = raw_line.decode("utf-8", "replace").strip()
            if not line or line.startswith(":") or not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                payload = json.loads(data)
            except ValueError:
                continue
            if not isinstance(payload, dict):
                continue
            if "error" in payload:
                raise UpstreamStreamError(describe_upstream_error(502, json.dumps(payload)))
            if payload.get("usage"):
                usage = payload["usage"]
            for choice in payload.get("choices") or []:
                delta = choice.get("delta") or {}
                text = delta.get("content")
                if isinstance(text, str) and text:
                    self.emit_delta(text)
                reasoning = delta.get("reasoning_content") or delta.get("reasoning")
                if reasoning:
                    self.emit_thinking()
        return usage

    def stream_responses(self, upstream):
        usage = None
        emitted = False
        for raw_line in upstream:
            line = raw_line.decode("utf-8", "replace").strip()
            if not line or line.startswith(":") or not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                payload = json.loads(data)
            except ValueError:
                continue
            if not isinstance(payload, dict):
                continue
            event_type = payload.get("type")
            if event_type == "response.output_text.delta":
                delta = payload.get("delta")
                if isinstance(delta, str) and delta:
                    emitted = True
                    self.emit_delta(delta)
            elif event_type in ("response.output_text.done", "response.refusal.delta"):
                delta = payload.get("text") or payload.get("delta")
                if not emitted and isinstance(delta, str) and delta:
                    emitted = True
                    self.emit_delta(delta)
            elif event_type in ("response.reasoning_summary_text.delta", "response.reasoning_text.delta"):
                self.emit_thinking()
            elif event_type == "response.completed":
                response = payload.get("response") or {}
                usage = response.get("usage") or usage
                if not emitted:
                    emitted = self.emit_response_output(response)
            elif event_type in ("response.failed", "response.incomplete"):
                response = payload.get("response") or {}
                error = response.get("error") or {}
                message = error.get("message") or "The model did not complete the response."
                raise UpstreamStreamError(
                    {
                        "code": "upstream_error",
                        "message": message,
                        "hint": "Try again or choose a different model.",
                    }
                )
            elif event_type == "error" or "error" in payload:
                raise UpstreamStreamError(describe_upstream_error(502, json.dumps(payload)))
        return usage

    def emit_response_output(self, response):
        emitted = False
        for item in response.get("output") or []:
            if not isinstance(item, dict) or item.get("type") != "message":
                continue
            for content in item.get("content") or []:
                if isinstance(content, dict) and content.get("type") in ("output_text", "text"):
                    text = content.get("text")
                    if isinstance(text, str) and text:
                        self.emit_delta(text)
                        emitted = True
        return emitted

    def stream_anthropic(self, upstream):
        usage = {}
        for raw_line in upstream:
            line = raw_line.decode("utf-8", "replace").strip()
            if not line or line.startswith(":") or not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                payload = json.loads(data)
            except ValueError:
                continue
            if not isinstance(payload, dict):
                continue
            event_type = payload.get("type")
            if event_type == "content_block_delta":
                delta = payload.get("delta") or {}
                if delta.get("type") == "text_delta":
                    self.emit_delta(delta.get("text"))
                elif delta.get("type") == "thinking_delta":
                    self.emit_thinking()
                elif isinstance(delta.get("text"), str):
                    self.emit_delta(delta["text"])
            elif event_type == "content_block_start":
                block = payload.get("content_block") or {}
                if isinstance(block.get("text"), str) and block["text"]:
                    self.emit_delta(block["text"])
            elif event_type == "message_start":
                block_usage = (payload.get("message") or {}).get("usage") or {}
                usage.update(block_usage)
            elif event_type == "message_delta":
                usage.update(payload.get("usage") or {})
            elif event_type == "message_stop":
                break
            elif event_type == "error":
                error = payload.get("error") or {}
                message = error.get("message") or "The model returned an error."
                raise UpstreamStreamError(
                    {
                        "code": "upstream_error",
                        "message": message,
                        "hint": "Try again or choose a different model.",
                    }
                )
        return usage or None

    def stream_google(self, upstream):
        usage = None
        for raw_line in upstream:
            line = raw_line.decode("utf-8", "replace").strip()
            if not line or line.startswith(":") or not line.startswith("data:"):
                continue
            data = line[5:].strip()
            if data == "[DONE]":
                break
            try:
                payload = json.loads(data)
            except ValueError:
                continue
            if not isinstance(payload, dict):
                continue
            if "error" in payload and not payload.get("candidates"):
                raise UpstreamStreamError(describe_upstream_error(502, json.dumps(payload)))
            metadata = payload.get("usageMetadata")
            if metadata:
                usage = {
                    "prompt_tokens": metadata.get("promptTokenCount"),
                    "completion_tokens": metadata.get("candidatesTokenCount"),
                    "total_tokens": metadata.get("totalTokenCount"),
                    "cost": metadata.get("cost"),
                }
            for candidate in payload.get("candidates") or []:
                content = candidate.get("content") or {}
                for part in content.get("parts") or []:
                    text = part.get("text")
                    if isinstance(text, str) and text:
                        if part.get("thought"):
                            self.emit_thinking()
                        else:
                            self.emit_delta(text)
        return usage


class RebbetServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 32


def start_server(config):
    host = config["host"]
    port = config["port"]
    last_error = None
    for candidate in range(port, port + 11):
        try:
            server = RebbetServer((host, candidate), AppHandler)
            server.config = config
            config["port"] = candidate
            return server
        except OSError as exc:
            last_error = exc
            if exc.errno in (48, 98, 10048):
                continue
            raise
    raise last_error or OSError("Could not bind a port")


def main():
    config = load_config()
    required = (
        "index.html",
        "admin.html",
        "static/app.js",
        "static/app-status.js",
        "static/style.css",
        "static/admin.js",
        "static/admin.css",
        "static/firebase.js",
    )
    missing = [name for name in required if not (ROOT / name).is_file()]
    if missing:
        print(
            "Warning: missing web files: " + ", ".join(missing) + ". Upload them next to app.py.",
            file=sys.stderr,
        )
    if not (ROOT / "index.html").is_file():
        print(
            "index.html is missing; serving the embedded Rebbet AI page instead.",
            file=sys.stderr,
        )
    try:
        server = start_server(config)
    except OSError as exc:
        print(f"Could not start {APP_NAME}: {exc}", file=sys.stderr)
        return 1

    display_host = "127.0.0.1" if config["host"] in ("0.0.0.0", "::") else config["host"]
    print(f"{APP_NAME} {VERSION}")
    print(f"Open: http://{display_host}:{config['port']}")
    print(f"Model: {config['default_model']}")
    if not config["api_key"]:
        print("Warning: no API key configured. Add api_key to config.json or set OPENCODE_API_KEY.", file=sys.stderr)
    print("Press Ctrl+C to stop.")

    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("\nStopping.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
